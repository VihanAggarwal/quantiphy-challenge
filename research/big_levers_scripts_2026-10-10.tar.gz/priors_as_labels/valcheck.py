"""Verifier: apply the sibling-prior transfer rule (and looser/stricter variants) to validation questions; compare with GT (measurement only)."""
import sys, re
sys.path.insert(0, '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/big/priors')
sys.path.insert(0, '/home/user/quantiphy-challenge')
from linkgrp import *
from qp.geometry import _tokens
from qp.data import load_split
import pandas as pd, numpy as np

def rule(qs, t_all, vis_size=0.9, vis_motion=None, untimed=True, accguard=True, sources=('simulation','segmentation')):
    tv, Pv = build(vis_thr=vis_size, use_vis=True)
    if vis_motion is None: tn, Pn = build(vis_thr=0.9, use_vis=False)
    else: tn, Pn = build(vis_thr=vis_motion, use_vis=True)
    gv = tv.drop_duplicates('video_id').set_index('video_id').grp
    gn = tn.drop_duplicates('video_id').set_index('video_id').grp
    acc_obj = {}
    for v, g in pd.concat([t_all, qs]).groupby('video_id'):
        s = set()
        for line in g.prior.iloc[0].split('\n'):
            m = re.search(r'acceleration\s+of\s+(?:the\s+)?(.+?)(?:\s+(?:at|from|before|after)\s+[\d.]+.*)?\s*=', line, re.I)
            if m: s.add(' '.join(_tokens(m.group(1))))
        for q in g.question:
            m = re.search(r'acceleration\s+of\s+(?:the\s+)?(.+?)(?:\s+(?:at|from|over|between)\s+.*)?\s+in\s+', q, re.I)
            if m: s.add(' '.join(_tokens(m.group(1))))
        acc_obj[v] = s
    rows = []
    for r in qs.to_dict('records'):
        if r['video_source'] not in sources: continue
        mm = Q_RE.search(r['question'])
        if not mm: continue
        q, obj, tm, u = mm.groups(); q = q.lower().replace('velocity', 'speed'); obj = ' '.join(_tokens(obj))
        motion = q in ('speed', 'acceleration')
        if accguard and motion and q == 'speed' and obj in acc_obj.get(r['video_id'], set()): continue
        P, grp = (Pn, gn) if motion else (Pv, gv)
        if r['video_id'] not in grp.index: continue
        c = P[(P.grp == grp[r['video_id']]) & (P.pq == q) & (P.pobj == obj)]
        own = [l.strip() for l in str(r['prior']).split('\n')]
        c = c[~((c.pvid == r['video_id']) & (c.pline.str.strip().isin(own)))]
        if motion and untimed:
            c = c[~c.pline.str.contains(r'\bat\s+[\d.]+\s*s|from\s+[\d.]+|before|after|^\s*t\s*=', case=False, regex=True)]
        if len(c) == 0 or c.pval.nunique() != 1: continue
        rows.append(dict(qid=r['qid'], video_id=r['video_id'], question=r['question'], value=abs(c.pval.iloc[0]) / UNIT[u.lower()],
                         src=c.pline.iloc[0] + ' @' + ','.join(sorted(set(c.pvid)))))
    return pd.DataFrame(rows)

if __name__ == '__main__':
    t_all = pd.read_pickle(SP + 'test.pkl')
    v = load_split('val')
    gt = v.set_index('qid').answer
    for name, kw in [('as_built', {}), ('no_accguard', dict(accguard=False)), ('timed_ok', dict(untimed=False)),
                     ('vis_for_motion', dict(vis_motion=0.9)), ('vis0.8', dict(vis_size=0.8, vis_motion=None)),
                     ('incl_internet', dict(sources=('simulation','segmentation','internet'))),
                     ('loosest', dict(accguard=False, untimed=False, vis_motion=0.8, vis_size=0.8, sources=('simulation','segmentation','internet')))]:
        R = rule(v, t_all, **kw)
        if len(R) == 0: print(name, 'fires 0'); continue
        R['gtv'] = R.qid.map(gt).astype(float); R['rel'] = (R['value'] / R['gtv'] - 1).abs()
        print('=====', name, 'fires', len(R), 'exact(<1%)', int((R.rel < 0.01).sum()))
        for r in R.itertuples(): print('  ', r.qid, r.video_id, r.question[:70], 'val=%.4g gt=%.4g' % (r.value, r.gtv), r.src[:80])
