"""Verifier rebuild: re-derive the sibling-prior transfer from test inputs (independent re-run of the rule), check the investigator CSVs
reproduce exactly, and write the verified category-only variants on top of trackA_v3_best_per_category.csv.
S3 'noconflict' drops transferred SPEEDS that disagree with the clip's own measured speed by more than 2x (footage contradicts the
sibling statement; GT convention in such conflicts is untested on validation)."""
import sys, shutil, json
sys.path.insert(0, '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/big/priors_as_labels')
from valcheck import *
OUT = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/big/priors_as_labels/'
INV = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/big/priors/'
base = pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_v3_best_per_category.csv')
t_all = pd.read_pickle(SP + 'test.pkl')
cat = t_all.set_index('qid').category
R = rule(t_all, t_all)
R['category'] = R.qid.map(cat)
cur = base.set_index('id').parsed_value
R['v3'] = R.qid.map(cur); R['ratio'] = R.value / R.v3
R['is_speed'] = R.question.str.contains(r'\b(speed|velocity)\b', case=False) & ~R.question.str.contains('acceleration', case=False)
def write(rows, name, c):
    new = base[['id', 'parsed_value']].copy()
    m = new.id.isin(rows.qid)
    new.loc[m, 'parsed_value'] = new.loc[m, 'id'].map(rows.set_index('qid').value)
    chg = ~np.isclose(new.parsed_value.values, base.parsed_value.values, rtol=1e-12, atol=0)
    assert (new.id.values == base.id.values).all() and len(new) == 3289
    assert np.isfinite(new.parsed_value).all() and (new.parsed_value > 0).all()
    assert (cat.loc[new.id[chg]] == c).all()
    new.to_csv(OUT + name, index=False)
    rr = new.parsed_value[chg] / base.parsed_value[chg]
    return int(chg.sum()), float(rr.median())
summary = {}
for c, f in [('S2', 'S2_sibling_prior_transfer.csv'), ('D2', 'D2_sibling_prior_transfer.csv'), ('S3', 'S3_sibling_prior_transfer.csv'), ('D3', 'D3_sibling_prior_transfer_ext.csv')]:
    x = R[R.category == c]
    n, med = write(x, f, c)
    inv = pd.read_csv(INV + f)
    mine = pd.read_csv(OUT + f)
    same = np.allclose(inv.parsed_value.values, mine.parsed_value.values, rtol=1e-12, atol=0) and (inv.id.values == mine.id.values).all()
    summary[c] = dict(changed=n, median_ratio=round(med, 4), reproduces_investigator_csv=bool(same))
x = R[(R.category == 'S3') & ~(R.is_speed & ((R.ratio > 2) | (R.ratio < 0.5)))]
summary['S3_noconflict'] = dict(zip(['changed', 'median_ratio'], write(x, 'S3_sibling_prior_transfer_noconflict.csv', 'S3')))
summary['S3_dropped'] = R[(R.category == 'S3') & R.is_speed & ((R.ratio > 2) | (R.ratio < 0.5))][['qid', 'video_id', 'question', 'v3', 'value']].to_dict('records')
R.to_pickle(OUT + 'transfer_rebuilt.pkl')
print(json.dumps(summary, indent=1, default=str))
