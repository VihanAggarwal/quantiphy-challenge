import cv2, numpy as np, pandas as pd, pickle
SP='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/big/priors/'
t=pd.read_pickle(SP+'test.pkl')
vids=t[t.video_source.isin(['simulation','segmentation','internet'])].drop_duplicates('video_id')
out={}
for r in vids.itertuples():
    cap=cv2.VideoCapture(r.video_path); n=int(cap.get(7))
    ims=[]
    for fi in [0, n//2]:
        cap.set(1,fi); ok,f=cap.read()
        if ok: ims.append(cv2.resize(f,(96,54),interpolation=cv2.INTER_AREA))
    out[r.video_id]=ims
pickle.dump(out,open(SP+'thumbs.pkl','wb')); print(len(out))
