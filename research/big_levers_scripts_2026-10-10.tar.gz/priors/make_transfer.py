"""Sibling-prior transfer for S2 / D2 / S3: a target equal to a quantity STATED as a prior of the same scene.
Scene links (test inputs only): segmented twins; identical depth_info numbers (>=3 decimals); identical prior lines
with a >=3-significant-digit value; near-identical views (thumbnail correlation >= VIS). Motion quantities transfer
only through non-visual links and only when the target clip neither states nor asks an acceleration of that object.
Internet clips excluded (dimension naming differs between their annotations)."""
import sys, re
sys.path.insert(0, '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/big/priors')
sys.path.insert(0, '/home/user/quantiphy-challenge')
from linkgrp import *
from qp.geometry import _tokens
OUT = SP
VIS = 0.9
base_csv = '/home/user/quantiphy-challenge/submissions/trackA_v3_best_per_category.csv'

def run():
    t_all = pd.read_pickle(SP + 'test.pkl')
    tv, Pv = build(vis_thr=VIS, use_vis=True)
    tn, Pn = build(vis_thr=VIS, use_vis=False)
    gv = tv.drop_duplicates('video_id').set_index('video_id').grp
    gn = tn.drop_duplicates('video_id').set_index('video_id').grp
    # per clip: objects with an acceleration stated or asked
    acc_obj = {}
    for v, g in t_all.groupby('video_id'):
        s = set()
        for line in g.prior.iloc[0].split('\n'):
            m = re.search(r'acceleration\s+of\s+(?:the\s+)?(.+?)(?:\s+(?:at|from|before|after)\s+[\d.]+.*)?\s*=', line, re.I)
            if m: s.add(' '.join(_tokens(m.group(1))))
        for q in g.question:
            m = re.search(r'acceleration\s+of\s+(?:the\s+)?(.+?)(?:\s+(?:at|from|over|between)\s+.*)?\s+in\s+', q, re.I)
            if m: s.add(' '.join(_tokens(m.group(1))))
        acc_obj[v] = s
    rows = []
    for r in t_all.to_dict('records'):
        if r['video_source'] not in ('simulation', 'segmentation'):
            continue
        mm = Q_RE.search(r['question'])
        if not mm:
            continue
        q, obj, tm, u = mm.groups(); q = q.lower().replace('velocity', 'speed'); obj = ' '.join(_tokens(obj))
        motion = q in ('speed', 'acceleration')
        if motion and q == 'speed' and obj in acc_obj[r['video_id']]:
            continue
        P, grp = (Pn, gn) if motion else (Pv, gv)
        c = P[(P.grp == grp[r['video_id']]) & (P.pq == q) & (P.pobj == obj)]
        own = [l.strip() for l in str(r['prior']).split('\n')]
        c = c[~((c.pvid == r['video_id']) & (c.pline.str.strip().isin(own)))]
        if motion:  # a stated motion value must be untimed (constant) to stand for a value at any time
            c = c[~c.pline.str.contains(r'\bat\s+[\d.]+\s*s|from\s+[\d.]+|before|after|^\s*t\s*=', case=False, regex=True)]
        if len(c) == 0 or c.pval.nunique() != 1:
            continue
        rows.append(dict(qid=r['qid'], video_id=r['video_id'], category=r['category'], question=r['question'],
                         value=abs(c.pval.iloc[0]) / UNIT[u.lower()], src=c.pline.iloc[0] + ' @' + ','.join(sorted(set(c.pvid)))))
    return pd.DataFrame(rows)

if __name__ == '__main__':
    R = run()
    b = pd.read_csv(base_csv)
    cur = b.set_index('id').parsed_value
    R['v3'] = R.qid.map(cur); R['ratio'] = R.value / R.v3
    pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 70)
    print(R[['qid', 'video_id', 'category', 'question', 'v3', 'value', 'ratio', 'src']].round(3).to_string())
    R.to_pickle(OUT + 'transfer_final.pkl')
    for cat in ('S2', 'D2', 'S3'):
        x = R[R.category == cat]
        new = b[['id', 'parsed_value']].copy()
        m = new.id.isin(x.qid)
        new.loc[m, 'parsed_value'] = new.loc[m, 'id'].map(x.set_index('qid').value)
        chg = (abs(new.parsed_value - b.parsed_value) > 1e-9 * abs(b.parsed_value))
        cats = b.set_index('id').loc[new.id[chg]].index
        test = pd.read_pickle(SP + 'test.pkl').set_index('qid')
        assert (test.loc[new.id[chg], 'category'] == cat).all()
        new.to_csv(OUT + f'{cat}_sibling_prior_transfer.csv', index=False)
        rr = (new.parsed_value[chg] / b.parsed_value[chg])
        print(cat, 'changed', int(chg.sum()), 'median ratio', round(float(rr.median()), 3) if len(rr) else None)
