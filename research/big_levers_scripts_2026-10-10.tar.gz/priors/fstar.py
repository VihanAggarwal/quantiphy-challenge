"""For each lab speed prior: f* that makes the measured speed at t equal the stated value (pipeline measure as fn of f)."""
import sys, pickle, math
from pathlib import Path
REPO = Path('/home/user/quantiphy-challenge'); sys.path.insert(0, str(REPO))
import numpy as np, pandas as pd
from qp import geometry as G
SP = Path('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/big/priors')
d = pickle.load(open(sys.argv[1], 'rb')); anns, meta = d['anns'], d['meta']
df = pd.read_pickle(SP / 'test.pkl').set_index('qid')
FF = {'f': None}
G._map_f = lambda fn, value, width, f_cam: FF['f']
rows = []; seen = set()
kinds = sys.argv[2].split(',') if len(sys.argv) > 2 else ['speed']
for q, a in anns.items():
    r = df.loc[q]
    if r.video_source != 'lab' or a.spec.prior.kind not in kinds: continue
    m = meta[r.video_id]; W, H = m['image_size']
    vals = {}
    for f in [400, 500, 600, 722, 850, 1000]:
        FF['f'] = f * W / 1280
        ans = G.solve(a.spec, a.tracks, (W, H), float(m['fps']), camera_fov_deg=84.0)
        vals[f] = ans.debug.get('prior_measured_si')
    if vals[722] is None: continue
    key = (r.video_id, round(vals[722], 6))
    if key in seen: continue
    seen.add(key)
    fs = np.array(sorted(vals)); vs = np.array([vals[f] for f in fs], float)
    st = a.spec.prior.value_si
    # interpolate log v vs log f to find f*
    lv, lf = np.log(vs), np.log(fs)
    fstar = np.nan
    if np.all(np.diff(lv) < 0) and lv.min() <= math.log(st) <= lv.max():
        fstar = float(np.exp(np.interp(math.log(st), lv[::-1], lf[::-1])))
    sens = abs(math.log(vals[850] / vals[600]) / math.log(850 / 600))
    rows.append(dict(video=r.video_id, prior=r.prior[:45], stated=st, meas722=vals[722], ratio=st / vals[722], sens=sens,
                     v400=vals[400], v1000=vals[1000], fstar=fstar))
R = pd.DataFrame(rows)
pd.set_option('display.width', 220)
print(R.round(3).to_string())
