"""Build annotations (raw and post-step: refine + dense motion) for a subset of test videos; pickle them.
Usage: python build_anns.py <out.pkl> <video_source filter or 'all'> [post]"""
import sys, pickle, json, math
from pathlib import Path
REPO = Path('/home/user/quantiphy-challenge')
sys.path.insert(0, str(REPO)); sys.path.insert(0, str(REPO / 'scripts'))
import pandas as pd
SP = Path('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/big/priors')
import run_claude as rc
from qp import claude_annotate as ca

out, src = sys.argv[1], sys.argv[2]
post = len(sys.argv) > 3 and sys.argv[3] == 'post'
df = pd.read_pickle(SP / 'test.pkl')
if src != 'all':
    df = df[df.video_source.isin(src.split(','))]
recs = rc.load_records(REPO / 'runs/test_v1_high_854/test/records')
recs = {k: v for k, v in recs.items() if k in set(df.video_id)}
recs = rc.prepare_records(df, recs)
anns = ca.load_annotations(recs)
anns = {q: a for q, a in anns.items() if q in set(df.qid)}
if post:
    log = []
    rc.post_steps(anns, df, recs, refine_priors=True, dense='motion',
                  dense_cache=SP / 'runs/_dense_cache/test', dense_workers=1, dense_log=log)
    print('dense log', len(log))
meta = {v: r['meta'] for v, r in recs.items()}
pickle.dump({'anns': anns, 'meta': meta}, open(out, 'wb'))
print('saved', len(anns))
