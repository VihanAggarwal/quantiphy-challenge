"""Measure every lab prior (and target) through the fixed rig camera f = F1280 * W/1280 px with depth_info.
Usage: python measure.py <anns.pkl> <out.pkl> [F1280]"""
import sys, pickle, math
from pathlib import Path
REPO = Path('/home/user/quantiphy-challenge')
sys.path.insert(0, str(REPO))
import numpy as np, pandas as pd
from qp import geometry as G

SP = Path('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/big/priors')
inp, out = sys.argv[1], sys.argv[2]
F1280 = float(sys.argv[3]) if len(sys.argv) > 3 else 722.0
d = pickle.load(open(inp, 'rb'))
anns, meta = d['anns'], d['meta']
df = pd.read_pickle(SP / 'test.pkl').set_index('qid')

FFIX = {'f': None}
G._map_f = lambda fn, value, width, f_cam: FFIX['f']

rows = []
for q, a in anns.items():
    r = df.loc[q]
    m = meta[r.video_id]
    W, H = m['image_size']
    FFIX['f'] = F1280 * W / 1280.0
    ans = G.solve(a.spec, a.tracks, (W, H), float(m['fps']), camera_fov_deg=84.0,
                  seen_scale=float(m.get('scale') or 1.0))
    dbg = ans.debug
    sp = a.spec
    rows.append(dict(qid=q, video_id=r.video_id, category=r.category, prior=r.prior, question=r.question,
                     pkind=sp.prior.kind, pobj=';'.join(map(str, sp.prior.objects or [])), ptime=sp.prior.time,
                     pwin=sp.prior.window, paxis=sp.prior.axis, pval=sp.prior.value_si,
                     tkind=sp.target.kind, tobj=';'.join(map(str, sp.target.objects or [])), ttime=sp.target.time,
                     twin=sp.target.window, taxis=sp.target.axis,
                     prior_meas=dbg.get('prior_measured_si'), target_meas=dbg.get('target_measured_si'),
                     f_px=dbg.get('f_px'), sens=dbg.get('f_sensitivity'), value=ans.value,
                     depth_prior=str(dbg.get('depth_prior')), depth_target=str(dbg.get('depth_target')),
                     range_prior=dbg.get('range_prior_m'), range_target=dbg.get('range_target_m'),
                     flags=';'.join(ans.flags), method=ans.method, direct=a.direct_answer))
res = pd.DataFrame(rows)
res['ratio'] = res.pval / res.prior_meas   # stated / measured
res.to_pickle(out)
print(len(res), 'rows;', res.prior_meas.notna().sum(), 'with prior measured')
