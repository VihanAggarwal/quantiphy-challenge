"""Lab: prior and target measured at a grid of fixed f (px @1280). Usage: fsweep_all.py <anns.pkl> <out.pkl>"""
import sys, pickle, math
from pathlib import Path
REPO = Path('/home/user/quantiphy-challenge'); sys.path.insert(0, str(REPO))
import numpy as np, pandas as pd
from qp import geometry as G
SP = Path('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/big/priors')
d = pickle.load(open(sys.argv[1], 'rb')); anns, meta = d['anns'], d['meta']
df = pd.read_pickle(SP / 'test.pkl').set_index('qid')
FF = {'f': None}
G._map_f = lambda fn, value, width, f_cam: FF['f']
FS = [350, 400, 450, 500, 550, 600, 650, 722, 800, 900, 1000, 1150]
rows = []
for q, a in anns.items():
    r = df.loc[q]
    if r.video_source != 'lab': continue
    m = meta[r.video_id]; W, H = m['image_size']
    row = dict(qid=q, video_id=r.video_id, category=r.category, pkind=a.spec.prior.kind, tkind=a.spec.target.kind,
               pval=a.spec.prior.value_si, unit=a.spec.target.unit)
    for f in FS:
        FF['f'] = f * W / 1280
        ans = G.solve(a.spec, a.tracks, (W, H), float(m['fps']), camera_fov_deg=84.0)
        row[f'p{f}'] = ans.debug.get('prior_measured_si'); row[f't{f}'] = ans.value
        if f == 722:
            row['flags'] = ';'.join(ans.flags)
    rows.append(row)
R = pd.DataFrame(rows); R.to_pickle(sys.argv[2]); print(len(R))
