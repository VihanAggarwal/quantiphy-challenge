"""Solve every test question with the plain geometry (no camera prior) and keep the debug fields.
Usage: python measure_all.py <anns.pkl> <out.pkl>"""
import sys, pickle, math
from pathlib import Path
REPO = Path('/home/user/quantiphy-challenge')
sys.path.insert(0, str(REPO))
import numpy as np, pandas as pd
from qp import geometry as G

SP = Path('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/big/priors')
inp, out = sys.argv[1], sys.argv[2]
d = pickle.load(open(inp, 'rb'))
anns, meta = d['anns'], d['meta']
df = pd.read_pickle(SP / 'test.pkl').set_index('qid')
rows = []
for q, a in anns.items():
    r = df.loc[q]
    m = meta[r.video_id]
    W, H = m['image_size']
    ans = G.solve(a.spec, a.tracks, (W, H), float(m['fps']), seen_scale=float(m.get('scale') or 1.0))
    dbg = ans.debug
    sp = a.spec
    rows.append(dict(qid=q, video_id=r.video_id, source=r.video_source, category=r.category, prior=r.prior,
                     question=r.question, W=W, H=H,
                     pkind=sp.prior.kind, pobj=';'.join(map(str, sp.prior.objects or [])), ptime=sp.prior.time,
                     pwin=sp.prior.window, paxis=sp.prior.axis, pval=sp.prior.value_si, pdim=sp.prior.dimension,
                     tkind=sp.target.kind, tobj=';'.join(map(str, sp.target.objects or [])), ttime=sp.target.time,
                     twin=sp.target.window, taxis=sp.target.axis, tdim=sp.target.dimension,
                     prior_px=dbg.get('prior_px'), target_px=dbg.get('target_px'), scale=dbg.get('scale_m_per_px'),
                     f_px=dbg.get('f_px'), fov=dbg.get('fov_deg'), sens=dbg.get('f_sensitivity'),
                     prior_meas=dbg.get('prior_measured_si'), target_meas=dbg.get('target_measured_si'),
                     range_prior=dbg.get('range_prior_m'), range_target=dbg.get('range_target_m'),
                     value=ans.value, flags=';'.join(ans.flags), method=ans.method, direct=a.direct_answer))
res = pd.DataFrame(rows)
res.to_pickle(out)
print(len(res))
