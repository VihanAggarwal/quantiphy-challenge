import pandas as pd, numpy as np, math
pd.set_option('display.width',250); pd.set_option('display.max_rows',400); pd.set_option('display.max_colwidth',60)
FS=[350,400,450,500,550,600,650,722,800,900,1000,1150]
R=pd.read_pickle('fsweep_post.pkl')
def fstar(row, pre, target):
    v=np.array([row[f'{pre}{f}'] for f in FS],float)
    if not np.isfinite(v).all() or target is None or not np.isfinite(target) or target<=0: return np.nan
    lv=np.log(v); lf=np.log(FS); lt=math.log(target)
    # find crossing
    for i in range(len(FS)-1):
        a,b=lv[i]-lt,lv[i+1]-lt
        if a==0: return FS[i]
        if a*b<0: return float(np.exp(lf[i]+(lf[i+1]-lf[i])*a/(a-b)))
    return np.nan
def sens(row,pre):
    try: return abs(math.log(row[f'{pre}800']/row[f'{pre}650'])/math.log(800/650))
    except: return np.nan
R['psens']=R.apply(lambda r: sens(r,'p'),axis=1); R['tsens']=R.apply(lambda r: sens(r,'t'),axis=1)
R['pfstar']=R.apply(lambda r: fstar(r,'p',r.pval),axis=1)
R.to_pickle('fsweep_post_an.pkl')
# priors: one per video
P=R.dropna(subset=['p722']).groupby('video_id').agg(pk=('pkind','first'),pval=('pval','first'),p722=('p722','median'),psens=('psens','median'),pf=('pfstar','median'))
P['ratio']=P.pval/P.p722
print(P.round(3).to_string())
for k,g in P.groupby('pk'):
    lat=g[g.psens>0.5]
    print(k,'all n',len(g),'median ratio',round(g.ratio.median(),3),'| lateral(sens>.5) n',len(lat),'median ratio',round(lat.ratio.median(),3),'gm',round(np.exp(np.log(lat.ratio).mean()),3),'median f*',round(lat.pf.median(),1))
