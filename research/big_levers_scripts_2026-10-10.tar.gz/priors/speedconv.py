"""Lab speed-prior conventions: 3D prior track at f=722 (depth_info + looming as in qp.geometry), speed at the
prior time by several definitions, compared with the stated value.
Usage: python speedconv.py <anns.pkl>"""
import sys, pickle, math
from pathlib import Path
REPO = Path('/home/user/quantiphy-challenge')
sys.path.insert(0, str(REPO))
import numpy as np, pandas as pd
from qp import geometry as G

SP = Path('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/big/priors')
d = pickle.load(open(sys.argv[1], 'rb'))
anns, meta = d['anns'], d['meta']
df = pd.read_pickle(SP / 'test.pkl').set_index('qid')
FFIX = {'f': None}
G._map_f = lambda fn, value, width, f_cam: FFIX['f']
CAP = {}
_orig = G._measure


def cap(q, a, b, va, vb, flags, tol, label, *args, **kw):
    if label == 'prior' and va.f is not None and abs(va.f - FFIX['f']) < 1e-6 and a is not None:
        t, uv = a.points()
        CAP['t'], CAP['P'], CAP['uv'] = t, va.pos(t, uv), uv
    return _orig(q, a, b, va, vb, flags, tol, label, *args, **kw)


G._measure = cap
rows = []
done = set()
for q, a in anns.items():
    r = df.loc[q]
    if a.spec.prior.kind != 'speed' or r.video_source != 'lab':
        continue
    m = meta[r.video_id]
    W, H = m['image_size']
    FFIX['f'] = 722.0 * W / 1280
    CAP.clear()
    ans = G.solve(a.spec, a.tracks, (W, H), float(m['fps']), camera_fov_deg=84.0)
    if 't' not in CAP:
        continue
    t, P = CAP['t'], CAP['P']
    key = (r.video_id, len(t), round(float(t[0]), 3))
    if key in done:
        continue
    done.add(key)
    t0 = a.spec.prior.time
    v = a.spec.prior.value_si
    out = dict(video=r.video_id, qid=q, stated=v, t0=t0, n=len(t), t_lo=t.min(), t_hi=t.max(),
               pipeline=ans.debug.get('prior_measured_si'))
    # interpolated position
    def pos(x):
        return np.array([np.interp(x, t, P[:, k]) for k in range(3)])
    for lab, (a0, a1) in {'fwd1f': (0, 1 / 24), 'bwd1f': (-1 / 24, 0), 'ctr1f': (-1 / 24, 1 / 24),
                          'fwd0.1': (0, 0.1), 'bwd0.1': (-0.1, 0), 'ctr0.1': (-0.1, 0.1),
                          'fwd0.2': (0, 0.2), 'bwd0.2': (-0.2, 0), 'ctr0.2': (-0.2, 0.2),
                          'ctr0.5': (-0.5, 0.5)}.items():
        lo, hi = t0 + a0, t0 + a1
        if lo < t.min() - 1e-6 or hi > t.max() + 1e-6:
            out[lab] = np.nan
        else:
            out[lab] = float(np.linalg.norm(pos(hi) - pos(lo)) / (hi - lo))
    # lateral-only and radial-only (range from depth fn) at ctr0.1 window
    rows.append(out)
res = pd.DataFrame(rows)
pd.set_option('display.width', 250)
cols = [c for c in res.columns if c not in ('video', 'qid', 'stated', 't0', 'n', 't_lo', 't_hi')]
for c in cols:
    res['r_' + c] = res.stated / res[c]
print(res[['video', 'stated', 't0', 'n', 't_lo', 't_hi'] + ['r_' + c for c in cols]].round(3).to_string())
print('median ratio stated/measured by definition:')
print(res[['r_' + c for c in cols]].apply(lambda x: np.exp(np.nanmedian(np.log(x)))).round(3).to_string())
print('geo-mean:')
print(res[['r_' + c for c in cols]].apply(lambda x: np.exp(np.nanmean(np.log(x)))).round(3).to_string())
print('rms log:')
print(res[['r_' + c for c in cols]].apply(lambda x: np.sqrt(np.nanmean(np.log(x) ** 2))).round(3).to_string())
res.to_pickle(SP / ('speedconv_' + Path(sys.argv[1]).stem + '.pkl'))
