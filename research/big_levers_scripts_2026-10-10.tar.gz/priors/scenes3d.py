import re, itertools
from collections import defaultdict
import pandas as pd
SP='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/big/priors/'
def base_id(v):
    v=re.sub(r'_segmented$','',v)
    return re.sub(r'(captured_\d+[ab]?)[sxX]?$',r'\1',v)
def scene_links(t, min_digits=3):
    t=t[t.video_type.str[1]=='3'].copy()
    t['base']=t.video_id.map(base_id)
    ent=defaultdict(set)
    for v,g in t.groupby('base'):
        for di in g.depth_info.unique():
            for num in re.findall(r'=\s*([0-9]+\.[0-9]{%d,})'%min_digits, di):
                ent[v].add(num)
    num2b=defaultdict(set)
    for b,s in ent.items():
        for n in s: num2b[n].add(b)
    parent={b:b for b in ent}
    def find(x):
        while parent[x]!=x: parent[x]=parent[parent[x]]; x=parent[x]
        return x
    for n,bs in num2b.items():
        bs=sorted(bs)
        for a in bs[1:]: parent[find(a)]=find(bs[0])
    comp=defaultdict(list)
    for b in ent: comp[find(b)].append(b)
    return {b:i for i,(k,v) in enumerate(sorted(comp.items())) for b in v}, [sorted(v) for k,v in sorted(comp.items())]
