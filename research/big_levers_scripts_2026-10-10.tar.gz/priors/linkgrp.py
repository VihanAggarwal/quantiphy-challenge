import pandas as pd, numpy as np, re, sys, itertools
from collections import defaultdict
sys.path.insert(0,'/home/user/quantiphy-challenge')
from qp.geometry import _tokens
from scenes3d import base_id, scene_links
SP='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/big/priors/'
def sig(v):
    return len(('%g'%abs(v)).replace('.','').replace('-','').lstrip('0'))
def build(vis_thr=0.95, use_vis=True, use_prior=True, use_depth=True):
    t=pd.read_pickle(SP+'test.pkl'); P=pd.read_pickle(SP+'prior_table.pkl')
    t['base']=t.video_id.map(base_id)
    parent={}
    def find(x):
        parent.setdefault(x,x)
        while parent[x]!=x: parent[x]=parent[parent[x]]; x=parent[x]
        return x
    def union(a,b): parent[find(a)]=find(b)
    for b in t.base.unique(): find(b)
    if use_prior:
        for key,g in P[P.pval.map(sig)>=3].groupby(['pq','pobj','pval']):
            bs=sorted(set(g.pbase))
            for b in bs[1:]: union(b,bs[0])
    if use_depth:
        comp3,_=scene_links(t)
        inv=defaultdict(list)
        for b,c in comp3.items(): inv[c].append(b)
        for c,bs in inv.items():
            for b in bs[1:]: union(b,bs[0])
    if use_vis:
        S=pd.read_pickle(SP+'vissim.pkl')
        for a,b in S[S.sim>=vis_thr][['a','b']].itertuples(index=False):
            union(base_id(a),base_id(b))
    t['grp']=t.base.map(find); P['grp']=P.pbase.map(find)
    return t,P
Q_RE=re.compile(r'what\s+is\s+the\s+(?:average\s+)?(height|length|width|diameter|size|speed|velocity|acceleration)\s+of\s+(?:the\s+)?(.+?)(\s+at\s+(?:time\s+)?[\d.]+\s*s)?\s*,?\s+in\s+(meters|m|cm|mm|m/s\^2|m/s|cm/s\^2|cm/s)\b', re.I)
UNIT={'m':1,'cm':0.01,'mm':0.001,'meters':1,'m/s':1,'cm/s':0.01,'m/s^2':1,'cm/s^2':0.01}
def candidates(qs, t, P):
    """qs: rows with video_id, question, prior; returns transfer value per row (or nan)."""
    grp=t.drop_duplicates('video_id').set_index('video_id').grp
    out=[]
    for r in qs.to_dict('records'):
        mm=Q_RE.search(r['question'])
        if not mm or r['video_id'] not in grp.index: out.append((np.nan,'')); continue
        q,obj,tm,u=mm.groups(); q=q.lower().replace('velocity','speed'); obj=' '.join(_tokens(obj))
        c=P[(P.grp==grp[r['video_id']])&(P.pq==q)&(P.pobj==obj)]
        own=[l.strip() for l in str(r['prior']).split('\n')]
        c=c[~((c.pvid==r['video_id'])&(c.pline.str.strip().isin(own)))]
        if len(c)==0 or c.pval.nunique()!=1: out.append((np.nan,'')); continue
        out.append((abs(c.pval.iloc[0])/UNIT[u.lower()], c.pline.iloc[0]+' @'+','.join(sorted(set(c.pvid)))))
    return out
