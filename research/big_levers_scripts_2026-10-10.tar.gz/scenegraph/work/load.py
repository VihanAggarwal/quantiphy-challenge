import sys, json, glob, re, math
sys.path.insert(0,'/home/user/quantiphy-challenge')
import pandas as pd, numpy as np
from qp.data import load_split
R='/home/user/quantiphy-challenge'
W='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/big/scenegraph'
def base_id(v):
    return re.sub(r'(_segmented|[sxX])$','',v)
def records(d=R+'/runs/test_v1_high_854/test/records'):
    out={}
    for f in glob.glob(d+'/*.json'):
        r=json.load(open(f)); out[r['video_id']]=r
    return out
def table():
    t=load_split('test')
    recs=records()
    rows={}
    for v,r in recs.items():
        p=r.get('parsed') or {}
        for q in p.get('questions',[]):
            s=q['spec']; T=s['target']; P=s['prior']
            rows[int(q['qid'])]=dict(tkind=T['kind'],tobj='|'.join(T['objects'] or []),tdim=T.get('dimension'),ttime=T.get('time'),twin=T.get('window'),tunit=T.get('unit'),
               pkind=P['kind'],pobj='|'.join(P['objects'] or []),pdim=P.get('dimension'),ptime=P.get('time'),pwin=P.get('window'),pval=P.get('value_si'),
               direct=q.get('direct_answer'),conf=q.get('confidence'))
    Q=pd.DataFrame.from_dict(rows,orient='index'); Q.index.name='qid'
    t=t.merge(Q,left_on='qid',right_index=True,how='left')
    run=pd.read_csv(R+'/runs/test_v1_high_854/test.csv').rename(columns={'id':'qid'})
    t=t.merge(run[['qid','geo_value','direct_value','method','flags']],on='qid',how='left')
    v3=pd.read_csv(R+'/submissions/trackA_v3_best_per_category.csv')[['id','parsed_value']].rename(columns={'id':'qid','parsed_value':'v3'})
    t=t.merge(v3,on='qid',how='left')
    t['base']=t.video_id.map(base_id)
    return t, recs
