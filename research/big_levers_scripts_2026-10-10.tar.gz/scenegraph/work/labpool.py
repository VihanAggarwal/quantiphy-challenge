from build import *
from series import qnorm
def lab_groups(t, kinds=('size',)):
    lab=t[(t.video_source=='lab')&(t.tkind.isin(kinds))].copy()
    lab['qn']=lab.question.map(qnorm)
    return {qn:g for qn,g in lab.groupby('qn') if g.base.nunique()>=2}
def base_value(g, b, mode='base'):
    gg=g[g.base==b]
    if mode=='base':
        r=gg[gg.video_id==b]
        if len(r): return v3[r.qid.iloc[0]]
        return gmed([v3[q] for q in gg.qid])
    return gmed([v3[q] for q in gg.qid])
def lab_pool(t, mode='base', max_spread=None, min_bases=2, include_self_render=True):
    out={}
    for qn,g in lab_groups(t).items():
        bases=sorted(g.base.unique())
        if len(bases)<min_bases: continue
        bv={b:base_value(g,b,mode) for b in bases}
        if max_spread and max(bv.values())/min(bv.values())>max_spread: continue
        for r in g.itertuples():
            vals=[bv[b] for b in bases if b!=r.base]+[v3[r.qid] if include_self_render else bv[r.base]]
            out[r.qid]=gmed(vals)
    return out
