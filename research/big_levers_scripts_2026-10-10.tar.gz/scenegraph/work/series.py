from fam2 import *
def prior_norm(p): return re.sub(r'\s+','',str(p).lower())
def qnorm(q):
    q=str(q).lower(); q=re.sub(r'(\d)\.0+s',r'\1s',q); q=re.sub(r'[^a-z0-9.]+',' ',q)
    return q.strip()
def shared_q(t,a,b):
    qa=set(t[t.base==a].question.map(qnorm)); qb=set(t[t.base==b].question.map(qnorm))
    return len(qa&qb)
def series_links(t, min_shared=2):
    links=[]
    s=t[t.video_id.str.startswith('simulation')].copy()
    s['pn']=s.prior.map(prior_norm)
    s=s[~s.pn.str.contains(r'gravit|=9\.[78]m')]
    for pn,g in s.groupby('pn'):
        bs=sorted(set(g.base))
        for i,a in enumerate(bs):
            for b in bs[i+1:]:
                if shared_q(t,a,b)>=min_shared: links.append((a,b,pn))
    return links
def families2(t, extra_links=()):
    uf=UF()
    for b in t.base.unique(): uf.f(b)
    L=depth_links(t)
    for (a,b),ns in L.items():
        if len(ns)>=2 and shared_q(t,a,b)>=1: uf.u(a,b)
    for a,b in extra_links: uf.u(base_id(a),base_id(b))
    fam={b:uf.f(b) for b in t.base.unique()}
    return t.base.map(fam), L
def build_series():
    t=pd.read_pickle(W+'/work/T.pkl'); t['base']=t.video_id.map(base_id)
    sl=series_links(t)
    t['fam'],L=families2(t, frame_links()+[(a,b) for a,b,_ in sl])
    return t,L,sl
