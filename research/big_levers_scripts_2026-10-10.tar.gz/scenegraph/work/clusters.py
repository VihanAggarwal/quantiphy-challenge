import pandas as pd, re, pickle, cv2, numpy as np
from fam import UF, base_id
S=pd.read_pickle('sim.pkl')
S['seg']=S.a.str.contains('segmented')|S.b.str.contains('segmented')
S['lab']=S.a.str.startswith('captured')|S.b.str.startswith('captured')
S['same_base']=[base_id(a)==base_id(b) for a,b in zip(S.a,S.b)]
X=S[~S.seg & ~S.lab & ~S.same_base & (S.ar_a==S.ar_b) & (S.ncc>0.85)]
uf=UF()
for a,b in zip(X.a,X.b): uf.u(a,b)
cl={}
for v in set(X.a)|set(X.b): cl.setdefault(uf.f(v),[]).append(v)
cl=[sorted(v) for v in cl.values()]
cl.sort()
pickle.dump(cl,open('frame_clusters.pkl','wb'))
T=pd.read_pickle('T.pkl')
for c in cl:
    print('CLUSTER',c)
    for v in c:
        g=T[T.video_id==v]
        print('   ',v,g.category.unique(),g.prior.unique()[:2], len(g))
# contact sheets
W='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/big/scenegraph'
d=pickle.load(open('thumbs.pkl','rb'))
for i,c in enumerate(cl):
    rows=[]
    for v in c:
        ims=[]
        for k in d[v]['keys']:
            im=cv2.imread(f'{W}/thumbs/{v}_{k}.jpg'); im=cv2.resize(im,(320,int(320*im.shape[0]/im.shape[1])))
            ims.append(im)
        r=np.hstack(ims)
        cv2.putText(r,v,(5,20),cv2.FONT_HERSHEY_SIMPLEX,0.6,(0,0,255),2)
        rows.append(r)
    wmax=max(r.shape[1] for r in rows)
    rows=[np.pad(r,((0,4),(0,wmax-r.shape[1]),(0,0))) for r in rows]
    cv2.imwrite(f'{W}/frames/cl_{i:02d}.jpg',np.vstack(rows))
print(len(cl))
