from evalknown import *
import os
EQF=os.environ.get('EQF','eq2.pkl'); MINB=int(os.environ.get('MINB','1'))
t=pd.read_pickle('TS.pkl'); ti=t.set_index('qid'); eq=pickle.load(open(EQF,'rb'))
A=pd.read_pickle('transfers3.pkl'); A=A[~A.conflict].copy()
A['lk']=np.log(A.value/A.v3); A['kind']=ti.loc[A.qid,'tkind'].values; A['method']=ti.loc[A.qid,'method'].values
A['fact']=A.line.str.strip().str.lower()+'|'+A.value.round(6).astype(str)   # one fact per stated line/value
def clipK(v, exclude_facts, kinds=('size','speed')):
    g=A[(A.video_id==v)&~A.fact.isin(exclude_facts)&A.kind.isin(kinds)]
    if not len(g): return 0.0
    return float(np.median(np.r_[g.lk.values,0.0]))
def predict(q, exclude_facts, useK=True, pool=True, only_direct_K=True):
    r=ti.loc[q]
    def corr(p):
        rp=ti.loc[p]; val=rp.v3
        if useK and (rp.method=='direct' or not only_direct_K) and rp.tkind in ('size','speed'):
            val=val*np.exp(clipK(rp.video_id, exclude_facts))
        return val
    if not pool: return corr(q)
    per=per_base_values(ti,eq,q,include_self=True)
    if len(per)<MINB: return corr(q)
    return gmed([corr(x[2]) for x in per.values()])
rows=[]
for fact,g in A.groupby('fact'):
    ex={fact}
    for r in g.itertuples():
        if r.method!='direct': continue
        rows.append(dict(cat=r.cat,qid=r.qid,kind=r.kind,V=r.value,v3=r.v3,
             m_raw=mra(r.v3,r.value), m_K=mra(predict(r.qid,ex,True,False),r.value),
             m_P=mra(predict(r.qid,ex,False,True),r.value), m_KP=mra(predict(r.qid,ex,True,True),r.value)))
R=pd.DataFrame(rows)
print(R.groupby('cat')[['m_raw','m_K','m_P','m_KP']].agg(['mean','size']).round(3))
print(R.groupby(['cat','kind'])[['m_raw','m_K','m_P','m_KP']].mean().round(3))
