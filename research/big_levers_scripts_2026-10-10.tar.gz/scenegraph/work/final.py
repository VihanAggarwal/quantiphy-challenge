from build import *
import json
known=known_rows2()
N={'S2':579,'D2':1163,'S3':578,'D3':969}
VARS={
 'S2':{'S2_T':dict(rule_T=True),'S2_TK2D':dict(rule_T=True,rule_K2D=True)},
 'D2':{'D2_T':dict(rule_T=True),'D2_T_LAB':dict(rule_T=True,rule_LAB=True,lab_cats=('S3','D3','D2'))},
 'S3':{'S3_T':dict(rule_T=True),'S3_T_LAB':dict(rule_T=True,rule_LAB=True)},
 'D3':{'D3_T':dict(rule_T=True),'D3_T_LAB':dict(rule_T=True,rule_LAB=True),'D3_TKP':dict(rule_T=True,rule_K=True,rule_P=True),'D3_TKP_LAB':dict(rule_T=True,rule_K=True,rule_P=True,rule_LAB=True)},
}
report=[]
for cat,vs in VARS.items():
    for name,cfg in vs.items():
        new,why=variant(cats=(cat,),**cfg)
        path,nch,medr=write(new,cat,name)
        # sanity: only own category changed
        df=pd.read_csv(path); base=V3
        diff=~np.isclose(df.parsed_value.values,base.parsed_value.values,rtol=1e-9)
        cats_changed=set(ti.loc[df.id[diff],'category'])
        assert cats_changed<= {cat}, cats_changed
        rules=pd.Series({q:w for q,w in why.items() if ti.loc[q,'category']==cat and not np.isclose(new[q],v3[q],rtol=1e-9)}).value_counts().to_dict()
        kq=[q for q in known if ti.loc[q,'category']==cat and q not in SUSPECT]
        m0=np.mean([mra(v3[q],known[q]) for q in kq]); m1=np.mean([mra(new[q],known[q]) for q in kq])
        kch=[q for q in kq if not np.isclose(new[q],v3[q],rtol=1e-9)]
        # if-right gain for transfer rows
        trq=[q for q,w in why.items() if w=='T' and ti.loc[q,'category']==cat]
        tgain=sum(1-mra(v3[q],new[q]) for q in trq)/N[cat]
        lr=np.abs(np.log([new[q]/v3[q] for q in df.id[diff]])) if diff.any() else np.array([0])
        report.append(dict(name=name,category=cat,csv=path,answers_changed=nch,median_ratio_changed=round(medr,4),median_abs_log_change=round(float(np.median(lr)),4),
                           changes_by_rule=rules,known_rows=len(kq),known_rows_changed=len(kch),known_mra_v3=round(m0,4),known_mra_new=round(m1,4),
                           transfer_if_right_category_gain=round(tgain,4)))
        print(report[-1])
json.dump(report,open(W+'/work/variants_summary.json','w'),indent=1)
