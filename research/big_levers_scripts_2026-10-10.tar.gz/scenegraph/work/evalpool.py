from pool import *
from mra import mra
import pickle
SUSPECT={403, 2349, 2607, 3049, 3051, 1123, 1130, 1354, 1355, 3054, 139, 2276}
def known_rows():
    m=pd.read_csv('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/val_test_map.csv')
    m=m[m.sim>=0.9]
    return dict(zip(m.tqid,m.answer)), set(m.vqid)
def gmed(vals):
    vals=[v for v in vals if v and v>0 and np.isfinite(v)]
    return float(np.exp(np.median(np.log(vals)))) if vals else np.nan
def pooled(t, eq, q, col='v3', mode='nontwin'):
    ti=t.set_index('qid')
    grp=eq[q]
    if mode=='all': return gmed([ti.loc[p,col] for p in grp])
    # one value per base: prefer original (non-segmented) clip, base render for lab
    per_base={}
    me=ti.loc[q]
    for p in grp:
        b=ti.loc[p,'base']
        if b==me.base and p!=q: continue      # same-base twins handled by other rules
        v=ti.loc[p,'video_id']
        rank=0 if v==b else 1
        if b not in per_base or rank<per_base[b][0]: per_base[b]=(rank,ti.loc[p,col])
    per_base[me.base]=(0,ti.loc[q,col])
    return gmed([x[1] for x in per_base.values()])
