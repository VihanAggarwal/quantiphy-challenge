from evalpool import *
def known_rows2():
    m=pd.read_csv('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/val_test_map.csv')
    m=m.sort_values('sim').drop_duplicates('tqid',keep='last')
    m=m[m.sim>=0.9]
    return dict(zip(m.tqid,m.answer))
if __name__=='__main__':
    t=pd.read_pickle('TS.pkl'); eq=equiv_groups(t); pickle.dump(eq,open('eq_series.pkl','wb'))
    known=known_rows2()
    ti=t.set_index('qid')
    rows=[]
    for q,gt in known.items():
        if q not in eq: continue
        nb=len(set(ti.loc[list(eq[q]),'base']))
        if nb<2: continue
        r=ti.loc[q]
        pn=pooled(t,eq,q,mode='nontwin')
        rows.append(dict(qid=q,vid=r.video_id,cat=r.category,kind=r.tkind,q=r.question[:50],gt=gt,v3=round(r.v3,3),pool_nt=round(pn,3),nb=nb,m_v3=mra(r.v3,gt),m_nt=mra(pn,gt),sus=q in SUSPECT))
    R=pd.DataFrame(rows)
    pd.set_option('display.width',250); pd.set_option('display.max_rows',200)
    print(R.to_string())
    R['size']=R.kind=='size'
    print(R[~R.sus].groupby(['size','cat'])[['m_v3','m_nt']].agg(['mean','size']))
    print(R[~R.sus].groupby('size')[['m_v3','m_nt']].mean())
