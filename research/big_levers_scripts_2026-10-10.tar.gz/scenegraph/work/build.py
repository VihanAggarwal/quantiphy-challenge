"""Production: scene-graph variants on top of v3."""
from evalknown import *
R='/home/user/quantiphy-challenge'
OUT=W
t=pd.read_pickle(W+'/work/TS.pkl'); ti=t.set_index('qid')
eq=pickle.load(open(W+'/work/eq3.pkl','rb'))
V3=pd.read_csv(R+'/submissions/trackA_v3_best_per_category.csv')
v3=dict(zip(V3.id,V3.parsed_value))
A=pd.read_pickle(W+'/work/transfers3.pkl'); A=A[~A.conflict].copy()
A['v3']=A.qid.map(v3)
A['lk']=np.log(A.value/A.v3); A['kind']=ti.loc[A.qid,'tkind'].values
def is_direct(q):
    d=ti.loc[q,'direct']
    try: d=float(d)
    except: return False
    return d>0 and abs(v3[q]/d-1)<1e-6
KIND_LEN={'size','distance','displacement','path_length'}
def clip_K(v, kinds=('size','speed')):
    g=A[(A.video_id==v)&A.kind.isin(kinds)]
    if not len(g): return 0.0
    return float(np.median(np.r_[g.lk.values,0.0]))
KC={v:clip_K(v) for v in t.video_id.unique()}
def corrected(q, useK=True):
    r=ti.loc[q]; val=v3[q]
    if useK and is_direct(q) and r.tkind in ('size','speed') :
        val=val*np.exp(KC[r.video_id])
    return val
from qp.parse import canonical_unit, _UNITS
def usc(q):
    cu=canonical_unit(ti.loc[q,'target_unit'] or 'm') or 'm'
    return _UNITS[cu][0] if cu in _UNITS else 1.0
def pooled_value(q, useK=True):
    per=per_base_values(ti,eq,q,col='v3',include_self=True)
    vals=[corrected(x[2],useK)*usc(x[2]) for x in per.values()]
    return gmed(vals)/usc(q), len(per)
def is_geo(q):
    m=str(ti.loc[q,'method'])
    return m.startswith('geometry') and not is_direct(q)
def variant(rule_T=True, rule_K=False, rule_P=False, rule_K2D=False, rule_LAB=False, lab_cats=('S3','D3'), cats=('S2','D2','S3','D3'), P_kinds=('size','speed'), P_cats=('D3',), K_cats=('D3',), K_kinds=('size','speed'), min_bases=3, k2d_min=0.1):
    new=dict(v3); why={}
    if rule_K2D:
        for q in t.qid:
            r=ti.loc[q]
            if r.category not in cats or r.category[1]!='2' or not is_geo(q): continue
            k=KC[r.video_id]
            if abs(k)>k2d_min: new[q]=v3[q]*np.exp(k); why[q]='K2D'
    for q in t.qid:
        r=ti.loc[q]
        if r.category not in cats: continue
        sim=r.video_id.startswith('simulation')
        val=None
        if rule_P and sim and r.category in P_cats and r.tkind in P_kinds and is_direct(q):
            pv,nb=pooled_value(q, useK=rule_K)
            if nb>=min_bases and np.isfinite(pv): val=pv; why[q]='pool'
        if val is None and rule_K and sim and r.category in K_cats and r.tkind in K_kinds and is_direct(q) and KC[r.video_id]!=0:
            val=corrected(q,True); why[q]='K'
        if val is not None: new[q]=val
    if rule_LAB:
        from labpool2 import lab_pool3
        LP,lw=lab_pool3(t,2.0,True,cats=lab_cats,base_mode='base',max_dev=1.6)
        for q,v in LP.items():
            if ti.loc[q,'category'] in cats: new[q]=v; why[q]=lw[q]
    if rule_T:
        for r in A.itertuples():
            if r.cat in cats: new[r.qid]=r.value; why[r.qid]='T'
    return new, why
def write(new, cat, name):
    df=V3.copy()
    m=df.id.map(lambda q: ti.loc[q,'category']==cat)
    df.loc[m,'parsed_value']=df.loc[m,'id'].map(new)
    path=f'{OUT}/{name}.csv'; df.to_csv(path,index=False)
    ch=df.parsed_value.values!=V3.parsed_value.values
    ch=ch & ~np.isclose(df.parsed_value.values,V3.parsed_value.values,rtol=1e-9)
    rat=(df.parsed_value[ch]/V3.parsed_value[ch])
    return path,int(ch.sum()),float(np.median(rat)) if ch.sum() else 1.0
