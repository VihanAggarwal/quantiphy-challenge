from transfer import *
GRAV=re.compile(r'gravit',re.I)
def depth_entries(di):
    """{object_token: tuple(sorted (t,dist))} from depth_info text"""
    out={}
    for line in str(di).split('\n'):
        m=re.search(r'(?:t\s*=\s*([\d.]+)\s*s?\s*,\s*)?distance_(.+?)_camera\s*=\s*([\d.]+)',line)
        if m:
            tt,obj,d=m.groups(); out.setdefault(obj.lower(),[]).append((float(tt) if tt else None,float(d)))
    return {k:tuple(sorted(v,key=lambda x:(x[0] is None,x[0] or 0))) for k,v in out.items()}
def obj_depth_identical(t, va, vb, oa, ob):
    da=depth_entries(t[t.video_id==va].depth_info.iloc[0]); db=depth_entries(t[t.video_id==vb].depth_info.iloc[0])
    for ka,ea in da.items():
        if name_score(ka,oa)<0.5: continue
        for kb,eb in db.items():
            if name_score(kb,ob)<0.5: continue
            if len(ea)>=2 and ea==eb: return True
    return False
def strict_same_render(a,b,mad_max=0.3):
    R=pd.read_pickle(W+'/work/aligned.pkl')
    for r in R.itertuples():
        if {r.a,r.b}=={a,b}: return r.na==r.nb and max(r.mad_aligned)<=mad_max and min(r.ncc_aligned)>=0.99
    return False
def accept(t, c):
    """c: candidate row. returns (ok, reason)"""
    if c.ns<0.6: return False,'name'
    if GRAV.search(c.prior): return False,'gravity'
    own=t[t.qid==c.qid].iloc[0]
    if c.pvid==c.video_id and own.prior.replace('\n',' ; ')==c.prior: return False,'own_prior'
    a,b=c.video_id,c.pvid
    sim_like = all(t[t.video_id==v].video_source.iloc[0] in ('simulation','segmentation') and 'internet' not in v and 'captured' not in v for v in (a,b))
    same_base = base_id(a)==base_id(b)
    if c.tkind=='size':
        if same_base: return True,'size_same_base'
        if sim_like: return True,'size_family_sim'
        return False,'size_nonsim'
    # motion
    if not c.ok_time: return False,'time'
    if a==b: return True,'motion_same_video'
    if same_base: return True,'motion_twin'
    ba,bb=base_id(a),base_id(b)
    if t[t.video_id==a].depth_info.iloc[0] and t[t.video_id==b].depth_info.iloc[0] and obj_depth_identical(t,a,b,c.tobj.split('|')[0],c.pobj.split('|')[0]):
        return True,'motion_depth_identical'
    if strict_same_render(ba,bb): return True,'motion_same_render'
    return False,'motion_unverified'
from qp.claude_annotate import prior_si
from qp.parse import canonical_unit, _UNITS
def stated_si(prior_text, pobj):
    """SI value of the prior line naming pobj (multi-line priors)"""
    lines=[l for l in str(prior_text).split(' ; ') if l.strip()]
    if len(lines)>1:
        best=max(lines,key=lambda l: name_score(l.split('=')[0],pobj))
    else: best=lines[0]
    r=prior_si(best)
    return r[0] if r else None
def to_unit(si, unit):
    cu=canonical_unit(unit or 'm') or 'm'
    return si/_UNITS[cu][0] if cu in _UNITS else si
def accepted_transfers(t, C):
    res=[accept(t,c) for c in C.itertuples()]
    C=C.assign(ok=[r[0] for r in res], why=[r[1] for r in res])
    A=C[C.ok].copy()
    A['si']=[stated_si(c.prior,c.pobj) for c in A.itertuples()]
    A['value']=[to_unit(c.si,c.tunit) for c in A.itertuples()]
    # one value per question; conflicting values -> drop
    out=[]
    for q,g in A.groupby('qid'):
        vals=g.value.round(9).unique()
        if len(vals)!=1: 
            print('CONFLICT',q,vals); continue
        r=g.iloc[0]
        out.append(dict(qid=q,video_id=r.video_id,cat=r["cat"],question=r.question,value=float(vals[0]),v3=r.v3,why=','.join(sorted(set(g.why))),src=','.join(sorted(set(g.pvid))),prior=r.prior))
    return pd.DataFrame(out), C
