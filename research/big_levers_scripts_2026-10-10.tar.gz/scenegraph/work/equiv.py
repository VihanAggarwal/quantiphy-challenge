from rules import *
MIN_NS=0.6
def qkey_match(a, b):
    if a.tkind!=b.tkind: return False
    if a.tkind not in ('size','speed','acceleration','distance','displacement','path_length'): return False
    ns=max([name_score(x,y) for x in str(a.tobj).split('|') for y in str(b.tobj).split('|')]+[0])
    if ns<MIN_NS: return False
    if a.tkind=='size' and dimnorm(a.tdim)!=dimnorm(b.tdim): return False
    if a.tkind!='size':
        ta,tb=fnum(a.ttime),fnum(b.ttime)
        wa=tuple(a.twin) if isinstance(a.twin,(list,tuple)) else None
        wb=tuple(b.twin) if isinstance(b.twin,(list,tuple)) else None
        if (ta,wa)!=(tb,wb): return False
    if a.tkind=='distance':
        # both objects must match
        oa=str(a.tobj).split('|'); ob=str(b.tobj).split('|')
        if len(oa)!=len(ob): return False
        if len(oa)==2 and not (name_score(oa[1],ob[1])>=0.6 or name_score(oa[1],ob[0])>=0.6): return False
    return True
def equiv_pairs(t):
    t=t.reset_index(drop=True)
    out=[]
    for f,g in t.groupby('fam'):
        if g.video_id.nunique()<2: continue
        rows=list(g.itertuples())
        for i,a in enumerate(rows):
            for b in rows[i+1:]:
                if a.video_id==b.video_id: continue
                if qkey_match(a,b): out.append((a.qid,b.qid))
    return out
