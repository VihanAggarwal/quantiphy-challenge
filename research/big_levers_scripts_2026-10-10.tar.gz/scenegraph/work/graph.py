"""Scene graph: SERIES (asset identity) and SCENARIO (motion identity) components over test clips."""
from series import *
from rules import obj_depth_identical, depth_entries, stated_si, to_unit, GRAV, dimnorm, fnum
from qp.geometry import name_score
MOTION_PRIOR=re.compile(r'speed|velocit|accel',re.I)
def strict_render_pairs(mad_max=0.3):
    R=pd.read_pickle(W+'/work/aligned.pkl')
    return [(r.a,r.b) for r in R.itertuples() if r.na==r.nb and max(r.mad_aligned)<=mad_max and min(r.ncc_aligned)>=0.99]
def scenario_components(t):
    uf=UF()
    for v in t.video_id.unique(): uf.f(v)
    for b,g in t.groupby('base'):
        vs=sorted(g.video_id.unique())
        for v in vs[1:]: uf.u(vs[0],v)
    for a,b in strict_render_pairs():
        uf.u(a,b)
    s=t[t.video_id.str.startswith('simulation')].copy()
    s['pn']=s.prior.map(prior_norm)
    s=s[s.prior.str.contains(MOTION_PRIOR) & ~s.pn.str.contains(r'gravit|=9\.[78]m')]
    for (pn,f),g in s.groupby(['pn','fam']):     # identical motion prior within one series family
        vs=sorted(g.video_id.unique())
        for v in vs[1:]: uf.u(vs[0],v)
    return {v:uf.f(v) for v in t.video_id.unique()}
def facts(t):
    """stated prior facts per clip: one row per (video, prior line)"""
    out=[]
    for (v,p),g in t.groupby(['video_id','prior']):
        r=g.iloc[0]
        lines=[l for l in str(p).split('\n') if l.strip()]
        for l in lines:
            si=stated_si(l, r.pobj)
            if si is None: continue
            out.append(dict(video_id=v,base=r.base,fam=r.fam,src=r.video_source,line=l,pkind=r.pkind,pobj=r.pobj if len(lines)==1 else l.split('=')[0],pdim=r.pdim,ptime=r.ptime,pwin=r.pwin,si=si,grav=bool(GRAV.search(l))))
    return pd.DataFrame(out)
def is_sim(v): return v.startswith('simulation')
def time_ok(q, f):
    tt=fnum(q.ttime)
    pt=fnum(f.ptime)
    pw=f.pwin if isinstance(f.pwin,(list,tuple)) else None
    if pt is None and pw is None: return True           # constant stated value
    if pt is not None and tt is not None and abs(pt-tt)<1e-6 and not isinstance(q.twin,(list,tuple)): return True
    return False
def transfers(t, F, min_name=0.6):
    rows=[]
    vscen=dict(zip(t.video_id,t.scen))
    for q in t.itertuples():
        if q.tkind not in ('size','speed','acceleration'): continue
        cand=F[(F.fam==q.fam)&(F.pkind==q.tkind)&(~F.grav)]
        for f in cand.itertuples():
            if f.video_id==q.video_id and f.line.strip()==q.prior.strip(): continue   # own prior
            ns=max([name_score(a,b) for a in str(q.tobj).split('|') for b in str(f.pobj).split('|')]+[0])
            if ns<min_name: continue
            same_base=base_id(f.video_id)==q.base
            if q.tkind=='size':
                if dimnorm(q.tdim)!=dimnorm(f.pdim): continue
                if not (same_base or (is_sim(q.video_id) and is_sim(f.video_id))): continue
                why='size_same_base' if same_base else 'size_series'
            else:
                if not time_ok(q,f): continue
                if f.video_id==q.video_id: why='motion_same_video'
                elif vscen[f.video_id]==q.scen: why='motion_same_scenario'
                elif t[t.video_id==q.video_id].depth_info.iloc[0] and t[t.video_id==f.video_id].depth_info.iloc[0] and obj_depth_identical(t,q.video_id,f.video_id,q.tobj.split('|')[0],f.pobj.split('|')[0]):
                    why='motion_depth_identical'
                else: continue
            rows.append(dict(qid=q.qid,video_id=q.video_id,cat=q.category,question=q.question,tunit=q.target_unit,v3=q.v3,src_video=f.video_id,line=f.line,si=f.si,ns=ns,why=why))
    R=pd.DataFrame(rows)
    R['value']=[to_unit(r.si,r.tunit) for r in R.itertuples()]
    out=[]
    for qid,g in R.groupby('qid'):
        vals=np.unique(np.round(g.value.values,9))
        r=g.iloc[0]
        out.append(dict(qid=qid,video_id=r.video_id,cat=r['cat'],question=r.question,v3=r.v3,value=float(vals[0]) if len(vals)==1 else np.nan,
                        conflict=len(vals)>1,why=','.join(sorted(set(g.why))),src=','.join(sorted(set(g.src_video))),line=r.line))
    return pd.DataFrame(out), R
from tracks import object_motion_identical
def near_render_pairs(mad_max=0.5):
    R_=pd.read_pickle(W+'/work/aligned.pkl')
    out={}
    for r in R_.itertuples():
        if r.na==r.nb and max(r.mad_aligned)<=mad_max and min(r.ncc_aligned)>=0.99:
            out.setdefault(r.a,set()).add(r.b); out.setdefault(r.b,set()).add(r.a)
    return out
_NR=None
def motion_linked(t, qv, fv, qobj, fobj, vscen):
    """motion identity of object between question clip qv and fact clip fv"""
    global _NR
    if _NR is None: _NR=near_render_pairs()
    if qv==fv or vscen[qv]==vscen[fv]: return 'motion_same_scenario'
    def dep(a,b,oa,ob):
        try:
            return bool(t[t.video_id==a].depth_info.iloc[0]) and bool(t[t.video_id==b].depth_info.iloc[0]) and obj_depth_identical(t,a,b,oa,ob)
        except Exception: return False
    if dep(qv,fv,qobj,fobj): return 'motion_depth_identical'
    # one hop through a near-identical render whose tracks of this object coincide tightly
    for c in _NR.get(qv,()):
        if not object_motion_identical(qv,c,qobj,tol=0.003,min_common=1,min_name=0.5,need_motion=False)[0]: continue
        if c==fv or vscen.get(c)==vscen[fv] or dep(c,fv,qobj,fobj): return 'motion_render_chain'
    return None
def transfers3(t, F, min_name=0.6):
    rows=[]
    vscen=dict(zip(t.video_id,t.scen))
    for q in t.itertuples():
        if q.tkind not in ('size','speed','acceleration'): continue
        cand=F[(F.fam==q.fam)&(F.pkind==q.tkind)&(~F.grav)]
        for f in cand.itertuples():
            if f.video_id==q.video_id and f.line.strip()==q.prior.strip(): continue
            ns=max([name_score(a,b) for a in str(q.tobj).split('|') for b in str(f.pobj).split('|')]+[0])
            if ns<min_name: continue
            same_base=base_id(f.video_id)==q.base
            if q.tkind=='size':
                if dimnorm(q.tdim)!=dimnorm(f.pdim): continue
                if not (same_base or (is_sim(q.video_id) and is_sim(f.video_id))): continue
                why='size_same_base' if same_base else 'size_series'
            else:
                if not time_ok(q,f): continue
                why=motion_linked(t,q.video_id,f.video_id,q.tobj.split('|')[0],f.pobj.split('|')[0],vscen)
                if why is None: continue
            rows.append(dict(qid=q.qid,video_id=q.video_id,cat=q.category,question=q.question,tunit=q.target_unit,v3=q.v3,src_video=f.video_id,line=f.line,si=f.si,ns=ns,why=why))
    R_=pd.DataFrame(rows)
    R_['value']=[to_unit(r.si,r.tunit) for r in R_.itertuples()]
    out=[]
    for qid,g in R_.groupby('qid'):
        vals=np.unique(np.round(g.value.values,9)); r=g.iloc[0]
        out.append(dict(qid=qid,video_id=r.video_id,cat=r['cat'],question=r.question,v3=r.v3,value=float(vals[0]) if len(vals)==1 else np.nan,
                        conflict=len(vals)>1,why=','.join(sorted(set(g.why))),src=','.join(sorted(set(g.src_video))),line=r.line))
    return pd.DataFrame(out), R_
