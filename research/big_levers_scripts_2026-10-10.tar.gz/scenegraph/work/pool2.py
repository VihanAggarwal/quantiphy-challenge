from graph import *
from equiv import qkey_match
from mra import mra
def equiv_groups2(t):
    t=t.reset_index(drop=True)
    eq={q:{q} for q in t.qid}
    for f,g in t.groupby('fam'):
        if g.video_id.nunique()<2: continue
        rows=list(g.itertuples())
        for i,a in enumerate(rows):
            for b in rows[i+1:]:
                if a.video_id==b.video_id or not qkey_match(a,b): continue
                if a.tkind not in ('size',):
                    same=(a.scen==b.scen)
                    if not same:
                        try:
                            same=bool(a.depth_info) and bool(b.depth_info) and obj_depth_identical(t,a.video_id,b.video_id,a.tobj.split('|')[0],b.tobj.split('|')[0])
                        except Exception: same=False
                    if not same: continue
                else:
                    if not (is_sim(a.video_id) and is_sim(b.video_id)) and a.base!=b.base: continue
                eq[a.qid].add(b.qid); eq[b.qid].add(a.qid)
    return eq
def gmed(vals):
    vals=[v for v in vals if v and v>0 and np.isfinite(v)]
    return float(np.exp(np.median(np.log(vals)))) if vals else np.nan
def per_base_values(ti, eq, q, col='v3', include_self=True, exclude_same_base=True):
    me=ti.loc[q]; per={}
    for p in eq[q]:
        if p==q and not include_self: continue
        b=ti.loc[p,'base']
        if exclude_same_base and b==me.base and p!=q: continue
        v=ti.loc[p,'video_id']; rank=0 if v==b else 1
        if b not in per or rank<per[b][0]: per[b]=(rank,ti.loc[p,col],p)
    return per
