import numpy as np
TH=[0.9,0.8,0.7,0.6,0.5,0.4,0.3,0.2,0.1,0.05]
def mra(pred,gt):
    if not (pred>0) or not (gt>0): return 0.0
    e=abs(pred-gt)/abs(gt)
    return float(np.mean([e<th for th in TH]))
