from pool2 import *
import pickle
SUSPECT={403, 2349, 2607, 3049, 3051, 1123, 1130, 1354, 1355, 3054, 139, 2276}
def known_rows2(minsim=0.9):
    m=pd.read_csv('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/val_test_map.csv')
    m=m.sort_values('sim').drop_duplicates('tqid',keep='last')
    m=m[m.sim>=minsim]
    return dict(zip(m.tqid,m.answer))
