import pickle, numpy as np, pandas as pd, itertools
d=pickle.load(open('thumbs.pkl','rb'))
cl=pickle.load(open('frame_clusters.pkl','rb'))
def norm(x):
    x=x.astype(np.float32).ravel(); x=x-x.mean(); n=np.linalg.norm(x); return x/n if n>0 else x
def mad(a,b):
    return float(np.mean(np.abs(a.astype(np.float32)-b.astype(np.float32))))
rows=[]
for c in cl:
    for a,b in itertools.combinations(c,2):
        A,B=d[a],d[b]
        same_n=A['n']==B['n']
        k=min(len(A['th']),len(B['th']))
        nc=[float(norm(A['th'][i])@norm(B['th'][i])) for i in range(k)]
        md=[mad(A['th'][i],B['th'][i]) for i in range(k)]
        rows.append((a,b,A['n'],B['n'],[round(x,4) for x in nc],[round(x,1) for x in md]))
R=pd.DataFrame(rows,columns=['a','b','na','nb','ncc_aligned','mad_aligned'])
pd.set_option('display.width',250); pd.set_option('display.max_rows',500)
print(R.to_string())
R.to_pickle('aligned.pkl')
