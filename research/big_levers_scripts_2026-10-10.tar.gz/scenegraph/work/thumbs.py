import cv2, glob, numpy as np, os, sys, pickle
cv2.setNumThreads(1)
out=sys.argv[1]
fs=sorted(glob.glob('/home/user/quantiphy-challenge/data/QuantiPhy/*.mp4'))
res={}
for f in fs:
    vid=os.path.basename(f)[:-4]
    cap=cv2.VideoCapture(f)
    n=int(cap.get(cv2.CAP_PROP_FRAME_COUNT)); W=cap.get(3); H=cap.get(4); fps=cap.get(5)
    want={0, max(0,n//2), max(0,n-1)}
    frames={}
    i=0
    while True:
        ok=cap.grab()
        if not ok: break
        if i in want:
            ok,fr=cap.retrieve()
            if ok:
                frames[i]=fr
        i+=1
    cap.release()
    keys=sorted(frames)
    th=[]
    for k in keys:
        fr=frames[k]
        g=cv2.cvtColor(fr,cv2.COLOR_BGR2GRAY)
        th.append(cv2.resize(g,(64,64),interpolation=cv2.INTER_AREA))
        sm=cv2.resize(fr,(int(240*W/H) if W<H else 240, int(240*H/W) if W>=H else 240),interpolation=cv2.INTER_AREA)
        cv2.imwrite(f'{out}/thumbs/{vid}_{k}.jpg', sm)
    res[vid]=dict(W=W,H=H,n=n,nread=i,fps=fps,keys=keys,th=th)
    print(vid, n, i, flush=True)
pickle.dump(res, open(f'{out}/work/thumbs.pkl','wb'))
