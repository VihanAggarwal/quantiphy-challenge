import pickle, numpy as np, cv2, re, pandas as pd
d=pickle.load(open('thumbs.pkl','rb'))
vids=sorted(d)
def norm(x):
    x=x.astype(np.float32).ravel(); x=x-x.mean(); n=np.linalg.norm(x); return x/n if n>0 else x
def grad(g):
    g=g.astype(np.float32); gx=cv2.Sobel(g,cv2.CV_32F,1,0); gy=cv2.Sobel(g,cv2.CV_32F,0,1); return np.hypot(gx,gy)
F={}; G={}
for v in vids:
    F[v]=np.stack([norm(x) for x in d[v]['th']])
    G[v]=np.stack([norm(grad(x)) for x in d[v]['th']])
rows=[]
for i,a in enumerate(vids):
    for b in vids[i+1:]:
        c=(F[a]@F[b].T).max(); cg=(G[a]@G[b].T).max()
        # same-index frame (first-first)
        c0=float(F[a][0]@F[b][0])
        rows.append((a,b,float(c),float(cg),c0))
S=pd.DataFrame(rows,columns=['a','b','ncc','gncc','ncc0'])
S['ar_a']=[d[a]['W']/d[a]['H'] for a in S.a]; S['ar_b']=[d[b]['W']/d[b]['H'] for b in S.b]
S['n_a']=[d[a]['n'] for a in S.a]; S['n_b']=[d[b]['n'] for b in S.b]
S.to_pickle('sim.pkl')
