from build import *
from qp.geometry import name_score
from rules import dimnorm
def lab_size_groups(t, min_ns=0.8):
    lab=t[(t.video_source=='lab')&(t.tkind=='size')].reset_index(drop=True)
    uf=UF()
    rows=list(lab.itertuples())
    for r in rows: uf.f(r.qid)
    for i,a in enumerate(rows):
        for b in rows[i+1:]:
            if dimnorm(a.tdim)!=dimnorm(b.tdim): continue
            if max(name_score(x,y) for x in str(a.tobj).split('|') for y in str(b.tobj).split('|'))<min_ns: continue
            uf.u(a.qid,b.qid)
    G={}
    for r in rows: G.setdefault(uf.f(r.qid),[]).append(r.qid)
    return {k:v for k,v in G.items() if len(set(ti.loc[v,'base']))>=2}
def lab_facts(t):
    lab=t[t.video_source=='lab']
    F=[]
    for (v,p),g in lab.groupby(['video_id','prior']):
        r=g.iloc[0]
        if r.pkind!='size': continue
        si=stated_si(p, r.pobj)
        if si: F.append((r.pobj,r.pdim,si,v))
    return F
def lab_pool2(t, max_spread=2.0, use_facts=True, mode='base'):
    out={}; why={}
    F=lab_facts(t)
    for k,qs in lab_size_groups(t).items():
        g=ti.loc[qs]
        # stated fact for this object?
        if use_facts:
            fv=[si for (po,pd_,si,v) in F if dimnorm(pd_)==dimnorm(g.tdim.iloc[0]) and max(name_score(po,o) for o in g.tobj.iloc[0].split('|'))>=0.8]
            if fv and len(set(np.round(fv,6)))==1:
                for q in qs: out[q]=to_unit(fv[0],ti.loc[q,'target_unit']); why[q]='labfact'
                continue
        bases=sorted(set(g.base))
        bv={}
        for b in bases:
            gb=g[g.base==b]
            r=gb[gb.video_id==b]
            bv[b]=v3[r.index[0]] if (mode=='base' and len(r)) else gmed([v3[q] for q in gb.index])
        if max_spread and max(bv.values())/min(bv.values())>max_spread: continue
        for q in qs:
            b=ti.loc[q,'base']
            vals=[bv[x] for x in bases if x!=b]+[v3[q]]
            out[q]=gmed(vals); why[q]='labpool'
    return out, why
from qp.parse import canonical_unit, _UNITS
def usc(q):
    cu=canonical_unit(ti.loc[q,'target_unit'] or 'm') or 'm'
    return _UNITS[cu][0] if cu in _UNITS else 1.0
def lab_pool3(t, max_spread2=2.0, use_facts=True, cats=('S3','D3','D2'), base_mode='base', max_dev=1.6):
    out={}; why={}
    F=lab_facts(t)
    for k,qs in lab_size_groups(t).items():
        g=ti.loc[qs]
        if use_facts:
            fv=[si for (po,pd_,si,v) in F if dimnorm(pd_)==dimnorm(g.tdim.iloc[0]) and max(name_score(po,o) for o in g.tobj.iloc[0].split('|'))>=0.8]
            if fv and len(set(np.round(fv,6)))==1:
                for q in qs:
                    if ti.loc[q,'category'] in cats: out[q]=fv[0]/usc(q); why[q]='labfact'
                continue
        bases=sorted(set(g.base)); bv={}
        for b in bases:
            gb=g[g.base==b]; r=gb[gb.video_id==b]
            if base_mode=='base' and len(r): bv[b]=v3[r.index[0]]*usc(r.index[0])
            else: bv[b]=gmed([v3[q]*usc(q) for q in gb.index])
        if len(bases)==2 and max_spread2 and max(bv.values())/min(bv.values())>max_spread2: continue
        for q in qs:
            if ti.loc[q,'category'] not in cats: continue
            b=ti.loc[q,'base']
            others=[bv[x] for x in bases if x!=b]
            own=v3[q]*usc(q)
            if max_dev and len(others)>=2 and max(own/gmed(others),gmed(others)/own)>max_dev: continue   # likely a different object of the same name
            out[q]=gmed(others+[own])/usc(q); why[q]='labpool'
    return out, why
