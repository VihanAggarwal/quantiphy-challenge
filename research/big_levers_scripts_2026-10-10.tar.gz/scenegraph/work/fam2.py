from fam import *
import pickle
EXCLUDE_CLUSTERS={('internet_0019','simulation_0177'),('internet_0046','internet_0068')}  # verified by eye: different scenes / no shared objects
def frame_links():
    cl=pickle.load(open(W+'/work/frame_clusters.pkl','rb'))
    links=[]
    for c in cl:
        if tuple(c) in EXCLUDE_CLUSTERS: continue
        for b in c[1:]: links.append((c[0],b))
    return links
def same_render_pairs(th=0.99, mad_max=2.0):
    R=pd.read_pickle(W+'/work/aligned.pkl')
    out=set()
    for r in R.itertuples():
        if r.na==r.nb and min(r.ncc_aligned)>=th and max(r.mad_aligned)<=mad_max:
            out.add((r.a,r.b)); out.add((r.b,r.a))
    return out
def build():
    t=pd.read_pickle(W+'/work/T.pkl'); t['base']=t.video_id.map(base_id)
    t['fam'],L=families(t, frame_links())
    return t,L
