from fam import *
from qp.geometry import name_score
def tnum(x):
    try: return float(x)
    except: return None
def stated(t):
    """one row per (video, prior statement) from Claude's parsed spec + raw text"""
    P=t.drop_duplicates(['video_id','prior','pkind','pobj','pdim','ptime','pval'])[['video_id','base','fam','category','prior','pkind','pobj','pdim','ptime','pwin','pval','depth_info']]
    return P
def cands(t, min_name=0.5):
    P=stated(t)
    out=[]
    for r in t.itertuples():
        if r.tkind not in ('size','speed','acceleration'): continue
        c=P[(P.fam==r.fam)&(P.pkind==r.tkind)]
        for p in c.itertuples():
            ns=max([name_score(a,b) for a in str(r.tobj).split('|') for b in str(p.pobj).split('|')]+[0])
            if ns<min_name: continue
            if r.tkind=='size' and str(r.tdim)!=str(p.pdim): 
                dimok=False
            else: dimok=True
            out.append(dict(qid=r.qid,video_id=r.video_id,cat=r.category,src=r.video_source,question=r.question,tobj=r.tobj,tdim=r.tdim,ttime=r.ttime,twin=r.twin,
                            pvid=p.video_id,prior=p.prior,pobj=p.pobj,pdim=p.pdim,ptime=p.ptime,pwin=p.pwin,pval=p.pval,ns=round(ns,2),dimok=dimok,same_video=(p.video_id==r.video_id),
                            same_base=(base_id(p.video_id)==r.base),tunit=r.tunit,v3=r.v3,direct=r.direct))
    return pd.DataFrame(out)
