from series import *
from equiv import qkey_match
from qp.geometry import name_score
MOTION_PRIOR=re.compile(r'speed|velocit|accel',re.I)
def same_scenario(t, va, vb):
    """same base, or identical non-generic MOTION prior text (a size prior says nothing about the motion)"""
    if base_id(va)==base_id(vb): return True
    pa=t[t.video_id==va].prior.iloc[0]; pb=t[t.video_id==vb].prior.iloc[0]
    if not (MOTION_PRIOR.search(pa) and MOTION_PRIOR.search(pb)): return False
    pa,pb=prior_norm(pa),prior_norm(pb)
    return pa==pb and not re.search(r'gravit|=9\.[78]m',pa)
def equiv_groups(t):
    """for each qid: list of equivalent qids in its series (incl itself)"""
    t=t.reset_index(drop=True)
    vinfo={}
    eq={q:{q} for q in t.qid}
    why={}
    for f,g in t.groupby('fam'):
        if g.video_id.nunique()<2: continue
        rows=list(g.itertuples())
        for i,a in enumerate(rows):
            for b in rows[i+1:]:
                if a.video_id==b.video_id: continue
                if not qkey_match(a,b): continue
                if a.tkind!='size':
                    if not (same_scenario(t,a.video_id,b.video_id) or obj_depth_ok(t,a,b)): continue
                eq[a.qid].add(b.qid); eq[b.qid].add(a.qid)
    return eq
_dcache={}
def obj_depth_ok(t,a,b):
    from rules import obj_depth_identical
    k=(a.video_id,b.video_id,a.tobj,b.tobj)
    if k not in _dcache:
        try:
            _dcache[k]=bool(t[t.video_id==a.video_id].depth_info.iloc[0]) and bool(t[t.video_id==b.video_id].depth_info.iloc[0]) and obj_depth_identical(t,a.video_id,b.video_id,a.tobj.split('|')[0],b.tobj.split('|')[0])
        except Exception: _dcache[k]=False
    return _dcache[k]
