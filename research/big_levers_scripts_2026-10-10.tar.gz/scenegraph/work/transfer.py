from fam2 import *
from qp.geometry import name_score
def fnum(x):
    try:
        x=float(x); return x if math.isfinite(x) else None
    except: return None
def stated(t):
    t=t.assign(_pw=t.pwin.astype(str)); P=t.drop_duplicates(['video_id','prior','pkind','pobj','pdim','ptime','_pw','pval'])
    return P[['video_id','base','fam','category','video_source','prior','pkind','pobj','pdim','ptime','pwin','pval']]
def dimnorm(d):
    d=str(d or '').lower().strip()
    if d in ('body length',): return 'length'
    return d
def candidates(t, min_name=0.5):
    P=stated(t); sr=same_render_pairs(); L=depth_links(t)
    out=[]
    for r in t.itertuples():
        if r.tkind not in ('size','speed','acceleration'): continue
        c=P[(P.fam==r.fam)&(P.pkind==r.tkind)]
        for p in c.itertuples():
            ns=max([name_score(a,b) for a in str(r.tobj).split('|') for b in str(p.pobj).split('|')]+[0])
            if ns<min_name: continue
            # skip own prior of same question (identical prior text in same video) - can't be asked
            if r.tkind=='size':
                if dimnorm(r.tdim)!=dimnorm(p.pdim): continue
                ok_time=True
            else:
                tt,pt=fnum(r.ttime),fnum(p.ptime)
                pw=p.pwin if isinstance(p.pwin,(list,tuple)) else None
                tw=r.twin if isinstance(r.twin,(list,tuple)) else None
                if pt is None and pw is None: ok_time=True        # constant stated value
                elif pt is not None and tt is not None and abs(pt-tt)<1e-6: ok_time=True
                else: ok_time=False
            a,b=r.video_id,p.video_id
            link='same_video' if a==b else ('twin' if base_id(a)==base_id(b) else ('same_render' if (base_id(a),base_id(b)) in sr else ('depth' if (min(base_id(a),base_id(b)),max(base_id(a),base_id(b))) in L and len(L[(min(base_id(a),base_id(b)),max(base_id(a),base_id(b)))])>=2 else 'frame')))
            out.append(dict(qid=r.qid,video_id=a,cat=r.category,src=r.video_source,question=r.question,tkind=r.tkind,tobj=r.tobj,tdim=r.tdim,ttime=r.ttime,twin=r.twin,
                            pvid=b,prior=p.prior.replace('\n',' ; '),pobj=p.pobj,pdim=p.pdim,ptime=p.ptime,pwin=p.pwin,pval=p.pval,ns=round(ns,2),ok_time=ok_time,link=link,
                            tunit=r.target_unit,v3=r.v3,direct=r.direct,method=r.method))
    return pd.DataFrame(out)
