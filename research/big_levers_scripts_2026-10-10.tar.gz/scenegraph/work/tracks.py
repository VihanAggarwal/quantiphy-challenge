from load import *
from qp.geometry import name_score
_recs={}
def rec(v):
    if v not in _recs:
        try: _recs[v]=json.load(open(R+'/runs/test_v1_high_854/test/records/%s.json'%v))
        except Exception: _recs[v]=None
    return _recs[v]
def obj_tracks(v):
    r=rec(v)
    out={}
    if not r or not r.get('parsed'): return out, None
    W_=r['meta']['image_size'][0]
    for q in r['parsed']['questions']:
        for tr in q.get('tracks') or []:
            for o in tr.get('obs') or []:
                c=None
                if o.get('point'): c=o['point']
                elif o.get('box'): b=o['box']; c=[(b[0]+b[2])/2,(b[1]+b[3])/2]
                if c is None: continue
                out.setdefault(tr['object'].lower(),{}).setdefault(int(o['frame']),[]).append((c[0]/W_,c[1]/W_))
    return out, W_
def tracks_coincide(a, b, tol=0.015, min_common=2):
    """True if some object tracked in both clips has coinciding normalized centers at >=min_common common frames"""
    ta,_=obj_tracks(a); tb,_=obj_tracks(b)
    best=None
    for oa,fa in ta.items():
        for ob,fb in tb.items():
            if name_score(oa,ob)<0.8: continue
            common=sorted(set(fa)&set(fb))
            if len(common)<min_common: continue
            d=[min(np.hypot(p[0]-q[0],p[1]-q[1]) for p in fa[f] for q in fb[f]) for f in common]
            md=float(np.median(d))
            if best is None or md<best[0]: best=(md,oa,ob,len(common))
    return (best is not None and best[0]<tol), best
def obj_tracks_typed(v):
    r=rec(v); out={}
    if not r or not r.get('parsed'): return out
    W_=r['meta']['image_size'][0]
    for q in r['parsed']['questions']:
        for tr in q.get('tracks') or []:
            for o in tr.get('obs') or []:
                if o.get('point'): out.setdefault((tr['object'].lower(),'p'),{}).setdefault(int(o['frame']),[]).append((o['point'][0]/W_,o['point'][1]/W_))
                if o.get('box'):
                    b=o['box']; out.setdefault((tr['object'].lower(),'b'),{}).setdefault(int(o['frame']),[]).append(((b[0]+b[2])/2/W_,(b[1]+b[3])/2/W_))
    return out
def object_motion_identical(a, b, obj, tol=0.01, min_common=2, min_name=0.6, need_motion=True):
    ta=obj_tracks_typed(a); tb=obj_tracks_typed(b)
    best=None
    for (oa,ka),fa in ta.items():
        if name_score(oa,obj)<min_name: continue
        for (ob,kb),fb in tb.items():
            if kb!=ka or name_score(ob,obj)<min_name: continue
            common=sorted(set(fa)&set(fb))
            if len(common)<min_common: continue
            # object must move between the common frames (else it only proves the camera)
            pa=[np.mean(fa[f],axis=0) for f in common]
            span=max(np.hypot(*(np.array(p)-pa[0])) for p in pa)
            d=float(np.median([min(np.hypot(p[0]-q[0],p[1]-q[1]) for p in fa[f] for q in fb[f]) for f in common]))
            if need_motion and span<3*tol: continue
            if best is None or d<best[0]: best=(d,oa,ob,ka,len(common),span)
    return (best is not None and best[0]<tol), best
