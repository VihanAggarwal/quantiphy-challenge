from load import *
import itertools
from collections import defaultdict
class UF:
    def __init__(s): s.p={}
    def f(s,x):
        s.p.setdefault(x,x)
        while s.p[x]!=x: s.p[x]=s.p[s.p[x]]; x=s.p[x]
        return x
    def u(s,a,b): s.p[s.f(a)]=s.f(b)
def depth_links(t, min_digits=3):
    ent=defaultdict(set)
    for v,g in t[t.depth_info.str.len()>0].groupby('base'):
        for di in g.depth_info.unique():
            for num in re.findall(r'=\s*([0-9]+\.[0-9]{%d,})'%min_digits, di):
                ent[v].add(num)
    num2b=defaultdict(set)
    for b,s in ent.items():
        for n in s: num2b[n].add(b)
    links=defaultdict(set)
    for n,bs in num2b.items():
        for a,b in itertools.combinations(sorted(bs),2): links[(a,b)].add(n)
    return links
def families(t, extra_links=()):
    uf=UF()
    for b in t.base.unique(): uf.f(b)
    L=depth_links(t)
    for (a,b),ns in L.items():
        if len(ns)>=2: uf.u(a,b)
    for a,b in extra_links: uf.u(base_id(a),base_id(b))
    fam={b:uf.f(b) for b in t.base.unique()}
    return t.base.map(fam), L
