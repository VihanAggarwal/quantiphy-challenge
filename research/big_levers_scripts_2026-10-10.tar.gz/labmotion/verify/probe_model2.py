"""D3 only: which (static, motion) GT models reproduce probe-3 D3 = -0.011, and what each predicts for D3_labmotion_direct vs v3."""
import sys
import numpy as np, pandas as pd
sys.path.insert(0, '/home/user/quantiphy-challenge')
from qp.mra import item_scores
from qp.data import load_split
SP = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/'
T = load_split('test').set_index('qid')
R = pd.read_pickle(SP + 'big/labmotion/work/lab_k.pkl').set_index('qid')
ld = lambda p: pd.read_csv(p).set_index('id').parsed_value.astype(float)
v2 = ld('/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv')
p3 = ld('/home/user/quantiphy-challenge/submissions/trackA_probe3_s2maxext_d2denseoff_labdirect.csv')
var = ld(SP + 'big/labmotion/D3_labmotion_direct.csv')
MOT = ['speed', 'acceleration', 'displacement', 'path_length']
R = R[R.cat == 'D3'].copy()
R['v2'] = v2.loc[R.index]; R['p3'] = p3.loc[R.index]; R['var'] = var.loc[R.index]
mot = R.tk.isin(MOT).values
N = 969
rng = np.random.default_rng(1)
def fill(x, alt):
    x = x.copy(); bad = ~(np.isfinite(x) & (x > 0)); x[bad] = alt[bad]; return x
geo = R.v2.values  # v2 == v3 on D3 lab
direct = fill(R.direct.values, geo)
k1 = fill(R['k1'].values, geo)
rows = []
for sname, sc in [('geo', geo), ('direct', direct), ('gmean', np.sqrt(geo * direct))]:
  for ss in [0.15, 0.25, 0.35]:
    for mname, mc in [('geo', geo), ('direct', direct), ('gmean', np.sqrt(geo * direct)), ('direct*1.2', direct * 1.2), ('geo*1.3', geo * 1.3)]:
      for sm in [0.2, 0.35, 0.5]:
        center = np.where(mot, mc, sc); sig = np.where(mot, sm, ss)
        z = rng.standard_normal((300, len(R)))
        G = center[None] * np.exp(sig[None] * z)
        a = np.mean([np.nansum(item_scores(R.v2.values, g)) for g in G]) / N
        b = np.mean([np.nansum(item_scores(R.p3.values, g)) for g in G]) / N
        c = np.mean([np.nansum(item_scores(R['var'].values, g)) for g in G]) / N
        rows.append((sname, ss, mname, sm, round(b - a, 4), round(c - a, 4)))
df = pd.DataFrame(rows, columns=['static', 'sig_s', 'motion', 'sig_m', 'pred_p3_dD3', 'pred_variant_dD3'])
df['err'] = (df.pred_p3_dD3 + 0.011).abs()
pd.set_option('display.width', 200); pd.set_option('display.max_rows', 400)
print(df[df.err <= 0.004].sort_values('err').to_string())
