"""Verifier: predicted probe-3 deltas (v2 -> probe3, lab S3/D3 only) under GT hypotheses.
GT_i = center_i * exp(sigma*z). Motion center: K1 geometry, K1.5 geometry, c*direct. Static center: v2 (geometry) * LN(sig_s) or direct."""
import sys
import numpy as np, pandas as pd
sys.path.insert(0, '/home/user/quantiphy-challenge')
from qp.mra import item_scores
from qp.data import load_split
SP = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/'
T = load_split('test').set_index('qid')
R = pd.read_pickle(SP + 'big/labmotion/work/lab_k.pkl').set_index('qid')
ld = lambda p: pd.read_csv(p).set_index('id').parsed_value.astype(float)
v2 = ld('/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv')
p3 = ld('/home/user/quantiphy-challenge/submissions/trackA_probe3_s2maxext_d2denseoff_labdirect.csv')
MOT = ['speed', 'acceleration', 'displacement', 'path_length']
R = R[R.cat.isin(['S3', 'D3'])].copy()
R['v2'] = v2.loc[R.index]; R['p3'] = p3.loc[R.index]
R['mot'] = R.tk.isin(MOT)
ncat = T.category.value_counts()
rng = np.random.default_rng(0)
NS = 400
def fill(x, alt):
    x = x.copy(); bad = ~(np.isfinite(x) & (x > 0)); x[bad] = alt[bad]; return x
k1 = fill(R['k1'].values, R['v2'].values)
k15 = fill(R['k1.5'].values, k1 * 1.0)
fac = k15 / k1
direct = fill(R['direct'].values, R['v2'].values)
def pred_delta(center, sig):
    out = {}
    z = rng.standard_normal((NS, len(R)))
    G = center[None, :] * np.exp(sig[None, :] * z)
    for c in ['S3', 'D3']:
        m = (R.cat == c).values
        a = np.mean([np.nansum(item_scores(R.v2.values[m], g[m])) for g in G])
        b = np.mean([np.nansum(item_scores(R.p3.values[m], g[m])) for g in G])
        out[c] = (b - a) / ncat[c]
    return out
mot = R.mot.values
res = []
for sm_name, sm in [('geo', R.v2.values), ('direct', direct)]:
  for sig_s in [0.1, 0.2, 0.3]:
    for mname, mc in [('K1geo', k1), ('K15geo', k15), ('direct*1.0', direct), ('direct*1.2', direct * 1.2),
                      ('direct*1.4', direct * 1.4), ('direct*K15fac', direct * fac), ('v2*K15fac', R.v2.values * fac)]:
      for sig_m in [0.15, 0.3, 0.45]:
        center = np.where(mot, mc, sm)
        sig = np.where(mot, sig_m, sig_s)
        d = pred_delta(center, sig)
        res.append((sm_name, sig_s, mname, sig_m, round(d['S3'], 4), round(d['D3'], 4)))
df = pd.DataFrame(res, columns=['static_c', 'sig_s', 'motion_c', 'sig_m', 'dS3', 'dD3'])
df['err'] = np.hypot(df.dS3 - 0.012, df.dD3 + 0.011)
pd.set_option('display.width', 200); pd.set_option('display.max_rows', 400)
print(df.sort_values('err').head(25).to_string())
print(df[df.motion_c.str.contains('K15')].sort_values('err').head(12).to_string())
