import sys, json
import numpy as np, pandas as pd
sys.path.insert(0, '/home/user/quantiphy-challenge')
from qp.mra import item_scores
OUT = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/big/labmotion/'
base = pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_v3_best_per_category.csv')[['id', 'parsed_value']]
R = pd.read_pickle('lab_k.pkl').set_index('qid')
MOT = ['speed', 'acceleration', 'displacement', 'path_length']
known = pd.read_pickle('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/big/priors/known_lab.pkl').set_index('qid')
stats = {}

def build(name, cat, fn):
    df = base.copy().set_index('id')
    sel = R[(R.cat == cat) & R.tk.isin(MOT)]
    old = df.loc[sel.index, 'parsed_value'].astype(float)
    new = pd.Series({q: fn(r, old[q]) for q, r in sel.iterrows()})
    new = new.where(np.isfinite(new) & (new > 0), old)
    df.loc[new.index, 'parsed_value'] = new
    out = df.reset_index()[['id', 'parsed_value']]
    path = OUT + name + '.csv'
    out.to_csv(path, index=False)
    ch = (np.abs(np.log(new / old)) > 1e-9)
    kn = known.index.intersection(new.index)
    ks = {}
    if len(kn):
        ks = dict(n=int(len(kn)), old=round(float(np.nanmean(item_scores(old[kn], known.answer[kn]))), 3),
                  new=round(float(np.nanmean(item_scores(new[kn], known.answer[kn]))), 3))
    stats[name] = dict(csv=path, category=cat, answers_changed=int(ch.sum()),
                       median_ratio_changed=round(float(np.exp(np.median(np.log(new[ch] / old[ch])))), 3) if ch.any() else None,
                       known_rows_motion=ks)
    print(name, stats[name])

fac = lambda r: (r['k1.5'] / r['k1']) if (np.isfinite(r['k1']) and np.isfinite(r['k1.5']) and r['k1'] > 0) else 1.0
d_or = lambda r, old: r['direct'] if np.isfinite(r['direct']) and r['direct'] > 0 else old
build('S3_labmotion_K15', 'S3', lambda r, old: d_or(r, old) * fac(r))
build('D3_labmotion_K15', 'D3', lambda r, old: d_or(r, old) * fac(r))
build('D3_labmotion_direct', 'D3', lambda r, old: d_or(r, old))
json.dump(stats, open('build_stats.json', 'w'), indent=1)
