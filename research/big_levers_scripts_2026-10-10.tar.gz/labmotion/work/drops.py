import cv2, numpy as np, glob, os, sys
out = []
for p in sorted(glob.glob('/home/user/quantiphy-challenge/data/QuantiPhy/captured_*.mp4')):
    v = os.path.basename(p)[:-4].strip()
    c = cv2.VideoCapture(p)
    prev = None; e = []
    while True:
        ok, f = c.read()
        if not ok:
            break
        g = cv2.cvtColor(cv2.resize(f, (320, 180)), cv2.COLOR_BGR2GRAY).astype(np.float32)
        if prev is not None:
            e.append(np.mean(np.abs(g - prev)))
        prev = g
    e = np.array(e)
    # ratio of transition i (i -> i+1) energy to the median of its 4 neighbours
    rat = []
    for i in range(len(e)):
        nb = [e[j] for j in (i - 2, i - 1, i + 1, i + 2) if 0 <= j < len(e)]
        rat.append(e[i] / (np.median(nb) + 1e-6))
    rat = np.array(rat)
    top = np.argsort(-rat)[:3]
    out.append((v, len(e) + 1, [(int(i), round(float(rat[i]), 2)) for i in top], round(float(rat[11]), 2) if len(rat) > 11 else None, round(float(rat[35]), 2) if len(rat) > 35 else None))
    print(*out[-1], flush=True)
