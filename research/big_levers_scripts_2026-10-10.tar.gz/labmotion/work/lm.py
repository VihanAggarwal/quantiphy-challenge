"""Shared helpers for the lab-motion lever (read-only use of repo code + priors agent's cached anns)."""
import sys, pickle, math
from pathlib import Path
REPO = Path('/home/user/quantiphy-challenge'); sys.path.insert(0, str(REPO))
import numpy as np, pandas as pd
from qp import geometry as G
from qp.data import load_split
PSP = Path('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/big/priors')
LSP = Path('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/big/labmotion')
_d = None
def anns_post():
    global _d
    if _d is None:
        _d = pickle.load(open(PSP / 'lab_post.pkl', 'rb'))
    return _d['anns'], _d['meta']
def anns_raw():
    d = pickle.load(open(PSP / 'lab_raw.pkl', 'rb'))
    return d['anns'], d['meta']
_t = None
def test():
    global _t
    if _t is None:
        _t = load_split('test')
    return _t
def show(q, anns=None):
    anns = anns or anns_post()[0]
    a = anns[q]
    print(q, a.spec.target, '\n   prior', a.spec.prior, '\n   direct', a.direct_answer)
    for tr in a.tracks:
        ts = [o.t for o in tr.obs]
        print('   ', tr.role, tr.object, tr.source, tr.depth_name, len(ts), (round(min(ts),3), round(max(ts),3)) if ts else None)

# ---------------- H_f model: true camera f=722@1280, GT lateral coordinates scaled by K
KF = {'f1280': 722.0, 'K': 1.0}
_orig_pos = G._View.pos
def _pos_k(self, t, uv):
    P = _orig_pos(self, t, uv)
    if self.rng is None or KF['K'] == 1.0:
        return P
    P = np.array(P, float, copy=True)
    P[:, :2] *= KF['K']
    return P
G._View.pos = _pos_k
_fixed_f = {'W': 1280}
G._map_f = lambda fn, value, width, f_cam: KF['f1280'] * width / 1280.0

def solve_k(a, meta, K=1.0, f1280=722.0):
    KF['K'], KF['f1280'] = K, f1280
    W, H = meta['image_size']
    try:
        return G.solve(a.spec, a.tracks, (W, H), float(meta['fps']), camera_fov_deg=84.0,
                       seen_scale=float(meta.get('scale') or 1.0))
    finally:
        KF['K'] = 1.0

# ---------------- capture 3D tracks (K=1, f fixed) of prior / target inside solve
CAP = {}
_orig_measure = G._measure
def _cap_measure(q, a, b, va, vb, flags, tol, role, *args, **kw):
    try:
        if a is not None and a.rows and va.rng is not None:
            t, uv = a.points()
            if len(t):
                CAP[role] = (t, va.pos(t, uv))
    except Exception:
        pass
    return _orig_measure(q, a, b, va, vb, flags, tol, role, *args, **kw)
G._measure = _cap_measure

def tracks3d(a, meta):
    CAP.clear()
    r = solve_k(a, meta, 1.0)
    return dict(CAP), r

def treal_from_t(t, fps=24.0):
    n = np.round(np.asarray(t, float) * fps).astype(int)
    return (n + (n >= 12) + (n >= 36) + (n >= 60)) / 25.0
