"""Ball rolling down a slope: true acceleration from the slope's 3D line (depth_info ends + pixel ends)
and the ball's image position, then the stretch factor of the slope direction under lateral scaling K."""
import sys
import numpy as np
from blob import frames, track, treal
f = 722.0; C = np.array([640.0, 360.0])

def unit(px):
    r = np.array([(px[0] - C[0]) / f, (px[1] - C[1]) / f, 1.0])
    return r / np.linalg.norm(r)

def analyse(vid, hsv_lo, hsv_hi, start_frame, start_xy, rest_range, top_px, bot_px, r_top, r_bot, seg, min_area=60, max_jump=80,
            prior_t=None, prior_a=None, prior_tag=''):
    fr = frames(vid)
    res = track(fr, hsv_lo, hsv_hi, start_frame, start_xy, min_area=min_area, max_jump=max_jump)
    n = np.array(sorted(res)); a = np.array([res[i] for i in n])
    E1, E2 = r_top * unit(top_px), r_bot * unit(bot_px)
    d = E2 - E1
    B0 = rest_range * unit(a[n == start_frame][0][:2]) if start_frame in n else rest_range * unit(start_xy)
    lam = np.linspace(-0.2, 1.4, 3201)
    pts = B0[None, :] + lam[:, None] * d[None, :]
    proj = np.column_stack([C[0] + f * pts[:, 0] / pts[:, 2], C[1] + f * pts[:, 1] / pts[:, 2]])
    s = []
    for row in a:
        k = np.argmin(np.linalg.norm(proj - row[:2], axis=1))
        s.append(lam[k] * np.linalg.norm(d))
    s = np.array(s)
    m = (n >= seg[0]) & (n <= seg[1])
    out = {}
    for tb in ('real', 'video'):
        tt = treal(n[m]) if tb == 'real' else n[m] / 24.0
        best = None
        for t0 in np.arange(tt[0] - 0.3, tt[-1] - 0.1, 0.002):
            mm = tt > t0
            if mm.sum() < 4:
                continue
            x = (tt[mm] - t0) ** 2 / 2
            A = np.column_stack([x, np.ones(mm.sum())])
            coef, *_ = np.linalg.lstsq(A, s[m][mm], rcond=None)
            e = np.mean((A @ coef - s[m][mm]) ** 2)
            if best is None or e < best[0]:
                best = (e, t0, coef[0])
        out[tb] = best
    stretch = {K: np.linalg.norm(d * np.array([K, K, 1])) / np.linalg.norm(d) for K in (1.0, 1.25, 1.5, 1.75)}
    print(vid, 'slope len (K=1) %.3f m' % np.linalg.norm(d), 'dir', np.round(d / np.linalg.norm(d), 3))
    for i in np.where(m)[0]:
        print('   n=%d y=%.1f s=%.4f' % (n[i], a[i][1], s[i]))
    for tb, b in out.items():
        print('  %s time: a_true=%.3f t0=%.3f rms=%.4f' % (tb, b[2], b[1], np.sqrt(b[0])),
              ' | a_K: ' + ' '.join('K%.2f=%.3f' % (K, b[2] * st) for K, st in stretch.items()),
              ' | stated %s %s' % (prior_a, prior_tag))
    return out, stretch

def analyse_res(vid, res, start_frame, rest_range, top_px, bot_px, r_top, r_bot, seg, prior_a=None, prior_tag=''):
    n = np.array(sorted(res)); a = np.array([res[i] for i in n])
    E1, E2 = r_top * unit(top_px), r_bot * unit(bot_px)
    d = E2 - E1
    B0 = rest_range * unit(res[start_frame][:2])
    lam = np.linspace(-0.2, 1.6, 3601)
    pts = B0[None, :] + lam[:, None] * d[None, :]
    proj = np.column_stack([C[0] + f * pts[:, 0] / pts[:, 2], C[1] + f * pts[:, 1] / pts[:, 2]])
    s = np.array([lam[np.argmin(np.linalg.norm(proj - row[:2], axis=1))] * np.linalg.norm(d) for row in a])
    m = (n >= seg[0]) & (n <= seg[1])
    stretch = {K: np.linalg.norm(d * np.array([K, K, 1])) / np.linalg.norm(d) for K in (1.0, 1.25, 1.5, 1.75)}
    print(vid, 'slope len (K=1) %.3f m' % np.linalg.norm(d), 'dir', np.round(d / np.linalg.norm(d), 3))
    for tb in ('real', 'video'):
        tt = treal(n[m]) if tb == 'real' else n[m] / 24.0
        best = None
        for t0 in np.arange(tt[0] - 0.3, tt[-1] - 0.1, 0.002):
            mm = tt > t0
            if mm.sum() < 4:
                continue
            x = (tt[mm] - t0) ** 2 / 2
            A = np.column_stack([x, np.ones(mm.sum())])
            coef, *_ = np.linalg.lstsq(A, s[m][mm], rcond=None)
            e = np.mean((A @ coef - s[m][mm]) ** 2)
            if best is None or e < best[0]:
                best = (e, t0, coef[0])
        print('  %s time: a_true=%.3f t0=%.3f rms=%.4f' % (tb, best[2], best[1], np.sqrt(best[0])),
              ' | a_K: ' + ' '.join('K%.2f=%.3f' % (K, best[2] * st) for K, st in stretch.items()),
              ' | stated %s %s' % (prior_a, prior_tag))
    return n, s
