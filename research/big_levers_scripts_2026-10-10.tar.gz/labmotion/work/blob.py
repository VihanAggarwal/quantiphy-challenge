"""Colour-blob tracker: per frame, the connected component of an HSV range nearest the predicted position."""
import cv2, numpy as np, sys
VID = '/home/user/quantiphy-challenge/data/QuantiPhy/%s.mp4'

def frames(vid):
    c = cv2.VideoCapture(VID % vid)
    out = []
    while True:
        ok, f = c.read()
        if not ok:
            break
        out.append(f)
    return out

def track(fr, lo, hi, start_frame, start_xy, min_area=150, max_jump=120, blur=0, both_dirs=True, mask_fn=None):
    """Returns dict frame -> (cx, cy, w, h, area, d_eq)."""
    res = {}
    def find(i, pred):
        hsv = cv2.cvtColor(fr[i], cv2.COLOR_BGR2HSV)
        if isinstance(lo[0], (tuple, list)):
            m = np.zeros(hsv.shape[:2], np.uint8)
            for a, b in zip(lo, hi):
                m |= cv2.inRange(hsv, a, b)
        else:
            m = cv2.inRange(hsv, lo, hi)
        if mask_fn is not None:
            m = mask_fn(m, fr[i])
        m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        n, lab, st, cen = cv2.connectedComponentsWithStats(m)
        best = None
        for k in range(1, n):
            if st[k][4] < min_area:
                continue
            dd = np.hypot(cen[k][0] - pred[0], cen[k][1] - pred[1])
            if dd > max_jump:
                continue
            if best is None or dd < best[0]:
                best = (dd, k)
        if best is None:
            return None
        k = best[1]
        return (float(cen[k][0]), float(cen[k][1]), int(st[k][2]), int(st[k][3]), int(st[k][4]),
                float(2 * np.sqrt(st[k][4] / np.pi)))
    for rng in ([range(start_frame, len(fr))] + ([range(start_frame - 1, -1, -1)] if both_dirs else [])):
        pred, prev = start_xy, None
        for i in rng:
            r = find(i, pred)
            if r is None:
                continue
            res[i] = r
            if prev is not None:
                pred = (2 * r[0] - prev[0], 2 * r[1] - prev[1])
            else:
                pred = r[:2]
            prev = r
    return res

def treal(n):
    n = np.asarray(n)
    return (n + (n >= 12) + (n >= 36)) / 25.0

def to3d(res, f=722.0, W=1280, H=720, D=None, r_anchor=None, K=1.0):
    """res: frame -> (cx,cy,w,h,area,deq). Range from apparent size: r = f*D/deq (D from anchor (frame, range) if given).
    Returns n, t_real, P (N,3) with lateral scaled by K."""
    n = np.array(sorted(res))
    a = np.array([res[i] for i in n])
    d = a[:, 5]
    if D is None:
        fa, ra = r_anchor
        D = ra * res[fa][5] / f
    r = f * D / d
    ray = np.column_stack([(a[:, 0] - W / 2) / f, (a[:, 1] - H / 2) / f, np.ones(len(a))])
    P = ray / np.linalg.norm(ray, axis=1)[:, None] * r[:, None]
    P[:, :2] *= K
    return n, treal(n), P, D

def track_diff(fr, bg_frames, start_frame, start_xy, thr=25, min_area=40, max_jump=80, rng=None, exclude=None):
    """Moving blob by difference to a background (median of bg_frames); nearest to prediction.
    exclude: (x0,y0,x1,y1) box ignored (e.g. the ball's rest position)."""
    bg = np.median(np.stack([fr[i] for i in bg_frames]).astype(np.float32), axis=0)
    res = {}
    pred, prev = start_xy, None
    for i in (rng if rng is not None else range(start_frame, len(fr))):
        d = np.abs(fr[i].astype(np.float32) - bg).max(axis=2)
        m = (d > thr).astype(np.uint8) * 255
        if exclude is not None:
            x0, y0, x1, y1 = exclude
            m[y0:y1, x0:x1] = 0
        m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        n, lab, st, cen = cv2.connectedComponentsWithStats(m)
        best = None
        for k in range(1, n):
            if st[k][4] < min_area:
                continue
            dd = np.hypot(cen[k][0] - pred[0], cen[k][1] - pred[1])
            if dd > max_jump:
                continue
            if best is None or dd < best[0]:
                best = (dd, k)
        if best is None:
            continue
        k = best[1]
        r = (float(cen[k][0]), float(cen[k][1]), int(st[k][2]), int(st[k][3]), int(st[k][4]), float(2 * np.sqrt(st[k][4] / np.pi)))
        res[i] = r
        pred = (2 * r[0] - prev[0], 2 * r[1] - prev[1]) if prev is not None else r[:2]
        prev = r
    return res
