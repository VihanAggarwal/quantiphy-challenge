import sys,os
sys.path.insert(0,'/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/big/scenegraph/work')
os.chdir('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/big/scenegraph/work')
os.environ['EQF']='eq3.pkl'; os.environ['MINB']=sys.argv[1] if len(sys.argv)>1 else '3'
import io, contextlib
buf=io.StringIO()
with contextlib.redirect_stdout(buf):
    exec(open('lofo.py').read())
R['fact']=[A[A.qid==q].fact.iloc[0] for q in R.qid]
R['factkey']=R.fact.str.split('|').str[0]
g=R.groupby(['cat','factkey'])[['m_raw','m_K','m_P','m_KP']].agg(['mean']).round(2)
g['n']=R.groupby(['cat','factkey']).size()
print(g.to_string())
# equal weight per fact
print('per-fact equal weight (D3):', R[R.cat=='D3'].groupby('factkey')[['m_raw','m_K','m_P','m_KP']].mean().mean().round(3).to_dict())
print('per-fact equal weight (S3):', R[R.cat=='S3'].groupby('factkey')[['m_raw','m_K','m_P','m_KP']].mean().mean().round(3).to_dict())
print('row mean:', R.groupby('cat')[['m_raw','m_K','m_P','m_KP']].mean().round(3))
