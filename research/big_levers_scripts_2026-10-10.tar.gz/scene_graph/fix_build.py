"""Verifier rebuild of scene_graph variants with two lab-pooling fixes.
Reuses the investigator's (read-only) modules in big/scenegraph/work; writes only to big/scene_graph/.
Fix 1 (prop identity): skip lab groups whose object name is an ambiguous bare noun, i.e. another lab
  object name is the same word with a modifier ('ball' vs 'soccer ball'/'orange ball', 'cup' vs 'white cup',
  'toy' vs 'yellow toy', 'book' vs 'note book', 'person' vs 'left person'); frames show different balls
  under the bare name 'ball' (0001 yellow, 0002 small orange, 0010 orange pendulum, 0013/0014 slope ball).
Fix 2 (event consistency): the different-object guard is decided once per event (base) on the median of
  its renders, and applies to all its renders (was: per render, so 0054b white ball 5.35 was pooled
  to 3.8 while 0054bs/bx of the same event were skipped).
"""
import sys, os, json
W='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/big/scenegraph/work'
OUT='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/big/scene_graph'
sys.path.insert(0,W); os.chdir(W)
import build as B
from build import *
import labpool2
labpool2.ti=ti; labpool2.v3=v3
from labpool2 import lab_size_groups, lab_facts, usc
from rules import dimnorm
OUT='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/big/scene_graph'
from qp.geometry import name_score

lab=t[(t.video_source=='lab')&(t.tkind=='size')]
NAMES=sorted({x.lower().strip() for o in lab.tobj for x in str(o).split('|')})
def ambiguous(name):
    n=name.lower().strip()
    if ' ' in n: return False
    return any(m!=n and m.split()[-1]==n for m in NAMES)

def lab_pool_fixed(t, max_spread2=2.0, use_facts=True, cats=('S3','D3'), max_dev=1.6, log=None):
    out={}; why={}
    F=lab_facts(t)
    for k,qs in lab_size_groups(t).items():
        g=ti.loc[qs]
        if use_facts:
            fv=[si for (po,pd_,si,v) in F if dimnorm(pd_)==dimnorm(g.tdim.iloc[0]) and max(name_score(po,o) for o in g.tobj.iloc[0].split('|'))>=0.8]
            if fv and len(set(np.round(fv,6)))==1:
                for q in qs:
                    if ti.loc[q,'category'] in cats: out[q]=fv[0]/usc(q); why[q]='labfact'
                continue
        objs={x.lower().strip() for o in g.tobj for x in str(o).split('|')}
        if any(ambiguous(o) for o in objs):
            if log is not None: log.append(('skip_ambiguous',sorted(objs),len(qs)))
            continue
        bases=sorted(set(g.base)); bv={}
        for b in bases:
            gb=g[g.base==b]; r=gb[gb.video_id==b]
            bv[b]=v3[r.index[0]]*usc(r.index[0]) if len(r) else gmed([v3[q]*usc(q) for q in gb.index])
        if len(bases)==2 and max_spread2 and max(bv.values())/min(bv.values())>max_spread2: continue
        # event-level guard
        bad=set()
        for b in bases:
            others=[bv[x] for x in bases if x!=b]
            if not (max_dev and len(others)>=2): continue
            own=float(np.median([v3[q]*usc(q) for q in qs if ti.loc[q,'base']==b]))   # event verdict = its median render
            if max(own/gmed(others),gmed(others)/own)>max_dev: bad.add(b)
        if bad and log is not None: log.append(('skip_event',sorted(objs),sorted(bad)))
        for q in qs:
            if ti.loc[q,'category'] not in cats: continue
            b=ti.loc[q,'base']
            if b in bad: continue
            others=[bv[x] for x in bases if x!=b]; own=v3[q]*usc(q)
            out[q]=gmed(others+[own])/usc(q); why[q]='labpool'
    return out, why

def variant_fixed(cats, rule_K=False, rule_P=False, rule_LAB=False, log=None):
    new,why=variant(rule_T=False,rule_K=rule_K,rule_P=rule_P,rule_LAB=False,cats=cats)
    if rule_LAB:
        LP,lw=lab_pool_fixed(t,cats=('S3','D3','D2'),log=log)
        for q,v in LP.items():
            if ti.loc[q,'category'] in cats: new[q]=v; why[q]=lw[q]
    for r in A.itertuples():
        if r.cat in cats: new[r.qid]=r.value; why[r.qid]='T'
    return new,why

if __name__=='__main__':
    from evalknown import known_rows2
    known=known_rows2()
    res={}
    log=[]
    VARS={'D3_TKP_LABfix':(('D3',),dict(rule_K=True,rule_P=True,rule_LAB=True)),
          'D3_T_LABfix':(('D3',),dict(rule_LAB=True)),
          'S3_T_LABfix':(('S3',),dict(rule_LAB=True)),
          'D3_TP_LABfix':(('D3',),dict(rule_P=True,rule_LAB=True))}
    for name,(cats,cfg) in VARS.items():
        lg=[] if name=='D3_T_LABfix' else None
        new,why=variant_fixed(cats,log=log if name=='D3_T_LABfix' else None,**cfg)
        df=V3.copy(); cat=cats[0]
        m=df.id.map(lambda q: ti.loc[q,'category']==cat)
        df.loc[m,'parsed_value']=df.loc[m,'id'].map(new)
        path=f'{OUT}/{name}.csv'; df.to_csv(path,index=False)
        diff=~np.isclose(df.parsed_value.values,V3.parsed_value.values,rtol=1e-9)
        assert set(ti.loc[df.id[diff],'category'])<={cat}
        rules=pd.Series({q:w for q,w in why.items() if ti.loc[q,'category']==cat and not np.isclose(new[q],v3[q],rtol=1e-9)}).value_counts().to_dict()
        kq=[q for q in known if ti.loc[q,'category']==cat]
        m0=np.mean([mra(v3[q],known[q]) for q in kq]); m1=np.mean([mra(new[q],known[q]) for q in kq])
        res[name]=dict(csv=path,changed=int(diff.sum()),rules=rules,known_n=len(kq),known_v3=round(m0,4),known_new=round(m1,4))
        print(name,res[name])
    print('LOG',log)
    json.dump(res,open(OUT+'/fix_build_summary.json','w'),indent=1)
