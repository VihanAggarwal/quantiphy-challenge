import sys, glob, numpy as np, pandas as pd
sys.path.insert(0,'/home/user/quantiphy-challenge')
from qp.data import load_split
R='/home/user/quantiphy-challenge'
D='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/big/scene_graph'
t=load_split('test'); cat=dict(zip(t.qid,t.category))
V3=pd.read_csv(R+'/submissions/trackA_v3_best_per_category.csv')
print('v3 rows',len(V3), 'template cols', list(V3.columns))
tmpl=glob.glob(R+'/data/*template*')+glob.glob(R+'/*template*')+glob.glob(R+'/submissions/*template*')
print('templates',tmpl)
for f in sorted(glob.glob(D+'/*.csv')):
    df=pd.read_csv(f)
    ok_ids = list(df.id)==list(V3.id)
    v=df.parsed_value.values.astype(float)
    fin=np.isfinite(v).all() and (v>0).all()
    diff=~np.isclose(v,V3.parsed_value.values,rtol=1e-9,atol=0)
    cats=pd.Series([cat[i] for i in df.id[diff]]).value_counts().to_dict()
    r=v[diff]/V3.parsed_value.values[diff]
    print(f.split('/')[-1], len(df), list(df.columns), 'ids_same',ok_ids, 'finite_pos',fin, 'nchanged',diff.sum(), cats, 'ratio min/med/max', np.round([r.min(),np.median(r),r.max()],3) if diff.any() else None)
