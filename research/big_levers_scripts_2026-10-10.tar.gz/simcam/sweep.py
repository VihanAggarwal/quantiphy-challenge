"""f-sweep: prior measured and target value at fixed f grid (fov deg). Usage: sweep.py <anns.pkl> <raw|post> <out.pkl>"""
import sys, pickle, math
from pathlib import Path
REPO = Path('/home/user/quantiphy-challenge'); sys.path.insert(0, str(REPO))
import numpy as np, pandas as pd
from qp import geometry as G
d = pickle.load(open(sys.argv[1], 'rb')); anns = d[sys.argv[2]]; meta = d['meta']; df = d['df'].set_index('qid')
FF = {'f': None}
G._map_f = lambda fn, value, width, f_cam: FF['f']
FOVS = [6, 9, 13, 18, 25, 33, 40, 50, 60, 72, 85, 100]
rows = []
for q, a in anns.items():
    r = df.loc[q]; m = meta[r.video_id]; W, H = m['image_size']
    row = dict(qid=q, vid=r.video_id, src=r.video_source, cat=r.category, W=W, H=H, fps=float(m['fps']),
               prior=r.prior, question=r.question, pkind=a.spec.prior.kind, pval=a.spec.prior.value_si,
               pobj=';'.join(map(str, a.spec.prior.objects or [])), pdim=a.spec.prior.dimension,
               paxis=a.spec.prior.axis, ptime=a.spec.prior.time, pwin=a.spec.prior.window,
               tkind=a.spec.target.kind, tobj=';'.join(map(str, a.spec.target.objects or [])),
               tdim=a.spec.target.dimension, taxis=a.spec.target.axis, tunit=a.spec.target.unit,
               direct=a.direct_answer, conf=a.confidence)
    # free solve (no camera)
    ans = G.solve(a.spec, a.tracks, (W, H), float(m['fps']), seen_scale=float(m.get('scale') or 1.0))
    row.update(geo=ans.value, method=ans.method, flags=';'.join(ans.flags), f_own=ans.debug.get('f_px'),
               sens=ans.debug.get('f_sensitivity'), depth_prior=str(ans.debug.get('depth_prior')),
               depth_target=str(ans.debug.get('depth_target')), range_prior=ans.debug.get('range_prior_m'),
               range_target=ans.debug.get('range_target_m'))
    for fov in FOVS:
        f = (W / 2) / math.tan(math.radians(fov) / 2)
        FF['f'] = f
        an = G.solve(a.spec, a.tracks, (W, H), float(m['fps']), camera_fov_deg=fov,
                     seen_scale=float(m.get('scale') or 1.0))
        row[f'p{fov}'] = an.debug.get('prior_measured_si')
        row[f't{fov}'] = an.value
        row[f'fl{fov}'] = ';'.join(f for f in an.flags if f not in ('f_camera_prior',))
    rows.append(row)
R = pd.DataFrame(rows); R.to_pickle(sys.argv[3]); print(len(R))
