import pandas as pd, numpy as np
from evalset import *
R = pd.read_pickle('sw_fam2.pkl')
E = evalset().merge(R, on='qid')
E['cat'] = E.cat
res = {}
def score(col):
    return pd.Series(mra(E[col], E.answer), index=E.index)
for gcol in ['g_own', 'g_fam']:
    for tau in [0.1, 0.2, 0.3, 0.5, 9]:
        g, d = E[gcol], E.direct
        lr = np.log(g / d)
        b = np.where(np.isfinite(lr) & (lr.abs() < tau), np.sqrt(g * d), d)
        E[f'b_{gcol}_{tau}'] = b
cols = ['direct', 'g_own', 'g_fam'] + [c for c in E.columns if c.startswith('b_')]
S = pd.DataFrame({c: score(c) for c in cols}); S['set'] = E.set; S['cat'] = E.cat; S['tkind'] = E.tkind
print(S.groupby(['set','cat'])[cols].mean().round(3).T)
print(S.groupby(['tkind'])[cols].mean().round(3).T)
