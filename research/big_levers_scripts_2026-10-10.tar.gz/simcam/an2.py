import sys, math
import pandas as pd, numpy as np
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500)
R = pd.read_pickle('sw_post.pkl')
FOVS = [6, 9, 13, 18, 25, 33, 40, 50, 60, 72, 85, 100]
cg = pd.read_csv('camgroups.csv').set_index('vid').cam
R['cam'] = R.vid.map(cg)
def fov_at(r, target):
    v = np.array([r[f't{f}'] for f in FOVS], float)
    if not np.isfinite(v).all() or (v <= 0).any() or not (target > 0): return np.nan
    lv = np.log(v); lt = math.log(target); lf = np.log(np.tan(np.radians(FOVS)/2))
    for i in range(len(FOVS)-1):
        a, b = lv[i]-lt, lv[i+1]-lt
        if a*b <= 0 and a != b: return float(np.degrees(2*np.arctan(np.exp(lf[i]+(lf[i+1]-lf[i])*a/(a-b)))))
    return np.nan
R['fov_dir'] = R.apply(lambda r: fov_at(r, r.direct), axis=1)
R['fov_own'] = np.where(R.method == '3d_focal_from_prior', np.degrees(2*np.arctan(R.W/2/R.f_own)), np.nan)
R.to_pickle('sw_post2.pkl')
lt = lambda x: np.log(np.tan(np.radians(x)/2))
def agg(g):
    fd = g.fov_dir.dropna()
    return pd.Series(dict(cat=g.cat.iloc[0], cam=g.cam.iloc[0], pk=g.pkind.iloc[0][:4], sens=round(g.sens.median(),2), n=len(g),
        fov_own=round(g.fov_own.median(),1), nd=len(fd), fov_dir=round(fd.median(),1) if len(fd) else np.nan,
        sd_dir=round(float(np.std(lt(fd))),2) if len(fd)>1 else np.nan))
A = R[R.tkind.isin(['size'])].groupby('vid').apply(agg)
print(A.to_string())
