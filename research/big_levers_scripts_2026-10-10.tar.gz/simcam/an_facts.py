import sys, math
sys.path.insert(0, '/home/user/quantiphy-challenge')
import pandas as pd, numpy as np
from qp.mra import item_scores
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500); pd.set_option('display.max_colwidth', 45)
R = pd.read_pickle(sys.argv[1] if len(sys.argv) > 1 else 'sw_post.pkl')
F = pd.read_pickle('facts_sg.pkl'); F = F[F.cat.isin(['S3','D3']) & ~F.conflict][['qid','value','line','why']].rename(columns={'value':'answer'})
K = pd.read_pickle('known3d.pkl')[['qid','answer']]; K['line']='VAL'; K['why']='val'
E = pd.concat([F, K[~K.qid.isin(F.qid)]])
M = E.merge(R, on='qid')
M['fov_own'] = np.degrees(2*np.arctan(M.W/2/M.f_own))
sc = lambda c: item_scores(M[c].fillna(0).values, M.answer.values)
M['blend'] = np.where(M.geo.notna() & (M.geo > 0), np.sqrt(M.direct * M.geo.clip(lower=1e-9)), M.direct)
for c in ['direct', 'geo', 'blend']: M['s_'+c] = sc(c)
M['grp'] = np.where(M.line=='VAL', 'val', 'fact')
print(M.groupby(['grp','cat'])[['s_direct','s_geo','s_blend']].agg(['mean']).round(3), M.groupby(['grp','cat']).size())
print(M[M.grp=='fact'][['qid','vid','tkind','question','answer','direct','geo','fov_own','s_direct','s_geo','method']].round(3).to_string())
