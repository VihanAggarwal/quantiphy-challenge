import sys, re
sys.path.insert(0, '/home/user/quantiphy-challenge')
import pandas as pd, numpy as np
from qp.data import load_split
v = load_split('val_hires'); t = load_split('test')
norm = lambda s: re.sub(r'[^a-z0-9.]+', ' ', str(s).lower().replace('？','?')).strip()
v['k'] = v.video_id + '|' + v.question.map(norm); t['k'] = t.video_id + '|' + t.question.map(norm)
m = v.merge(t[['k', 'qid']], on='k', suffixes=('_val', ''))
m = m[(m.video_type.str[1] == '3') & (m.video_source != 'lab')]
print(len(m), 'of', ((v.video_type.str[1] == '3') & (v.video_source != 'lab')).sum())
m[['qid', 'qid_val', 'video_id', 'category', 'question', 'answer']].to_pickle('known3d.pkl')
# unmatched
vv = v[(v.video_type.str[1] == '3') & (v.video_source != 'lab')]
print(vv[~vv.qid.isin(m.qid_val)][['qid','video_id','question']].to_string())
