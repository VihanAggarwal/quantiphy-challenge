import sys, math
sys.path.insert(0, '/home/user/quantiphy-challenge')
import pandas as pd, numpy as np
from qp.mra import item_scores
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500); pd.set_option('display.max_colwidth', 45)
R = pd.read_pickle(sys.argv[1] if len(sys.argv) > 1 else 'sw_post.pkl')
K = pd.read_pickle('known3d.pkl')
FOVS = [6, 9, 13, 18, 25, 33, 40, 50, 60, 72, 85, 100]
M = K.merge(R, on='qid')
def fov_needed(r):
    v = np.array([r[f't{f}'] for f in FOVS], float)
    if not np.isfinite(v).all() or (v <= 0).any(): return np.nan
    lv = np.log(v); lt = math.log(r.answer); lf = np.log(np.tan(np.radians(FOVS)/2))
    for i in range(len(FOVS)-1):
        a, b = lv[i]-lt, lv[i+1]-lt
        if a*b <= 0 and a != b: return float(np.degrees(2*np.arctan(np.exp(lf[i]+(lf[i+1]-lf[i])*a/(a-b)))))
    return np.nan
M['fov_need'] = M.apply(fov_needed, axis=1)
M['fov_own'] = np.degrees(2*np.arctan(M.W/2/M.f_own))
M['s_dir'] = item_scores(M.direct.fillna(0).values, M.answer.values)
M['s_geo'] = item_scores(M.geo.fillna(0).values, M.answer.values)
M['s_40'] = item_scores(M.t40.fillna(0).values, M.answer.values)
print(M[['qid','video_id','tkind','tdim','question_x','answer','direct','geo','t40','fov_own','fov_need','s_dir','s_geo','s_40','method']].round(3).to_string())
print(M.groupby('video_id')[['s_dir','s_geo','s_40']].mean().round(3))
print(M[['s_dir','s_geo','s_40']].mean())
