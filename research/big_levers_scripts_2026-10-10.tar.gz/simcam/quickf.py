import sys, pickle, math
sys.path.insert(0, '/home/user/quantiphy-challenge')
import numpy as np, pandas as pd
from qp import geometry as G
d = pickle.load(open('anns_test.pkl', 'rb')); anns = d['raw']; meta = d['meta']; df = d['df'].set_index('qid')
rows = []
for q, a in anns.items():
    r = df.loc[q]
    if a.spec.prior.kind != 'size': continue
    m = meta[r.video_id]; W, H = m['image_size']
    groups = G._depth_groups(a.spec.depth)
    pt = [t for t in a.tracks if t.role == 'prior']
    if not pt or not pt[0].obs: continue
    tr = pt[0]
    fn = G.match_depth([tr.depth_name] if tr.depth_name else [tr.object, *(a.spec.prior.objects[:1])], groups)
    if fn is None:
        fn = G.match_depth([tr.object, *(a.spec.prior.objects[:1])], groups)
    for o in tr.obs:
        e = o.extent
        if e is None and o.box is not None:
            b = o.box; dim = a.spec.prior.dimension
            e = [[b[0], b[1]], [b[0], b[3]]] if dim == 'height' else [[b[0], b[1]], [b[2], b[1]]]
        if e is None: continue
        L = math.hypot(e[1][0]-e[0][0], e[1][1]-e[0][1])
        rng = float(fn(np.array([o.t]))[0]) if fn is not None else np.nan
        rows.append(dict(qid=q, vid=r.video_id, W=W, H=H, t=o.t, L=L, rng=rng, pval=a.spec.prior.value_si,
                         pdim=a.spec.prior.dimension, cx=(e[0][0]+e[1][0])/2, cy=(e[0][1]+e[1][1])/2))
R = pd.DataFrame(rows)
R['f'] = R.L * R.rng / R.pval
R['fW'] = R.f / R.W
R['fov'] = np.degrees(2*np.arctan(0.5/R.fW))
g = R.groupby('vid').agg(W=('W','first'), H=('H','first'), n=('f','size'), nq=('qid','nunique'), fW=('fW','median'),
                         fWsd=('fW', lambda x: np.std(np.log(x))), fov=('fov','median'), pval=('pval','first'), pdim=('pdim','first'))
pd.set_option('display.width', 200)
print(g.round(3).to_string())
R.to_pickle('quickf.pkl')
