import pandas as pd, numpy as np
from lib import *
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500)
R = pd.read_pickle('sw_fam2.pkl')
C = pd.read_pickle('clips_loo.pkl').set_index('vid')
anch = C[(C.pk == 'size') & (C.sens > 0.8) & C.fov_own.notna()]
famA = anch.groupby('fam').lt_own.median().map(fov_from_lt)
R['fov_A'] = R.fam.map(famA)
R['g_A'] = R.apply(lambda r: at(r, r.fov_A), axis=1)
R.to_pickle('sw_fam3.pkl')
out = []
for (f, e), g in R[R.tkind == 'size'].groupby(['fam', 'eq']):
    if g.base.nunique() < 2: continue
    row = dict(fam=f, eq=e)
    for c in ['direct', 'g_own', 'g_A']:
        x = np.log(g[c].where(g[c] > 0)).dropna(); row[c] = float(np.std(x)) if len(x) >= 2 else np.nan
    out.append(row)
D = pd.DataFrame(out)
print(D.groupby('fam')[['direct','g_own','g_A']].mean().round(3).join(D.groupby('fam').size().rename('ng')).join(famA.round(1).rename('fovA')))
# per D3 clip: direct-implied fov vs anchor
x = R[(R.cat == 'D3') & R.fov_A.notna()].groupby('vid').agg(fam=('fam','first'), fovA=('fov_A','first'), fov_own=('fov_own','median'),
      fov_dir=('fov_dir','median'), n=('qid','size'))
print(x.round(1).to_string())
