import sys
sys.path.insert(0, '/home/user/quantiphy-challenge')
import pandas as pd, numpy as np, math
from lib import *
from evalset import mra
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500)
R = pd.read_pickle('sw_fam2.pkl')
cg = pd.read_csv('camgroups.csv').set_index('vid').cam
R['cam'] = R.vid.map(cg)
# per clip: own fov (solve p(fov) = pval) using median prior measurement across questions at each fov
rows = []
for v, g in R.groupby('vid'):
    p = {f: np.nanmedian(g[f'p{f}'].astype(float)) if g[f'p{f}'].notna().any() else np.nan for f in FOVS}
    row = dict(vid=v, fam=g.fam.iloc[0], cam=g.cam.iloc[0], base=g.base.iloc[0], W=g.W.iloc[0], H=g.H.iloc[0], cat=g.cat.iloc[0],
               pk=g.pkind.iloc[0], pval=g.pval.iloc[0], sens=g.sens.median(), **{f'p{f}': p[f] for f in FOVS})
    row['fov_own'] = solve_fov(row, row['pval'], 'p')
    rows.append(row)
C = pd.DataFrame(rows)
C['lt_own'] = C.fov_own.map(lambda x: lt(x) if np.isfinite(x) else np.nan)
good = C[(C.sens > 0.8) & C.lt_own.notna()]
print('clips', len(C), 'good', len(good))
print('global median fov over good clips', fov_from_lt(good.lt_own.median()), 'IQR', [round(fov_from_lt(x),1) for x in good.lt_own.quantile([.25,.75])])
# LOO calibration strategies (exclude same base i.e. twin too)
def loo(c, key):
    pool = good[(good.base != c.base)]
    if key == 'global': pool = pool
    elif key == 'res': pool = pool[(pool.W == c.W) & (pool.H == c.H)]
    else: pool = pool[pool[key] == c[key]]
    if len(pool) == 0: return np.nan
    return fov_from_lt(pool.lt_own.median())
for key in ['global', 'res', 'fam', 'cam']:
    C['fov_' + key] = C.apply(lambda c: loo(c, key), axis=1)
    C['pred_' + key] = C.apply(lambda c: at(c, c['fov_' + key], 'p'), axis=1)
C['fov_def'] = 39.6
C['pred_def'] = C.apply(lambda c: at(c, 39.6, 'p'), axis=1)
for key in ['global', 'res', 'fam', 'cam', 'def']:
    m = C['pred_' + key].notna() & C.pval.notna()
    s = mra(C.loc[m, 'pred_' + key], C.loc[m, 'pval'])
    sub = C[m].copy(); sub['s'] = s
    print(key, 'n', m.sum(), 'MRA', round(s.mean(), 3), '| size priors', round(sub[sub.pk=='size'].s.mean(), 3), sub[sub.pk=='size'].shape[0],
          '| motion', round(sub[sub.pk!='size'].s.mean(), 3), sub[sub.pk!='size'].shape[0])
C.to_pickle('clips_loo.pkl')
print(C[['vid','fam','pk','sens','fov_own','fov_res','fov_fam','fov_cam','pval','pred_fam','pred_cam','pred_def']].round(2).to_string())
