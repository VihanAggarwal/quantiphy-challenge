"""frame.py vid frame_idx [maxside] -> img/<vid>_<f>.jpg"""
import sys, cv2
sys.path.insert(0,'/home/user/quantiphy-challenge')
from qp.data import _video_index, TEST_DIR
vid, k = sys.argv[1], int(sys.argv[2]); ms = int(sys.argv[3]) if len(sys.argv)>3 else 900
p = _video_index(TEST_DIR)[vid]
cap = cv2.VideoCapture(str(p)); cap.set(cv2.CAP_PROP_POS_FRAMES, k); ok, im = cap.read()
h, w = im.shape[:2]; s = ms / max(h, w)
im = cv2.resize(im, (int(w*s), int(h*s)), interpolation=cv2.INTER_AREA)
out = f'/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/big/simcam/img/{vid}_{k}.jpg'
cv2.imwrite(out, im); print(out, w, h)
