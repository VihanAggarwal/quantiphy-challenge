import sys
sys.path.insert(0, '/home/user/quantiphy-challenge')
import pandas as pd, numpy as np
from qp.mra import item_scores
def evalset():
    F = pd.read_pickle('facts_sg.pkl'); F = F[F.cat.isin(['S3','D3']) & ~F.conflict][['qid','value','line']].rename(columns={'value':'answer'})
    F['set'] = 'fact'
    K = pd.read_pickle('known3d.pkl')[['qid','answer']]; K['line'] = 'VAL'; K['set'] = 'val'
    return pd.concat([F, K[~K.qid.isin(F.qid)]], ignore_index=True)
def mra(v, a): return item_scores(np.nan_to_num(np.asarray(v, float), nan=0.0), np.asarray(a, float))
