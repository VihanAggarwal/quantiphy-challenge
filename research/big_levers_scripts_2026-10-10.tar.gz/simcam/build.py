"""Build anns (raw + post) for 3D non-lab questions. Usage: build.py <split> <records_dir> <out.pkl>"""
import sys, pickle
from pathlib import Path
REPO = Path('/home/user/quantiphy-challenge')
sys.path.insert(0, str(REPO)); sys.path.insert(0, str(REPO / 'scripts'))
import run_claude as rc
from qp import claude_annotate as ca
from qp.data import load_split
W = Path('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/big/simcam')
split, recdir, out = sys.argv[1], Path(sys.argv[2]), sys.argv[3]
df = load_split(split)
df = df[(df.video_type.str[1] == '3') & (df.video_source != 'lab')]
recs = rc.load_records(recdir)
recs = {k: v for k, v in recs.items() if k in set(df.video_id)}
recs = rc.prepare_records(df, recs)
raw = ca.load_annotations(recs)
raw = {q: a for q, a in raw.items() if q in set(df.qid)}
import copy
post = copy.deepcopy(raw)
log = []
rc.post_steps(post, df, recs, refine_priors=True, dense='motion', dense_cache=W / 'dense_cache' / split,
              dense_workers=1, dense_log=log)
meta = {v: r['meta'] for v, r in recs.items()}
pickle.dump({'raw': raw, 'post': post, 'meta': meta, 'df': df}, open(out, 'wb'))
print('saved', len(raw), len(post), 'dense log', len(log))
