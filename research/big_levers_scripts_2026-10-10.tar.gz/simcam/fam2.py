"""Families v2: twins + camgroups + scenegraph series + text links (>=2 shared normalized questions of >=3 tokens,
excluding pairs whose shared questions are all generic 'dim + object' of <=3 tokens)."""
import re, sys, json, math
sys.path.insert(0, '/home/user/quantiphy-challenge')
import pandas as pd, numpy as np
from collections import defaultdict
R = pd.read_pickle('sw_fam.pkl')
base = lambda v: re.sub(r'_segmented$', '', v)
cg = pd.read_csv('camgroups.csv').set_index('vid').cam
sf = json.load(open('../scenegraph/families.json'))['series_families']
bases = sorted(R.base.unique()); parent = {b: b for b in bases}
def find(x):
    while parent[x] != x: parent[x] = parent[parent[x]]; x = parent[x]
    return x
def union(a, b):
    if a in parent and b in parent: parent[find(a)] = find(b)
for v in R.vid.unique(): union(base(v), base(cg[v]))
for k, d in sf.items():
    bs = [b for b in d['bases'] if b in parent]
    for b in bs[1:]: union(b, bs[0])
qb = defaultdict(set)
for r in R.itertuples(): qb[r.qn].add(r.base)
pair = defaultdict(list)
for q, bs in qb.items():
    bs = sorted(bs)
    for i in range(len(bs)):
        for j in range(i+1, len(bs)): pair[(bs[i], bs[j])].append(q)
for (a, b), qs in pair.items():
    if len(qs) >= 2 and max(len(q.split()) for q in qs) >= 4: union(a, b)
R['fam'] = R.base.map(find)
from qp.geometry import name_score
eq = {}; k = 0
for f, g in R.groupby('fam'):
    items = list(g.itertuples()); lab = {}
    for i, a in enumerate(items):
        if a.qid in lab: continue
        lab[a.qid] = k
        for b in items[i+1:]:
            if b.qid in lab or b.tkind != a.tkind: continue
            same = a.qn == b.qn
            if not same and a.tkind == 'size':
                ns = max([name_score(x, y) for x in str(a.tobj).split(';') for y in str(b.tobj).split(';')] + [0])
                same = ns >= 0.8 and str(a.tdim).lower() == str(b.tdim).lower() and str(a.tdim) != ''
            if same: lab[b.qid] = k
        k += 1
    eq.update(lab)
R['eq'] = R.qid.map(eq)
R.to_pickle('sw_fam.pkl')
for f, g in R.groupby('fam'):
    if g.base.nunique() > 1: print(f, sorted(g.base.unique()))
