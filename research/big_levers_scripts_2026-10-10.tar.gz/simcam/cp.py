"""Camera pooling (CP): clips sharing the exact camera (twins / identical depth values) share f.
Per clip: own f (clip median of the free prior solve), weight w (size prior & sens>0.8: 1; motion prior & sens>0.8: wm; else 0).
f_pool = weighted median of members' f. Direct answers rescaled by tan(fov_pool/2)/tan(fov_ref/2), where fov_ref is the clip's own fov
(or, with ref='dir', Claude's implied fov) when |log ratio| > theta."""
import sys
import pandas as pd, numpy as np, math
from lib import *
from evalset import evalset, mra
R = pd.read_pickle('sw_fam3.pkl')
cg = pd.read_csv('camgroups.csv').set_index('vid').cam
R['cam'] = R.vid.map(cg)
def wmed(vals, ws):
    o = np.argsort(vals); v = np.asarray(vals)[o]; w = np.asarray(ws)[o]; c = np.cumsum(w)
    return float(v[np.searchsorted(c, c[-1] / 2)])
def build(wm=0.5, theta=0.1, ref='own', kinds=('size','distance','speed','displacement','path_length','acceleration'), min_members=2):
    clip = R.groupby('vid').agg(cam=('cam','first'), fov=('fov_own','median'), sens=('sens','median'), pk=('pkind','first'),
                                fdir=('fov_dir','median'))
    clip['w'] = np.where(clip.fov.notna() & (clip.sens > 0.8), np.where(clip.pk == 'size', 1.0, wm), 0.0)
    pool = {}
    for c, g in clip.groupby('cam'):
        g = g[g.w > 0]
        if len(g) < min_members: continue
        pool[c] = fov_from_lt(wmed(g.fov.map(lt).values, g.w.values))
    clip['fov_pool'] = clip.cam.map(pool)
    reff = clip.fov if ref == 'own' else clip.fdir
    clip['ratio'] = [math.tan(math.radians(p)/2)/math.tan(math.radians(o)/2) if np.isfinite(p) and np.isfinite(o) else 1.0
                     for p, o in zip(clip.fov_pool, reff)]
    clip.loc[np.abs(np.log(clip.ratio)) <= theta, 'ratio'] = 1.0
    out = R[['qid','vid','cat','tkind','direct']].copy()
    out['ratio'] = out.vid.map(clip.ratio).fillna(1.0)
    out.loc[~out.tkind.isin(kinds), 'ratio'] = 1.0
    out['cp'] = out.direct * out.ratio
    return out, clip
if __name__ == '__main__':
    E = evalset()
    for ref in ['own', 'dir']:
        for wm in [0.0, 0.5, 1.0]:
            for theta in [0.05, 0.1, 0.2, 0.4]:
                out, clip = build(wm, theta, ref)
                M = E.merge(out, on='qid')
                M['s0'] = mra(M.direct, M.answer); M['s1'] = mra(M.cp, M.answer)
                ch = M[M.ratio != 1.0]
                g = M.groupby(['set','cat'])[['s0','s1']].mean()
                print(ref, wm, theta, 'changed test', int((out.ratio != 1).sum()), 'changed eval', len(ch),
                      ' '.join(f'{k[0]}-{k[1]}:{r.s0:.3f}->{r.s1:.3f}' for k, r in g.iterrows()))
