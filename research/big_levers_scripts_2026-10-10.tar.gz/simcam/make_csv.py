import sys
import pandas as pd, numpy as np
from evalset import evalset, mra
sys.path.insert(0, '/home/user/quantiphy-challenge')
from qp.data import load_split
V3 = '/home/user/quantiphy-challenge/submissions/trackA_v3_best_per_category.csv'
base = pd.read_csv(V3)
t = load_split('test').set_index('qid')
R = pd.read_pickle('sw_fam3.pkl').set_index('qid')
T = pd.read_pickle('csc_clips.pkl').set_index('vid')
KINDS = ('size', 'distance', 'displacement', 'path_length', 'speed', 'acceleration')
hits = T[T.hit]
new = base.copy()
log = []
for q, r in R.iterrows():
    if r.vid not in hits.index or r.tkind not in KINDS or t.loc[q, 'category'] != 'D3': continue
    i = new.index[new.id == q][0]
    old = new.at[i, 'parsed_value']
    if not np.isclose(old, r.direct, rtol=1e-6):
        print('note: v3 != direct for', q, old, r.direct)
    val = old * hits.loc[r.vid, 'r_dir']
    new.at[i, 'parsed_value'] = val
    log.append(dict(qid=q, vid=r.vid, question=r.question, old=old, new=val))
L = pd.DataFrame(log)
pd.set_option('display.width', 200); pd.set_option('display.max_colwidth', 70)
print(L.round(3).to_string())
out = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/big/simcam/D3_camera_consistency.csv'
new.to_csv(out, index=False)
chg = (new.parsed_value != base.parsed_value)
cats = t.loc[new.id[chg], 'category'].value_counts().to_dict()
print('changed', int(chg.sum()), cats, 'median ratio', float(np.median(new.parsed_value[chg] / base.parsed_value[chg])))
E = evalset().merge(L, on='qid')
print(E[['qid','line','answer','old','new']])
print('eval rows', len(E), 'MRA old', mra(E.old, E.answer).mean(), 'new', mra(E.new, E.answer).mean())
