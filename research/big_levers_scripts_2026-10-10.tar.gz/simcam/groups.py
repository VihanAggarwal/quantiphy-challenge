import re, sys
sys.path.insert(0, '/home/user/quantiphy-challenge')
import pandas as pd, numpy as np
from collections import defaultdict
from qp.data import load_split
t = load_split('test'); t = t[(t.video_type.str[1] == '3') & (t.video_source != 'lab')]
base = lambda v: re.sub(r'_segmented$', '', v)
ent = defaultdict(set)
for v, g in t.groupby('video_id'):
    for di in g.depth_info.unique():
        for num in re.findall(r'=\s*([0-9]+\.[0-9]{3,})', di):
            ent[base(v)].add(num)
bases = sorted(set(map(base, t.video_id)))
parent = {b: b for b in bases}
def find(x):
    while parent[x] != x: parent[x] = parent[parent[x]]; x = parent[x]
    return x
num2b = defaultdict(set)
for b, s in ent.items():
    for n in s: num2b[n].add(b)
for n, bs in num2b.items():
    bs = sorted(bs)
    for a in bs[1:]: parent[find(a)] = find(bs[0])
grp = {b: find(b) for b in bases}
G = pd.DataFrame({'vid': sorted(t.video_id.unique())}); G['base'] = G.vid.map(base); G['cam'] = G.base.map(grp)
G.to_csv('camgroups.csv', index=False)
for c, g in G.groupby('cam'):
    if g.base.nunique() > 1: print(c, sorted(g.base.unique()))
