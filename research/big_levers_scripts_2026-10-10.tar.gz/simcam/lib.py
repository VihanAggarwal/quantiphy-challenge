import math, numpy as np, pandas as pd
FOVS = [6, 9, 13, 18, 25, 33, 40, 50, 60, 72, 85, 100]
LT = np.log(np.tan(np.radians(FOVS) / 2))
def lt(fov): return math.log(math.tan(math.radians(fov) / 2))
def fov_from_lt(x): return math.degrees(2 * math.atan(math.exp(x)))
def at(row, fov, pre='t'):
    """value of column series pre{fov} at an arbitrary fov (log-log interp in tan(fov/2))."""
    if fov is None or not np.isfinite(fov): return np.nan
    v = np.array([row[f'{pre}{f}'] for f in FOVS], float)
    ok = np.isfinite(v) & (v > 0)
    if ok.sum() < 2: return np.nan
    x = lt(fov)
    xs, ys = LT[ok], np.log(v[ok])
    if x < xs[0] or x > xs[-1]:
        i = 0 if x < xs[0] else -2
        s = (ys[i+1]-ys[i])/(xs[i+1]-xs[i]); return float(np.exp(ys[i] + s*(x-xs[i])))
    return float(np.exp(np.interp(x, xs, ys)))
def solve_fov(row, target, pre='t'):
    """fov at which pre-series equals target (first crossing), nan if none."""
    v = np.array([row[f'{pre}{f}'] for f in FOVS], float)
    if not (target and target > 0): return np.nan
    ok = np.isfinite(v) & (v > 0)
    xs, ys = LT[ok], np.log(v[ok]) - math.log(target)
    for i in range(len(xs)-1):
        if ys[i] == 0: return fov_from_lt(xs[i])
        if ys[i]*ys[i+1] < 0: return fov_from_lt(xs[i] + (xs[i+1]-xs[i])*ys[i]/(ys[i]-ys[i+1]))
    return np.nan
