"""Camera-consistency scale correction (CSC).
Exact-camera groups: 3D sim/seg clips sharing identical depth_info distances (>=3 decimals), twins included.
For clip c, reference camera f_ref = weighted log-tan mean of the own prior-solved f of OTHER bases in the group
(size prior, sens>0.8: w=1; motion prior, sens>0.8: w=0.5), needing total weight >= 1.5 and tan spread <= 1.3x.
If both the clip's own prior-solved f and Claude's implied f (f at which our geometry reproduces the direct answers,
clip median over size questions) are > 1.5x off f_ref in the same direction, Claude's direct answers inherited a
wrong prior scale: rescale scale-linear answers (size, distance, displacement, path, speed, acceleration) by
tan(fov_ref/2) / tan(fov_dir/2)."""
import sys, math
import pandas as pd, numpy as np
from lib import *
R = pd.read_pickle('sw_fam3.pkl')
cg = pd.read_csv('camgroups.csv').set_index('vid').cam
R['cam'] = R.vid.map(cg)
KINDS = ('size', 'distance', 'displacement', 'path_length', 'speed', 'acceleration')
clip = R.groupby('vid').agg(cam=('cam','first'), base=('base','first'), cat=('cat','first'), fov=('fov_own','median'),
                            sens=('sens','median'), pk=('pkind','first'))
clip['fdir'] = R[R.tkind == 'size'].groupby('vid').fov_dir.median()
clip['w'] = np.where(clip.fov.notna() & (clip.sens > 0.8), np.where(clip.pk == 'size', 1.0, 0.5), 0.0)
rows = []
for v, c in clip.iterrows():
    o = clip[(clip.cam == c.cam) & (clip.base != c.base) & (clip.w > 0)]
    if o.w.sum() < 1.5: continue
    l = o.fov.map(lt)
    if l.max() - l.min() > math.log(1.3): continue
    lref = float((l * o.w).sum() / o.w.sum())
    fref = fov_from_lt(lref)
    r_own = math.exp(lref - lt(c.fov)) if np.isfinite(c.fov) else np.nan
    r_dir = math.exp(lref - lt(c.fdir)) if np.isfinite(c.fdir) else np.nan
    hit = np.isfinite(r_own) and np.isfinite(r_dir) and abs(math.log(r_own)) > math.log(1.5) and abs(math.log(r_dir)) > math.log(1.5) \
          and np.sign(math.log(r_own)) == np.sign(math.log(r_dir))
    rows.append(dict(vid=v, cat=c['cat'], fov_own=c.fov, fov_dir=c.fdir, fov_ref=fref, n_ref=len(o), r_own=r_own, r_dir=r_dir, hit=hit))
T = pd.DataFrame(rows)
pd.set_option('display.width', 200)
print(T.round(3).to_string())
T.to_pickle('csc_clips.pkl')
