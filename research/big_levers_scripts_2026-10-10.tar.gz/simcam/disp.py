import sys, math
import pandas as pd, numpy as np
from lib import *
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500)
R = pd.read_pickle('sw_fam.pkl')
R['fov_own'] = np.where(R.method == '3d_focal_from_prior', np.degrees(2*np.arctan(R.W/2/R.f_own)), np.nan)
# family common fov: median over clips (clip median of own fov) with good conditioning
clip = R.groupby('vid').agg(fam=('fam','first'), fov=('fov_own','median'), sens=('sens','median'), pk=('pkind','first'))
good = clip[(clip.sens > 0.8) & clip.fov.notna()]
famfov = good.groupby('fam').fov.median()
R['fov_fam'] = R.fam.map(famfov)
R['g_fam'] = R.apply(lambda r: at(r, r.fov_fam), axis=1)
R['g_own'] = R.geo
out = []
S = R[R.tkind == 'size']
for (f, e), g in S.groupby(['fam', 'eq']):
    if g.base.nunique() < 2: continue
    row = dict(fam=f, eq=e, n=len(g), q=g.question.iloc[0][:50])
    for c in ['direct', 'g_own', 'g_fam']:
        x = np.log(g[c].where(g[c] > 0)).dropna()
        row[c] = float(np.std(x)) if len(x) >= 2 else np.nan
    out.append(row)
D = pd.DataFrame(out)
print(D.groupby('fam')[['direct','g_own','g_fam']].mean().round(3).join(D.groupby('fam').size().rename('ngroups')).join(famfov.round(1)))
print(D[['direct','g_own','g_fam']].mean().round(3))
R.to_pickle('sw_fam2.pkl')
