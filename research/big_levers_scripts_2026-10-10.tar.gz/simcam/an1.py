import pandas as pd, numpy as np, math
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500); pd.set_option('display.max_colwidth', 50)
R = pd.read_pickle('sw_post.pkl')
R['fW_own'] = R.f_own / R.W
R['fov_own'] = np.degrees(2*np.arctan(0.5/R.fW_own))
ok = R.method.isin(['3d_focal_from_prior'])
g = R.groupby('vid').agg(cat=('cat','first'), W=('W','first'), H=('H','first'), pk=('pkind','first'), n=('qid','size'),
    nok=('method', lambda m: (m=='3d_focal_from_prior').sum()),
    fov=('fov_own', lambda x: np.nan), sens=('sens','median'), prior=('prior', lambda s: s.iloc[0][:40]))
for v, gg in R[ok].groupby('vid'):
    g.loc[v, 'fov'] = np.degrees(2*np.arctan(0.5/np.median(gg.fW_own)))
    g.loc[v, 'fovsd'] = np.std(np.log(gg.fW_own))
print(g.round(3).to_string())
