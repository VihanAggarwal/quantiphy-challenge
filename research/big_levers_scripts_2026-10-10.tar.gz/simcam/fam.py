"""Families of 3D sim/seg clips: union of twins, shared depth values (camgroups), scenegraph series
families, and >=2 shared normalized question texts. Equivalence groups: same family, same tkind,
same normalized question text (or same tkind/dim and object name score >= .8)."""
import re, sys, json
sys.path.insert(0, '/home/user/quantiphy-challenge')
import pandas as pd, numpy as np
from collections import defaultdict
from qp.geometry import name_score
R = pd.read_pickle('sw_post2.pkl')
base = lambda v: re.sub(r'_segmented$', '', v)
R['base'] = R.vid.map(base)
cg = pd.read_csv('camgroups.csv').set_index('vid').cam
sf = json.load(open('../scenegraph/families.json'))['series_families']
bases = sorted(R.base.unique())
parent = {b: b for b in bases}
def find(x):
    while parent[x] != x: parent[x] = parent[parent[x]]; x = parent[x]
    return x
def union(a, b):
    if a in parent and b in parent: parent[find(a)] = find(b)
for v in R.vid.unique(): union(base(v), base(cg[v]))
for k, d in sf.items():
    bs = [b for b in d['bases'] if b in parent]
    for b in bs[1:]: union(b, bs[0])
def qn(s):
    s = s.lower().replace('’', "'").replace('？', '?')
    s = re.sub(r'\b(the|a|an|of|in|meters?|m/s\^?2?|m/s|what|is|are|how)\b', ' ', s)
    return re.sub(r'[^a-z0-9.]+', ' ', s).strip()
R['qn'] = R.question.map(qn)
qb = defaultdict(set)
for r in R.itertuples(): qb[r.qn].add(r.base)
pair = defaultdict(int)
for q, bs in qb.items():
    bs = sorted(bs)
    for i in range(len(bs)):
        for j in range(i+1, len(bs)): pair[(bs[i], bs[j])] += 1
for (a, b), n in pair.items():
    if n >= 2: union(a, b)
R['fam'] = R.base.map(lambda b: find(b))
# equivalence groups
gid = {}
rows = R.reset_index(drop=True)
eq = {}
k = 0
for f, g in rows.groupby('fam'):
    items = list(g.itertuples())
    lab = {}
    for i, a in enumerate(items):
        if a.qid in lab: continue
        lab[a.qid] = k
        for b in items[i+1:]:
            if b.qid in lab or b.tkind != a.tkind: continue
            same = a.qn == b.qn
            if not same and a.tkind == 'size':
                ns = max([name_score(x, y) for x in str(a.tobj).split(';') for y in str(b.tobj).split(';')] + [0])
                same = ns >= 0.8 and str(a.tdim).lower() == str(b.tdim).lower() and str(a.tdim) != ''
            if same: lab[b.qid] = k
        k += 1
    eq.update(lab)
R['eq'] = R.qid.map(eq)
R.to_pickle('sw_fam.pkl')
for f, g in R.groupby('fam'):
    print(f, sorted(g.vid.unique()), len(g), 'eq groups with >=2 clips:', (g.groupby('eq').vid.nunique() >= 2).sum())
