"""Mask-based prior extents on segmented twins -> focal length. Compare with Claude-extent f."""
import pickle, sys, math, re
sys.path.insert(0, '/home/user/quantiphy-challenge')
import numpy as np, pandas as pd, cv2
from qp import geometry as G
from qp.data import _video_index, TEST_DIR
idx = _video_index(TEST_DIR)
d = pickle.load(open('anns_test.pkl', 'rb'))
anns, df, meta = d['raw'], d['df'].set_index('qid'), d['meta']
out = []; seen = set()
for q, a in anns.items():
    v = df.loc[q].video_id
    if not v.endswith('_segmented') or a.spec.prior.kind != 'size' or v in seen: continue
    seen.add(v)
    m = meta[v]; W, H = m['image_size']; fps = float(m['fps'])
    groups = G._depth_groups(a.spec.depth)
    pt = [t for t in a.tracks if t.role == 'prior'][0]
    fn = G.match_depth([pt.object, *a.spec.prior.objects[:1]], groups)
    if fn is None: print(v, 'no depth'); continue
    times = sorted({t for g in groups for t, _ in g[1] if t is not None and G.name_score(g[0], pt.object) >= .5} or {o.t for o in pt.obs})
    cap = cv2.VideoCapture(str(idx[v]))
    dim = a.spec.prior.dimension
    for t in times:
        k = int(round(t * fps)); cap.set(cv2.CAP_PROP_POS_FRAMES, k); ok, im = cap.read()
        if not ok: continue
        # nearest Claude box
        o = min(pt.obs, key=lambda o: abs(o.t - t))
        if o.box is None: continue
        bx = np.array(o.box, float); cx, cy = (bx[0]+bx[2])/2, (bx[1]+bx[3])/2; bw, bh = bx[2]-bx[0], bx[3]-bx[1]
        mask = (im.min(axis=2) < 225).astype(np.uint8)
        n, lab, st, cen = cv2.connectedComponentsWithStats(mask, 8)
        x0, x1 = int(max(0, cx - bw)), int(min(W, cx + bw)); y0, y1 = int(max(0, cy - bh)), int(min(H, cy + bh))
        ids = set(np.unique(lab[y0:y1, x0:x1])) - {0}
        ids = [i for i in ids if st[i, cv2.CC_STAT_AREA] >= 0.05 * bw * bh]
        if not ids: continue
        sel = np.isin(lab, ids)
        ys, xs = np.where(sel[y0:y1, x0:x1]); ys = ys + y0; xs = xs + x0
        hpx = ys.max() - ys.min() + 1; wpx = xs.max() - xs.min() + 1
        L = hpx if dim in ('height',) else (max(hpx, wpx) if dim == 'diameter' else wpx)
        r = float(fn(np.array([t]))[0])
        f_mask = L * r / a.spec.prior.value_si
        # claude extent at nearest obs
        if o.extent is not None:
            Lc = math.hypot(o.extent[1][0]-o.extent[0][0], o.extent[1][1]-o.extent[0][1])
        else:
            Lc = bh if dim == 'height' else bw
        out.append(dict(vid=v, t=t, dim=dim, val=a.spec.prior.value_si, r=r, L_mask=L, L_claude=Lc, box_h=bh, box_w=bw,
                        fW_mask=f_mask/W, fW_claude=Lc*r/a.spec.prior.value_si/W, W=W))
        cv2.imwrite(f'img/mask_{v}_{k}.png', (sel*255).astype(np.uint8)[::2, ::2])
M = pd.DataFrame(out)
M['fov_mask'] = np.degrees(2*np.arctan(0.5/M.fW_mask)); M['fov_claude'] = np.degrees(2*np.arctan(0.5/M.fW_claude))
M['ratio'] = M.L_mask / M.L_claude
pd.set_option('display.width', 250)
print(M.round(3).to_string())
print(M.groupby('vid')[['fov_mask','fov_claude','ratio']].median().round(2))
M.to_pickle('maskf.pkl')
