"""Val replays: D2 score for refine on/off x dense motion/off, per run (records cached, no API)."""
from ev import *
from pathlib import Path
from qp import claude_annotate as ca
from qp.data import load_split
VC = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/valcache/'
runs = sys.argv[1].split(',')
out = {}
for run in runs:
    rd = Path('/home/user/quantiphy-challenge/runs') / run
    sub = [p for p in rd.iterdir() if p.is_dir()][0]
    split = sub.name
    df = load_split(split)
    recs = rc.prepare_records(df, rc.load_records(sub / 'records'))
    for ref in (True, False):
        for dense in ('motion', 'off'):
            anns = rc.post_steps(ca.load_annotations(recs), df, recs, refine_priors=ref, dense=dense, dense_cache=VC + split)
            res = rc.build_results(df, recs, anns=anns)
            m = df[['qid', 'category', 'video_source', 'video_id', 'answer']].merge(res, left_on='qid', right_on='id')
            m['s'] = item_scores(m.parsed_value, m.answer)
            out[(run, ref, dense)] = m
            d2 = m[m.category == 'D2']
            print(run, 'refine' if ref else 'norefine', dense, 'D2 %.4f' % d2.s.mean(), 'sim %.4f' % d2[d2.video_source != 'internet'].s.mean(), 'all %.4f' % m.groupby('category').s.mean().mean(), flush=True)
pickle.dump(out, open('valrep_%s.pkl' % runs[0], 'wb'))
