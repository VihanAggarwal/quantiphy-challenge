"""D2 variant builder from cached annotations (no API): ro anns (+ CV prior) (+ extent padding)."""
from ev import *
import re
MARKING = re.compile(r"\b(lanes?|courts?|lines?|circles?|field|pitch|goal|calibre|caliber|ruler|markings?|road|crosswalk)\b", re.I)


def is_marking(q):
    return any(MARKING.search(o or '') for o in (q.objects or []))


def pad_anns(anns, df, recs, k):
    """S2 investigator's rule: object-size extents and boxes padded by k px of the 854-px annotator view."""
    anns = copy.deepcopy(anns)
    vid = dict(zip(df.qid, df.video_id))
    n = 0
    for q, a in anns.items():
        sc = float(recs[vid[q]]['meta'].get('scale') or 1.0)
        p = k / sc / 2.0
        for tr in a.tracks:
            quant = a.spec.prior if tr.role.startswith('prior') else a.spec.target
            if quant.kind not in ('size', 'other', 'distance') or is_marking(quant):
                continue
            for o in tr.obs:
                if o.extent is not None:
                    e = np.asarray(o.extent, float); u = e[1] - e[0]; L = float(np.linalg.norm(u))
                    if L > 0:
                        d = u / L * p
                        o.extent = [list(e[0] - d), list(e[1] + d)]
                        n += 1
                if o.box is not None:
                    o.box = [o.box[0] - p, o.box[1] - p, o.box[2] + p, o.box[3] + p]
    return anns, n


def replace_prior(anns, df, prior_tracks):
    """prior_tracks: {video_id: RoleTrack}; replaces role 'prior' tracks of motion-prior questions."""
    anns = copy.deepcopy(anns)
    n = 0
    for r in df.itertuples():
        tr = prior_tracks.get(r.video_id)
        a = anns.get(int(r.qid))
        if tr is None or a is None or a.spec.prior.kind not in ('speed', 'acceleration', 'displacement'):
            continue
        if not any(t.role == 'prior' for t in a.tracks):
            continue
        a.tracks = [t for t in a.tracks if t.role != 'prior'] + [copy.deepcopy(tr)]
        n += 1
    return anns, n


P = load('test.pkl'); df = P['df']; recs = P['records']
RO = load('dense_ro.pkl')['anns']
