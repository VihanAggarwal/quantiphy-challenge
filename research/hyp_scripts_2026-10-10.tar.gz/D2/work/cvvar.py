"""D2 variant: refine off + dense (ro) + seg-mask CV prior tracks on twin scenes (+0.8 px padding) (+segtwin)."""
import sys
sys.path.insert(0, '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/cv')
from build import *
from cvtrack import to_roletrack
import mkcsv, segtwin
CV = {}
for f in ('cv_seg.pkl', 'cv_simseg.pkl'):
    CV.update({v: r for v, r in load('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/cv/' + f).items() if r})
X = pd.read_pickle('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/cv/cmp_seg.pkl')
X = X[(X.which == 'c') & X.cv.notna()].drop_duplicates('v').set_index('v')
use = {}
for v, r in X.iterrows():
    if r.nok >= 15 and r.nok >= 0.5 * r.n and abs(np.log(r.cv / r.ro)) < 0.10:
        use[v] = to_roletrack(CV[v]['out'], 'c', CV[v]['ok'], CV[v]['obj'])
print('CV prior used on', len(use), 'videos')
an, n = replace_prior(RO, df, use)
print('questions with CV prior', n)
an_pad, _ = pad_anns(an, df, recs, 0.8)
res = rc.build_results(df, recs, anns=an_pad)
vals = dict(zip(res.id.astype(int), res.parsed_value))
mkcsv.write('D2_refineoff_pad_cvprior', vals)
mkcsv.write('D2_refineoff_pad_cvprior_segtwin', segtwin.apply(vals))
