"""Per-question prior measurement (px) under several track sets and estimators."""
import sys, pickle, os, math, copy
REPO = os.environ.get('QP_REPO', '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/base/repo')
sys.path.insert(0, REPO); sys.path.insert(0, REPO + '/scripts')
import numpy as np, pandas as pd
from qp import geometry as G
from qp.spec import RoleTrack

def prior_obj(a):
    objs = {}
    flags = set()
    for tr in a.tracks or []:
        tr = RoleTrack.from_dict(tr) if isinstance(tr, dict) else tr
        o, role = G._Obj(tr, flags), str(tr.role).strip().lower()
        if o.rows and (role not in objs or len(o.rows) > len(objs[role].rows)):
            objs[role] = o
    return objs.get('prior'), objs

def estimators(a, fps):
    """speed priors w/o time: path/duration (current), chord/duration, median local speed."""
    p = a.spec.prior
    o, _ = prior_obj(a)
    if o is None:
        return {}
    t, P = o.points()
    if len(t) < 2:
        return {}
    cols = G._axis_cols(p.axis, 2)
    tol = max(2.0 / fps, 0.1)
    out = {'n': len(t), 'T': float(t[-1] - t[0])}
    try:
        fl = set()
        out['cur'] = G._motion(p, t, P, fl, tol, None)
    except Exception as e:
        out['cur'] = np.nan
    if p.kind == 'speed' and p.time is None and not p.window:
        fits = [G._local(t, P, g, G.SPEED_HALF_WIN) for g in np.linspace(t[0], t[-1], int(np.clip(len(t), 10, 60)))]
        sp = [float(np.linalg.norm(np.asarray(f[1])[cols])) for f in fits]
        out['med'] = float(np.median(sp))
        a0, b0 = G._local(t, P, t[0], G.SPEED_HALF_WIN), G._local(t, P, t[-1], G.SPEED_HALF_WIN)
        out['chord'] = float(np.linalg.norm((b0[0] - a0[0])[cols])) / float(t[-1] - t[0])
        # frame-step jumps (dense tracks)
        d = np.linalg.norm(np.diff(P, axis=0), axis=1) / np.maximum(np.diff(t), 1e-9)
        out['maxstep_ratio'] = float(d.max() / max(np.median(d), 1e-9)) if len(d) > 3 else np.nan
    return out
