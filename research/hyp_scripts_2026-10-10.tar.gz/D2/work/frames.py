import sys, cv2, os
sys.path.insert(0, '/home/user/quantiphy-challenge')
from qp.data import load_split
df = load_split('test')
out = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/img/'
for v in sys.argv[1:]:
    p = df[df.video_id == v].video_path.iloc[0]
    cap = cv2.VideoCapture(p); n = int(cap.get(7)); fps = cap.get(5); W = cap.get(3); H = cap.get(4)
    print(v, n, fps, W, H)
    ims = []
    for f in [0, n // 3, 2 * n // 3, n - 1]:
        cap.set(1, f); ok, im = cap.read()
        im = cv2.resize(im, (640, int(640 * H / W)))
        cv2.putText(im, f'f{f} t={f/fps:.2f}', (10, 30), 0, 0.9, (0, 0, 255), 2)
        ims.append(im)
    top = cv2.hconcat(ims[:2]); bot = cv2.hconcat(ims[2:])
    cv2.imwrite(out + v + '.jpg', cv2.vconcat([top, bot]))
