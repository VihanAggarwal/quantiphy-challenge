import sys, pickle
from pathlib import Path
REPO='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/base/repo'
sys.path.insert(0, REPO); sys.path.insert(0, REPO + '/scripts')
import run_claude as rc
from qp import claude_annotate as ca
from qp.data import load_split
df = load_split('test'); df = df[df.category == 'D2'].reset_index(drop=True)
records = rc.prepare_records(df, rc.load_records(Path('/home/user/quantiphy-challenge/runs/test_v1_high_854/test/records')))
raw = {q: a for q, a in ca.load_annotations(records).items() if q in set(df.qid)}
pickle.dump({'df': df, 'records': records, 'raw': raw}, open('test_raw.pkl', 'wb'))
