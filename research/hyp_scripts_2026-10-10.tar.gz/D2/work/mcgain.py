"""Model-based expected MRA on twin-scene D2 geometry questions: true prior px = seg-mask CV track; target
extent error drawn from the S2 twin-mask study (Claude/mask, D2 targets, |log|<0.3); compare prior px of
v2 (refine+dense), ro (refine off + dense), raw."""
from ev import *
from qp.mra import item_scores
X = pd.read_pickle('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/cv/cmp.pkl')
X = X[(X.which == 'c') & X.cv.notna() & (X.nok >= 15)].drop_duplicates('v').set_index('v')
R = pd.read_pickle('ppx2.pkl')
T = pd.read_csv('/home/user/quantiphy-challenge/runs/test_v1_high_854/test.csv').set_index('id')
R = R[R.video_id.isin(X.index) & R.qid.map(lambda q: str(T.loc[q].method).startswith('geometry'))]
S = pd.read_pickle('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/t2/twins3.pkl')
te = np.log(S[S.cat == 'D2'].claude / S[S.cat == 'D2'].m50).values
te = te[np.abs(te) < 0.3]
rng = np.random.default_rng(0)
out = {}
for name, col in [('v2', 'dense'), ('ro', 'ro'), ('raw', 'raw')]:
    sc = []
    for _ in range(200):
        e_t = rng.choice(te, len(R))
        e_p = np.log(R.video_id.map(X.cv).values / R[col].values)   # answer error from the prior: px_true/px_used
        r = np.exp(e_t + e_p)
        sc.append(item_scores(pd.Series(r), pd.Series(np.ones(len(r)))).mean())
    out[name] = np.mean(sc)
print(len(R), 'questions in', R.video_id.nunique(), 'twin-scene videos;', {k: round(v, 4) for k, v in out.items()})
# all D2 geometry questions: true prior = CV (twins) else raw x lognormal(0, 0.025)
R2 = pd.read_pickle('ppx2.pkl')
R2 = R2[R2.qid.map(lambda q: str(T.loc[q].method).startswith('geometry')) & R2.raw.notna() & R2.ro.notna() & R2.dense.notna()]
out = {}
for name, col in [('v2', 'dense'), ('ro', 'ro'), ('raw', 'raw')]:
    sc = []
    for _ in range(200):
        e_t = rng.choice(te, len(R2))
        vid_noise = {v: rng.normal(0, 0.025) for v in R2.video_id.unique()}
        true = np.where(R2.video_id.isin(X.index), R2.video_id.map(X.cv), R2.raw * np.exp(R2.video_id.map(vid_noise)))
        r = np.exp(e_t + np.log(true / R2[col].values))
        sc.append(item_scores(pd.Series(r), pd.Series(np.ones(len(r)))).mean())
    out[name] = np.mean(sc)
print(len(R2), 'D2 geometry questions;', {k: round(v, 4) for k, v in out.items()}, '-> x', len(R2), '/1163')
