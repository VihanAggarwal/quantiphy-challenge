from ev import *
P = load('test.pkl'); df = P['df']; raw = P['raw']; recs = P['records']
R = pd.read_pickle('ppx2.pkl')
g = R.groupby('video_id').agg(src=('video_source', 'first'), raw=('raw', 'first'), ref=('refine', 'first'), ro=('ro', 'first'), why=('refine_why', 'first'), q=('qid', 'first'))
rows = []
for v, r in g.iterrows():
    a = raw.get(int(r.q))
    if a is None: continue
    tr = [t for t in a.tracks if t.role == 'prior']
    if not tr: continue
    tr = max(tr, key=lambda t: len(t.obs))
    o = G._Obj(tr, set()); t, Pp = o.points()
    if len(t) < 3: continue
    deg = 2 if a.spec.prior.kind == 'acceleration' else 1
    c = np.polyfit(t, Pp, deg); res = Pp - np.vander(t, deg + 1) @ c
    sig = np.sqrt((res ** 2).sum() / max(1, (len(t) - deg - 1) * 2))
    D = np.linalg.norm(Pp[-1] - Pp[0])
    sc = float(recs[v]['meta'].get('scale') or 1)
    rows.append(dict(v=v, src=r.src, kind=a.spec.prior.kind, n=len(t), D=D, sig=sig, sig_seen=sig * sc, D_seen=D * sc, snr=D / max(sig, 1e-6), rr=r.ref / r.raw, ror=r.ro / r.raw, why=r.why))
X = pd.DataFrame(rows)
X.to_pickle('rawstats.pkl')
pd.set_option('display.width', 200); pd.set_option('display.max_rows', 300)
print(X[X.why == 'refined'].sort_values('rr').round(3).to_string())
