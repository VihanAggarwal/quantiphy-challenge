from ev import *
P = load('test.pkl'); df = P['df']; recs = P['records']
RO = load('dense_ro.pkl')['anns']
def prior_px(anns):
    out = {}
    for r in df.itertuples():
        a = anns.get(int(r.qid))
        if a is None: continue
        rec = recs[r.video_id]
        ans = G.solve(a.spec, a.tracks, tuple(rec['meta']['image_size']), float(rec['meta']['fps']), seen_scale=float(rec['meta'].get('scale') or 1.0))
        out[int(r.qid)] = ans.debug.get('prior_px', np.nan)
    return out
R = pd.read_pickle('ppx.pkl')
x = prior_px(RO)
R['ro'] = R.qid.map(x)
R.to_pickle('ppx2.pkl')
# check build_results reproduces refineoff csv
res = rc.build_results(df, recs, anns=copy.deepcopy(RO))
ref = pd.read_csv('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/probe3/refineoff/runs/test_v1_high_854/test.csv').set_index('id')
m = res.set_index('id').parsed_value
print('match refineoff csv:', np.isclose(m, ref.parsed_value.reindex(m.index), rtol=1e-6).mean())
res.to_csv('res_ro.csv', index=False)
