"""Post-steps once for the questions of some categories (refine + dense from the scratch cache); pickle anns.
Usage: prep.py <split> <records_dir> <out.pkl> <dense_cache>"""
import sys, pickle, copy, time, os
from pathlib import Path
REPO = os.environ.get('QP_REPO', '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/base/repo')
sys.path.insert(0, REPO); sys.path.insert(0, REPO + '/scripts')
import run_claude as rc
from qp import claude_annotate as ca, refine
from qp import dense_track as dt
from qp.data import load_split
split, rec_dir, out, cache = sys.argv[1:5]
cats = os.environ.get('CATS', 'D2').split(',')
df = load_split(split)
df = df[df.category.isin(cats)].reset_index(drop=True)
records = rc.prepare_records(df, rc.load_records(Path(rec_dir)))
raw = ca.load_annotations(records)
raw = {q: a for q, a in raw.items() if q in set(df.qid)}
paths, meta = rc.video_maps(df, records, raw)
t0 = time.time()
ref = copy.deepcopy(raw)
rlog = []
refine.refine_annotations(ref, paths, {q: m[:2] for q, m in meta.items()}, log=rlog)
refined = {(q, role) for q, role, info in rlog if info.get('why') == 'refined'}
t1 = time.time()
den = copy.deepcopy(ref)
log = []
dt.densify_annotations(den, paths, meta, what='motion', cache_dir=cache, log=log, workers=int(os.environ.get('W', '1')),
                       skip=refined, size_method=dt.SIZE_METHOD, motion_kinds=tuple(dt.MOTION))
t2 = time.time()
# dense without refine (refine off), from the raw tracks
nod = copy.deepcopy(raw)
log2 = []
if os.environ.get('NOREFINE'):
    dt.densify_annotations(nod, paths, meta, what='motion', cache_dir=cache, log=log2, workers=int(os.environ.get('W', '1')),
                           skip=set(), size_method=dt.SIZE_METHOD, motion_kinds=tuple(dt.MOTION))
t3 = time.time()
print(f'refine {t1-t0:.0f}s, dense {t2-t1:.0f}s, dense-norefine {t3-t2:.0f}s')
pickle.dump({'df': df, 'records': records, 'raw': raw, 'refine': ref, 'dense': den, 'dense_norefine': nod,
             'rlog': rlog, 'dense_log': log, 'dense_log2': log2, 'paths': paths, 'meta': meta}, open(out, 'wb'))
