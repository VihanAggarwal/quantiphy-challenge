from ev import *
from qp import dense_track as dt
P = load('test.pkl')
sub = copy.deepcopy(P['raw'])
log = []
dt.densify_annotations(sub, P['paths'], P['meta'], what='motion', cache_dir='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/cache_ro/test',
                       log=log, workers=1, skip=set(), size_method=dt.SIZE_METHOD, motion_kinds=tuple(dt.MOTION))
pickle.dump({'anns': sub, 'log': log}, open('dense_ro.pkl', 'wb'))
