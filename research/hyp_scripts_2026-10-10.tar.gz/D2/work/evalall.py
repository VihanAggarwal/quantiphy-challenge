"""Evaluate D2 variant CSVs: val-on-test (39 q, val GT incl. twins), pseudo-GT (sizes stated as priors in sibling
scene videos; 28 clean q), twin-answer consistency (seg vs original, 94 pairs; segtwin variants excluded)."""
import glob, os
import numpy as np, pandas as pd
from vot import VOT
from qp.mra import item_scores
SP = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/'
pg = pd.read_csv(SP + 'work/pseudo_gt.csv'); pg = pg[pg.category == 'D2'].set_index('qid')
bad = {241, 295, 298, 1845, 1846, 466, 1913, 475, 1922, 518, 1649, 8}   # other-asset matches / slow-motion clip
pg = pg[~pg.index.isin(bad)]
tw = pd.read_csv(SP + 'work/segtwin_pairs.csv'); tw = tw[tw.sp]
files = {'v2': '/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv',
         'probe3(d2 dense off)': '/home/user/quantiphy-challenge/submissions/trackA_probe3_s2maxext_d2denseoff_labdirect.csv'}
files.update({os.path.basename(f)[:-4]: f for f in sorted(glob.glob(SP + 'variants/*.csv'))})
rows = []
for k, f in files.items():
    s = pd.read_csv(f).set_index('id').parsed_value
    l = np.log(s.reindex(tw.qs).values / s.reindex(tw.qo).values)
    rows.append(dict(variant=k, vot=item_scores(s.reindex(VOT.index), VOT.answer).mean(),
                     pseudo=item_scores(s.reindex(pg.index), pg.pgt).mean(),
                     twin_mean_abs_log=np.mean(np.abs(l)), twin_gt10=int((np.abs(l) > np.log(1.1)).sum())))
X = pd.DataFrame(rows).set_index('variant')
print(X.round(4).to_string())
X.to_csv(SP + 'work/evalall.csv')
