from ev import *
import json, sys
P = load('test.pkl'); df = P['df']; recs = P['records']
T = pd.read_csv('/home/user/quantiphy-challenge/runs/test_v1_high_854/test.csv')
RO = pd.read_csv('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/probe3/refineoff/runs/test_v1_high_854/test.csv')
DO = pd.read_csv('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/probe3/denseoff/runs/test_v1_high_854/test.csv') if os.path.exists('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/probe3/denseoff/runs/test_v1_high_854/test.csv') else None
v2 = pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv').set_index('id').parsed_value
T = T.set_index('id'); RO = RO.set_index('id')
for v in sys.argv[1:]:
    d = df[df.video_id == v]
    m = recs[v]['meta']
    print('=====', v, m.get('image_size'), 'fps', m.get('fps'), 'scale', m.get('scale'), 'prior:', d.prior.iloc[0])
    for r in d.itertuples():
        t = T.loc[r.qid]
        print(f"  {r.qid} {r.question[:70]:70s} v2={v2[r.qid]:.4g} geo={t.geo_value:.4g} dir={t.direct_value:.4g} ro={RO.loc[r.qid].parsed_value:.4g} {t.method} {t.flags}")
