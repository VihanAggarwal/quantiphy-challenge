from ev import *
P = load('test.pkl'); df = P['df']; recs = P['records']
RO = load('dense_ro.pkl')['anns']
out = {}
for name, anns in [('raw', P['raw']), ('refine', P['refine']), ('dense', P['dense']), ('ro', RO)]:
    res = rc.build_results(df, recs, anns=copy.deepcopy(anns)).set_index('id')
    out[name] = res
pickle.dump(out, open('allres.pkl', 'wb'))
v2 = pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv').set_index('id').parsed_value
for k, r in out.items():
    print(k, 'match v2', np.isclose(r.parsed_value, v2.reindex(r.index), rtol=1e-6).mean())
