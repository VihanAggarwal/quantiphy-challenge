import re
import numpy as np, pandas as pd
import mkcsv


def normq(q):
    return re.sub(r"[^a-z0-9.]", "", str(q).lower())


def twin_map():
    t = mkcsv._t
    t = t.assign(twin=t.video_id.str.replace('_segmented', '', regex=False), nq=t.question.map(normq))
    orig = {}
    for r in t[~t.video_id.str.endswith('_segmented')].itertuples():
        orig.setdefault((r.twin, r.nq), (int(r.qid), r.prior, r.category))
    m = {}
    for r in t[(t.category == 'D2') & t.video_id.str.endswith('_segmented')].itertuples():
        o = orig.get((r.twin, r.nq))
        if o and o[1] == r.prior and o[2] == 'D2':
            m[int(r.qid)] = o[0]
    return m


def apply(vals):
    m = twin_map()
    out = dict(vals)
    for s, o in m.items():
        if o in vals and np.isfinite(vals[o]) and vals[o] > 0:
            out[s] = vals[o]
    return out
