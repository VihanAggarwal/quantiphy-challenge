"""Write a D2-only variant CSV: v2 with D2 rows replaced from a {qid: value} source. Usage via write(name, newvals)."""
import sys, json
import numpy as np, pandas as pd
sys.path.insert(0, '/home/user/quantiphy-challenge')
from qp.data import load_split
SP = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2'
V2 = '/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv'
_t = load_split('test')
D2 = set(_t[_t.category == 'D2'].qid.astype(int))
SRC = dict(zip(_t.qid.astype(int), _t.video_source))


def write(name, newvals):
    v2 = pd.read_csv(V2)
    out = v2.copy()
    vals = []
    for i, v in zip(out.id, out.parsed_value):
        nv = newvals.get(int(i), np.nan) if int(i) in D2 else v
        vals.append(nv if (np.isfinite(nv) and nv > 0) else v)
    out['parsed_value'] = vals
    assert out.parsed_value.notna().all() and (out.parsed_value > 0).all()
    r = out.parsed_value / v2.parsed_value
    ch = np.abs(np.log(r)) > 1e-9
    assert not (ch & ~out.id.isin(D2)).any(), 'non-D2 changed'
    path = f'{SP}/variants/{name}.csv'
    out.to_csv(path, index=False)
    src = pd.Series([SRC[int(i)] for i in out.id[ch]]).value_counts().to_dict()
    info = dict(csv=path, answers_changed=int(ch.sum()), median_ratio_changed=float(np.median(r[ch])) if ch.any() else 1.0,
                median_abs_log_changed=float(np.median(np.abs(np.log(r[ch])))) if ch.any() else 0.0,
                n_gt10pct=int((np.abs(np.log(r)) > np.log(1.1)).sum()), by_source=src)
    json.dump(info, open(f'{SP}/variants/{name}.json', 'w'), indent=1)
    print(name, info)
    return out
