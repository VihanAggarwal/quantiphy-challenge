"""Pseudo ground truth for test size questions: the same '<dimension> of the <object>' stated as a
prior value elsewhere in the test set (same simulation scene family). Evaluation only."""
import re, sys
import pandas as pd, numpy as np
sys.path.insert(0, '/home/user/quantiphy-challenge')
from qp.data import load_split
from qp.parse import _UNITS, canonical_unit

def norm(s):
    s = s.lower().strip()
    s = re.sub(r'\s+', ' ', s)
    s = re.sub(r'^(the )', '', s)
    return s

PRI = re.compile(r'^\s*(.*?)\s*=\s*([-+0-9.eE]+)\s*([a-zA-Z/^0-9]*)\s*$')
Q = re.compile(r'what is the (.*?)(?: in (?:meters|metres|m|cm|centimeters|mm|m/s|cm/s|m/s\^2)| \(in [^)]*\))?\s*\??\s*$', re.I)

def prior_key(p):
    m = PRI.match(p)
    if not m:
        return None
    k, v, u = m.groups()
    k = norm(k)
    try:
        v = float(v)
    except ValueError:
        return None
    u = u.strip() or 'm'
    cu = canonical_unit(u)
    if cu in _UNITS:
        v = v * _UNITS[cu][0]
    return k, v

def q_key(q):
    m = Q.match(q.strip())
    if not m:
        return None
    k = norm(m.group(1))
    k = re.sub(r',$', '', k).strip()
    return k

def scene_num(v):
    m = re.match(r'simulation_(\d+)', v)
    return int(m.group(1)) if m else None

def build(df=None, maxgap=8):
    df = load_split('test') if df is None else df
    pri = {}
    for r in df.itertuples():
        pk = prior_key(r.prior)
        if pk:
            pri.setdefault(pk[0], []).append((r.video_id, pk[1]))
    rows = []
    for r in df.itertuples():
        k = q_key(r.question)
        if not k or k not in pri:
            continue
        n = scene_num(r.video_id)
        vals = [v for vid, v in pri[k] if vid != r.video_id and n is not None and scene_num(vid) is not None
                and abs(scene_num(vid) - n) <= maxgap]
        same = [v for vid, v in pri[k] if vid == r.video_id]
        if not vals:
            continue
        unit = r.target_unit or 'm'
        cu = canonical_unit(unit)
        f = _UNITS[cu][0] if cu in _UNITS else 1.0
        rows.append(dict(qid=r.qid, video_id=r.video_id, category=r.category, key=k,
                         pgt=float(np.median(vals)) / f, n=len(vals), spread=(max(vals) / min(vals)) if min(vals) > 0 else np.nan))
    return pd.DataFrame(rows)

if __name__ == '__main__':
    p = build()
    print(len(p)); print(p.category.value_counts())
    print(p[p.spread > 1.01])
    p.to_csv('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/work/pseudo_gt.csv', index=False)
    print(p.head(30))
