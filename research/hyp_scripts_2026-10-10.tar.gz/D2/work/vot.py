"""val-on-test D2: test questions (incl. segmented/original twins) that share a validation clip's question -> val GT."""
import re, sys
import numpy as np, pandas as pd
sys.path.insert(0, '/home/user/quantiphy-challenge')
from qp.data import load_split
from qp.mra import item_scores
def normq(q): return re.sub(r"[^a-z0-9.]", "", str(q).lower())
def base(v): return v.replace('_segmented', '')
val = load_split('val'); t = load_split('test')
val = val.assign(b=val.video_id.map(base), nq=val.question.map(normq))
t = t.assign(b=t.video_id.map(base), nq=t.question.map(normq))
gt = {}
for r in val.itertuples():
    gt.setdefault((r.b, r.nq), []).append(r.answer)
rows = []
for r in t[t.category == 'D2'].itertuples():
    g = gt.get((r.b, r.nq))
    if g and len(set(g)) == 1:
        rows.append(dict(qid=r.qid, video_id=r.video_id, answer=g[0]))
VOT = pd.DataFrame(rows).set_index('qid')
if __name__ == '__main__':
    print(len(VOT), VOT.video_id.value_counts().to_dict())
    SP = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/variants/'
    import glob, os
    files = ['/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv',
             '/home/user/quantiphy-challenge/submissions/trackA_probe3_s2maxext_d2denseoff_labdirect.csv'] + sorted(glob.glob(SP + '*.csv'))
    for f in files:
        s = pd.read_csv(f).set_index('id').parsed_value
        sc = item_scores(s.reindex(VOT.index), VOT.answer)
        print('%-45s %.4f' % (os.path.basename(f), sc.mean()))
