from ev import *
P = load('test.pkl')
df = P['df']; recs = P['records']
def prior_px(anns):
    out = {}
    for r in df.itertuples():
        a = anns.get(int(r.qid))
        if a is None: continue
        rec = recs[r.video_id]
        ans = G.solve(a.spec, a.tracks, tuple(rec['meta']['image_size']), float(rec['meta']['fps']), seen_scale=float(rec['meta'].get('scale') or 1.0))
        out[int(r.qid)] = (ans.debug.get('prior_px', np.nan), ';'.join(ans.flags))
    return out
rows = []
X = {w: prior_px(P[w]) for w in ['raw', 'refine', 'dense']}
for q in X['raw']:
    rows.append(dict(qid=q, raw=X['raw'][q][0], refine=X['refine'][q][0], dense=X['dense'][q][0], fl=X['dense'][q][1]))
R = pd.DataFrame(rows).merge(df[['qid', 'video_id', 'video_source', 'prior', 'inference_type']], on='qid')
# which post-step applied to the prior
rl = {(q, role): i for q, role, i in P['rlog']}
dl = {(q, role): i for q, role, k, i in P['dense_log']}
R['refine_why'] = [rl.get((q, 'prior'), {}).get('why', '') for q in R.qid]
R['dense_why'] = [str(dl.get((q, 'prior'), {}).get('why', '')) for q in R.qid]
R['claude_disp'] = [rl.get((q, 'prior'), {}).get('claude_disp', np.nan) for q in R.qid]
R['lk_disp'] = [rl.get((q, 'prior'), {}).get('lk_disp', np.nan) for q in R.qid]
R.to_pickle('ppx.pkl')
