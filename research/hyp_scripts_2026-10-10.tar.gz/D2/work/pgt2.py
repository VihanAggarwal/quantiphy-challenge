"""Looser pseudo-GT: a D2 question 'what is the <kind> of the <obj> ...' matched to a prior '<kind> of the <obj> = v'
stated in another video of the same simulation scene family (scene number within 8). Evaluation only."""
import re, sys
import numpy as np, pandas as pd
sys.path.insert(0, '/home/user/quantiphy-challenge')
from qp.data import load_split
from qp.parse import _UNITS, canonical_unit
t = load_split('test')
PRI = re.compile(r'^\s*(?:the\s+)?(speed|velocity|acceleration|length|height|width|diameter)\s+of\s+the\s+(.*?)\s*=\s*([-+0-9.eE]+)\s*([a-zA-Z/^0-9]*)\s*$', re.I)
def sn(v):
    m = re.match(r'simulation_(\d+)', v); return int(m.group(1)) if m else None
pri = []
for r in t.drop_duplicates('video_id').itertuples():
    m = PRI.match(r.prior.strip())
    if not m or sn(r.video_id) is None: continue
    kind, obj, val, u = m.groups()
    kind = {'velocity': 'speed'}.get(kind.lower(), kind.lower())
    try: val = abs(float(val))
    except ValueError: continue
    cu = canonical_unit(u or 'm')
    if cu in _UNITS: val *= _UNITS[cu][0]
    pri.append((r.video_id, sn(r.video_id), kind, obj.lower().strip(), val))
rows = []
for r in t[t.category == 'D2'].itertuples():
    n = sn(r.video_id)
    if n is None: continue
    q = r.question.lower()
    m = re.match(r'\s*what is the (?:average )?(speed|velocity|acceleration|length|height|width|diameter) of the (.*?)(?: at [0-9.]+ ?s| in | \(|\?|,)', q)
    if not m: continue
    kind = {'velocity': 'speed'}.get(m.group(1), m.group(1)); obj = m.group(2).strip()
    if kind in ('speed', 'acceleration') and re.search(r'\bat\s*(time\s*)?[0-9.]+\s*s', q):
        continue   # instantaneous: a stated constant prior only if the motion is uniform; skip
    vals = [p[4] for p in pri if p[0] != r.video_id and abs(p[1] - n) <= 8 and p[2] == kind and p[3] == obj]
    if not vals: continue
    cu = canonical_unit(r.target_unit or 'm'); f = _UNITS[cu][0] if cu in _UNITS else 1.0
    rows.append(dict(qid=r.qid, video_id=r.video_id, kind=kind, obj=obj, pgt=np.median(vals) / f, n=len(vals), spread=max(vals) / min(vals)))
X = pd.DataFrame(rows)
X.to_csv('pseudo_gt2.csv', index=False)
print(len(X)); print(X.kind.value_counts()); print(X[X.kind.isin(['speed','acceleration'])].to_string())
