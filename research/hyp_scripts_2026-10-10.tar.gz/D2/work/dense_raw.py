from ev import *
from qp import dense_track as dt
P = load('test.pkl')
R = pd.read_pickle('ppx.pkl')
R['ref_raw'] = R.refine / R.raw
vids = R[(R.refine_why == 'refined')].drop_duplicates('video_id')
vids = vids[np.abs(np.log(vids.ref_raw)) > float(sys.argv[1])].video_id.tolist() if len(sys.argv) > 1 else vids.video_id.tolist()
print(len(vids), vids)
qs = set(P['df'][P['df'].video_id.isin(vids)].qid)
sub = {q: copy.deepcopy(a) for q, a in P['raw'].items() if q in qs}
paths = {q: p for q, p in P['paths'].items() if q in qs}
meta = {q: m for q, m in P['meta'].items() if q in qs}
log = []
dt.densify_annotations(sub, paths, meta, what='motion', cache_dir='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/base/runs/_dense_cache/test',
                       log=log, workers=1, skip=set(), size_method=dt.SIZE_METHOD, motion_kinds=tuple(dt.MOTION))
pickle.dump({'anns': sub, 'log': log}, open('dense_raw_%s.pkl' % (sys.argv[1] if len(sys.argv) > 1 else 'all'), 'wb'))
