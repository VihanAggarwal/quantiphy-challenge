"""Evaluate geometry variants on pickled D2 annotations."""
import sys, pickle, os, math, copy
REPO = os.environ.get('QP_REPO', '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/base/repo')
sys.path.insert(0, REPO); sys.path.insert(0, REPO + '/scripts')
import numpy as np, pandas as pd
import run_claude as rc
from qp.mra import item_scores
from qp import geometry as G

def load(p):
    return pickle.load(open(p, 'rb'))

def results(P, which='dense', anns=None):
    anns = anns if anns is not None else P[which]
    res = rc.build_results(P['df'], P['records'], anns=copy.deepcopy(anns))
    return res

def score(P, res, col='parsed_value'):
    df = P['df']
    if 'answer' not in df:
        return None
    m = df[['qid', 'video_id', 'answer', 'video_source', 'inference_type']].merge(res, left_on='qid', right_on='id')
    m['s'] = item_scores(m[col], m['answer'])
    return m
