import sys, glob, hashlib
sys.path.insert(0, '/home/user/quantiphy-challenge')
import numpy as np, pandas as pd
from qp.data import load_split
T = pd.read_csv('/home/user/quantiphy-challenge/data/submission_template/quantiphy_submission_template.csv')
t = load_split('test')
cat = dict(zip(t.qid.astype(int), t.category))
v2 = pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv')
print('template ids', len(T), 'v2 ids', len(v2), 'v2 cols', v2.columns.tolist())
print('v2 ids == template ids (order):', (v2.id.values == T.id.values).all())
VD = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/variants/'
for f in sorted(glob.glob(VD + '*.csv')):
    d = pd.read_csv(f)
    raw = open(f).read()
    ok_cols = d.columns.tolist() == ['id', 'parsed_value']
    same_ids = len(d) == len(T) and (d.id.values == T.id.values).all()
    dup = d.id.duplicated().any()
    fin = np.isfinite(d.parsed_value).all() and (d.parsed_value > 0).all()
    m = d.merge(v2, on='id', suffixes=('', '_v2'))
    ch = ~np.isclose(m.parsed_value, m.parsed_value_v2, rtol=0, atol=0)
    cats = pd.Series([cat[int(i)] for i in m.id[ch]]).value_counts().to_dict()
    nonD2 = sum(v for k, v in cats.items() if k != 'D2')
    # check non-D2 rows exactly byte-equal values (string compare)
    s1 = pd.read_csv(f, dtype=str); s2 = pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv', dtype=str)
    nond2mask = ~s1.id.astype(int).map(cat).eq('D2')
    strdiff = (s1.parsed_value[nond2mask] != s2.parsed_value[nond2mask]).sum()
    r = m.parsed_value[ch] / m.parsed_value_v2[ch]
    print(f.split('/')[-1], 'cols', ok_cols, 'ids==template', same_ids, 'dup', dup, 'finite>0', fin, 'min', d.parsed_value.min(), 'max', d.parsed_value.max(),
          'changed', int(ch.sum()), cats, 'nonD2 changed', nonD2, 'nonD2 string diffs', int(strdiff), 'med ratio', round(float(np.median(r)), 4),
          'min/max ratio', round(float(r.min()), 3), round(float(r.max()), 3), 'md5', hashlib.md5(raw.encode()).hexdigest()[:10])
