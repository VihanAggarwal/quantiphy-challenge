import os, sys, time
W='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/work'
os.chdir(W); sys.path.insert(0, W)
t0=time.time()
from build import *   # P, df, recs, RO, pad_anns, replace_prior
import segtwin
OUT='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/review_integrity/'
VD='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/variants/'
v2 = pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv').set_index('id').parsed_value
d2 = sorted(df.qid.astype(int))
def fin(vals):
    return {q: (vals.get(q, np.nan) if np.isfinite(vals.get(q, np.nan)) and vals.get(q, np.nan) > 0 else v2[q]) for q in d2}
def cmp(name, vals):
    f = pd.read_csv(VD + name + '.csv').set_index('id').parsed_value
    a = np.array([vals[q] for q in d2]); b = f.reindex(d2).values
    eq = np.isclose(a, b, rtol=1e-12, atol=0)
    print(name, 'repro==csv', eq.sum(), '/', len(d2), 'maxrel', np.nanmax(np.abs(a/b-1)))
    for q in np.array(d2)[~eq][:10]: print('   ', q, vals[q], f[q])
res_ro = rc.build_results(df, recs, anns=copy.deepcopy(RO)); vro = dict(zip(res_ro.id.astype(int), res_ro.parsed_value))
print('nonfinite ro', sum(not (np.isfinite(vro.get(q, np.nan)) and vro.get(q,np.nan)>0) for q in d2))
cmp('D2_refineoff', fin(vro))
an_pad, n = pad_anns(RO, df, recs, 0.8); print('padded obs', n)
res_pad = rc.build_results(df, recs, anns=an_pad); vpad = dict(zip(res_pad.id.astype(int), res_pad.parsed_value))
print('nonfinite pad', sum(not (np.isfinite(vpad.get(q, np.nan)) and vpad.get(q,np.nan)>0) for q in d2))
cmp('D2_refineoff_pad', fin(vpad))
cmp('D2_refineoff_pad_segtwin', fin(segtwin.apply(vpad)))
pickle.dump(dict(vro=vro, vpad=vpad, res_pad=res_pad, res_ro=res_ro), open(OUT+'repro.pkl','wb'))
print('time', time.time()-t0)
