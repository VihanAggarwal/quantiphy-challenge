import os, sys, time
W='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/work'
CVD='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/cv/'
os.chdir(W); sys.path.insert(0, W); sys.path.insert(0, CVD)
from build import *
from cvtrack import to_roletrack
import segtwin
VD='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/variants/'
X0 = pd.read_pickle(CVD+'cmp_seg.pkl'); print('cmp_seg tags', X0.tag.value_counts().to_dict(), 'which', X0.which.value_counts().to_dict())
X1 = pd.read_pickle(CVD+'cmp.pkl'); print('cmp == cmp_seg', X0.equals(X1))
CV = {}
for f in ('cv_seg.pkl', 'cv_simseg.pkl'):
    CV.update({v: r for v, r in load(CVD + f).items() if r})
X = X0[(X0.which == 'c') & X0.cv.notna()].drop_duplicates('v').set_index('v')
use = {}
for v, r in X.iterrows():
    if r.nok >= 15 and r.nok >= 0.5 * r.n and abs(np.log(r.cv / r.ro)) < 0.10:
        use[v] = to_roletrack(CV[v]['out'], 'c', CV[v]['ok'], CV[v]['obj'])
print('CV prior used on', len(use), sorted(use))
rej = [(v, round(r.cv/r.ro,3), int(r.nok), int(r.n)) for v, r in X.iterrows() if v not in use]
print('rejected', rej)
an, n = replace_prior(RO, df, use); print('questions with CV prior', n)
an_pad, _ = pad_anns(an, df, recs, 0.8)
res = rc.build_results(df, recs, anns=an_pad)
vals = dict(zip(res.id.astype(int), res.parsed_value))
v2 = pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv').set_index('id').parsed_value
d2 = sorted(df.qid.astype(int))
st = segtwin.apply(vals)
fin = {q: (st[q] if np.isfinite(st.get(q, np.nan)) and st[q] > 0 else v2[q]) for q in d2}
f = pd.read_csv(VD+'D2_refineoff_pad_cvprior_segtwin.csv').set_index('id').parsed_value
a = np.array([fin[q] for q in d2]); b = f.reindex(d2).values
print('cvprior_segtwin repro==csv', np.isclose(a, b, rtol=1e-12).sum(), '/', len(d2))
# which videos in 'use' come from where: cv track built from segmented twin frames in both cases?
print({v: CV[v]['mode'] for v in use})
