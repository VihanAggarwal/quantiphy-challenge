import sys
sys.path.insert(0, '/home/user/quantiphy-challenge')
import numpy as np, pandas as pd
from qp.data import load_split
t = load_split('test'); D2 = set(t[t.category=='D2'].qid.astype(int))
REP = pd.read_csv('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/probe3/refineoff/runs/test_v1_high_854/test.csv').set_index('id')
V = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/variants/'
v4 = pd.read_csv(V+'D2_refineoff.csv').set_index('id').parsed_value
v2 = pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv').set_index('id')
d2 = sorted(D2)
rep = REP.parsed_value.reindex(d2)
eq = np.isclose(v4.reindex(d2), rep, rtol=1e-12, atol=0)
print('D2 rows: v4 == replay', eq.sum(), '/', len(d2))
for q in np.array(d2)[~eq]:
    print(q, v4[q], rep[q], v2.parsed_value[q], REP.loc[q, ['method','flags']].tolist())
# v2 vs replay on non-D2: what replay changed elsewhere
nd = [q for q in REP.index if q not in D2]
print('replay non-D2 differs from v1 test.csv?')
T1 = pd.read_csv('/home/user/quantiphy-challenge/runs/test_v1_high_854/test.csv').set_index('id')
x = ~np.isclose(REP.parsed_value.reindex(T1.index), T1.parsed_value, rtol=1e-12)
print('replay vs repo test.csv changed:', x.sum(), pd.Series([t.set_index('qid').category[q] for q in T1.index[x]]).value_counts().to_dict())
# v2 vs repo test.csv on D2
y = ~np.isclose(v2.parsed_value.reindex(d2), T1.parsed_value.reindex(d2), rtol=1e-12)
print('v2 vs repo test.csv on D2 differ:', y.sum())
