import sys
sys.path.insert(0, '/home/user/quantiphy-challenge')
import numpy as np, pandas as pd
from qp.data import load_split
t = load_split('test'); cat = dict(zip(t.qid.astype(int), t.category))
V2='/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv'
f='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/variants/D2_refineoff_pad_segtwin.csv'
a=pd.read_csv(f,dtype=str); b=pd.read_csv(V2,dtype=str)
print('cols equal', a.columns.tolist()==b.columns.tolist())
for c in a.columns:
    if c=='parsed_value': continue
    d=(a[c].fillna('')!=b[c].fillna('')).sum()
    if d: print('col differs', c, d)
m = ~a.id.astype(int).map(cat).eq('D2')
idx = np.where(m & (a.parsed_value != b.parsed_value))[0]
for i in idx: print(a.id[i], cat[int(a.id[i])], repr(a.parsed_value[i]), repr(b.parsed_value[i]), float(a.parsed_value[i])==float(b.parsed_value[i]))
