import os, sys
W='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/work'
sys.path.insert(0, W); sys.path.insert(0, '/home/user/quantiphy-challenge')
import cv2, numpy as np, pandas as pd
import segtwin, mkcsv
t = mkcsv._t.set_index('qid')
m = segtwin.twin_map()
print('pairs', len(m))
vids = set()
for s, o in m.items(): vids |= {t.loc[s].video_id, t.loc[o].video_id}
info = {}
for v in sorted(vids):
    p = t[t.video_id == v].video_path.iloc[0]
    cap = cv2.VideoCapture(p)
    info[v] = (int(cap.get(cv2.CAP_PROP_FRAME_COUNT)), round(cap.get(cv2.CAP_PROP_FPS), 3), int(cap.get(3)), int(cap.get(4)))
bad = []
for s, o in m.items():
    vs, vo = t.loc[s].video_id, t.loc[o].video_id
    if info[vs] != info[vo] or t.loc[s].fps != t.loc[o].fps:
        bad.append((s, o, vs, info[vs], t.loc[s].fps, info[vo], t.loc[o].fps, t.loc[s].question[:70]))
print('pairs with differing frame count/fps/size:', len(bad))
for b in bad: print(b)
# categories / sources of mapped pairs
print(pd.Series([t.loc[o].video_source for o in m.values()]).value_counts().to_dict(), pd.Series([t.loc[s].video_source for s in m]).value_counts().to_dict())
