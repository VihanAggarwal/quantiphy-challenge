import os, sys
W='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/work'
os.chdir(W); sys.path.insert(0, W)
from ev import *
P = load('test.pkl'); df = P['df']
RO = load('dense_ro.pkl')['anns']
R = pickle.load(open('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/review_integrity/repro.pkl','rb'))
vro, vpad = R['vro'], R['vpad']
m = df[['qid','video_id','video_source','question']].copy()
m['tk'] = [RO[q].spec.target.kind if q in RO else None for q in m.qid]
m['pk'] = [RO[q].spec.prior.kind if q in RO else None for q in m.qid]
m['r'] = [vpad[q]/vro[q] for q in m.qid]
ch = np.abs(np.log(m.r)) > 1e-9
print(m[ch].groupby(['pk','tk']).r.agg(['count','median','min','max']).round(4).to_string())
print(m[ch & (m.tk=='distance')][['qid','video_id','question','r']].head(20).to_string())
print('pk in size kinds (prior padded) and changed:', (ch & m.pk.isin(['size','other','distance'])).sum())
big = m[ch & (np.abs(np.log(m.r)) > 0.03)].sort_values('r', ascending=False)
v2 = pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv').set_index('id').parsed_value
big['v2'] = big.qid.map(v2); big['pad'] = big.qid.map(vpad); big['method'] = big.qid.map(R['res_pad'].set_index('id').method)
print(len(big)); print(big[['qid','video_id','question','r','v2','pad','method']].to_string())
