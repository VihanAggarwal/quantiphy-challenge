import sys, pickle
REPO='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/base/repo'
sys.path.insert(0, REPO); sys.path.insert(0, REPO+'/scripts')
import numpy as np, pandas as pd
W='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/work/'
A = pickle.load(open(W+'allres.pkl','rb'))
REP = pd.read_csv('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/probe3/refineoff/runs/test_v1_high_854/test.csv').set_index('id')
T1 = pd.read_csv('/home/user/quantiphy-challenge/runs/test_v1_high_854/test.csv').set_index('id')
v2 = pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv').set_index('id').parsed_value
for k, r in A.items():
    ids = r.index
    ref = REP if k == 'ro' else T1
    eq = np.isclose(r.parsed_value, ref.parsed_value.reindex(ids), rtol=1e-9)
    print(k, len(ids), 'match', eq.sum())
    if k in ('ro','dense'):
        for q in ids[~eq]:
            print('  ', q, r.loc[q, ['parsed_value','method','flags']].tolist(), '| replay', ref.loc[q, ['parsed_value','method','flags']].tolist(), '| v2', v2[q])
