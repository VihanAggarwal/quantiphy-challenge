import sys, re, glob, os, pickle
sys.path.insert(0, '/home/user/quantiphy-challenge')
import numpy as np, pandas as pd
from qp.data import load_split
from qp.mra import item_scores
P = pickle.load(open('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/work/test.pkl','rb')) if False else None
def base(v):
    v = v.replace('_segmented', '')
    m = re.match(r'(captured_\d+a?)[sx]?$', v)
    return m.group(1) if m else v
def norm(s): return re.sub(r'\s+', '', str(s).strip().lower())
val = load_split('val'); t = load_split('test')
val = val.assign(b=val.video_id.map(base), k=val.question.map(norm)+'|'+val.prior.map(norm)+'|'+val.depth_info.fillna('').map(norm))
t = t.assign(b=t.video_id.map(base), k=t.question.map(norm)+'|'+t.prior.map(norm)+'|'+t.depth_info.fillna('').map(norm))
gt = {}
for r in val.itertuples(): gt.setdefault((r.b, r.k), set()).add(r.answer)
rows = []
for r in t.itertuples():
    g = gt.get((r.b, r.k))
    if g and len(g) == 1: rows.append((r.qid, r.category, r.video_id, list(g)[0]))
K = pd.DataFrame(rows, columns=['qid','cat','video_id','gt']).set_index('qid')
print('known rows', len(K), K.cat.value_counts().to_dict())
KD = K[K.cat=='D2']
print('D2 known', len(KD), 'videos', KD.video_id.nunique())
files = {'v2':'/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv'}
files.update({os.path.basename(f)[:-4]: f for f in sorted(glob.glob('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/variants/*.csv'))})
for k, f in files.items():
    s = pd.read_csv(f).set_index('id').parsed_value
    x = s.reindex(KD.index)
    lr = np.abs(np.log(x / KD['gt']))
    exact = (lr < 1e-4).sum()
    sc = item_scores(x, KD['gt']).mean()
    print(f'{k:40s} D2-known MRA {sc:.4f}  exact(<0.01%) {exact}  within1% {(lr<0.01).sum()}  changed-vs-v2 on known {(np.abs(np.log(x/ pd.read_csv(files["v2"]).set_index("id").parsed_value.reindex(KD.index)))>1e-9).sum()}')
