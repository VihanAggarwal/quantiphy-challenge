import sys; sys.path.insert(0,'/home/user/quantiphy-challenge')
import pandas as pd, numpy as np
from qp import mra
R=pd.read_pickle('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/work/ppx2.pkl').set_index('qid')
d=pd.read_csv('d2.csv').set_index('qid')
TRUE={'simulation_0240':77.0,'simulation_0238':77.0,'simulation_0236':77.3,'simulation_0241':64.0,'simulation_0239':64.7,'simulation_0237':64.7,
'simulation_0239_segmented':64.5,'simulation_0237_segmented':64.7,'simulation_0225':127.0,'simulation_0227':127.5,'simulation_0228':131.0,
'simulation_0225_segmented':127.0,'simulation_0119':30.5,'simulation_0192':1980,'simulation_0192_segmented':1980,'simulation_0118':62.75,
'simulation_0243_segmented':196.0,'simulation_0248':77.5,'simulation_0248_segmented':77.5,'simulation_0196':115.0,'simulation_0231':210.0,
'simulation_0177':82.0,'simulation_0177_segmented':81.5,'simulation_0047':109.0,'simulation_0130':125.5,'simulation_0057':164.0,
'simulation_0245_segmented':198.0,'simulation_0198':113800}
rows=[]
for v,tr in TRUE.items():
    q=R[R.video_id==v]
    r=q.iloc[0]
    rows.append(dict(video=v,n=len(q),true=tr,raw=r.raw,v2=r.dense,ro=r.ro,e_raw=np.log(r.raw/tr),e_v2=np.log(r.dense/tr) if r.dense==r.dense else np.nan,e_ro=np.log(r.ro/tr),
                     rpro_med=d.loc[q.index].r_pro.median(), rmain_med=d.loc[q.index].r_main.median()))
T=pd.DataFrame(rows); pd.set_option('display.width',250)
print(T.round(3).to_string())
w=T.n
for c in ['e_raw','e_v2','e_ro']:
    x=T[c].abs(); m=x.notna()
    print(c,'weighted mean |log err|',round((x[m]*w[m]).sum()/w[m].sum(),4),' n>10%',int((w[m]*(x[m]>0.0953)).sum()),' n>5%',int((w[m]*(x[m]>0.0488)).sum()))
# expected MRA: e_pro = Tnoise * true/ro ; e_v2 = e_pro / r_pro ; e_main = e_pro * r_main/r_pro
rng=np.random.default_rng(0)
qs=d[d.video_id.isin(TRUE)].copy()
qs['true']=qs.video_id.map(TRUE); qs['ro']=R.loc[qs.index].ro
base=qs['true']/qs['ro']
for sig in [0.05,0.10,0.15,0.20]:
    S={'v2':[],'pro':[],'main':[]}
    for k in range(400):
        Tn=np.exp(rng.normal(0,sig,len(qs)))
        e_pro=Tn*base.values; e_v2=e_pro/qs.r_pro.values; e_main=e_pro*qs.r_main.values/qs.r_pro.values
        for nm,e in [('v2',e_v2),('pro',e_pro),('main',e_main)]:
            S[nm].append(np.mean(mra.item_scores(e,np.ones(len(e)))))
    print(f'sigma {sig}: n={len(qs)} mean MRA v2 {np.mean(S["v2"]):.3f} pro {np.mean(S["pro"]):.3f} main {np.mean(S["main"]):.3f}  => D2 delta pro {(np.mean(S["pro"])-np.mean(S["v2"]))*len(qs)/1163:+.4f} main(prior part only) {(np.mean(S["main"])-np.mean(S["v2"]))*len(qs)/1163:+.4f}')
