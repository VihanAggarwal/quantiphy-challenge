"""median-background difference blob tracker in a ROI: centroid per frame (largest comp near prev)."""
import cv2, sys, numpy as np
v=sys.argv[1]; f0,f1=int(sys.argv[2]),int(sys.argv[3]); x0,y0,x1,y1=[int(a) for a in sys.argv[4].split(',')]; thr=float(sys.argv[5]); start=np.array([float(a) for a in sys.argv[6].split(',')])
bgr=sys.argv[7] if len(sys.argv)>7 else 'all'
cap=cv2.VideoCapture(f'/home/user/quantiphy-challenge/data/QuantiPhy/{v}.mp4'); fps=cap.get(5); F=[]
while cap.grab():
    ok,img=cap.retrieve(); F.append(img[y0:y1,x0:x1].astype(np.float32))
F=np.array(F); bg=np.median(F,axis=0)
prev=start-[x0,y0]; rows=[]
for i in range(f0,f1+1):
    d=np.abs(F[i]-bg).max(axis=2); m=(d>thr).astype(np.uint8)
    m=cv2.morphologyEx(m,cv2.MORPH_CLOSE,np.ones((5,5),np.uint8)); m=cv2.morphologyEx(m,cv2.MORPH_OPEN,np.ones((3,3),np.uint8))
    n,lab,st,cen=cv2.connectedComponentsWithStats(m)
    best=None
    for k in range(1,n):
        if st[k,4]<int(sys.argv[8]) if len(sys.argv)>8 else st[k,4]<40: continue
        dd=np.linalg.norm(cen[k]-prev)
        if best is None or dd<best[0]: best=(dd,k)
    if best and best[0]<60:
        k=best[1]; c=cen[k]; prev=c
        # weighted centroid of diff inside comp
        rows.append((i,c[0]+x0,c[1]+y0,st[k,4], st[k,1]+y0, st[k,1]+st[k,3]+y0, st[k,0]+x0, st[k,0]+st[k,2]+x0))
R=np.array(rows); t=R[:,0]/fps
np.set_printoptions(suppress=True,linewidth=200,precision=1)
print(R[::3])
for j,nm in [(1,'cx'),(2,'cy'),(4,'top'),(5,'bot'),(6,'left'),(7,'right')]:
    s=np.polyfit(t,R[:,j],1)[0]; print(f'{v} {nm:5s} slope {s:7.2f} px/s chord {(R[-1,j]-R[0,j])/(t[-1]-t[0]):7.2f}')
P=R[:,1:3]; print('2D chord speed',np.linalg.norm(P[-1]-P[0])/(t[-1]-t[0]), 'n',len(R))
