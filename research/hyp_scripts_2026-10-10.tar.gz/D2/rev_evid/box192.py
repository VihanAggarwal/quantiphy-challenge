import sys; sys.path.insert(0,'.')
from tm import read, track
import numpy as np
fr,fps=read('simulation_0192',0,90)
pos,cc=track(fr,0,[815,90,1075,280],S=60,mode='fixed')
fs=np.array(sorted(pos)); y=np.array([pos[f][1] for f in fs]); t=fs/fps
np.set_printoptions(suppress=True,precision=1,linewidth=200)
print(np.c_[fs,y,[cc[f] for f in fs]][::6])
# find landing: first frame where y stops increasing
dy=np.diff(y); land=fs[np.argmax((fs[1:]>20)&(dy<0.5))]
print('landing frame ~',land)
for end in [53,60,66,int(land)-2]:
    m=fs<=end; c=np.polyfit(t[m],y[m],2); print(f'fit f0-{end}: accel {2*c[0]:.1f} px/s^2  rms {np.sqrt(np.mean((np.polyval(c,t[m])-y[m])**2)):.2f}')
