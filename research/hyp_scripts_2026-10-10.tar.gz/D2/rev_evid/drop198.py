import sys; sys.path.insert(0,'.')
from tm import read
import numpy as np, cv2
fr,fps=read('simulation_0198',0,13)
from tm import sub
box=[1422,770,1470,835]; x0,y0,x1,y1=box; tpl=fr[1][y0:y1,x0:x1]
rows=[]
for f in sorted(fr):
    win=fr[f][600:2560,1300:1600]
    r=cv2.matchTemplate(win,tpl,cv2.TM_CCOEFF_NORMED); x,y,c=sub(r); rows.append((f,1300+x,600+y,c))
R=np.array(rows); np.set_printoptions(suppress=True,precision=1,linewidth=200); print(R)
t=R[:,0]/fps
for lo,hi in [(0,6),(1,6),(2,8),(2,13),(3,13)]:
    m=(R[:,0]>=lo)&(R[:,0]<=hi)&(R[:,3]>0.6)
    c=np.polyfit(t[m],R[m,2],2); print(f'f{lo}-{hi}: accel {2*c[0]:.0f} px/s^2 rms {np.sqrt(np.mean((np.polyval(c,t[m])-R[m,2])**2)):.2f} n {m.sum()}')
