"""Independent px-speed of a prior object by template matching (fixed f0 template + re-anchoring).
usage: tm.py video f0 f1 x0,y0,x1,y1 (original px box of a rigid part at f0) [search_px]"""
import cv2, sys, numpy as np, json
def read(v, f0, f1):
    cap=cv2.VideoCapture(f'/home/user/quantiphy-challenge/data/QuantiPhy/{v}.mp4'); fr={}; i=0
    while cap.grab():
        if f0<=i<=f1:
            ok,img=cap.retrieve(); fr[i]=img.astype(np.float32)
        i+=1
        if i>f1: break
    return fr, cap.get(5)
def sub(r):
    # subpixel parabola peak
    y,x=np.unravel_index(np.argmax(r),r.shape); dx=dy=0.0
    if 0<x<r.shape[1]-1:
        a,b,c=r[y,x-1],r[y,x],r[y,x+1]; den=a-2*b+c; dx=0.5*(a-c)/den if den!=0 else 0
    if 0<y<r.shape[0]-1:
        a,b,c=r[y-1,x],r[y,x],r[y+1,x]; den=a-2*b+c; dy=0.5*(a-c)/den if den!=0 else 0
    return x+dx, y+dy, float(r[y,x])
def track(fr, f0, box, S=40, mode='fixed', reanchor=0.0):
    x0,y0,x1,y1=box; tpl=fr[f0][y0:y1,x0:x1]; pos={f0:(float(x0),float(y0))}; cc={f0:1.0}
    vel=np.zeros(2); last=np.array([x0,y0],float); tf=f0
    for f in sorted(fr):
        if f==f0: continue
        pred=last+vel
        sx0=int(max(0,pred[0]-S)); sy0=int(max(0,pred[1]-S))
        sx1=int(min(fr[f].shape[1],pred[0]+(x1-x0)+S)); sy1=int(min(fr[f].shape[0],pred[1]+(y1-y0)+S))
        win=fr[f][sy0:sy1,sx0:sx1]
        r=cv2.matchTemplate(win,tpl,cv2.TM_CCOEFF_NORMED)
        x,y,c=sub(r); p=np.array([sx0+x,sy0+y])
        vel=p-last; last=p; pos[f]=tuple(p); cc[f]=c
        if mode=='chain' or (reanchor and c<reanchor):
            ix,iy=int(round(p[0])),int(round(p[1]))
            tpl=fr[f][iy:iy+(y1-y0),ix:ix+(x1-x0)]
    return pos, cc
if __name__=='__main__':
    v=sys.argv[1]; f0=int(sys.argv[2]); f1=int(sys.argv[3]); box=[int(a) for a in sys.argv[4].split(',')]
    S=int(sys.argv[5]) if len(sys.argv)>5 else 40
    fr,fps=read(v,f0,f1)
    out={}
    for mode,ra in [('fixed',0.0),('fixed_ra.85',0.85),('chain',0.0)]:
        pos,cc=track(fr,f0,box,S,'chain' if mode=='chain' else 'fixed',ra)
        fs=np.array(sorted(pos)); P=np.array([pos[f] for f in fs]); t=fs/fps
        cx=np.polyfit(t,P[:,0],1)[0]; cy=np.polyfit(t,P[:,1],1)[0]
        chord=np.linalg.norm(P[-1]-P[0])/(t[-1]-t[0])
        # path of a smoothed track (moving average over 5 frames)
        k=5; Ps=np.array([np.convolve(P[:,j],np.ones(k)/k,mode='valid') for j in range(2)]).T
        path=np.linalg.norm(np.diff(Ps,axis=0),axis=1).sum()/((len(Ps)-1)/fps)
        out[mode]=dict(fit=float(np.hypot(cx,cy)),chord=float(chord),path5=float(path),cc_min=float(min(cc.values())),cc_med=float(np.median(list(cc.values()))))
        print(f'{v} {mode:12s} fit {np.hypot(cx,cy):7.2f}  chord {chord:7.2f}  path5 {path:7.2f} px/s  cc min {min(cc.values()):.2f} med {np.median(list(cc.values())):.2f}  disp {P[-1]-P[0]}')
    json.dump(out,open(f'tm_{v}_{f0}_{f1}.json','w'))
