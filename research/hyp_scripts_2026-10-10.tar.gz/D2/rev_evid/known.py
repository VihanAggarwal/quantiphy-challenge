import sys, re; sys.path.insert(0,'/home/user/quantiphy-challenge')
import pandas as pd, numpy as np
from qp.data import load_split
from qp import mra
SP='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad'
base=lambda v: re.sub(r'(_segmented|(?<=\d)[a-z]+)$','',v)
norm=lambda s: re.sub(r'\s+','',str(s).lower())
val=load_split('val'); t=load_split('test')
val['k']=[ (base(v),norm(q),norm(p),norm(d)) for v,q,p,d in zip(val.video_id,val.question,val.prior,val.depth_info)]
t['k']=[ (base(v),norm(q),norm(p),norm(d)) for v,q,p,d in zip(t.video_id,t.question,t.prior,t.depth_info)]
g=val.groupby('k').answer.agg(['first','nunique','size'])
t['gtv']=t.k.map(g['first']); t['gt_n']=t.k.map(g['nunique'])
K=t[t.gtv.notna()].copy()
print('known rows',len(K), K.category.value_counts().to_dict(), 'ambiguous',(K.gt_n>1).sum())
v2=pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv').set_index('id').parsed_value
files={'v2':None,'pro':SP+'/hyp/D2/variants/D2_refineoff.csv','pad':SP+'/hyp/D2/variants/D2_refineoff_pad.csv','main':SP+'/hyp/D2/variants/D2_refineoff_pad_segtwin.csv','cv':SP+'/hyp/D2/variants/D2_refineoff_pad_cvprior_segtwin.csv'}
K=K.set_index('qid')
for nm,f in files.items():
    s=v2 if f is None else pd.read_csv(f).set_index('id').parsed_value
    K[nm]=s.reindex(K.index)
D=K[K.category=='D2'].copy()
for nm in files:
    D['s_'+nm]=mra.item_scores(D[nm].values, D.gtv.values) if hasattr(mra,'item_scores') else np.nan
print(D[['s_'+n for n in files]].mean().round(4).to_dict(), len(D))
pd.set_option('display.width',250)
ch=D[(D.pro!=D.v2)|(D.main!=D.v2)]
print(ch[['video_id','gtv','v2','pro','main']+['s_'+n for n in files]].round(3).to_string())
D.to_csv('known_d2.csv')
