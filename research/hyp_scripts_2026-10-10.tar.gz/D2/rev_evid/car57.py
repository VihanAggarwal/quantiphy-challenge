import cv2, numpy as np
cap=cv2.VideoCapture('/home/user/quantiphy-challenge/data/QuantiPhy/simulation_0057.mp4'); fps=cap.get(5); rows=[]; i=0
while cap.grab():
    ok,img=cap.retrieve(); hsv=cv2.cvtColor(img,cv2.COLOR_BGR2HSV)
    m=((hsv[...,0]>5)&(hsv[...,0]<22)&(hsv[...,1]>150)&(hsv[...,2]>120)).astype(np.uint8)
    m[:, :250]=0; m[:, 500:]=0
    ys,xs=np.nonzero(m)
    if len(ys)>200: rows.append((i, ys.max(), ys.min(), ys.mean(), xs.mean(), len(ys)))
    i+=1
R=np.array(rows,float); t=R[:,0]/fps
np.set_printoptions(suppress=True,precision=1,linewidth=200); print(R[::6])
for lo,hi in [(6,90),(12,84),(20,90)]:
    m=(R[:,0]>=lo)&(R[:,0]<=hi)
    for j,nm in [(1,'front'),(2,'rear')]:
        ok=m&((R[:,2]>2) if nm=='rear' else (R[:,1]<1075))
        c=np.polyfit(t[ok],R[ok,j],2); print(f'f{lo}-{hi} {nm}: accel {2*c[0]:.1f} px/s^2 rms {np.sqrt(np.mean((np.polyval(c,t[ok])-R[ok,j])**2)):.2f} n {ok.sum()}')
