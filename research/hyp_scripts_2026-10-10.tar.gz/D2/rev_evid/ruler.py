import cv2, sys, numpy as np
v=sys.argv[1]; frames=[int(x) for x in sys.argv[2].split(',')]; x0,y0,x1,y1=[int(a) for a in sys.argv[3].split(',')]
step=int(sys.argv[4]) if len(sys.argv)>4 else 20; sc=float(sys.argv[5]) if len(sys.argv)>5 else 1.0
cap=cv2.VideoCapture(f'/home/user/quantiphy-challenge/data/QuantiPhy/{v}.mp4'); i=0; out=[]
while cap.grab():
    if i in frames:
        ok,img=cap.retrieve(); c=img[y0:y1,x0:x1].copy()
        if sc!=1: c=cv2.resize(c,None,fx=sc,fy=sc,interpolation=cv2.INTER_CUBIC)
        for gx in range((x0//step+1)*step, x1, step):
            X=int((gx-x0)*sc); col=(0,255,255) if gx%(5*step)==0 else (255,255,0)
            cv2.line(c,(X,0),(X,c.shape[0]),col,1)
            if gx%(5*step)==0: cv2.putText(c,str(gx),(X+2,c.shape[0]-5),cv2.FONT_HERSHEY_SIMPLEX,0.45,(0,255,255),1)
        for gy in range((y0//step+1)*step, y1, step):
            Y=int((gy-y0)*sc)
            if gy%(5*step)==0:
                cv2.line(c,(0,Y),(c.shape[1],Y),(0,200,0),1); cv2.putText(c,str(gy),(2,Y-2),cv2.FONT_HERSHEY_SIMPLEX,0.45,(0,255,0),1)
        cv2.putText(c,f'f{i}',(5,20),cv2.FONT_HERSHEY_SIMPLEX,0.7,(0,0,255),2)
        out.append(c)
    i+=1
    if i>max(frames): break
cv2.imwrite(f'fr/r_{v}_{sys.argv[2].replace(",","-")}.jpg',np.vstack(out))
