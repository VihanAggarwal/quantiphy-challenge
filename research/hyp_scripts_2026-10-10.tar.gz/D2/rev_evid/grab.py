import cv2, sys, numpy as np
v=sys.argv[1]; frames=[int(x) for x in sys.argv[2].split(',')]
crop=None
if len(sys.argv)>3: crop=[int(x) for x in sys.argv[3].split(',')]  # x0,y0,x1,y1 original px
scale=float(sys.argv[4]) if len(sys.argv)>4 else 1.0
cap=cv2.VideoCapture(f'/home/user/quantiphy-challenge/data/QuantiPhy/{v}.mp4')
W,H=int(cap.get(3)),int(cap.get(4))
print(v,W,H,cap.get(5),cap.get(7))
imgs=[]
i=0
want=set(frames)
while cap.grab():
    if i in want:
        ok,img=cap.retrieve()
        if crop: img=img[crop[1]:crop[3],crop[0]:crop[2]]
        if scale!=1: img=cv2.resize(img,None,fx=scale,fy=scale,interpolation=cv2.INTER_AREA)
        cv2.putText(img,f'f{i}',(5,25),cv2.FONT_HERSHEY_SIMPLEX,0.8,(0,0,255),2)
        imgs.append(img)
    i+=1
    if i>max(frames): break
out=np.vstack(imgs) if len(sys.argv)>5 and sys.argv[5]=='v' else np.hstack(imgs) if len(imgs)<=3 else np.vstack([np.hstack(imgs[k:k+2]) for k in range(0,len(imgs)-1,2)])
cv2.imwrite(f'fr/{v}_{sys.argv[2].replace(",","-")}.jpg',out)
