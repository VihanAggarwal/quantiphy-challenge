"""dark-blob tracker: centroid / left / right edges of pixels darker than thr in a row band; connected comp nearest prev."""
import cv2, sys, numpy as np
v=sys.argv[1]; f0,f1=int(sys.argv[2]),int(sys.argv[3]); y0,y1=[int(a) for a in sys.argv[4].split(',')]; thr=int(sys.argv[5]); x0=int(sys.argv[6])
xr=[int(a) for a in sys.argv[7].split(',')] if len(sys.argv)>7 else [0,99999]
cap=cv2.VideoCapture(f'/home/user/quantiphy-challenge/data/QuantiPhy/{v}.mp4'); fps=cap.get(5); i=0; rows=[]; prev=np.array([x0,(y0+y1)/2])
while cap.grab():
    if f0<=i<=f1:
        ok,img=cap.retrieve(); g=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)[y0:y1, xr[0]:xr[1]]
        m=(g<thr).astype(np.uint8); m=cv2.morphologyEx(m,cv2.MORPH_OPEN,np.ones((3,3),np.uint8))
        n,lab,st,cen=cv2.connectedComponentsWithStats(m)
        best=None
        for k in range(1,n):
            if st[k,4]<150: continue
            c=cen[k]+[xr[0],y0]; d=np.linalg.norm(c-prev)
            if best is None or d<best[0]: best=(d,k,c)
        if best:
            k=best[1]; c=best[2]; prev=c
            rows.append((i,c[0],c[1],st[k,0]+xr[0],st[k,0]+st[k,2]+xr[0],st[k,4]))
    i+=1
    if i>f1: break
R=np.array(rows); t=R[:,0]/fps
for j,nm in [(1,'cx'),(3,'left'),(4,'right')]:
    s=np.polyfit(t,R[:,j],1)[0]; print(f'{v} {nm:6s} slope {s:7.2f} px/s   first {R[0,j]:.1f} last {R[-1,j]:.1f} chord {(R[-1,j]-R[0,j])/(t[-1]-t[0]):.2f}')
print('area min/med/max',R[:,5].min(),np.median(R[:,5]),R[:,5].max(), 'n',len(R))
