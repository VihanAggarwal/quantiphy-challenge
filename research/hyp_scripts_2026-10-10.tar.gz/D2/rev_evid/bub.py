import sys; sys.path.insert(0,'.')
from tm import read, track
import numpy as np
fr,fps=read('simulation_0196',0,49)
for box in ([612,942,688,1012],[620,950,680,1005],[600,930,700,1025]):
  for f0 in (20,):
    pos,cc=track({k:v for k,v in fr.items() if k>=f0},f0,box,S=30,mode='fixed')
    fs=np.array(sorted(pos)); P=np.array([pos[f] for f in fs]); t=fs/fps
    np.set_printoptions(suppress=True,precision=1,linewidth=200)
    print(box, 'cc', np.round([cc[f] for f in fs[::4]],2))
    print(np.c_[fs,P][::4].T)
    v=np.polyfit(t,P,1)[0]; print('fit speed',np.hypot(*v),'chord',np.linalg.norm(P[-1]-P[0])/(t[-1]-t[0]))
