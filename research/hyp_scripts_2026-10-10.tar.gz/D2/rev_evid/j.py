import sys; sys.path.insert(0,'/home/user/quantiphy-challenge')
import pandas as pd, numpy as np
from qp.data import load_split
SP='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad'
t=load_split('test')
v2=pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv').set_index('id').parsed_value
ro=pd.read_csv(SP+'/probe3/refineoff/runs/test_v1_high_854/test.csv').set_index('id')
base=pd.read_csv('/home/user/quantiphy-challenge/runs/test_v1_high_854/test.csv').set_index('id')
main=pd.read_csv(SP+'/hyp/D2/variants/D2_refineoff_pad_segtwin.csv').set_index('id').parsed_value
pro=pd.read_csv(SP+'/hyp/D2/variants/D2_refineoff.csv').set_index('id').parsed_value
t=t.set_index('qid')
t['v2']=v2; t['ro_csv']=ro.parsed_value; t['ro_method']=ro.method; t['base_method']=base.method; t['base_flags']=base.flags
t['main']=main; t['pro']=pro
d=t[t.category=='D2'].copy()
d['r_pro']=d.pro/d.v2; d['r_main']=d.main/d.v2
d.to_csv('d2.csv')
print(len(d), (d.r_pro!=1).sum(), (abs(np.log(d.r_pro))>np.log(1.1)).sum())
g=d.assign(big=abs(np.log(d.r_pro))>np.log(1.1)).groupby('video_id').agg(n=('big','size'),nbig=('big','sum'),med=('r_pro','median'),src=('video_source','first'))
print(g[g.nbig>0].sort_values('nbig',ascending=False).to_string())
# non-D2 changed?
for nm,s in [('main',main),('pro',pro)]:
    ch=(s!=v2)
    print(nm,'nonD2 changed',(ch & (t.category!='D2')).sum())
