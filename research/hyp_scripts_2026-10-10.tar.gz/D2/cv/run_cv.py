"""Run the CV prior tracker on D2 sim/seg videos; save per-video tracks and per-question px/answers."""
import sys, os, copy, pickle, math, re, time
sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/work')
import numpy as np, pandas as pd, cv2
from cvtrack import load_frames, claude_track, track, to_roletrack, good_mask
from qp import geometry as G
from qp.spec import RoleTrack, Obs

W = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/work/'
P = pickle.load(open(W + 'test.pkl', 'rb'))
df, recs, raw = P['df'], P['records'], P['raw']
srcs = sys.argv[1].split(',') if len(sys.argv) > 1 else ['simulation', 'segmentation']
only = sys.argv[2].split(',') if len(sys.argv) > 2 and sys.argv[2] else None
outp = sys.argv[3] if len(sys.argv) > 3 else os.path.dirname(__file__) + '/cv_tracks.pkl'
res = pickle.load(open(outp, 'rb')) if os.path.exists(outp) else {}


def size_estimate(v, d, prior_name, ptr, frames, s, fps):
    boxes = [o.box for o in ptr.obs if o.box is not None]
    if boxes:
        return float(np.median([max(b[2] - b[0], b[3] - b[1]) for b in boxes])), 'box'
    L = []
    for q in d.qid:
        a = raw.get(int(q))
        if a is None:
            continue
        for tr in a.tracks:
            if G.name_score(tr.object, prior_name) >= 0.5:
                for o in tr.obs:
                    if o.box is not None:
                        L.append(max(o.box[2] - o.box[0], o.box[3] - o.box[1]))
                    elif o.extent is not None:
                        e = np.asarray(o.extent, float)
                        L.append(float(np.hypot(*(e[1] - e[0]))))
    if L:
        return float(np.median(L)), 'other'
    # blob under the first point (global median background)
    t, p, _ = claude_track(ptr)
    f = int(round(t[0] * fps))
    f = min(max(f, 0), len(frames) - 1)
    bg = np.median(frames[np.linspace(0, len(frames) - 1, min(len(frames), 40)).round().astype(int)], axis=0)
    diff = np.abs(frames[f].astype(np.int16) - bg.astype(np.int16)).max(axis=2)
    m = (diff > 22).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
    k, lab, st, cen = cv2.connectedComponentsWithStats(m)
    x, y = (p[0] * s).round().astype(int)
    if k > 1:
        y = min(max(y, 0), lab.shape[0] - 1); x = min(max(x, 0), lab.shape[1] - 1)
        j = lab[y, x]
        if j == 0:
            ys, xs = np.nonzero(lab)
            dd = (xs - x) ** 2 + (ys - y) ** 2
            if dd.min() < (20) ** 2:
                j = lab[ys[dd.argmin()], xs[dd.argmin()]]
        if j > 0 and st[j, 4] < 0.25 * lab.size:
            return float(max(st[j, 2], st[j, 3]) / s), 'blob'
    return 40.0, 'default'


vids = df[df.video_source.isin(srcs)].drop_duplicates('video_id').video_id.tolist()
if only:
    vids = [v for v in vids if v in only]
for v in vids:
    if v in res and not only:
        continue
    d = df[df.video_id == v]
    ptr, pq = None, None
    for q in d.qid:
        a = raw.get(int(q))
        if a is None or a.spec.prior.kind not in ('speed', 'acceleration', 'displacement'):
            continue
        for tr in a.tracks:
            if tr.role == 'prior' and sum(o.point is not None or o.box is not None for o in tr.obs) >= 2 and (ptr is None or len(tr.obs) > len(ptr.obs)):
                ptr, pq = tr, a.spec.prior
    if ptr is None:
        res[v] = None
        continue
    t0 = time.time()
    path = d.video_path.iloc[0]
    fps = float(recs[v]['meta']['fps'])
    frames, s, (Wd, Hd) = load_frames(path)
    size, how = size_estimate(v, d, ptr.object, ptr, frames, s, fps)
    t, p, _ = claude_track(ptr)
    mode = 'white' if v.endswith('_segmented') else 'plate'
    if os.environ.get('SEGMASK') and not v.endswith('_segmented'):
        sib = v + '_segmented'
        sp = df[df.video_id == sib].video_path
        if not len(sp):
            sp = pd.Series([d.video_path.iloc[0].replace(v + '.mp4', sib + '.mp4')])
        if os.path.exists(sp.iloc[0]):
            f2, s2, _ = load_frames(sp.iloc[0])
            if f2.shape == frames.shape:
                frames, mode = f2, 'white'
        if mode != 'white':
            res[v] = None
            continue
    try:
        out = track(frames, s, fps, t, p, size, mode=mode)
        ok = good_mask(out)
        if ok.sum() >= 3:
            off = np.median(out['c'][ok] - np.array([np.interp(out['t'][ok], t, p[:, 0]), np.interp(out['t'][ok], t, p[:, 1])]).T, axis=0)
            out = track(frames, s, fps, t, p, size, mode=mode, offset=off)
            ok = good_mask(out)
    except Exception as e:  # noqa
        print(v, 'ERR', e)
        res[v] = None
        continue
    res[v] = dict(out=out, ok=ok, mode=mode, size=size, size_how=how, prior=pq, obj=ptr.object, n_claude=len(t), s=s)
    print(f'{v} n={len(out["f"])} ok={ok.sum()} size={size:.0f}({how}) {time.time() - t0:.1f}s', flush=True)
    del frames
    pickle.dump(res, open(outp, 'wb'))
pickle.dump(res, open(outp, 'wb'))
