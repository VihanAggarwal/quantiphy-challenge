"""Prior px-motion from CV tracks vs raw/refine/dense/ro (per video, first motion-prior question)."""
import sys, os, copy, pickle
sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/work')
import numpy as np, pandas as pd
from ev import load, G
from cvtrack import to_roletrack

W = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/work/'
P = load(W + 'test.pkl'); df, recs, raw = P['df'], P['records'], P['raw']
R = pd.read_pickle(W + 'ppx2.pkl').set_index('qid')


def cv_px(v, cvres, which='c', anns=None):
    """{qid: prior_px} with the prior track replaced by the CV track."""
    anns = anns or raw
    r = cvres.get(v)
    if not r:
        return {}
    tr = to_roletrack(r['out'], which, r['ok'], r['obj'])
    if len(tr.obs) < 3:
        return {}
    out = {}
    for q in df[df.video_id == v].qid:
        a = anns.get(int(q))
        if a is None or a.spec.prior.kind not in ('speed', 'acceleration', 'displacement'):
            continue
        tracks = [t for t in a.tracks if t.role != 'prior'] + [tr]
        m = recs[v]['meta']
        ans = G.solve(a.spec, tracks, tuple(m['image_size']), float(m['fps']), seen_scale=float(m.get('scale') or 1.0))
        out[int(q)] = (ans.debug.get('prior_px', np.nan), ans.value, ';'.join(ans.flags))
    return out


if __name__ == '__main__':
    files = sys.argv[1:]
    rows = []
    for fpath in files:
        cvres = pickle.load(open(fpath, 'rb'))
        tag = os.path.basename(fpath).replace('.pkl', '')
        for v in cvres:
            if not cvres[v]:
                continue
            for which in ('c', 'bc'):
                x = cv_px(v, cvres, which)
                if not x:
                    continue
                q = sorted(x)[0]
                rows.append(dict(v=v, tag=tag, which=which, q=q, cv=x[q][0], raw=R.loc[q, 'raw'], ref=R.loc[q, 'refine'],
                                 den=R.loc[q, 'dense'], ro=R.loc[q, 'ro'], nok=int(cvres[v]['ok'].sum()), n=len(cvres[v]['ok']),
                                 kind=raw[q].spec.prior.kind, fl=x[q][2]))
    X = pd.DataFrame(rows)
    for c in ('raw', 'ref', 'den', 'ro'):
        X[c + '/cv'] = X[c] / X.cv
    pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500)
    print(X.drop(columns=['raw', 'ref', 'den', 'ro']).round(3).to_string())
    X.to_pickle(os.path.dirname(__file__) + '/cmp.pkl')
