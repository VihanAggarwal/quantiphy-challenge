import sys, cv2, numpy as np
sys.path.insert(0, '/home/user/quantiphy-challenge')
from qp.data import load_split
df = load_split('test')
v = sys.argv[1]; x0, y0, x1, y1 = map(int, sys.argv[2:6]); times = [float(t) for t in sys.argv[6].split(',')]
zoom = float(sys.argv[7]) if len(sys.argv) > 7 else 3
p = df[df.video_id == v].video_path.iloc[0]
cap = cv2.VideoCapture(p); fps = cap.get(5)
ims = []
for t in times:
    cap.set(1, int(round(t * fps))); ok, im = cap.read()
    c = im[y0:y1, x0:x1].copy()
    c = cv2.resize(c, None, fx=zoom, fy=zoom, interpolation=cv2.INTER_NEAREST)
    # grid lines every 10 px
    for gx in range(0, x1 - x0, 10):
        cv2.line(c, (int(gx * zoom), 0), (int(gx * zoom), 6), (0, 0, 255) if (x0 + gx) % 50 == 0 else (0, 255, 255), 1)
    cv2.putText(c, f't={t:.2f} x0={x0}', (5, c.shape[0] - 8), 0, 0.6, (0, 0, 255), 2)
    ims.append(c)
cv2.imwrite(sys.argv[8] if len(sys.argv) > 8 else "crop.jpg", cv2.hconcat(ims) if (y1-y0) > (x1-x0) else cv2.vconcat(ims))
