"""Independent classical-CV track of a motion PRIOR object (static camera: simulation / segmentation renders).

Per frame in the annotator's span: ROI around the annotator's interpolated position, background = per-pixel
median of the same ROI in frames where the object is predicted far away ("clean plate"), foreground mask by
colour difference, the component(s) at the predicted position, mask centroid + bbox. Output in ORIGINAL px.
"""
import sys, os, math, pickle
import cv2
import numpy as np

REPO = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/base/repo'
sys.path.insert(0, REPO)
from qp.spec import RoleTrack, Obs  # noqa


def load_frames(path, max_side=960):
    cap = cv2.VideoCapture(path)
    W, H = cap.get(3), cap.get(4)
    s = min(1.0, max_side / max(W, H))
    fr = []
    while True:
        ok, im = cap.read()
        if not ok:
            break
        if s < 1:
            im = cv2.resize(im, (int(round(W * s)), int(round(H * s))), interpolation=cv2.INTER_AREA)
        fr.append(im)
    return np.stack(fr), s, (int(W), int(H))


def claude_track(tr):
    t, p, boxes = [], [], []
    for o in tr.obs:
        o = Obs(**o) if isinstance(o, dict) else o
        if o.point is not None:
            t.append(o.t); p.append(o.point)
        elif o.box is not None:
            b = o.box; t.append(o.t); p.append([(b[0] + b[2]) / 2, (b[1] + b[3]) / 2])
        elif o.extent is not None:
            e = np.asarray(o.extent, float); t.append(o.t); p.append(list((e[0] + e[1]) / 2))
        if o.box is not None:
            boxes.append(o.box)
    o = np.argsort(t)
    return np.asarray(t)[o], np.asarray(p, float)[o], boxes


def track(frames, s, fps, t, p, size_px, thr=22, far_k=2.2, min_bg=5, max_bg=31, span=None, mode='plate', offset=(0.0, 0.0), rk=1.5):
    """size_px: object long side in ORIGINAL px. Returns dict of arrays (original px)."""
    n, Hh, Ww = frames.shape[:3]
    f_pts = t * fps
    f0, f1 = (int(math.ceil(f_pts[0] - 1e-6)), int(math.floor(f_pts[-1] + 1e-6))) if span is None else span
    f0, f1 = max(f0, 0), min(f1, n - 1)
    allf = np.arange(n)
    # predicted position (working px) for every frame: linear interp, linear extrapolation at the ends
    def pred(f):
        x = np.interp(f, f_pts, p[:, 0]); y = np.interp(f, f_pts, p[:, 1])
        if len(f_pts) >= 2:
            if np.ndim(f) == 0:
                f = np.array([f]); x = np.array([x]); y = np.array([y])
            lo, hi = f < f_pts[0], f > f_pts[-1]
            v0 = (p[1] - p[0]) / max(f_pts[1] - f_pts[0], 1e-9); v1 = (p[-1] - p[-2]) / max(f_pts[-1] - f_pts[-2], 1e-9)
            x = np.where(lo, p[0, 0] + v0[0] * (f - f_pts[0]), np.where(hi, p[-1, 0] + v1[0] * (f - f_pts[-1]), x))
            y = np.where(lo, p[0, 1] + v0[1] * (f - f_pts[0]), np.where(hi, p[-1, 1] + v1[1] * (f - f_pts[-1]), y))
        return np.stack([x, y], -1) * s
    P = pred(allf.astype(float)) + np.asarray(offset) * s
    r = max(size_px * s / 2, 4.0)
    R = int(math.ceil(max(rk * 2 * r, r + 16)))
    out = {k: [] for k in ('f', 'c', 'bc', 'box', 'area', 'flag')}
    exp_area = None
    if mode == 'white':
        nonw = (255 - frames.astype(np.int16)).max(axis=3) > thr          # n,H,W
        fmin, fmax = frames.min(axis=0).astype(np.int16), frames.max(axis=0).astype(np.int16)
        static = nonw.all(axis=0) & ((fmax - fmin).max(axis=2) < 30)
        med = np.median(frames, axis=0).astype(np.int16)
        del nonw
    for f in range(f0, f1 + 1):
        cx, cy = P[f]
        x0, y0, x1, y1 = int(cx - R), int(cy - R), int(cx + R), int(cy + R)
        x0c, y0c, x1c, y1c = max(x0, 0), max(y0, 0), min(x1, Ww), min(y1, Hh)
        if x1c - x0c < 8 or y1c - y0c < 8:
            continue
        flag = ''
        roi = frames[f, y0c:y1c, x0c:x1c].astype(np.int16)
        if mode == 'white':
            diff = (255 - roi).max(axis=2)
            st_roi = static[y0c:y1c, x0c:x1c] & (np.abs(roi - med[y0c:y1c, x0c:x1c]).max(axis=2) < 25)
            diff = np.where(st_roi, 0, diff)
        else:
            d = np.linalg.norm(P - P[f], axis=1)
            far = np.where(d > far_k * r + 2)[0]
            if len(far) < min_bg:
                flag = 'slow'
                far = np.argsort(-d)[:max(min_bg, 7)]
            if len(far) > max_bg:
                far = far[np.linspace(0, len(far) - 1, max_bg).round().astype(int)]
            bg = np.median(frames[far, y0c:y1c, x0c:x1c], axis=0).astype(np.int16)
            diff = np.abs(roi - bg).max(axis=2)
        m = (diff > thr).astype(np.uint8)
        m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
        k, lab, st, cen = cv2.connectedComponentsWithStats(m)
        if k <= 1:
            continue
        # disc of radius 0.7r around the prediction
        yy, xx = np.mgrid[y0c:y1c, x0c:x1c]
        disc = (xx - cx) ** 2 + (yy - cy) ** 2 <= (0.8 * r) ** 2
        ov = np.bincount(lab[disc].ravel(), minlength=k); ov[0] = 0
        if ov.max() == 0:
            continue
        main = int(np.argmax(ov))
        keep = [main]
        mc = cen[main]
        for j in range(1, k):
            if j != main and st[j, 4] >= 6 and np.hypot(*(cen[j] - mc)) < 1.2 * r:
                keep.append(j)
        mk = np.isin(lab, keep)
        ys, xs = np.nonzero(mk)
        area = len(xs)
        bx0, by0, bx1, by1 = xs.min(), ys.min(), xs.max() + 1, ys.max() + 1
        touch = bx0 <= 0 or by0 <= 0 or bx1 >= mk.shape[1] or by1 >= mk.shape[0]
        if touch:
            flag += '|touch'
        c = np.array([xs.mean() + x0c, ys.mean() + y0c])
        bc = np.array([(bx0 + bx1) / 2 + x0c - 0.5, (by0 + by1) / 2 + y0c - 0.5])
        out['f'].append(f); out['c'].append(c / s); out['bc'].append(bc / s)
        out['box'].append(np.array([bx0 + x0c, by0 + y0c, bx1 + x0c, by1 + y0c]) / s)
        out['area'].append(area / s / s); out['flag'].append(flag)
    for k_ in ('f', 'area'):
        out[k_] = np.asarray(out[k_])
    for k_ in ('c', 'bc', 'box'):
        out[k_] = np.asarray(out[k_]).reshape(-1, 2 if k_ != 'box' else 4)
    out['t'] = out['f'] / fps
    return out


def to_roletrack(out, which='c', ok=None, name='prior'):
    sel = np.ones(len(out['f']), bool) if ok is None else ok
    obs = [Obs(t=float(t), point=[float(a), float(b)]) for t, (a, b) in zip(out['t'][sel], out[which][sel])]
    return RoleTrack(role='prior', object=name, obs=obs, source='cv')


def good_mask(out, area_tol=0.5):
    """frames whose mask does not touch the ROI border and whose area is within area_tol (log) of the median."""
    if not len(out['f']):
        return np.zeros(0, bool)
    a = out['area']
    med = np.median(a)
    ok = np.array(['touch' not in fl for fl in out['flag']]) & (np.abs(np.log(np.maximum(a, 1) / med)) < area_tol)
    return ok
