import sys, re, difflib
sys.path.insert(0,'/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/work')
import numpy as np, pandas as pd
import segtwin, mkcsv
t=mkcsv._t.set_index('qid')
m=segtwin.twin_map()
seg=t[(t.category=='D2')&t.video_id.str.endswith('_segmented')]
um=seg[~seg.index.isin(m.keys())]
def nn(s):
    s=str(s).lower(); s=re.sub(r'(\d+)\.0+\b', r'\1', s); return re.sub(r'[^a-z0-9.]','',s)
cnt=0
for q,r in um.iterrows():
    o=t[t.video_id==r.video_id.replace('_segmented','')]
    if not len(o): print(q, r.video_id, 'NO ORIGINAL VIDEO IN TEST'); continue
    best=max(o.index, key=lambda i: difflib.SequenceMatcher(None, o.loc[i,'question'], r.question).ratio())
    sim=difflib.SequenceMatcher(None, o.loc[best,'question'], r.question).ratio()
    if sim>0.85:
        cnt+=1
        print(q, best, o.loc[best,'category'], round(sim,3), '|', r.question[:80], '|', o.loc[best,'question'][:80], '| P:', r.prior, '||', o.loc[best,'prior'], '| nn-eq', nn(r.question)==nn(o.loc[best,'question']))
print(cnt, len(um))
