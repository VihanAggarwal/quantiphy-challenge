import os, sys, pickle, collections
W='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/work'
os.chdir(W); sys.path.insert(0, W)
from build import *
# aliasing of Obs / track / obs-list objects across questions
cnt=collections.Counter(); lst=collections.Counter(); trk=collections.Counter(); spec=collections.Counter()
for q,a in RO.items():
    spec[id(a.spec.target)]+=1; spec[id(a.spec.prior)]+=1
    for tr in a.tracks:
        trk[id(tr)]+=1; lst[id(tr.obs)]+=1
        quant = a.spec.prior if tr.role.startswith('prior') else a.spec.target
        if quant.kind in ('size','other','distance'):
            for o in tr.obs: cnt[id(o)]+=1
print('shared obs in padded tracks', sum(1 for v in cnt.values() if v>1), 'shared tracks', sum(1 for v in trk.values() if v>1), 'shared obs lists', sum(1 for v in lst.values() if v>1), 'shared quantities', sum(1 for v in spec.values() if v>1))
# all obs
allc=collections.Counter()
for q,a in RO.items():
    for tr in a.tracks:
        for o in tr.obs: allc[id(o)]+=1
print('shared obs anywhere', sum(1 for v in allc.values() if v>1))
# expected-vs-actual ratio check for changed size targets
R=pickle.load(open('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/review_integrity/repro.pkl','rb'))
an_pad,_=pad_anns(RO, df, recs, 0.8)
rows=[]
for r in df.itertuples():
    q=int(r.qid); a=RO[q]; b=an_pad[q]
    if a.spec.target.kind!='size': continue
    sc=float(recs[r.video_id]['meta'].get('scale') or 1.0)
    tt=[tr for tr in a.tracks if tr.role=='target']; tb=[tr for tr in b.tracks if tr.role=='target']
    if not tt: continue
    L0=[np.hypot(*(np.subtract(o.extent[1],o.extent[0]))) for o in tt[0].obs if o.extent is not None]
    L1=[np.hypot(*(np.subtract(o.extent[1],o.extent[0]))) for o in tb[0].obs if o.extent is not None]
    if not L0: continue
    d=np.array(L1)-np.array(L0)
    rows.append(dict(qid=q, vid=r.video_id, sc=sc, dL_min=d.min(), dL_max=d.max(), exp=0.8/sc, Lmed=np.median(L0), r=R['vpad'][q]/R['vro'][q], rexp=(np.median(L0)+0.8/sc)/np.median(L0)))
X=pd.DataFrame(rows)
X['dev']=X.dL_max/X.exp
print(X.dev.describe(), (np.abs(X.dL_min-X.exp)>1e-6).sum(), (np.abs(X.dL_max-X.exp)>1e-6).sum())
X['rr']=np.log(X.r)/np.log(X.rexp)
print(X.rr.describe())
print(X[np.abs(X.rr-1)>0.3].to_string())
