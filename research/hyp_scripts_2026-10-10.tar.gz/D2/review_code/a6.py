import os, sys, pickle
W='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/work'
os.chdir(W); sys.path.insert(0, W)
from build import *
SP='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad'
rlog=P['rlog']
from collections import Counter
print(Counter(info.get('why') for q,role,info in rlog))
refined={q for q,role,info in rlog if info.get('why')=='refined'}
print('refined questions', len(refined))
v2=pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv').set_index('id').parsed_value
T1=pd.read_csv('/home/user/quantiphy-challenge/runs/test_v1_high_854/test.csv').set_index('id')
REP=pd.read_csv(SP+'/probe3/refineoff/runs/test_v1_high_854/test.csv').set_index('id')
d2=sorted(df.qid.astype(int))
r=(REP.parsed_value.reindex(d2)/v2.reindex(d2))
ch=r[np.abs(np.log(r))>1e-9].index
print('changed', len(ch), 'in refined', sum(q in refined for q in ch))
nr=[q for q in ch if q not in refined]
vid=dict(zip(df.qid, df.video_id))
for q in nr[:60]:
    a=P['raw'][q]
    print(q, vid[q], a.spec.prior.kind, a.spec.target.kind, round(r[q],4), T1.loc[q,'method'], REP.loc[q,'method'], T1.loc[q,'flags'], '||', REP.loc[q,'flags'])
