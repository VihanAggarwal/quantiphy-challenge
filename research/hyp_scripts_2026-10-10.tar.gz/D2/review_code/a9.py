import sys, re
sys.path.insert(0, '/home/user/quantiphy-challenge')
import numpy as np, pandas as pd
from qp.data import load_split
from qp.mra import item_scores
def base(v):
    v = v.replace('_segmented', '')
    m = re.match(r'(captured_\d+a?)[sx]?$', v)
    return m.group(1) if m else v
def norm(s): return re.sub(r'\s+', '', str(s).strip().lower())
val = load_split('val'); t = load_split('test')
for d in (val,t):
    d['b']=d.video_id.map(base); d['k']=d.question.map(norm)+'|'+d.prior.map(norm)+'|'+d.depth_info.fillna('').map(norm)
gt={}
for r in val.itertuples(): gt.setdefault((r.b,r.k),set()).add(r.answer)
rows=[(r.qid,r.video_id,r.question[:60],list(gt[(r.b,r.k)])[0]) for r in t[t.category=='D2'].itertuples() if (r.b,r.k) in gt and len(gt[(r.b,r.k)])==1]
K=pd.DataFrame(rows,columns=['qid','vid','q','G']).set_index('qid')
V='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/variants/'
F={'v2':'/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv'}
for k in ['D2_refineoff','D2_refineoff_pad','D2_refineoff_pad_segtwin','D2_refineoff_pad_cvprior_segtwin']: F[k]=V+k+'.csv'
for k,f in F.items():
    s=pd.read_csv(f).set_index('id').parsed_value.reindex(K.index)
    K[k[:12] if k=='v2' else k.replace('D2_refineoff','ro')]=s/K.G
cols=[c for c in K.columns if c not in('vid','q','G')]
pd.set_option('display.width',250)
print(K.round(3).to_string())
for c in cols: print(c, item_scores(K[c]*K.G, K.G).mean().round(4))
