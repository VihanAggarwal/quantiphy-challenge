import os, sys, re
W='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/work'
os.chdir(W); sys.path.insert(0, W)
from build import *
MOD = re.compile(r"\s+\b(on|in|at|near|closest to|nearest to|next to|beside|along|by|crossing|inside|within)\b.*$", re.I)
vid=dict(zip(df.qid, df.video_id)); qq=dict(zip(df.qid, df.question))
for q,a in RO.items():
    for role,quant in (('prior',a.spec.prior),('target',a.spec.target)):
        if quant.kind in ('size','other','distance') and is_marking(quant):
            head=any(MARKING.search(MOD.sub('', o or '')) for o in (quant.objects or []))
            print(q, vid[q], role, quant.kind, quant.objects, 'head-noun marking:', head, '|', qq[q][:80])
