import os, sys, pickle
W='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/work'
os.chdir(W); sys.path.insert(0, W)
from build import *
SP='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad'
R=pickle.load(open(SP+'/hyp/D2/review_integrity/repro.pkl','rb'))
vro, vpad = R['vro'], R['vpad']
resp=R['res_pad'].set_index('id'); reso=R['res_ro'].set_index('id')
rows=[]
for r in df.itertuples():
    q=int(r.qid); a=RO.get(q)
    if a is None: continue
    sc=float(recs[r.video_id]['meta'].get('scale') or 1.0)
    padded=[]
    for tr in a.tracks:
        quant = a.spec.prior if tr.role.startswith('prior') else a.spec.target
        if quant.kind in ('size','other','distance') and not is_marking(quant):
            ne=sum(o.extent is not None for o in tr.obs); nb=sum(o.box is not None for o in tr.obs)
            if ne or nb: padded.append(f'{tr.role}:{tr.object}:e{ne}b{nb}')
    rows.append(dict(qid=q, vid=r.video_id, src=r.video_source, pk=a.spec.prior.kind, tk=a.spec.target.kind, tobj='|'.join(a.spec.target.objects or []),
        dim=a.spec.target.dimension, mark=is_marking(a.spec.target), sc=sc, W=recs[r.video_id]['meta']['image_size'][0], H=recs[r.video_id]['meta']['image_size'][1],
        padded=';'.join(padded), r=vpad[q]/vro[q], m_ro=reso.loc[q,'method'], m_pad=resp.loc[q,'method'], gm=resp.loc[q,'geo_method'], q=r.question[:90]))
X=pd.DataFrame(rows)
X.to_pickle('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/review_code/padX.pkl')
ch=np.abs(np.log(X.r))>1e-9
print('changed', ch.sum())
print(X.groupby(['pk','tk']).apply(lambda g: pd.Series(dict(n=len(g), ch=(np.abs(np.log(g.r))>1e-9).sum(), med=g.r[np.abs(np.log(g.r))>1e-9].median()))).to_string())
print('prior-role padded:', X.padded.str.contains('prior').sum())
print(X[X.padded.str.contains('prior')][['qid','vid','pk','tk','padded','r','q']].to_string())
print('method switch', (X.m_ro!=X.m_pad).sum()); print(X[X.m_ro!=X.m_pad][['qid','vid','m_ro','m_pad','r']].to_string())
print('portrait/odd', X[(X.H>X.W)].drop_duplicates('vid')[['vid','W','H','sc']].to_string())
