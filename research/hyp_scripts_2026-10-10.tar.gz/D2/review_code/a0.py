import sys; sys.path.insert(0,'/home/user/quantiphy-challenge')
import pandas as pd, numpy as np
from qp.data import load_split
t=load_split('test')
print(t.columns.tolist())
d=t[t.category=='D2']
print(d.video_source.value_counts())
d=d.assign(seg=d.video_id.str.endswith('_segmented'))
print(d.groupby(['video_source','seg']).size())
print(d[d.video_source=='segmentation'].video_id.str.replace(r'\d+','N',regex=True).value_counts())
print(d[d.seg].video_source.value_counts())
print(d.head(3).T)
