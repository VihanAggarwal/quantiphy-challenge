import sys; sys.path.insert(0,'/home/user/quantiphy-challenge')
import pandas as pd, numpy as np
SP='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad'
X=pd.read_pickle(SP+'/hyp/D2/work/ppx2.pkl').set_index('qid')
from qp.data import load_split
t=load_split('test').set_index('qid')
v2=pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv').set_index('id').parsed_value
T1=pd.read_csv('/home/user/quantiphy-challenge/runs/test_v1_high_854/test.csv').set_index('id')
REP=pd.read_csv(SP+'/probe3/refineoff/runs/test_v1_high_854/test.csv').set_index('id')
d2=X.index
r=REP.parsed_value.reindex(d2)/v2.reindex(d2)
ch=r[np.abs(np.log(r))>1e-9].index
Y=pd.DataFrame({'r':r[ch], 'pxr':X.dense[ch]/X.ro[ch], 'm1':T1.method.reindex(ch), 'm2':REP.method.reindex(ch), 'tk':[t.loc[q,'question'][:60] for q in ch], 'vid':X.video_id[ch]})
Y['dev']=np.log(Y.r)-np.log(Y.pxr)
print('changed', len(Y), 'method switch', (Y.m1!=Y.m2).sum())
print(Y[(Y.m1!=Y.m2)].to_string())
same=Y[Y.m1==Y.m2]
print('same-method: |dev|>1%:', (np.abs(same.dev)>0.01).sum(), 'of', len(same))
print(same[np.abs(same.dev)>0.01].to_string())
rs=np.random.RandomState(2)
print(Y.loc[sorted(rs.choice(ch,10,replace=False))].round(4).to_string())
