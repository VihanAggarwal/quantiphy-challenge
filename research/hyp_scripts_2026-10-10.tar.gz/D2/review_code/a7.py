import os, sys, pickle
W='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/work'
os.chdir(W); sys.path.insert(0, W)
from build import *
R=pickle.load(open('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/review_integrity/repro.pkl','rb'))
vro, vpad = R['vro'], R['vpad']
print('nonfinite ro', sum(not np.isfinite(v) for v in vro.values()), 'pad', sum(not np.isfinite(v) for v in vpad.values()))
an_pad,_=pad_anns(RO, df, recs, 0.8)
d=df.set_index('qid')
ch=[q for q in d.index if abs(np.log(vpad[q]/vro[q]))>1e-9]
rs=np.random.RandomState(1)
for q in sorted(rs.choice(ch, 12, replace=False)):
    a=RO[q]; b=an_pad[q]; v=d.loc[q,'video_id']; sc=recs[v]['meta']['scale']
    print(f'--- {q} {v} sc={sc:.4f} size={recs[v]["meta"]["image_size"]} | {d.loc[q,"question"]} | prior: {d.loc[q,"prior"]} | tk={a.spec.target.kind} dim={a.spec.target.dimension} pk={a.spec.prior.kind}')
    for ta,tb in zip(a.tracks,b.tracks):
        e0=[o.extent for o in ta.obs if o.extent is not None]; e1=[o.extent for o in tb.obs if o.extent is not None]
        bx0=[o.box for o in ta.obs if o.box is not None]; bx1=[o.box for o in tb.obs if o.box is not None]
        if e0!=e1 or bx0!=bx1:
            L0=[round(float(np.hypot(*np.subtract(e[1],e[0]))),1) for e in e0]; L1=[round(float(np.hypot(*np.subtract(e[1],e[0]))),1) for e in e1]
            print(f'   {ta.role}:{ta.object} ext L {L0} -> {L1}; box0 {np.round(bx0[0],1).tolist() if bx0 else None} -> {np.round(bx1[0],1).tolist() if bx1 else None}')
    print(f'   ro {vro[q]:.4f} pad {vpad[q]:.4f} ratio {vpad[q]/vro[q]:.4f}')
