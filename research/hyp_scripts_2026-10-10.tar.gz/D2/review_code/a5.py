import os, sys, pickle
W='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/work'
CVD='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/cv/'
os.chdir(W); sys.path.insert(0, W); sys.path.insert(0, CVD)
from build import *
from cvtrack import to_roletrack
CV={}
for f in ('cv_seg.pkl','cv_simseg.pkl'):
    d=load(CVD+f); print(f, len(d), sum(1 for v in d.values() if v))
    for v,r in d.items():
        if r:
            if v in CV: print('DUP key', v)
            CV[v]=r
X0=pd.read_pickle(CVD+'cmp_seg.pkl')
print(X0.tag.value_counts().to_dict())
X=X0[(X0.which=='c')&X0.cv.notna()].drop_duplicates('v').set_index('v')
use=[v for v,r in X.iterrows() if r.nok>=15 and r.nok>=0.5*r.n and abs(np.log(r.cv/r.ro))<0.10]
print('use', len(use))
# check: which tag each X row came from vs CV source
dups=X0[(X0.which=='c')&X0.cv.notna()].groupby('v').tag.nunique()
print('videos with rows from >1 tag', (dups>1).sum())
# per video: distinct prior objects / prior strings / prior kinds among motion-prior questions
raw=P['raw']
rows=[]
for v in use:
    d=df[df.video_id==v]
    pri=[]
    for q in d.qid:
        a=RO.get(int(q))
        if a is None or a.spec.prior.kind not in ('speed','acceleration','displacement'): continue
        ptr=[t for t in a.tracks if t.role=='prior']
        pri.append((int(q), d.set_index('qid').loc[q,'prior'], a.spec.prior.kind, a.spec.prior.axis, ptr[0].object if ptr else None, len(ptr)))
    objs=set(p[4] for p in pri); priors=set(p[1] for p in pri)
    rows.append(dict(v=v, nq=len(pri), cvobj=CV[v]['obj'], mode=CV[v]['mode'], objs=objs, priors=priors, kinds=set(p[2] for p in pri), gate_q=X.loc[v,'q'], cvro=X.loc[v,'cv']/X.loc[v,'ro']))
Y=pd.DataFrame(rows)
pd.set_option('display.width',300); pd.set_option('display.max_colwidth',120)
print(Y[(Y.priors.map(len)>1)|(Y.objs.map(len)>1)].to_string())
print(Y.kinds.map(lambda s: tuple(sorted(s))).value_counts())
print(Y[['v','mode']].groupby('mode').size())
Y.to_pickle('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/review_code/cvY.pkl')
