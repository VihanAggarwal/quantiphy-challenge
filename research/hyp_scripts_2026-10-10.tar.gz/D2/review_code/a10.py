import os, sys, pickle
W='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/work'
CVD='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/cv/'
os.chdir(W); sys.path.insert(0, W); sys.path.insert(0, CVD)
from build import *
from cvtrack import to_roletrack
import segtwin
V='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/variants/'
a=pd.read_csv(V+'D2_refineoff_pad_segtwin.csv').set_index('id').parsed_value
b=pd.read_csv(V+'D2_refineoff_pad_cvprior_segtwin.csv').set_index('id').parsed_value
d=df.set_index('qid')
CV={}
for f in ('cv_seg.pkl','cv_simseg.pkl'):
    CV.update({v:r for v,r in load(CVD+f).items() if r})
X=pd.read_pickle(CVD+'cmp_seg.pkl'); X=X[(X.which=='c')&X.cv.notna()].drop_duplicates('v').set_index('v')
use={v:to_roletrack(CV[v]['out'],'c',CV[v]['ok'],CV[v]['obj']) for v,r in X.iterrows() if r.nok>=15 and r.nok>=0.5*r.n and abs(np.log(r.cv/r.ro))<0.10}
an,n=replace_prior(RO, df, use)
def ppx(anns,q):
    v=d.loc[q,'video_id']; m=recs[v]['meta']; A=anns[q]
    s=G.solve(A.spec, A.tracks, tuple(m['image_size']), float(m['fps']), seen_scale=float(m.get('scale') or 1.0))
    return s.debug.get('prior_px', np.nan), s.value
m=segtwin.twin_map()
ch=[q for q in d.index if abs(np.log(b[q]/a[q]))>1e-9]
print('changed', len(ch))
rows=[]
for q in ch:
    src=m.get(q,q)
    p0,_=ppx(RO,src); p1,_=ppx(an,src)
    A=RO[src]
    rows.append(dict(q=q, src=src, vid=d.loc[src,'video_id'], pk=A.spec.prior.kind, pt=A.spec.prior.time, pw=A.spec.prior.window, tk=A.spec.target.kind, r=b[q]/a[q], pxr=p0/p1, cvro_gate=X.loc[d.loc[src,'video_id'],'cv']/X.loc[d.loc[src,'video_id'],'ro'] if d.loc[src,'video_id'] in X.index else np.nan, prior=d.loc[src,'prior'], qq=d.loc[q,'question'][:50]))
Y=pd.DataFrame(rows)
pd.set_option('display.width',300); pd.set_option('display.max_colwidth',60)
Y['dev']=np.log(Y.r)-np.log(Y.pxr)
print((np.abs(Y.dev)>0.01).sum())
print(Y[np.abs(Y.dev)>0.01].round(3).to_string())
print('max |log r|', np.abs(np.log(Y.r)).max())
print(Y.sort_values('r').round(3).head(8).to_string()); print(Y.sort_values('r').round(3).tail(8).to_string())
# within-video spread of r for prior px
print(Y.groupby('vid').pxr.agg(['min','max','count']).assign(spread=lambda g: g['max']/g['min']).sort_values('spread').tail(8).round(3))
