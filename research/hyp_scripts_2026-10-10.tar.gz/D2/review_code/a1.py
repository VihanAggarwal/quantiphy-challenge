import sys, pickle
REPO='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/base/repo'
sys.path.insert(0, REPO); sys.path.insert(0, REPO+'/scripts')
import numpy as np, pandas as pd
from qp.data import load_split
SP='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad'
t=load_split('test').set_index('qid'); d2=sorted(t[t.category=='D2'].index)
R=pickle.load(open(SP+'/hyp/D2/review_integrity/repro.pkl','rb'))
vro=pd.Series(R['vro']).reindex(d2); vpad=pd.Series(R['vpad']).reindex(d2)
REP=pd.read_csv(SP+'/probe3/refineoff/runs/test_v1_high_854/test.csv').set_index('id')
T1=pd.read_csv('/home/user/quantiphy-challenge/runs/test_v1_high_854/test.csv').set_index('id')
v2=pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv').set_index('id').parsed_value
V='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/variants/'
F={k:pd.read_csv(V+k+'.csv').set_index('id').parsed_value.reindex(d2) for k in ['D2_refineoff','D2_refineoff_pad','D2_refineoff_pad_segtwin','D2_refineoff_pad_cvprior_segtwin']}
rep=REP.parsed_value.reindex(d2)
print('v2 vs T1 D2 equal', np.isclose(v2.reindex(d2), T1.parsed_value.reindex(d2), rtol=1e-12).sum())
eq=np.isclose(vro, rep, rtol=1e-9)
print('inproc RO vs replay', eq.sum(), len(d2), 'nan inproc', vro.isna().sum(), 'nan replay', rep.isna().sum())
bad=[q for q,e in zip(d2,eq) if not e]
for q in bad[:40]:
    print(q, t.loc[q,'video_id'], vro[q], rep[q], v2[q], R['res_ro'].set_index('id').loc[q,'method'], REP.loc[q,'method'], REP.loc[q,'flags'])
print('refineoff csv vs replay', np.isclose(F['D2_refineoff'], rep, rtol=1e-12).sum())
