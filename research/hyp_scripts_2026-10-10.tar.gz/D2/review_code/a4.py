import sys
sys.path.insert(0,'/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/work')
import numpy as np, pandas as pd
import segtwin, mkcsv
t=mkcsv._t.set_index('qid')
m=segtwin.twin_map()
V='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/variants/'
pad=pd.read_csv(V+'D2_refineoff_pad.csv').set_index('id').parsed_value
st=pd.read_csv(V+'D2_refineoff_pad_segtwin.csv').set_index('id').parsed_value
v2=pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv').set_index('id').parsed_value
P=pd.read_csv('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D2/work/segtwin_pairs.csv')
print('pairs csv', len(P), P.sp.sum(), 'twin_map', len(m), 'csv sp-true pairs == twin_map', set(zip(P[P.sp].qs,P[P.sp].qo))==set(m.items()))
ch=[q for q in st.index if abs(np.log(st[q]/pad[q]))>1e-12]
print('segtwin changed vs pad', len(ch), 'all in map', all(q in m for q in ch))
bad=[]
for s,o in m.items():
    ok = (t.loc[s,'question'].strip()==t.loc[o,'question'].strip(), t.loc[s,'prior']==t.loc[o,'prior'], t.loc[s,'video_id'].replace('_segmented','')==t.loc[o,'video_id'], t.loc[s,'fps']==t.loc[o,'fps'], t.loc[s,'target_unit']==t.loc[o,'target_unit'], t.loc[s,'inference_type']==t.loc[o,'inference_type'], abs(st[s]/pad[o]-1)<1e-12)
    if not all(ok): bad.append((s,o,ok))
print('pairs with any mismatch', len(bad))
for b in bad: print(b, '|', t.loc[b[0],'question'], '|', t.loc[b[1],'question'], '|', t.loc[b[0],'prior'], '|', t.loc[b[1],'prior'])
# which seg D2 questions were NOT matched and why
seg=t[(t.category=='D2')&t.video_id.str.endswith('_segmented')]
um=seg[~seg.index.isin(m.keys())]
print('unmatched seg D2', len(um))
tt=t.assign(nq=t.question.map(segtwin.normq))
for q,r in um.iterrows():
    o=tt[(tt.video_id==r.video_id.replace('_segmented',''))&(tt.nq==segtwin.normq(r.question))]
    if len(o): print('  ', q, r.video_id, '| orig', o.index.tolist(), o.category.tolist(), '| seg prior:', r.prior, '| orig prior:', o.prior.tolist())
# sample 10 changed
rs=np.random.RandomState(0)
for s in sorted(rs.choice(ch, 10, replace=False)):
    o=m[s]
    print(s, '<-', o, t.loc[s,'video_id'], '|', t.loc[s,'question'][:70], '|', t.loc[s,'prior'], '| v2 seg', round(v2[s],4), 'pad seg', round(pad[s],4), 'new', round(st[s],4), 'pad orig', round(pad[o],4), 'v2 orig', round(v2[o],4))
