import sys, pickle; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
pd.set_option("display.width",250); pd.set_option("display.max_colwidth",70)
specs=pickle.load(open(SP+"/work/specs.pkl","rb"))
lab=pd.read_pickle("lab3.pkl")
d=lab[lab.kind=="distance"].copy()
out=[]
for r in d.itertuples():
    sp=specs[r.qid]; objs=sp.target.objects; tt=sp.target.time
    if len(objs)<2: continue
    def z(o):
        c=[e for e in sp.depth if e.object==o and (e.time is None or tt is None or abs(e.time-tt)<1e-6)]
        return c[0].distance_m if c else np.nan
    z1,z2=z(objs[0]),z(objs[1])
    unit=100 if "cm" in r.question else 1
    lb=abs(z1-z2)*unit
    out.append((r.video_id,r.category,r.question[12:70],objs,tt,z1,z2,round(lb,2),round(r.geo,2),r.dir,r.chg))
o=pd.DataFrame(out,columns=["vid","cat","q","objs","t","z1","z2","lb","geo","dir","chg"])
o["geo_viol"]=o.geo<o.lb*0.98; o["dir_viol"]=o.dir<o.lb*0.98
print(o[o.lb.notna()].to_string())
