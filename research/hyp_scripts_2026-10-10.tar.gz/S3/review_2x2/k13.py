import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
pd.set_option("display.width",250); pd.set_option("display.max_rows",200); pd.set_option("display.max_colwidth",60)
x=pd.read_pickle("sf_df.pkl")
v=val(); v["nq"]=v.question.map(normq)
g34=v[v.video_id=="captured_0034as"].set_index("nq").answer
x["gtv"]=x.ans
m=x.twin=="captured_0034b"; x.loc[m,"gtv"]=x.loc[m,"nq"].map(g34)
q=x.question.str.lower()
ident=pd.Series(np.nan,index=x.index)
ident[q.str.contains("diameter of the white ball")]=4.0
ident[q.str.contains("soccer ball")&q.str.contains("diameter")]=17.5
x["ident"]=ident
x["pt_known"]=x.gtv.fillna(x.ident)
def sc(p,t): return item_scores(np.asarray(p,float),np.asarray(t,float))
x["H_geo"]=x.sf; x["H_dir"]=x.df
x["gm"]=np.sqrt(x.sf*x.df)
# card anchored: for 0038-0040 geometry x 0.956
x["card"]=np.where(x.twin.isin(["captured_0038","captured_0039","captured_0040"]), x.sf*0.956, np.nan)
rows=[]
for name,pt in [("known/ident only",x.pt_known),("known/ident else geomean",x.pt_known.fillna(x.gm)),("known/ident else card(0038-40) else geomean",x.pt_known.fillna(x.card).fillna(x.gm)),
                ("truth=split value",x.sf),("truth=direct_full value",x.df)]:
    d=sc(x.sf,pt)-sc(x.df,pt); ok=~np.isnan(d)
    rows.append((name,int(ok.sum()),np.nansum(d),np.nansum(d)/578))
for r in rows: print(f"{r[0]:48s} n={r[1]:3d} split-minus-direct {r[2]:+.2f} pts = {r[3]:+.4f} S3")
x["d_known"]=sc(x.sf,x.pt_known)-sc(x.df,x.pt_known)
x["d_card"]=sc(x.sf,x.pt_known.fillna(x.card).fillna(x.gm))-sc(x.df,x.pt_known.fillna(x.card).fillna(x.gm))
x["q"]=x.question.str.slice(12,60)
print(x[["video_id","q","sf","df","pt_known","card","d_known","d_card"]].round(2).to_string())
