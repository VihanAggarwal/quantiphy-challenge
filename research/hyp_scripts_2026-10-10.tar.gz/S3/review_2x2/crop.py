import cv2
for v,tsec,box in [("captured_0038",0.5,(600,400,1150,800)),("captured_0037",0.5,(400,380,1100,800)),("captured_0040",0.5,(300,350,1250,800))]:
    cap=cv2.VideoCapture(f"/home/user/quantiphy-challenge/data/QuantiPhy/{v}.mp4")
    cap.set(cv2.CAP_PROP_POS_FRAMES,int(tsec*24)); ok,f=cap.read()
    x0,y0,x1,y1=box; c=f[y0:y1,x0:x1]
    cv2.imwrite(f"fr/{v}_crop.jpg",c,[cv2.IMWRITE_JPEG_QUALITY,90])
