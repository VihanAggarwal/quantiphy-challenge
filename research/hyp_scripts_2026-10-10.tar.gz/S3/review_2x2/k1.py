import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
import pickle
t = test()
print(t.columns.tolist()); print(t.shape)
specs = pickle.load(open(SP + "/work/specs.pkl", "rb"))
print(type(specs), len(specs))
k = list(specs.keys())[:3]; print(k, specs[k[0]])
lab = t[(t.video_source=="lab")&t.category.isin(["S3","D3"])]
print(lab.groupby("category").size())
print(sum(q in specs for q in lab.qid), len(lab))
print(lab.video_id.value_counts().head(20))
print(sorted(lab.video_id.unique())[:60])
