import sys, pickle; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
specs=pickle.load(open(SP+"/work/specs.pkl","rb"))
lab=pd.read_pickle("lab3.pkl")
for r in lab[lab.video_id.isin(["captured_0031","captured_0031x","captured_0032","captured_0032s"])&(lab.kind=="distance")].itertuples():
    sp=specs[r.qid]; print(r.video_id, sp.target.objects, sp.target.time, [(e.object,e.distance_m,e.time) for e in sp.depth], r.geo, r.dir)
