import pandas as pd, numpy as np
pd.set_option("display.width",300); pd.set_option("display.max_colwidth",100); pd.set_option("display.max_rows",500)
x=pd.read_pickle("chg.pkl")
y=x[(x.category=="S3")&(x.gA=="motion")].copy()
print(y.groupby("twin").agg(n=("qid","size"),cap_geo=("cap_geo","sum"),cap_dir=("cap_dir","sum"),abslog=("absl","median")).round(2).sort_values("cap_geo",ascending=False))
y["q"]=y.question.str.slice(0,80)
print(y[y.absl>0.2][["video_id","kind","q","geo","dir","cap_geo","cap_dir"]].sort_values("video_id").to_string())
import json
