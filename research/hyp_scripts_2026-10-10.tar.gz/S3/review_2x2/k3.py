import pandas as pd, numpy as np
pd.set_option("display.width",250); pd.set_option("display.max_colwidth",90); pd.set_option("display.max_rows",500)
lab=pd.read_pickle("lab.pkl")
x=lab[lab.chg&(lab.category=="S3")&lab.kind.isin(["size","distance","other"])]
print(x[["video_id","kind","question","prior","geo","dir"]].sort_values(["kind","video_id"]).to_string())
