import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
pd.set_option("display.width",250); pd.set_option("display.max_rows",300)
V="/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/variants_labdirect/"
t=test().copy(); v=val()
for d in (t,v):
    d["twin"]=d.video_id.str.replace("_segmented","",regex=False).map(base_of); d["nq"]=d.question.map(normq)
gt=v.set_index(["twin","nq"]).answer; gt=gt[~gt.index.duplicated()]
t["ans"]=[gt.get((a,b),np.nan) for a,b in zip(t.twin,t.nq)]
g34=v[v.video_id=="captured_0034as"].set_index("nq").answer
m=t.twin=="captured_0034b"; t.loc[m,"ans"]=t.loc[m,"nq"].map(g34)
q=t.question.str.lower()
t["ident"]=np.where(q.str.contains("diameter of the white ball")&(t.video_source=="lab")&(t.category=="S3"),4.0,np.where(q.str.contains("soccer ball")&q.str.contains("diameter"),17.5,np.nan))
t["pt"]=t.ans.fillna(pd.Series(t.ident,index=t.index))
t=t.set_index("qid")
p3=pd.read_csv("/home/user/quantiphy-challenge/submissions/trackA_probe3_s2maxext_d2denseoff_labdirect.csv").set_index("id").parsed_value
F={n:pd.read_csv(V+n+".csv").set_index("id").parsed_value for n in ["S3p3_split_full","S3p3_direct_full","S3p3_split_only","S3p3_segtwin_only","S3p3_segtwin_render"]}
lab=pd.read_pickle("lab3.pkl").set_index("qid")
S=t[t.category=="S3"]
def comp(name):
    f=F[name]; ch=S.index[~np.isclose(f[S.index],p3[S.index],rtol=1e-12)]
    y=S.loc[ch].copy(); y["new"]=f[ch]; y["old"]=p3[ch]
    y["part"]=np.where(y.video_source!="lab","segtwin",np.where(y.twin=="captured_0034b","0034b",
              np.where(lab.reindex(ch).kind.isin(["size","other","distance"]),"lab_static","lab_motion")))
    y["capg"]=1-item_scores(y.old.values,y.new.values); y["capl"]=1-item_scores(y.new.values,y.old.values)
    y["d"]=item_scores(y.new.values,y.pt.values)-item_scores(y.old.values,y.pt.values)
    r=y.groupby("part").agg(n=("video_id","size"),cap_gain=("capg","sum"),cap_loss=("capl","sum"),n_known=("pt",lambda s:s.notna().sum()),d_known=("d","sum"),
        cap_known=("capg",lambda s: s[y.loc[s.index,"pt"].notna()].sum()))
    r["realized_frac_known"]=r.d_known/r.cap_known
    print("==",name,len(ch)); print(r.round(3))
    return y
ys={n:comp(n) for n in F}
