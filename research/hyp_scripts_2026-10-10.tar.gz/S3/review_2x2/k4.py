import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
pd.set_option("display.width",250); pd.set_option("display.max_colwidth",80); pd.set_option("display.max_rows",500)
v=val(); 
vl=v[v.video_source=="lab"]
print(vl.groupby(["video_id","category"]).size())
lab=pd.read_pickle("lab.pkl")
lab["twin"]=lab.video_id.map(base_of); lab["nq"]=lab.question.map(normq)
v["twin"]=v.video_id.map(base_of); v["nq"]=v.question.map(normq)
gt=v.set_index(["twin","nq"]).answer; gt=gt[~gt.index.duplicated()]
lab["ans"]=[gt.get((a,b),np.nan) for a,b in zip(lab.twin,lab.nq)]
k=lab[lab.ans.notna()]
print(k.groupby(["category","kind"]).agg(n=("qid","size"),chg=("chg","sum")))
k=k.copy()
k["sg"]=item_scores(k.v2.values,k.ans.values); k["sd"]=item_scores(k.p3.values,k.ans.values)
print(k[k.chg].groupby(["category","kind"]).agg(n=("qid","size"),geo=("sg","mean"),dir=("sd","mean"),clips=("twin","nunique")).round(3))
print(k[k.chg][["video_id","category","kind","question","ans","v2","p3","sg","sd"]].sort_values(["category","kind"]).to_string())
pd.to_pickle(lab,"lab2.pkl")
