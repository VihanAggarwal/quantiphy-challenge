import cv2, numpy as np
for v,box in [("captured_0040",(640,390,780,520)),("captured_0038",(640,420,780,550))]:
    cap=cv2.VideoCapture(f"/home/user/quantiphy-challenge/data/QuantiPhy/{v}.mp4")
    cap.set(cv2.CAP_PROP_POS_FRAMES,12); ok,f=cap.read()
    x0,y0,x1,y1=box; c=f[y0:y1,x0:x1]
    c=cv2.resize(c,None,fx=4,fy=4,interpolation=cv2.INTER_NEAREST)
    for gx in range(0,c.shape[1],40): cv2.line(c,(gx,0),(gx,c.shape[0]),(0,255,0) if (gx//40)%5==0 else (0,120,0),1)
    for gy in range(0,c.shape[0],40): cv2.line(c,(0,gy),(c.shape[1],gy),(0,255,0) if (gy//40)%5==0 else (0,120,0),1)
    cv2.imwrite(f"fr/{v}_tower.jpg",c)
