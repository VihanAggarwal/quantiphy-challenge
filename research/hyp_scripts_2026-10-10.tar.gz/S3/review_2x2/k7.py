import pandas as pd, numpy as np
pd.set_option("display.width",250); pd.set_option("display.max_colwidth",70); pd.set_option("display.max_rows",500)
lab=pd.read_pickle("lab2.pkl")
print(lab.drop_duplicates("twin")[["twin","category","prior"]].to_string())
s=lab[lab.kind.isin(["size","other"])]
s=s.assign(q=s.question.str.replace("What is the ","").str.slice(0,55))
g=s.groupby(["twin","category","q"]).agg(n=("qid","size"),chg=("chg","sum"),geo=("geo",lambda v: "/".join(f"{a:.3g}" for a in v)),dir=("dir",lambda v: "/".join(f"{a:.3g}" for a in v)),ans=("ans","first"))
print(g.to_string())
