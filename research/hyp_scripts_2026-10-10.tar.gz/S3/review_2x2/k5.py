import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
import itertools
lab=pd.read_pickle("lab2.pkl")
x=lab[lab.chg].copy()
# caps: swing if truth = geo (direct loses) and if truth = dir (direct wins)
x["cap_geo"]=1-item_scores(x.p3.values, x.v2.values)   # max loss for direct (truth=geo)
x["cap_dir"]=1-item_scores(x.v2.values, x.p3.values)   # max gain for direct (truth=dir)
x["absl"]=np.abs(np.log(x.p3/x.v2))
def grp(k, scheme):
    if scheme=="A": return "static" if k in ("size","other","distance") else "motion"
    if scheme=="B": return "static" if k in ("size","other") else "motion"
    if scheme=="C": return "static" if k in ("size","other","distance","path_length","displacement") else "motion"  # all 'lengths' vs rates
x["gA"]=x.kind.map(lambda k: grp(k,"A")); x["gB"]=x.kind.map(lambda k: grp(k,"B")); x["gC"]=x.kind.map(lambda k: grp(k,"C"))
print(x.groupby(["category","gA"]).agg(n=("qid","size"),cap_geo=("cap_geo","sum"),cap_dir=("cap_dir","sum"),abslog=("absl","sum")).round(2))
print(x.groupby(["category","kind"]).agg(n=("qid","size"),cap_geo=("cap_geo","sum"),cap_dir=("cap_dir","sum")).round(2))
N={"S3":578,"D3":969}
D={"S3":0.012,"D3":-0.011}
def solve(scheme, w, dS, dD):
    A=[];b=[]
    for c,d in (("S3",dS),("D3",dD)):
        y=x[x.category==c]
        A.append([y.loc[y["g"+scheme]=="static",w].sum(), y.loc[y["g"+scheme]=="motion",w].sum()]); b.append(d*N[c])
    A=np.array(A,float); sol=np.linalg.solve(A,np.array(b))
    return A,sol
x["one"]=1.0
x["capmean"]=(x.cap_geo+x.cap_dir)/2
x["absl07"]=np.minimum(x.absl,0.7)
for scheme in "ABC":
  for w in ("one","capmean","absl07"):
    res=[]
    for dS in (0.0115,0.012,0.0125):
      for dD in (-0.0115,-0.011,-0.0105):
        A,s=solve(scheme,w,dS,dD)
        res.append((dS,dD,s[0],s[1], s[0]*A[0,0]))  # S3 static total effect (direct-minus-geo), MRA-points
    r=np.array([[a[2],a[3],a[4]] for a in res])
    c=[a for a in res if a[0]==0.012 and a[1]==-0.011][0]
    print(f"scheme {scheme} w={w:8s} central: static {c[2]:+.3f} motion {c[3]:+.3f} S3static_total {c[4]:+.2f} pts -> split gain {-c[4]/578:+.4f}; range S3static_total [{r[:,2].min():+.2f},{r[:,2].max():+.2f}] gain [{-r[:,2].max()/578:+.4f},{-r[:,2].min()/578:+.4f}]")
x.to_pickle("chg.pkl")
