import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
pd.set_option("display.width",250); pd.set_option("display.max_rows",200)
lab=pd.read_pickle("lab3.pkl")
v=val(); v["nq"]=v.question.map(normq)
g34=v[v.video_id=="captured_0034as"].set_index("nq").answer
lab["grp"]=np.where(lab.kind.isin(["size","other","distance"]),"static","motion")
lab["geo_ok"]=lab.geo.where(lab.geo>0)
def pseudo(df, how):
    out={}
    for (tw,nq),g in df.groupby(["twin","nq"]):
        for i,r in g.iterrows():
            o=g.drop(i)
            if how=="loo":
                vals=list(o.geo_ok.dropna())+list(o.dir.dropna())
            elif how=="all6":
                vals=list(g.geo_ok.dropna())+list(g.dir.dropna())
            elif how=="loo_dir":   # other renders' direct only
                vals=list(o.dir.dropna())
            elif how=="loo_geo":
                vals=list(o.geo_ok.dropna())
            out[i]=np.exp(np.median(np.log(vals))) if len(vals) else np.nan
    return pd.Series(out)
x=lab[lab.chg].copy()
N={"S3":578,"D3":969}; OFF={"S3":0.012*578,"D3":-0.011*969}
for how in ["loo","all6","loo_dir","loo_geo"]:
    pt=pseudo(lab,how)
    x["pt"]=pt.reindex(x.index)
    m=x.twin=="captured_0034b"
    x.loc[m,"pt"]=x.loc[m,"nq"].map(g34)
    x["d"]=item_scores(x.p3.values,x.pt.values)-item_scores(x.v2.values,x.pt.values)
    tab=x.groupby(["category","grp"]).agg(n=("qid","size"),n_pt=("pt",lambda s: s.notna().sum()),delta=("d","sum")).round(2)
    print("==",how); print(tab)
    for c in ("S3","D3"):
        y=x[x.category==c]
        print(f"  {c}: predicted total {y.d.sum():+.2f} pts (official {OFF[c]:+.2f}); excl 0034b {y[y.twin!='captured_0034b'].d.sum():+.2f}")
    # known rows check: pseudo vs val gt
    k=x[x.ans.notna()&(x.twin!="captured_0034b")]
    k_true=item_scores(k.p3.values,k.ans.values)-item_scores(k.v2.values,k.ans.values)
    print("  known rows: true delta", round(np.nansum(k_true),2), "pseudo delta", round(k.d.sum(),2), "n",len(k))
    x[f"d_{how}"]=x.d
x.to_pickle("x_pseudo.pkl")
