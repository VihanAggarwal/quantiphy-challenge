import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
pd.set_option("display.width",250)
lab=pd.read_pickle("lab3.pkl")
v=val(); v["nq"]=v.question.map(normq)
g34=v[v.video_id=="captured_0034as"].set_index("nq").answer
b=lab[(lab.twin=="captured_0034b")&lab.chg].copy()
b["gtv"]=b.nq.map(g34)
print(b.gtv.notna().sum(), len(b))
b["sg"]=item_scores(b.v2.values,b.gtv.values); b["sd"]=item_scores(b.p3.values,b.gtv.values)
b["grp"]=np.where(b.kind.isin(["size","other","distance"]),"static","motion")
print(b.groupby("grp").agg(n=("qid","size"),geo=("sg","sum"),dir=("sd","sum")))
print(b[["video_id","kind","question","gtv","v2","p3","sg","sd"]].to_string())
