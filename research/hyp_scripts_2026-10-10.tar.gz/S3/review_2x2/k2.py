import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
import pickle
t = test().copy()
specs = pickle.load(open(SP + "/work/specs.pkl", "rb"))
run = run_csv().set_index("id")
p3 = pd.read_csv("/home/user/quantiphy-challenge/submissions/trackA_probe3_s2maxext_d2denseoff_labdirect.csv").set_index("id").parsed_value
pv = v2().set_index("id").parsed_value
t["v2"]=t.qid.map(pv); t["p3"]=t.qid.map(p3)
t["chg"]=~np.isclose(t.v2,t.p3,rtol=1e-9)
print(t[t.chg].groupby(["category","video_source"]).size())
lab = t[(t.video_source=="lab")&t.category.isin(["S3","D3"])].copy()
lab["kind"]=lab.qid.map(lambda q: specs[q].target.kind)
lab["pkind"]=lab.qid.map(lambda q: specs[q].prior.kind)
lab["geo"]=lab.qid.map(run.geo_value); lab["dir"]=lab.qid.map(run.direct_value); lab["meth"]=lab.qid.map(run.method)
print("p3==dir all lab:", np.isclose(lab.p3, lab.dir).mean())
print("v2==geo where chg:", np.isclose(lab[lab.chg].v2, lab[lab.chg].geo).mean())
print(pd.crosstab([lab.category, lab.kind], lab.chg))
print(pd.crosstab([lab.category], lab.pkind))
lab["lr"]=np.log(lab.p3/lab.v2)  # direct/geo
x=lab[lab.chg]
print(x.groupby(["category","kind"]).lr.agg(['size','median','mean',lambda s: np.mean(np.abs(s)), lambda s:(np.abs(s)>np.log(1.25)).sum()]).round(3))
print(x.groupby(["category","kind"]).meth.value_counts())
# question text check
import re
def qk(q):
    q=q.lower()
    if 'acceler' in q: return 'acc'
    if 'speed' in q or 'velocity' in q: return 'speed'
    if 'distance' in q and ('travel' in q or 'move' in q or 'cover' in q or 'displace' in q): return 'disp'
    if 'far' in q or 'distance' in q: return 'distance?'
    return 'size?'
lab["qk"]=lab.question.map(qk)
print(pd.crosstab(lab.kind, lab.qk))
pd.to_pickle(lab,"lab.pkl")
