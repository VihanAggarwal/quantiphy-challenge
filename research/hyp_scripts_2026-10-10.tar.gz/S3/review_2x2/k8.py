import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
pd.set_option("display.width",250)
V="/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/variants_labdirect/"
t=test().set_index("qid")
p3=pd.read_csv("/home/user/quantiphy-challenge/submissions/trackA_probe3_s2maxext_d2denseoff_labdirect.csv").set_index("id").parsed_value
pv=v2().set_index("id").parsed_value
lab=pd.read_pickle("lab2.pkl").set_index("qid")
F={n:pd.read_csv(V+n+".csv").set_index("id").parsed_value for n in ["S3p3_split_full","S3p3_direct_full","S3p3_split_only","S3p3_segtwin_only"]}
for n,f in F.items():
    d=~np.isclose(f,p3,rtol=1e-12)
    ids=f.index[d]
    print(n, d.sum(), t.loc[ids].category.value_counts().to_dict(), t.loc[ids].video_source.value_counts().to_dict())
    # check non-S3 identical to p3
sf,df=F["S3p3_split_full"],F["S3p3_direct_full"]
d=~np.isclose(sf,df,rtol=1e-12); ids=sf.index[d]
x=lab.loc[ids].copy(); x["sf"]=sf[ids]; x["df"]=df[ids]
print("split_full vs direct_full differ:",len(ids), x.kind.value_counts().to_dict())
print("sf==v2:",np.isclose(x.sf,x.v2).mean(), " df==p3:",np.isclose(x.df,x.p3).mean())
x["absl"]=np.abs(np.log(x.sf/x.df))
x["cap_geo"]=1-item_scores(x.df.values,x.sf.values); x["cap_dir"]=1-item_scores(x.sf.values,x.df.values)
print(x.groupby("twin").agg(n=("kind","size"),medlr=("absl","median"),cap_geo=("cap_geo","sum"),cap_dir=("cap_dir","sum")).round(2))
print("total caps", x.cap_geo.sum().round(2), x.cap_dir.sum().round(2), " in S3 MRA units:", (x.cap_geo.sum()/578).round(4),(x.cap_dir.sum()/578).round(4))
x.to_pickle("sf_df.pkl")
# split_only vs p3 rows: compare with 2x2 static rows
so=F["S3p3_split_only"]; d=~np.isclose(so,p3,rtol=1e-12); ids=so.index[d]
y=lab.loc[ids]; print("split_only:",len(ids), y.kind.value_counts().to_dict(), y.twin.value_counts().to_dict())
chs=lab[(lab.category=="S3")&lab.chg&lab.kind.isin(["size","other","distance"])]
print("S3 static changed in p3 not in split_only:", sorted(set(chs.index)-set(ids)), chs.loc[sorted(set(chs.index)-set(ids))].twin.tolist())
