import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
lab=pd.read_pickle("lab2.pkl")
lab["grpA"]=np.where(lab.kind.isin(["size","other","distance"]),"static","motion")
# only questions where geometry is valid in all renders
lab=lab[lab.geo.notna()&(lab.geo>0)&lab.dir.notna()]
rows=[]
for (tw,nq),g in lab.groupby(["twin","nq"]):
    if len(g)<2: continue
    rows.append(dict(twin=tw,nq=nq,category=g.category.iloc[0],kind=g.kind.iloc[0],grp=g.grpA.iloc[0],n=len(g),
        chg=g.chg.any(), sg=np.std(np.log(g.geo),ddof=1), sd=np.std(np.log(g.dir),ddof=1),
        lr=np.median(np.log(g.dir/g.geo))))
r=pd.DataFrame(rows)
r=r[r.twin!="captured_0034b"]
for sub,name in ((r,"all"),(r[r.chg],"changed-in-p3")):
    print("==",name)
    print(sub.groupby(["category","kind"]).agg(nq=("nq","size"),clips=("twin","nunique"),sd_geo_med=("sg","median"),sd_dir_med=("sd","median"),sd_geo_mean=("sg","mean"),sd_dir_mean=("sd","mean"),geo_less=("sg",lambda s: 0)).round(3).drop(columns="geo_less"))
    sub=sub.assign(geo_tighter=(sub.sg<sub.sd))
    print(sub.groupby(["category","grp"]).agg(nq=("nq","size"),clips=("twin","nunique"),sd_geo_med=("sg","median"),sd_dir_med=("sd","median"),frac_geo_tighter=("geo_tighter","mean")).round(3))
r.to_pickle("cons.pkl")
