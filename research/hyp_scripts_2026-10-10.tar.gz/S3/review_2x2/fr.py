import cv2, sys
for v,tsec in [("captured_0013",1.0),("captured_0037",0.5),("captured_0038",0.5),("captured_0040",0.5),("captured_0053",0.3),("captured_0031",1.6),("captured_0014",0.5),("captured_0039",0.5)]:
    cap=cv2.VideoCapture(f"/home/user/quantiphy-challenge/data/QuantiPhy/{v}.mp4")
    fps=cap.get(cv2.CAP_PROP_FPS); n=cap.get(cv2.CAP_PROP_FRAME_COUNT)
    cap.set(cv2.CAP_PROP_POS_FRAMES,int(tsec*fps)); ok,f=cap.read()
    if not ok: print(v,"fail"); continue
    h,w=f.shape[:2]; s=960/w; f=cv2.resize(f,(960,int(h*s)))
    cv2.imwrite(f"fr/{v}.jpg",f,[cv2.IMWRITE_JPEG_QUALITY,80]); print(v,w,h,fps,n)
