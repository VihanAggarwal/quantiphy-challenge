import numpy as np, pandas as pd
x=pd.read_pickle("chg.pkl")
x["cap"]=(x.cap_geo+x.cap_dir)/2
B=4.5  # 0034b direct-minus-geo in S3 (GT of 0034a): motion +3.6, static +0.9
def A_b(excl_b, w, grouping, dS=0.012, dD=-0.011, b_adj=B):
    y=x if not excl_b else x[x.twin!="captured_0034b"]
    st = (lambda k: k in ("size","other","distance")) if grouping=="A" else (lambda k: k in ("size","other"))
    A=[];b=[]
    for c,d,n in (("S3",dS,578),("D3",dD,969)):
        z=y[y.category==c]; s=z.kind.map(st)
        A.append([z.loc[s,w].sum(), z.loc[~s,w].sum()]); b.append(d*n-(b_adj if (excl_b and c=="S3") else 0))
    return np.array(A,float), np.array(b)
x["one"]=1.0
print("excl_b  w    grp | static  motion | S3 static total pts | split gain (S3) [rounding range]")
for excl in (False,True):
  for w in ("one","cap"):
    for grp in ("A","B"):
        gains=[]
        for dS in (0.0115,0.012,0.0125):
          for dD in (-0.0115,-0.011,-0.0105):
            for badj in ((B,) if not excl else (3.5,4.5,6.0)):
              A,b=A_b(excl,w,grp,dS,dD,badj); s=np.linalg.solve(A,b); gains.append(-s[0]*A[0,0]/578)
        A,b=A_b(excl,w,grp); s=np.linalg.solve(A,b)
        print(f"{str(excl):6s} {w:4s} {grp}   | {s[0]:+.3f} {s[1]:+.3f} | {s[0]*A[0,0]:+6.2f} | {-s[0]*A[0,0]/578:+.4f} [{min(gains):+.4f},{max(gains):+.4f}]")
# alternatives (count weights, excl 0034b, grouping A)
A,b=A_b(True,"one","A")
(nSs,nSm),(nDs,nDm)=A
print("counts excl b:",A.tolist(), "rhs",b.round(2).tolist())
# (i) category-specific static offset a: s_D = s_S + a ; (ii) motion offset: m_D = m_S - bb ; (iii) proportional s_S=lam*s_D
for a in (-0.08,-0.04,0,0.04,0.08):
    M=np.array([[nSs,nSm],[nDs,nDm]]); rhs=np.array([b[0], b[1]-nDs*a]); s=np.linalg.solve(M,rhs)
    print(f"static offset a={a:+.2f} (s_D=s_S+a): s_S {s[0]:+.3f} m {s[1]:+.3f} -> split gain {-s[0]*nSs/578:+.4f}")
for bb in (-0.1,-0.05,0,0.05,0.1,0.15):
    M=np.array([[nSs,nSm],[nDs,nDm]]); rhs=np.array([b[0], b[1]+nDm*bb]); s=np.linalg.solve(M,rhs)
    print(f"motion offset b={bb:+.2f} (m_D=m_S-b): s {s[0]:+.3f} m_S {s[1]:+.3f} m_D {s[1]-bb:+.3f} -> split gain {-s[0]*nSs/578:+.4f}")
for lam in (0.3,0.55,1.0,1.5):
    M=np.array([[nSs*lam,nSm],[nDs,nDm]]); s=np.linalg.solve(M,b)
    print(f"proportional s_S={lam}*s_D: s_D {s[0]:+.3f} s_S {lam*s[0]:+.3f} m {s[1]:+.3f} -> split gain {-lam*s[0]*nSs/578:+.4f}")
# breakeven: m_D value that makes s=0 with shared static
print("m_D at which shared static effect = 0:", b[1]/nDm, " (count units, excl 0034b)")
