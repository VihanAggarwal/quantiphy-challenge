"""Lab camera calibration from the stated prior sizes: f = d_px * range / D for each ball prior at each time
depth_info gives that ball's range; d_px from a circle fit to the SAM foreground mask (blue vs black render)."""
from common import *
import pickle, cv2
from qp.geometry import _depth_groups, name_score, _compatible, _tokens
import vidio
obs = pd.read_pickle(SP + "/work/obs.pkl"); specs = pickle.load(open(SP + "/work/specs.pkl", "rb"))
t = test()
lab = t[(t.video_source == "lab")]
F0 = 740.0
rows = []
for base, g in lab.groupby(lab.video_id.map(base_of)):
    if len(vidio.variants(base)) < 3: continue
    q0 = [q for q in g.qid if q in specs]
    if not q0: continue
    sp = specs[q0[0]]
    if sp.prior.kind != "size" or not re.search(r"ball", " ".join(sp.prior.objects)): continue
    P, D = sp.prior.objects[0], sp.prior.value_si
    o = obs[obs.base == base]
    for name, pairs in _depth_groups(sp.depth):
        if not (_compatible(P, name) or name_score(P, name) >= 0.5 or (set(_tokens(name)) <= {"ball"} )): continue
        for tt, Z in pairs:
            if tt is None: continue
            k = int(round(tt * 24))
            # Claude's localisation of this ball near tt
            cand = o[(o.obj.map(lambda n: _compatible(n, name) or name_score(n, name) >= 0.6 or (set(_tokens(name)) <= {"ball"} and _compatible(n, P)))) & ((o.t - tt).abs() <= 0.1)]
            cs = []
            for r in cand.itertuples():
                if r.box is not None: cs.append(((r.box[0] + r.box[2]) / 2, (r.box[1] + r.box[3]) / 2))
                elif r.point is not None: cs.append(tuple(r.point))
                elif r.extent is not None: cs.append(tuple(np.mean(r.extent, axis=0)))
            if not cs:
                rows.append(dict(base=base, ball=name, D=D, t=tt, Z=Z, k=k, note="no_claude_loc")); continue
            c0 = np.median(np.array(cs), axis=0)
            r_exp = F0 * D / 2 / Z
            mask = vidio.fgmask(base, min(k, len(vidio.frames(base + "s")) - 1))
            fit = vidio.fit_ball(mask, c0, r_exp)
            if fit is None:
                rows.append(dict(base=base, ball=name, D=D, t=tt, Z=Z, k=k, cx=c0[0], cy=c0[1], note="no_fit")); continue
            c, rad, cover = fit
            dpx = 2 * rad + 1.0
            # range is to the ball's surface or centre? report both
            rows.append(dict(base=base, ball=name, D=D, t=tt, Z=Z, k=k, cx=c[0], cy=c[1], dpx=dpx, cover=cover, n_loc=len(cs),
                             f_c=dpx * Z / D, f_s=dpx * (Z + D / 2) / D, note=""))
d = pd.DataFrame(rows)
pd.set_option("display.width", 220); pd.set_option("display.max_rows", 200)
print(d.round(3).to_string())
d.to_csv(SP + "/work/calib_balls.csv", index=False)
ok = d[(d.note == "") & (d.cover > 0.5)]
print("n", len(ok), "median f (range=centre)", ok.f_c.median(), "fov", np.degrees(2 * np.arctan(640 / ok.f_c.median())))
print("median f (range=surface)", ok.f_s.median())
