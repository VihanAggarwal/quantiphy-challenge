import json
SP = "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3"
bundle = {
 "category": "S3",
 "findings": [
  "LAB RENDERS: every lab clip exists as 3 renders of ONE video (original with blurred background; 's' blue background; 'x' black/white/green background; same frames, SAM2 foreground). Questions/prior/depth_info are duplicated, so val GT of a val lab clip applies to all 3 test renders: a val-on-test harness (S3: 52 lab + 34 non-lab test answers with GT; D3 lab 54). A foreground mask = pixels where the s and x renders agree (|s-x|<40).",
  "CAMERA (lab_focal.csv): the lab camera is fixed. GT-implied f from static val objects (Claude extents, own depth) is tight: 713-738 px over 12 renders of 4 clips (0013, 0034a, 0041, 0061), median 722 px = FOV 83.1 deg at 1280 px (mask-measured static soccer ball 0034a: 735-739). The current 84 deg MAP (711 px) is within 1.5%: FOV sweep on val-on-test lab is flat between 82 and 86 deg (S3 sel .742-.752, D3 sizes .80-.81) -> no variant worth uploading.",
  "Per-clip calibration from the prior HURTS: prior-implied f (prior size x depth / px) is biased high and noisy (Claude extents median 769 px, range 595-1140; mask circle fits median 849 px), because the size priors are moving balls at the depth_info times (blur inflates px, depths of small moving balls look too large: mask-measured ping-pong balls come out 4.3-6.1 cm with f=722 and the stated depths). Solo f on val-on-test: S3 lab .715 vs .748 (MAP), D3 sizes .59 vs .81. Keep a fixed camera; use the prior only as a consistency check.",
  "Probe 3 prediction (all-direct on lab): val-on-test S3 lab .748 -> .687 (category S3 about -0.036), D3 lab .681 -> .619 (D3 about -0.030). Geometry beats direct on lab for sizes (.925 vs .863), speeds (.658 vs .612) and path lengths (.70 vs .50); keep geometry routing on lab.",
  "Lab speeds: the ~0.7x under-estimate is mostly not fixable geometry. Dense mask ball tracks + looming (range ~ 1/apparent diameter, anchored on depth_info) help single-anchor cases (0034a left ball 69 -> 76 cm/s vs GT 83) but GT contradicts the video in others (0034a right ball: constant apparent size, lateral 0.60-0.65 m/s at f=722, GT 0.99; 0061 soccer GT 2.79 vs 1.7). Not proposed.",
  "Non-lab S3 (idea 4, negative): val-on-test direct .803 vs geometry .638 (34 q); geo/direct geometric mean .715; no geometry subset (own depths, sizes, well-conditioned f) beats direct. The only free lever found: segmented renders.",
  "SEGMENTED RENDERS are worse: a simulation_XXXX_segmented clip is the same scene with the background removed; on val-on-test pairs the original clip's answer beats the segmented clip's own answer in every category (S3 .700 -> .945, n=11; D3 .487 -> .562; S2 .693 -> .733; D2 .923 -> .938; all .723 -> .811, n=47, 9 clips). The same holds for lab renders on direct-routed MOTION questions (s/x own .383 vs original render .600 S3 n=6; D3 .50 -> 1.00 n=2); sizes show no difference. The S2/D2/D3 owners can reuse this.",
  "Data defects found from the inputs: captured_0034b(s,x) is a second camera filming the 0034a event, but carries 0034a's depth_info verbatim -> its prior measured through the rig camera is 0.49x the stated size (FOV ~127 deg; all other clips 0.86-1.56x) and geometry halves everything (soccer ball 12.2 cm, speeds 27-32 cm/s); captured_0040 'distance_white_cup_camera = 8420m' (decimal slip, 0.8420 m: re-solved cup rim 8.5-9.0 / height 14.6-14.8 cm, matching the same cup measured by geometry in 0037-0039: 14.7-14.8 / 8.5-8.7); 0035a/0035b list the soccer ball twice at one time (apparent size shows 0035a's 2.412 m entry is the basketball); 0027 'book' entries sit at the red-ball question times (likely the ball); 0028 'ball' entries are the ping-pong ball but fail the name match (routed to direct, whose answers are physics-consistent)."
 ],
 "variants": [
  {"name": "S3_combo", "csv": SP + "/variants/S3_combo.csv",
   "mechanism": "segtwin (S3 questions of a segmented simulation clip take the original clip's answer for the identical question, prior and depth_info) + labfix: (a) depth_info decimal slip restored (> 20x the clip's other entries) and the geometry re-solved; (b) a lab clip whose prior, measured through the fixed rig camera, is off its stated value by > 1.75x has depth_info for another camera -> answer of the identical question on the clip where they agree (same event, rig view; only 0034b), else direct; (c) s/x renders: direct-routed motion answers (speed/acceleration/displacement/path) take the original render's answer.",
   "answers_changed": 87, "median_ratio_changed": 1.186,
   "val_evidence": "val-on-test S3 (86 test answers with val GT on all renders/twins): v2 .770 -> .816 (lab .748 -> .773, non-lab .803 -> .882); 0034b judged with 0034a's GT (same event): .419 -> .786 (n=21). Rules partly designed on these clips (in-sample).",
   "expected_direction": "up, about +0.02 to +0.03 on S3 (segtwin ~+.006, 0034b ~+.011, render/decimal ~+.005)", "confidence": "medium"},
  {"name": "S3_combo_cons", "csv": SP + "/variants/S3_combo_cons.csv",
   "mechanism": "S3_combo + lab render consensus: a geometry-routed lab answer becomes the log-median of the geometry-routed answers of the same question over the clip's 3 renders (independent annotations of the same video; removes one-off bad annotations such as 0031x distance 12.5 vs 22.8/23.6 cm, 0031s white-ball speed 7.6 vs 50/36.5).",
   "answers_changed": 242, "median_ratio_changed": 1.005,
   "val_evidence": "consensus part is neutral on val-on-test (val clips' geometry agrees across renders: S3 .789 -> .789, D3 .727 -> .727); 34 test answers move > 10%.",
   "expected_direction": "S3_combo plus a small, uncertain-sign change (~+0.003 +- 0.005)", "confidence": "low-medium"},
  {"name": "S3_labfix", "csv": SP + "/variants/S3_labfix.csv",
   "mechanism": "labfix (a)+(b)+(c) only (lab, 41 answers: 6 decimal slip, 21 0034b sibling, 14 original-render motion).",
   "answers_changed": 41, "median_ratio_changed": 1.801,
   "val_evidence": "val-on-test S3 lab .748 -> .773 (n=52); 0034b with 0034a GT .419 -> .786 (n=21).",
   "expected_direction": "up, about +0.015 on S3", "confidence": "medium"},
  {"name": "S3_segtwin", "csv": SP + "/variants/S3_segtwin.csv",
   "mechanism": "segtwin only (46 segmentation answers).",
   "answers_changed": 46, "median_ratio_changed": 1.037,
   "val_evidence": "val-on-test S3 segmented .700 -> .945 (n=11, 2 clips); all categories .723 -> .811 (n=47, 9 clips).",
   "expected_direction": "up, about +0.006 to +0.02 on S3", "confidence": "medium"}
 ],
 "files": {"lab_focal_csv": SP + "/lab_focal.csv", "scripts": SP + "/work/",
           "notes": "lab_focal.csv: per lab video (S3+D3 test) prior-implied f (Claude extents; D3 motion priors flagged by sensitivity), mask circle-fit f, GT-implied f for val clips, f used in v2, recommended 722 px."}
}
json.dump(bundle, open(SP + "/bundle.json", "w"), indent=1)
print("ok")
