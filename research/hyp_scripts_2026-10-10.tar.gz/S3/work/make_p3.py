"""S3 variants on the probe-3 base (lab = Claude's direct answer). Writes SP/variants_labdirect/*.csv."""
from common import *
import pickle
OUT = SP + "/variants_labdirect"
P3F = "/home/user/quantiphy-challenge/submissions/trackA_probe3_s2maxext_d2denseoff_labdirect.csv"
specs = pickle.load(open(SP + "/work/specs.pkl", "rb"))
t = test(); run = run_csv().set_index("id")
p3df = pd.read_csv(P3F); p3 = p3df.set_index("id").parsed_value
pv = v2().set_index("id").parsed_value
for x in (t,):
    x["twin"] = x.video_id.str.replace("_segmented", "", regex=False).map(base_of); x["nq"] = x.question.map(normq)
S = t[t.category == "S3"].copy()
lab = S[S.video_source == "lab"].copy()
lab["var"] = [vid[len(b):] for vid, b in zip(lab.video_id, lab.twin)]
lab["kind"] = lab.qid.map(lambda q: specs[q].target.kind if q in specs else "?")
lab["static"] = lab.kind.isin(["size", "other", "distance"])
lab["dir"] = lab.qid.map(run.direct_value); lab["meth"] = lab.qid.map(run.method)
basedir = lab[lab["var"] == ""].set_index("nq" if False else ["twin", "nq"]).dir
basedir = basedir[~basedir.index.duplicated()]
lab["dir_base"] = [basedir.get((a, b), d) for a, b, d in zip(lab.twin, lab.nq, lab.dir)]
labfix = pd.read_csv(SP + "/work/labfix_changes.csv").set_index("qid")
dec = labfix[labfix.why.str.startswith("a_")].new          # 0040 cup re-solved with 0.842 m (geometry)
BAD = {"captured_0034b"}                                   # depth_info of another camera (prior check, labfix (b))

# segmented twin (non-lab): copy the original clip's answer
seg = {}
orig = S[~S.video_id.str.endswith("_segmented") & (S.video_source != "lab")].set_index(["twin", "nq"])
for r in S[S.video_id.str.endswith("_segmented")].itertuples():
    if (r.twin, r.nq) in orig.index:
        o = orig.loc[[(r.twin, r.nq)]].iloc[0]
        if o.prior == r.prior and o.depth_info == r.depth_info:
            seg[r.qid] = float(p3[o.qid])

def lab_value(r, split, use_c, use_b, use_a):
    """one S3 lab answer."""
    if split and r.static and r.twin not in BAD:  # geometry needs depth_info of this view
        if use_a and r.qid in dec.index: return float(dec[r.qid])
        if r.meth.startswith("geometry"):  # v2's geometry selection
            return float(pv[r.qid])
    return float(r.dir_base if use_c else r.dir)

def build(name, split=False, use_c=True, use_b=True, use_a=True, use_seg=True):
    val = p3.copy()
    if use_seg:
        for q, x in seg.items(): val[q] = x
    cur = {}
    for r in lab.itertuples():
        cur[r.qid] = lab_value(r, split, use_c, use_b, use_a)
    if use_b:  # 0034b static questions take the 0034a answer (same event, rig camera): median over its renders
        sib = lab[lab.twin == "captured_0034a"]
        for r in lab[lab.twin.isin(BAD) & lab.static].itertuples():
            s = sib[(sib.nq == r.nq) & (sib.prior == r.prior)]
            if len(s):
                cur[r.qid] = float(np.exp(np.median(np.log([cur[q] for q in s.qid]))))
    for q, x in cur.items(): val[q] = x
    out = p3df.copy(); out["parsed_value"] = out.id.map(val)
    assert out.parsed_value.notna().all() and (out.parsed_value > 0).all()
    ch = ~np.isclose(out.parsed_value.values, p3df.parsed_value.values, rtol=1e-12)
    cats = t.set_index("qid").loc[out.id[ch], "category"].value_counts().to_dict()
    assert set(cats) <= {"S3"}, cats
    r_ = out.parsed_value[ch].values / p3df.parsed_value[ch].values
    out.to_csv(f"{OUT}/{name}.csv", index=False)
    src = t.set_index("qid").loc[out.id[ch], "video_source"].value_counts().to_dict()
    print(f"{name:22s} changed vs probe3: {int(ch.sum()):3d} {src} median new/old {np.median(r_):.3f} >10%: {int((np.abs(np.log(r_)) > np.log(1.1)).sum())}")
    return out
build("S3p3_split_full", split=True)
build("S3p3_direct_full", split=False)
build("S3p3_split_only", split=True, use_c=False, use_b=False, use_a=True, use_seg=False)
build("S3p3_segtwin_render", split=False, use_b=False)
build("S3p3_segtwin_only", split=False, use_c=False, use_b=False, use_a=False)
