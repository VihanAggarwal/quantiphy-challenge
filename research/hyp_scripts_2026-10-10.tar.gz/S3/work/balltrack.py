"""Per-frame ball diameter + centre in the lab clips, from the SAM foreground mask (blue vs black render):
RANSAC circle on the mask boundary near the annotator's track, tracked frame to frame."""
from common import *
import cv2, vidio

def guess_track(obs_rows):
    """(t, uv) centre guesses from annotator obs rows (points, box centres, extent midpoints)."""
    T, U = [], []
    for r in obs_rows.itertuples():
        if r.point is not None: c = r.point
        elif r.box is not None: c = ((r.box[0] + r.box[2]) / 2, (r.box[1] + r.box[3]) / 2)
        elif r.extent is not None: c = tuple(np.mean(r.extent, axis=0))
        else: continue
        T.append(r.t); U.append(c)
    if not T: return None
    T = np.array(T); U = np.array(U, float); o = np.argsort(T)
    T, U = T[o], U[o]
    # median per unique time
    ut = np.unique(np.round(T, 3))
    UU = np.array([np.median(U[np.isclose(np.round(T, 3), x)], axis=0) for x in ut])
    return ut, UU

def interp(tr, t):
    T, U = tr
    return np.array([np.interp(t, T, U[:, 0]), np.interp(t, T, U[:, 1])])

def track_ball(base, tr, r0, frames_idx, fps=24.0, tol=1.5):
    out = []
    prev_c, prev_r = None, r0
    for k in frames_idx:
        g = interp(tr, k / fps)
        c0 = g if prev_c is None else 0.5 * g + 0.5 * prev_c
        mask = vidio.fgmask(base, k)
        best = None
        for cc in (c0, g):
            fit = vidio.fit_ball(mask, cc, prev_r, win=2.5, rlim=(0.7, 1.4), tol=tol, iters=1500)
            if fit is not None and (best is None or fit[2] > best[2]):
                best = fit
        if best is None:
            out.append(dict(k=k, t=k / fps, ok=False)); continue
        c, r, cover = best
        # fill: share of the fitted disc that is foreground
        H, W = mask.shape
        yy, xx = np.ogrid[:H, :W]
        disc = (xx - c[0]) ** 2 + (yy - c[1]) ** 2 <= (r * 0.9) ** 2
        fill = float(mask[disc].mean()) if disc.any() else 0.0
        out.append(dict(k=k, t=k / fps, cx=c[0], cy=c[1], d=2 * r + 1, cover=cover, fill=fill, gx=g[0], gy=g[1], ok=True))
        if cover > 0.45 and fill > 0.8:
            prev_c, prev_r = c, r
    return pd.DataFrame(out)

if __name__ == "__main__":
    obs = pd.read_pickle(SP + "/work/obs.pkl")
    base, pat, Z, D, ka, kb = sys.argv[1], sys.argv[2], float(sys.argv[3]), float(sys.argv[4]), int(sys.argv[5]), int(sys.argv[6])
    o = obs[(obs.base == base) & obs.obj.str.contains(pat, regex=True)]
    tr = guess_track(o)
    r0 = 740 * D / 2 / Z
    d = track_ball(base, tr, r0, range(ka, kb + 1))
    pd.set_option("display.width", 200); pd.set_option("display.max_rows", 200)
    print(d.round(2).to_string())
