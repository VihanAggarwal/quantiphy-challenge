"""Lab render consensus: the background renders (original, s, x) of a lab clip are the same video, annotated
independently; a geometry-routed answer becomes the log-median of the geometry-routed answers of the same
question over the renders (robust to one bad annotation)."""
from common import *
t = test()
run = run_csv().set_index("id")
lab_ch = pd.read_csv(SP + "/work/labfix_changes.csv").set_index("qid")
def apply_cons(inp, out_name):
    sub = pd.read_csv(SP + f"/variants/{inp}.csv"); v = sub.set_index("id").parsed_value.copy()
    lab = t[(t.video_source == "lab") & (t.category == "S3")].copy()
    lab["base"] = lab.video_id.map(base_of); lab["nq"] = lab.question.map(normq)
    geo_routed = lambda q: (run.loc[q, "method"].startswith("geometry") and q not in lab_ch.index) or \
                           (q in lab_ch.index and lab_ch.loc[q, "why"].startswith("a_"))
    lab = lab[[geo_routed(q) for q in lab.qid]]
    changed = []
    for (b, nq), g in lab.groupby(["base", "nq"]):
        if len(g) < 2: continue
        vals = v[g.qid.to_numpy()]
        m = float(np.exp(np.median(np.log(vals))))
        for q in g.qid:
            if not np.isclose(v[q], m, rtol=1e-6):
                changed.append((q, v[q], m)); v[q] = m
    out = sub.copy(); out["parsed_value"] = out.id.map(v)
    out.to_csv(SP + f"/variants/{out_name}.csv", index=False)
    c = pd.DataFrame(changed, columns=["qid", "old", "new"]); c["r"] = c.new / c.old
    base0 = v2().set_index("id").parsed_value
    tot = (out.set_index("id").parsed_value - base0).abs() > 1e-12
    cats = t.set_index("qid").loc[tot[tot].index, "category"].value_counts().to_dict()
    print(f"{out_name}: consensus changed {len(c)} (>10%: {(np.abs(np.log(c.r)) > np.log(1.1)).sum()}), total vs v2 {int(tot.sum())} {cats}, median ratio vs v2 {float((out.set_index('id').parsed_value[tot[tot].index] / base0[tot[tot].index]).median()):.3f}")
    return c
c = apply_cons("S3_combo", "S3_combo_cons")
