from common import *
import pickle
specs = pickle.load(open(SP + "/work/specs.pkl", "rb"))
t = test(); v = val()
for x in (t, v):
    x["twin"] = x.video_id.str.replace("_segmented", "", regex=False).map(base_of); x["nq"] = x.question.map(normq)
gt = v.set_index(["twin", "nq"]).answer; gt = gt[~gt.index.duplicated()]
run = run_csv().set_index("id")
lab = t[t.video_source == "lab"].copy()
lab["ans"] = [gt.get((a, b), np.nan) for a, b in zip(lab.twin, lab.nq)]
lab["dir"] = lab.qid.map(run.direct_value)
lab["kind"] = lab.qid.map(lambda q: specs[q].target.kind if q in specs else "?")
lab["grp"] = np.where(lab.kind.isin(["size", "other", "distance"]), "static", "motion")
lab["var"] = [vid[len(b):] for vid, b in zip(lab.video_id, lab.twin)]
g = lab.groupby(["twin", "nq"])
lab["dir_med"] = np.exp(g.dir.transform(lambda s: np.median(np.log(s))))
basev = lab[lab["var"] == ""].set_index(["twin", "nq"]).dir
lab["dir_base"] = [basev.get((a, b), np.nan) for a, b in zip(lab.twin, lab.nq)]
lab["dir_base"] = lab.dir_base.fillna(lab.dir)
e = lab[lab.ans.notna()]
for c in ("S3", "D3", "both"):
    for gname in ("static", "motion", "all"):
        x = e if c == "both" else e[e.category == c]
        x = x if gname == "all" else x[x.grp == gname]
        if not len(x): continue
        print(f"{c:4s} {gname:6s} n={len(x):3d} own {mra(x.dir, x.ans):.3f}  base-render {mra(x.dir_base, x.ans):.3f}  median3 {mra(x.dir_med, x.ans):.3f}   [clips {x.twin.nunique()}]")
# per variant
for c in ("S3", "D3"):
    x = e[e.category == c]
    print(c, {vv or "orig": round(mra(y.dir, y.ans), 3) for vv, y in x.groupby("var")})
pd.to_pickle(lab, SP + "/work/labdir.pkl")
