"""Collect, per lab base clip, the Claude obs (boxes / extents / points, original px) of every named object."""
from common import *
import pickle
t = test()
lab = t[(t.video_source == "lab") & t.category.isin(["S3", "D3"])]
anns, recs = anns_for(lab, post=False)
rows = []
for r in lab.itertuples():
    a = anns.get(r.qid)
    if a is None: continue
    for tr in a.tracks:
        for o in tr.obs:
            rows.append(dict(qid=r.qid, vid=r.video_id, base=base_of(r.video_id), cat=r.category, role=tr.role, obj=str(tr.object), t=o.t,
                             point=None if o.point is None else list(o.point), box=None if o.box is None else list(o.box),
                             extent=None if o.extent is None else [list(map(float, p)) for p in np.reshape(o.extent, (2, 2))],
                             pkind=a.spec.prior.kind, pobj=(a.spec.prior.objects or [""])[0], tkind=a.spec.target.kind, tdim=a.spec.target.dimension,
                             tobj=(a.spec.target.objects or [""])[0]))
d = pd.DataFrame(rows)
d.to_pickle(SP + "/work/obs.pkl")
print(len(d))
specs = {q: a.spec for q, a in anns.items()}
pickle.dump(specs, open(SP + "/work/specs.pkl", "wb"))
