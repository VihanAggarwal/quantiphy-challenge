from common import *
t = test(); v = val()
t["twin"] = t.video_id.str.replace("_segmented", "", regex=False).map(base_of)
v["twin"] = v.video_id.str.replace("_segmented", "", regex=False).map(base_of)
t["nq"] = t.question.map(normq); v["nq"] = v.question.map(normq)
sub = v2()[["id", "parsed_value"]].rename(columns={"parsed_value": "v2"})
run = run_csv()
t = t.merge(sub, left_on="qid", right_on="id").merge(run[["id", "geo_value", "direct_value", "method"]], on="id")
# GT on test rows from val (same clip family + same question)
gt = v.set_index(["twin", "nq"]).answer
gt = gt[~gt.index.duplicated()]
t["ans"] = [gt.get((a, b), np.nan) for a, b in zip(t.twin, t.nq)]
def cons(col, how="median"):
    lg = np.log(t[col].where(t[col] > 0))
    g = lg.groupby([t.twin, t.nq])
    return np.exp(g.transform("median" if how == "median" else "mean"))
t["v2_cons"] = cons("v2"); t["v2_cmean"] = cons("v2", "mean")
t["dir_cons"] = cons("direct_value")
t["gsize"] = t.groupby(["twin", "nq"]).qid.transform("size")
e = t[t.ans.notna()]
for cat in ["S3", "D3", "S2", "D2"]:
    for src in sorted(e.video_source.unique()):
        x = e[(e.category == cat) & (e.video_source == src)]
        if not len(x): continue
        print(f"{cat} {src:13s} n={len(x):3d} (in groups {int((x.gsize>1).sum())}) v2 {mra(x.v2, x.ans):.3f} cons-median {mra(x.v2_cons, x.ans):.3f} cons-mean {mra(x.v2_cmean, x.ans):.3f} | direct {mra(x.direct_value, x.ans):.3f} dir-cons {mra(x.dir_cons, x.ans):.3f}")
t[["qid","video_id","twin","nq","category","video_source","v2","v2_cons","v2_cmean","dir_cons","gsize","ans"]].to_pickle(SP+"/work/cons.pkl")
