from common import *
import vidio, masktrack
obs = pd.read_pickle(SP + "/work/obs.pkl")
F = 722.0
cases = [("captured_0038", "white ball", [(1.4, 0.716)]), ("captured_0039", "white ball", [(1.0, 1.014), (1.5, 0.737)]),
         ("captured_0040", "white ball", [(1.5, 0.7045), (2.0, 0.627)]), ("captured_0031", "white ball", [(1.6, 0.994)]),
         ("captured_0032", "white ball", [(1.5, 1.353)]), ("captured_0034a", "soccer ball", [(0.0, 0.894), (1.0, 0.894)]),
         ("captured_0035a", "soccer ball", [(0.6, 2.758)]), ("captured_0035b", "soccer ball", [(0.9, 2.477)]),
         ("captured_0021", "ping pong ball", [(1.0, 1.511), (1.4, 1.03)]), ("captured_0022", "ping pong ball", [(0.6, 1.751), (0.8, 1.687), (1.2, 1.526)]),
         ("captured_0036", "ping pong ball", [(0.9, 1.01), (1.4, 0.716)]), ("captured_0037", "ping pong ball", [(1.0, 1.055)]),
         ("captured_0029", "tennis ball", [(1.0, 0.901), (1.24, 1.144), (1.6, 1.027)]), ("captured_0035a", "basketball", [(0.6, 2.27)]),
         ("captured_0035b", "basketball", [(0.9, 2.7777)])]
for base, name, ents in cases:
    names = sorted(set(obs[obs.base == base].obj))
    cand = [n for n in names if name.split()[0] in n and "ball" in n] or [n for n in names if "ball" in n]
    s = None
    for n in cand:
        s = masktrack.seeds(obs, base, n)
        if s is not None: break
    if s is None: print(base, name, "no seeds", names); continue
    sd, bs = s
    for tt, Z in ents:
        k = int(round(tt * 24)); k = min(k, len(vidio.frames(base + "s")) - 1)
        g = np.array([np.interp(tt, sd.t, sd.u), np.interp(tt, sd.t, sd.v)])
        r0 = F * 0.04 / 2 / Z if "white" in name or "ping" in name else (bs / 2 if bs else 30)
        fit = vidio.fit_ball(vidio.fgmask(base, k), g, r0, win=2.5, rlim=(0.6, 1.6))
        if fit is None: print(base, name, tt, "nofit"); continue
        c, r, cov = fit; d = 2 * r + 1
        print(f"{base} {n:16s} t={tt} Z={Z} d={d:.1f}px cover={cov:.2f} -> D={100 * d * Z / F:.2f} cm (center) {100 * d * Z / F / (1 - d / 2 / F):.2f}")
