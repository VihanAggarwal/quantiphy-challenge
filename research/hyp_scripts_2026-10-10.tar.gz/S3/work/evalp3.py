from common import *
t = test(); v = val()
for x in (t, v):
    x["twin"] = x.video_id.str.replace("_segmented", "", regex=False).map(base_of); x["nq"] = x.question.map(normq)
gt = v.set_index(["twin", "nq"]).answer; gt = gt[~gt.index.duplicated()]
t["ans"] = [gt.get((a, b), np.nan) for a, b in zip(t.twin, t.nq)]
v34 = v[v.video_id == "captured_0034as"].set_index("nq").answer
t["ans34b"] = [v34.get(n, np.nan) if vid.startswith("captured_0034b") else np.nan for vid, n in zip(t.video_id, t.nq)]
e = t[t.category == "S3"]
P3F = "/home/user/quantiphy-challenge/submissions/trackA_probe3_s2maxext_d2denseoff_labdirect.csv"
for nm in ["probe3", "v2", "S3p3_segtwin_only", "S3p3_segtwin_render", "S3p3_split_only", "S3p3_direct_full", "S3p3_split_full"]:
    f = P3F if nm == "probe3" else None
    p = (pd.read_csv(f) if f else v2() if nm == "v2" else pd.read_csv(SP + f"/variants_labdirect/{nm}.csv")).set_index("id").parsed_value
    x = e[e.ans.notna()]; y = e[e.ans34b.notna()]
    lab = x[x.video_source == "lab"]; nl = x[x.video_source != "lab"]
    print(f"{nm:20s} known S3 n={len(x)} {mra(p[x.qid], x.ans):.3f} | lab n={len(lab)} {mra(p[lab.qid], lab.ans):.3f} | nonlab {mra(p[nl.qid], nl.ans):.3f} | 0034b(GT:=0034a) {mra(p[y.qid], y.ans34b):.3f}")
