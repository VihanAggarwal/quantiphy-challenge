"""Depth-free focal length from the table top (a rectangle): f^2 = -(v1-c).(v2-c) for the vanishing points of
its two pairs of parallel edges, edges = lines fitted to the silhouette of the largest foreground component."""
import cv2, numpy as np, vidio, sys, pandas as pd
SP = "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3"

def line_through(P):
    vx, vy, x0, y0 = cv2.fitLine(P.astype(np.float32), cv2.DIST_HUBER, 0, 0.01, 0.01).ravel()
    return np.cross([x0, y0, 1.0], [x0 + vx, y0 + vy, 1.0])

def table_f(base, k=0, draw=None):
    m = vidio.fgmask(base, k)
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
    n, lab, st, _ = cv2.connectedComponentsWithStats(m)
    if n < 2: return None
    i = 1 + int(np.argmax(st[1:, cv2.CC_STAT_AREA]))
    comp = (lab == i).astype(np.uint8)
    # remove the pole: open with a wide horizontal kernel keeps the top
    cs, _ = cv2.findContours(comp, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    C = max(cs, key=cv2.contourArea)[:, 0, :].astype(float)
    hull = cv2.convexHull(C.astype(np.float32))
    # quadrilateral approximation of the hull
    peri = cv2.arcLength(hull, True)
    for eps in np.linspace(0.01, 0.1, 40):
        poly = cv2.approxPolyDP(hull, eps * peri, True)[:, 0, :]
        if len(poly) <= 4: break
    if len(poly) != 4: return None
    # points of C near each side
    lines = []
    for j in range(4):
        a, b = poly[j], poly[(j + 1) % 4]
        ab = b - a; L = np.linalg.norm(ab); u = ab / L; nrm = np.array([-u[1], u[0]])
        s = (C - a) @ u; dist = np.abs((C - a) @ nrm)
        sel = (s > 0.15 * L) & (s < 0.85 * L) & (dist < 6)
        if sel.sum() < 20: return None
        lines.append(line_through(C[sel]))
    H, W = m.shape; c = np.array([W / 2, H / 2])
    v1 = np.cross(lines[0], lines[2]); v2 = np.cross(lines[1], lines[3])
    if abs(v1[2]) < 1e-12 or abs(v2[2]) < 1e-12: return dict(base=base, f=np.nan, note="parallel")
    v1 = v1[:2] / v1[2]; v2 = v2[:2] / v2[2]
    f2 = -float((v1 - c) @ (v2 - c))
    out = dict(base=base, k=k, v1x=v1[0], v1y=v1[1], v2x=v2[0], v2y=v2[1], f=np.sqrt(f2) if f2 > 0 else np.nan,
               poly=poly.tolist(), dv1=np.linalg.norm(v1 - c), dv2=np.linalg.norm(v2 - c))
    if draw is not None:
        im = vidio.frames(base)[k].copy()
        cv2.polylines(im, [poly.astype(np.int32)], True, (0, 0, 255), 2)
        cv2.putText(im, f"{base[-6:]} f={out['f']:.0f}", (20, 60), 0, 2, (0, 0, 255), 4)
        draw.append(cv2.resize(im, (640, 360)))
    return out

if __name__ == "__main__":
    bases = sys.argv[1:]
    draws, rows = [], []
    for b in bases:
        for k in (0, 24, 48):
            try:
                r = table_f(b, k, draws if k == 0 else None)
            except Exception as e:
                r = dict(base=b, k=k, note=str(e))
            if r: rows.append(r)
    d = pd.DataFrame(rows)
    pd.set_option("display.width", 200)
    print(d[[c for c in d.columns if c != "poly"]].round(1).to_string())
    while len(draws) % 2: draws.append(np.zeros_like(draws[0]))
    for j in range(0, len(draws), 6):
        cv2.imwrite(SP + f"/frames/vp_{j//6}.jpg", np.vstack([np.hstack(draws[i:i + 2]) for i in range(j, min(j + 6, len(draws)), 2)]))
    d.to_csv(SP + "/work/vp.csv", index=False)
