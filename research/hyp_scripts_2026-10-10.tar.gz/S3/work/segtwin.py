from common import *
t = test(); v = val()
for x in (t, v):
    x["twin"] = x.video_id.str.replace("_segmented", "", regex=False).map(base_of)
    x["nq"] = x.question.map(normq)
gt = v.set_index(["twin", "nq"]).answer; gt = gt[~gt.index.duplicated()]
t["ans"] = [gt.get((a, b), np.nan) for a, b in zip(t.twin, t.nq)]
sub = v2()[["id", "parsed_value"]].rename(columns={"parsed_value": "v2"})
run = run_csv()[["id", "geo_value", "direct_value"]]
m = t.merge(sub, left_on="qid", right_on="id").merge(run, on="id")
seg = m[m.video_id.str.endswith("_segmented")]
orig = m[~m.video_id.str.endswith("_segmented") & (m.video_source != "lab")]
j = seg.merge(orig[["twin", "nq", "v2", "direct_value", "video_source", "qid"]], on=["twin", "nq"], suffixes=("", "_o"))
print("segmented questions with an original twin:", len(j), j.groupby("category").size().to_dict())
e = j[j.ans.notna()]
for c, g in e.groupby("category"):
    print(f"{c} n={len(g)} seg v2 {mra(g.v2, g.ans):.3f} | orig v2 {mra(g.v2_o, g.ans):.3f} | gmean {mra(np.sqrt(g.v2 * g.v2_o), g.ans):.3f} || direct: seg {mra(g.direct_value, g.ans):.3f} orig {mra(g.direct_value_o, g.ans):.3f}")
g = e
print(f"ALL n={len(g)} seg v2 {mra(g.v2, g.ans):.3f} | orig v2 {mra(g.v2_o, g.ans):.3f} | gmean {mra(np.sqrt(g.v2 * g.v2_o), g.ans):.3f}")
# unique val clips involved
print(e.groupby("category").twin.unique())
# test-wide: ratio seg/orig
j["lr"] = np.log(j.v2 / j.v2_o)
print(j.groupby("category").lr.agg(["size", "median", lambda x: np.mean(np.abs(x) > np.log(1.25))]))
j.to_pickle(SP + "/work/segtwin.pkl")
