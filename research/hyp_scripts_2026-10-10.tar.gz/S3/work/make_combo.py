from common import *
base = v2()
t = test().set_index("qid")
seg = pd.read_csv(SP + "/variants/S3_segtwin.csv").set_index("id").parsed_value
lab = pd.read_csv(SP + "/work/labfix_changes.csv")
b0 = base.set_index("id").parsed_value
def build(name, use_seg=True, whys=("a", "b", "c")):
    v = b0.copy()
    if use_seg:
        d = (seg - b0).abs() > 1e-12; v[d] = seg[d]
    for r in lab.itertuples():
        if r.why[0] in whys: v[r.qid] = r.new
    out = base.copy(); out["parsed_value"] = out.id.map(v)
    out.to_csv(SP + f"/variants/{name}.csv", index=False)
    ch = (out.set_index("id").parsed_value - b0).abs() > 1e-12
    ids = ch[ch].index
    cats = t.loc[ids, "category"].value_counts().to_dict()
    ratio = (out.set_index("id").parsed_value[ids] / b0[ids])
    print(f"{name}: changed {len(ids)} {cats} median ratio {ratio.median():.3f}  median |log| {np.median(np.abs(np.log(ratio))):.3f}")
    assert set(cats) <= {"S3"}
    assert out.parsed_value.notna().all() and (out.parsed_value > 0).all()
    return out
build("S3_combo", True, ("a", "b", "c"))
build("S3_combo_noc", True, ("a", "b"))
build("S3_labfix", False, ("a", "b", "c"))
build("S3_segtwin", True, ())
