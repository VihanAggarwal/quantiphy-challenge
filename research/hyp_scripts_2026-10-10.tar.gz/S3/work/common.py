import sys, os, re, json, math
os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
SP = "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3"
REPO = SP + "/base/repo"
sys.path.insert(0, REPO)
import numpy as np, pandas as pd
from qp.data import load_split
from qp.mra import item_scores

def base_of(v):
    return re.sub(r"(captured_\d+[ab]?)[sxX]?$", r"\1", v)

def normq(q):
    return re.sub(r"[^a-z0-9.]", "", str(q).lower())

_T = None
def test():
    global _T
    if _T is None:
        t = load_split("test"); t["base"] = t.video_id.map(base_of); _T = t
    return _T

def val():
    v = load_split("val"); v["base"] = v.video_id.map(base_of); return v

def gt_on_test(cats=("S3", "D3"), src="lab"):
    """test qid -> val GT for questions of val clips (all background variants), matched by question text."""
    t, v = test(), val()
    v = v[v.category.isin(cats) & (v.video_source == src)]
    out = {}
    for r in v.itertuples():
        m = t[(t.base == r.base) & (t.question.map(normq) == normq(r.question))]
        for q in m.qid:
            out[int(q)] = (float(r.answer), int(r.qid))
    return out

def v2():
    return pd.read_csv("/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv")

def run_csv(path="/home/user/quantiphy-challenge/runs/test_v1_high_854/test.csv"):
    return pd.read_csv(path)

def mra(pred, gt):
    return float(np.nanmean(item_scores(pred, gt)))

RUNS = SP + "/base/runs"

def load_records(run="test_v1_high_854", label="test", videos=None):
    import glob
    out = {}
    for p in glob.glob(f"{RUNS}/{run}/{label}/records/*.json"):
        r = json.load(open(p))
        if videos is None or r["video_id"] in videos:
            out[r["video_id"]] = r
    return out

def anns_for(df, run="test_v1_high_854", label="test", dense="motion", post=True):
    sys.path.insert(0, REPO + "/scripts")
    import run_claude as rc
    from qp import claude_annotate as ca
    recs = load_records(run, label, set(df.video_id))
    recs = rc.prepare_records(df, recs)
    anns = ca.load_annotations(recs)
    if post:
        anns = rc.post_steps(anns, df, recs, dense=dense, dense_cache=f"{RUNS}/_dense_cache/{label}")
    return anns, recs
