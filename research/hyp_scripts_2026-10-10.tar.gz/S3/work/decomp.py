"""Per-kind decomposition of the two official probe-3 deltas (S3 and D3 lab: geometry -> direct)."""
from common import *
lab = pd.read_pickle(SP + "/work/p3lab.pkl")
D = {"S3": (0.012, 578, (0.011, 0.013)), "D3": (-0.011, 969, (-0.012, -0.010))}
def solve(groups, weight):
    A, b = [], []
    for c in ("S3", "D3"):
        x = lab[(lab.category == c) & lab.chg]
        w = weight(x)
        A.append([float(w[x.grp.isin(g)].sum()) for g in groups]); b.append(D[c][0] * D[c][1])
    A = np.array(A); b = np.array(b)
    return A, np.linalg.solve(A, b)
for name, wf in [("count", lambda x: pd.Series(1.0, index=x.index)),
                 ("|log ratio| capped 0.7", lambda x: np.minimum(np.abs(x.lr), 0.7)),
                 ("disagree>5%", lambda x: (np.abs(x.lr) > 0.05).astype(float))]:
    for groups, gl in [((["size"], ["distance", "motion"]), "static=size | motion+distance"),
                       ((["size", "distance"], ["motion"]), "static=size+distance | motion")]:
        A, sol = solve(groups, wf)
        print(f"{name:24s} {gl:32s} A={A.round(1).tolist()}  per-unit direct-minus-geo: static {sol[0]:+.3f}  motion {sol[1]:+.3f}")
# sensitivity to the rounding of the official numbers
A, _ = solve((["size", "distance"], ["motion"]), lambda x: pd.Series(1.0, index=x.index))
for ds in D["S3"][2]:
    for dd in D["D3"][2]:
        s = np.linalg.solve(A, np.array([ds * 578, dd * 969]))
        print(f"  S3 {ds:+.3f} D3 {dd:+.3f}: static {s[0]:+.3f} motion {s[1]:+.3f} -> split gain S3 {-s[0] * A[0, 0] / 578:+.4f}")
