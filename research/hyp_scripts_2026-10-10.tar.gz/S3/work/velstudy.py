from common import *
F = 722.0; C = np.array([640.0, 360.0])
def load(base, name):
    d = pd.read_csv(SP + f"/work/mtracks/{base}__{name.replace(' ', '_')}.csv")
    return d[d.good].sort_values("t")
def locfit(t, Y, t0, half):
    sel = np.abs(t - t0) <= half + 1e-9
    if sel.sum() < 4: return None
    c = np.polyfit(t[sel] - t0, Y[sel], 2)
    return c[-1], c[-2], 2 * c[0]
def depth_interp(entries):
    ts = np.array([e[0] for e in entries]); ds = np.array([e[1] for e in entries])
    if len(ts) == 1: return lambda t: np.full(np.shape(t), ds[0])
    o = np.argsort(ts); ts, ds = ts[o], ds[o]
    s0 = (ds[1] - ds[0]) / (ts[1] - ts[0]); s1 = (ds[-1] - ds[-2]) / (ts[-1] - ts[-2])
    def fn(t):
        t = np.asarray(t, float); out = np.interp(t, ts, ds)
        out = np.where(t < ts[0], ds[0] + s0 * (t - ts[0]), out); return np.where(t > ts[-1], ds[-1] + s1 * (t - ts[-1]), out)
    return fn
def pos3d(u, v, Z):
    ray = np.c_[(u - C[0]) / F, (v - C[1]) / F, np.ones(len(u))]
    return ray * (Z / np.linalg.norm(ray, axis=1))[:, None]
cases = [  # base, obj, depth entries [(t, Z)], [(qtime, kind, GT)]
    ("captured_0021", "ping pong ball", [(1.0, 1.511), (1.4, 1.03)], [(1.2, "v", 117.73), (1.4, "v", 87.9)]),
    ("captured_0027", "red ball", [(0.2, 1.0995), (0.6, 1.151)], [(0.2, "v", 201.73), (0.6, "v", 66.68), (0.2, "a", 1086.09)]),
    ("captured_0034a", "left tennis ball", [(1.2, 0.706)], [(1.2, "v", 82.93), (1.3, "v", 84.54)]),
    ("captured_0034a", "right tennis ball", [(1.2, 0.776)], [(1.2, "v", 99.47), (1.3, "v", 92.33)]),
    ("captured_0061", "basketball", [(1.1, 2.42), (1.6, 1.9015)], [(1.1, "v", 932), (1.6, "v", 84.05)]),
]
for base, name, ent, qs in cases:
    d = load(base, name)
    t = d.t.to_numpy(); u = d.cx.to_numpy(); v = d.cy.to_numpy(); dd = d.d.to_numpy()
    Zi = depth_interp(ent)(t)
    # looming: anchor at first entry time
    ta, Za = ent[0]
    lfit = locfit(t, np.log(dd), ta, 0.25)
    da = np.exp(lfit[0]) if lfit else np.interp(ta, t, dd)
    # smooth log d
    lds = np.array([locfit(t, np.log(dd), x, 0.25)[0] if locfit(t, np.log(dd), x, 0.25) else np.log(y) for x, y in zip(t, dd)])
    Zl = Za * da / np.exp(lds)
    for qt, kind, gt in qs:
        out = []
        for lbl, Z in (("lat(Zi const@t)", np.full(len(t), depth_interp(ent)(qt))), ("depthinfo", Zi), ("loom", Zl)):
            P = pos3d(u, v, Z)
            for half in (0.13, 0.26):
                f = locfit(t, P, qt, half)
                if f is None: out.append(f"{lbl}/{half}: -"); continue
                val = np.linalg.norm(f[1] if kind == "v" else f[2]) * 100
                out.append(f"{lbl}/{half}: {val:.0f}")
        print(f"{base[-5:]} {name:18s} {kind}@{qt}: GT {gt:.0f} | " + " | ".join(out))

print("--- anchored looming (Z = a/d + b through the depth anchors; 1 anchor: Z = Za*da/d)")
def anchored(t, dd, ents):
    lds = np.array([(locfit(t, np.log(dd), x, 0.25) or [np.log(y)])[0] for x, y in zip(t, dd)])
    ds = np.exp(lds)
    inv = 1 / ds
    at = np.array([e[0] for e in ents]); az = np.array([e[1] for e in ents])
    ia = np.interp(at, t, inv)
    if len(ents) == 1:
        return az[0] * inv / ia[0]
    A = np.c_[ia, np.ones(len(ia))]
    (a, b), *_ = np.linalg.lstsq(A, az, rcond=None)
    return a * inv + b
for base, name, ent, qs in cases:
    d = load(base, name)
    t = d.t.to_numpy(); u = d.cx.to_numpy(); v = d.cy.to_numpy(); dd = d.d.to_numpy()
    Z = anchored(t, dd, ent)
    P = pos3d(u, v, Z)
    out = []
    for qt, kind, gt in qs:
        for half in (0.13, 0.26):
            f = locfit(t, P, qt, half)
            val = np.linalg.norm(f[1] if kind == "v" else f[2]) * 100 if f else np.nan
            out.append(f"{kind}@{qt}/{half}: {val:.0f} (GT {gt:.0f})")
    print(base[-5:], name, " | ".join(out))
