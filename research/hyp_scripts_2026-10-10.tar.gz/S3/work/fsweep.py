"""Val-on-test (val GT on all background variants of the val lab clips): MRA of the geometry answer (and the
v2 selection) for the lab camera prior at several FOVs, a fixed f (CAM_SIG tiny), and the prior alone (solo)."""
from common import *
import qp.geometry as G
from qp.geometry import solve
from qp import combine
g = gt_on_test()
t = test()
df = t[t.qid.isin(g)]
anns, recs = anns_for(df)
run = run_csv().set_index("id")
res = {}
def evaluate(label, **kw):
    out = []
    for r in df.itertuples():
        a = anns.get(r.qid); m = recs[r.video_id]["meta"]
        A = solve(a.spec, a.tracks, tuple(m["image_size"]), float(m["fps"]), seen_scale=float(m.get("scale") or 1), **kw)
        flags = [f for f in str(run.loc[r.qid, "flags"]).split(";") if not f.startswith("geo:")] + [f"geo:{f}" for f in A.flags]
        v, how, _ = combine.choose(A.value, run.loc[r.qid, "direct_value"], flags, True, "lab", A.method)
        out.append((r.qid, r.category, A.value if A.value else np.nan, v, g[r.qid][0], a.spec.target.kind))
    d = pd.DataFrame(out, columns=["qid", "cat", "geo", "sel", "ans", "kind"])
    res[label] = d
    s = []
    for c in ("S3", "D3"):
        x = d[d.cat == c]; xs = x[x.kind == "size"]
        s.append(f"{c}: geo {mra(x.geo.fillna(0), x.ans):.3f} sel {mra(x.sel, x.ans):.3f} | sizes n={len(xs)} geo {mra(xs.geo.fillna(0), xs.ans):.3f}")
    print(f"{label:14s}", " || ".join(s))
for fov in (76, 80, 82, 84, 86, 90):
    evaluate(f"map{fov}", camera_fov_deg=float(fov))
G.CAM_SIG_LOG_F = 1e-4
for fov in (78, 80, 82, 83, 84, 86):
    evaluate(f"fixed{fov}", camera_fov_deg=float(fov))
G.CAM_SIG_LOG_F = 0.05
evaluate("solo")
G.CAM_SIG_LOG_F = 0.10
evaluate("map84_sig.10", camera_fov_deg=84.0)
G.CAM_SIG_LOG_F = 0.20
evaluate("map84_sig.20", camera_fov_deg=84.0)
pd.to_pickle(res, SP + "/work/fsweep.pkl")
