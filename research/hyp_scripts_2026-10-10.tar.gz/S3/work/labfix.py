"""Lab S3 consistency fixes (all from the question inputs, no GT):
 (a) decimal slip: a depth_info distance > 20x the median of the clip's other entries is read with its
     decimal point restored (8420 m -> 0.8420 m; lab scenes are within a few metres) and the geometry re-solved;
 (b) depth_info for another camera: the prior measured through the rig's camera (f at 84 deg) is off its stated
     value by > 1.75x (implied FOV impossible for the rig): the clip's depth_info does not describe this view ->
     the answer of the same question (same prior, depth_info and question text) on a clip where they agree
     (the same event filmed by the rig camera), else Claude's direct estimate;
 (c) background-replaced renders (s/x) of a lab clip: a direct-routed MOTION answer (speed, acceleration,
     displacement, path) takes the original render's answer: judging motion needs the static background
     (val-on-test motion: own .383 vs original-render .600 S3, .50 vs 1.00 D3; sizes no evidence either way)."""
from common import *
from qp.geometry import solve
from qp import combine
from qp.spec import DepthEntry
import copy, pickle
specs = pickle.load(open(SP + '/work/specs.pkl', 'rb'))
t = test()
sub = v2(); val_of = dict(zip(sub.id, sub.parsed_value))
run = run_csv().set_index("id")
rep = pd.read_csv(SP + "/work/repro.csv").set_index("qid")
lab = t[(t.video_source == "lab") & (t.category == "S3")].copy()
lab["base"] = lab.video_id.map(base_of); lab["nq"] = lab.question.map(normq)
new = {}; why = {}
# (a)
anns, recs = anns_for(lab[lab.video_id.str.startswith("captured_0040")])
for q, a in anns.items():
    ds = [e.distance_m for e in a.spec.depth]
    fixed = []
    for e in a.spec.depth:
        others = np.median([x for x in ds if x is not e.distance_m] or [e.distance_m])
        d = e.distance_m
        if d > 20 * others:
            p = round(math.log10(d / others)); d = d / 10 ** p
        fixed.append(DepthEntry(object=e.object, distance_m=d, time=e.time))
    if [e.distance_m for e in fixed] == ds: continue
    sp = copy.deepcopy(a.spec); sp.depth = fixed
    vid = t.set_index("qid").loc[q, "video_id"]; m = recs[vid]["meta"]
    A = solve(sp, a.tracks, tuple(m["image_size"]), float(m["fps"]), camera_fov_deg=84.0, seen_scale=float(m["scale"]))
    flags = [f for f in str(run.loc[q, "flags"]).split(";") if not f.startswith("geo:") and f != "geo_rejected_implausible"] + [f"geo:{f}" for f in A.flags]
    v, how, _ = combine.choose(A.value, run.loc[q, "direct_value"], flags, True, "lab", A.method)
    if not np.isclose(v, val_of[q]):
        new[q] = v; why[q] = f"a_decimal({how})"
# (b)
rep["ratio"] = rep.prior_meas / rep.pval
clip_ratio = rep[rep.cat == "S3"].groupby("vid").ratio.median()
bad = set(clip_ratio[(clip_ratio < 1 / 1.75) | (clip_ratio > 1.75)].index)
print("clips with depth_info inconsistent with the view:", sorted(bad))
key = lambda r: (r.prior, r.depth_info, r.nq)
good_rows = lab[~lab.video_id.isin(bad)]
for r in lab[lab.video_id.isin(bad)].itertuples():
    sib = good_rows[(good_rows.prior == r.prior) & (good_rows.depth_info == r.depth_info) & (good_rows.nq == r.nq)]
    if len(sib):
        v = float(np.exp(np.median(np.log([val_of[q] for q in sib.qid])))); w = "b_sibling"
    else:
        v = float(run.loc[r.qid, "direct_value"]); w = "b_direct"
    if np.isfinite(v) and v > 0 and not np.isclose(v, val_of[r.qid]):
        new[r.qid] = v; why[r.qid] = w
# (c)
basemap = lab[lab.video_id == lab.base].set_index(["base", "nq"]).qid
basemap = basemap[~basemap.index.duplicated()]
for r in lab[(lab.video_id != lab.base) & ~lab.video_id.isin(bad)].itertuples():
    if run.loc[r.qid, "method"] != "direct" or r.qid in new: continue
    if specs[r.qid].target.kind not in ("speed", "acceleration", "displacement", "path_length"): continue
    qb = basemap.get((r.base, r.nq))
    if qb is None: continue
    v = new.get(int(qb), val_of[int(qb)])
    if np.isfinite(v) and v > 0 and not np.isclose(v, val_of[r.qid]):
        new[r.qid] = v; why[r.qid] = "c_original_render"
out = sub.copy(); out["parsed_value"] = [new.get(i, v) for i, v in zip(out.id, out.parsed_value)]
c = pd.DataFrame([(q, val_of[q], v, why[q]) for q, v in new.items()], columns=["qid", "old", "new", "why"])
c["ratio"] = c.new / c.old
print(c.groupby("why").agg(n=("qid", "size"), med_ratio=("ratio", "median")))
print("total changed", len(c), "median ratio", c.ratio.median())
c.to_csv(SP + "/work/labfix_changes.csv", index=False)
out.to_csv(SP + "/variants/S3_labfix.csv", index=False)
cat = t.set_index("qid").category
diff = sub.set_index("id").parsed_value.sub(out.set_index("id").parsed_value).abs() > 1e-12
print("categories changed:", cat[diff[diff].index].value_counts().to_dict())
print(c.sort_values("qid").to_string())
