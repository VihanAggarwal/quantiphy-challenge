import cv2, numpy as np, functools
VD = "/home/user/quantiphy-challenge/data/QuantiPhy/"

@functools.lru_cache(maxsize=12)
def frames(vid):
    c = cv2.VideoCapture(VD + vid + ".mp4"); out = []
    while True:
        ok, f = c.read()
        if not ok: break
        out.append(f)
    return out

def variants(base):
    import os
    vs = [v for v in (base, base + "s", base + "x", base + "X") if os.path.exists(VD + v + ".mp4")]
    return vs

def fgmask(base, k, thr=40):
    """foreground (object) mask of frame k: where the blue- and black-background renders agree."""
    s = frames(base + "s")[k].astype(np.int16)
    xv = base + "x" if base + "x" in variants(base) else base + "X"
    x = frames(xv)[k].astype(np.int16)
    d = np.abs(x - s).max(axis=2)
    return (d < thr).astype(np.uint8)

def circle_ls(P):
    A = np.c_[2 * P, np.ones(len(P))]; b = (P ** 2).sum(1)
    sol, *_ = np.linalg.lstsq(A, b, rcond=None)
    c = sol[:2]; r = np.sqrt(max(sol[2] + c @ c, 0))
    return c, r

def fit_ball(mask, c0, r_exp, rng=np.random.default_rng(0), win=2.2, rlim=(0.55, 1.6), tol=1.5, iters=3000):
    """RANSAC circle on the fg/bg boundary near c0 -> (centre, radius, inlier share of the circumference)."""
    H, W = mask.shape
    h = int(win * r_exp) + 4
    x0, y0 = max(0, int(c0[0]) - h), max(0, int(c0[1]) - h)
    x1, y1 = min(W, int(c0[0]) + h), min(H, int(c0[1]) + h)
    m = mask[y0:y1, x0:x1]
    if m.size == 0: return None
    er = cv2.erode(m, np.ones((3, 3), np.uint8))
    by, bx = np.nonzero(m - er)  # inner boundary pixels of fg
    if len(bx) < 10: return None
    P = np.c_[bx + x0 + 0.5, by + y0 + 0.5].astype(float)
    best = (0, None)
    for _ in range(iters):
        idx = rng.choice(len(P), 3, replace=False)
        try:
            c, r = circle_ls(P[idx])
        except Exception:
            continue
        if not (rlim[0] * r_exp <= r <= rlim[1] * r_exp): continue
        if np.hypot(*(c - c0)) > 1.2 * r_exp: continue
        d = np.abs(np.hypot(*(P - c).T) - r)
        n = int((d < tol).sum())
        if n > best[0]: best = (n, (c, r))
    if best[1] is None: return None
    c, r = best[1]
    for _ in range(3):
        d = np.abs(np.hypot(*(P - c).T) - r); inl = P[d < tol]
        if len(inl) < 6: break
        c, r = circle_ls(inl)
    d = np.abs(np.hypot(*(P - c).T) - r)
    cover = (d < tol).sum() / (2 * np.pi * r)
    return c, r, float(cover)
