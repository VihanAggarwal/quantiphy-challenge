from common import *
import cv2, vidio, sys
d = pd.read_csv(SP + "/work/calib_balls.csv")
tiles = []
for r in d.itertuples():
    if not np.isfinite(r.dpx if r.dpx == r.dpx else np.nan): continue
    k = min(r.k, len(vidio.frames(r.base + "s")) - 1)
    im = vidio.frames(r.base)[k].copy()
    m = vidio.fgmask(r.base, k)
    h = int(max(r.dpx * 1.3, 30))
    x0, y0 = int(r.cx) - h, int(r.cy) - h
    crop = im[max(0, y0):y0 + 2 * h, max(0, x0):x0 + 2 * h].copy()
    mc = m[max(0, y0):y0 + 2 * h, max(0, x0):x0 + 2 * h] * 255
    S = 8 if h < 30 else 4 if h < 60 else 2
    crop = cv2.resize(crop, None, fx=S, fy=S, interpolation=cv2.INTER_NEAREST)
    mc = cv2.cvtColor(cv2.resize(mc, None, fx=S, fy=S, interpolation=cv2.INTER_NEAREST), cv2.COLOR_GRAY2BGR)
    for c in (crop, mc):
        cv2.circle(c, (int((r.cx - max(0, x0)) * S), int((r.cy - max(0, y0)) * S)), int(r.dpx / 2 * S), (0, 0, 255), 1)
    tile = np.hstack([crop, mc]); tile = cv2.resize(tile, (480, 240))
    cv2.putText(tile, f"{r.base[-5:]} t={r.t} d={r.dpx:.1f} f={r.f_c:.0f}", (5, 20), 0, 0.6, (0, 255, 0), 2)
    tiles.append(tile)
while len(tiles) % 3: tiles.append(np.zeros_like(tiles[0]))
rows = [np.hstack(tiles[i:i + 3]) for i in range(0, len(tiles), 3)]
for j in range(0, len(rows), 4):
    cv2.imwrite(SP + f"/frames/fits_{j//4}.jpg", np.vstack(rows[j:j + 4]))
print(len(tiles))
