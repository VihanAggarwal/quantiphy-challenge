"""Dense ball tracks for the lab clips from the SAM foreground masks (blue vs black background renders, which
share every foreground pixel): per frame a RANSAC circle on the mask boundary, seeded by the annotator's
track of that ball and tracked frame to frame. Output per frame: centre, diameter, quality."""
from common import *
import cv2, vidio
from qp.geometry import _tokens

F_LAB = 711.0

def seeds(obs, base, name):
    """pooled annotator centres (t, u, v) and box sizes for the object `name` over all renders of `base`."""
    key = " ".join(_tokens(name))
    o = obs[(obs.base == base) & (obs.obj.map(lambda n: " ".join(_tokens(n))) == key)]
    T, U, S = [], [], []
    for r in o.itertuples():
        if r.point is not None: c = r.point
        elif r.box is not None: c = ((r.box[0] + r.box[2]) / 2, (r.box[1] + r.box[3]) / 2)
        else: continue
        T.append(round(r.t * 24) / 24); U.append(c)
        if r.box is not None: S.append(max(r.box[2] - r.box[0], r.box[3] - r.box[1]))
    if not T: return None
    d = pd.DataFrame({"t": T, "u": [c[0] for c in U], "v": [c[1] for c in U]})
    g = d.groupby("t").median().reset_index()
    return g, (float(np.median(S)) if S else None)

def track(base, seed, r0, fps=24.0):
    n = len(vidio.frames(base + "s"))
    T = seed.t.to_numpy(); Uu = seed.u.to_numpy(); Vv = seed.v.to_numpy()
    out = []
    prev = None  # (k, c, r, vel)
    for k in range(n):
        t = k / fps
        if t < T[0] - 0.25 or t > T[-1] + 0.25:
            continue
        g = np.array([np.interp(t, T, Uu), np.interp(t, T, Vv)])
        cands = [g]
        r_ref = r0
        if prev is not None and k - prev[0] <= 3:
            p = prev[1] + prev[3] * (k - prev[0])
            cands = [p, g]; r_ref = prev[2]
        mask = vidio.fgmask(base, k)
        best = None
        for c0 in cands:
            fit = vidio.fit_ball(mask, c0, r_ref, win=2.6, rlim=(0.75, 1.33), tol=1.5, iters=1200)
            if fit is None: continue
            c, r, cover = fit
            H, W = mask.shape
            y0, y1, x0, x1 = int(max(0, c[1] - r)), int(min(H, c[1] + r + 1)), int(max(0, c[0] - r)), int(min(W, c[0] + r + 1))
            yy, xx = np.mgrid[y0:y1, x0:x1]
            disc = (xx - c[0]) ** 2 + (yy - c[1]) ** 2 <= (0.9 * r) ** 2
            fill = float(mask[y0:y1, x0:x1][disc].mean()) if disc.any() else 0.0
            dist = float(np.hypot(*(c - g)))
            score = cover * fill
            if best is None or score > best[-1]:
                best = (c, r, cover, fill, dist, score)
        if best is None:
            continue
        c, r, cover, fill, dist, score = best
        good = cover >= 0.35 and fill >= 0.85 and dist <= max(3 * r, 60)
        out.append(dict(k=k, t=t, cx=c[0], cy=c[1], d=2 * r + 1, cover=cover, fill=fill, dist=dist, good=good))
        if good:
            vel = np.zeros(2) if prev is None else (c - prev[1]) / max(k - prev[0], 1)
            prev = (k, c, r, vel)
    return pd.DataFrame(out)

if __name__ == "__main__":
    obs = pd.read_pickle(SP + "/work/obs.pkl")
    base, name = sys.argv[1], sys.argv[2]
    sd, bs = seeds(obs, base, name)
    r0 = (bs / 2) if bs else float(sys.argv[3])
    d = track(base, sd, r0)
    pd.set_option("display.width", 200); pd.set_option("display.max_rows", 200)
    print("seed span", sd.t.min(), sd.t.max(), "r0", r0)
    print(d.round(2).to_string())
