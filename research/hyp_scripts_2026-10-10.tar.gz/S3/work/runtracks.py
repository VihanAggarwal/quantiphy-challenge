"""Dense mask ball tracks for chosen (base, object) pairs -> SP/work/mtracks/<base>__<obj>.csv"""
from common import *
import masktrack, os
os.makedirs(SP + "/work/mtracks", exist_ok=True)
obs = pd.read_pickle(SP + "/work/obs.pkl")
pairs = [a.split("::") for a in sys.argv[1:]]
for base, name in pairs:
    s = masktrack.seeds(obs, base, name)
    if s is None: print(base, name, "no seeds"); continue
    sd, bs = s
    r0 = bs / 2 if bs else 20
    d = masktrack.track(base, sd, r0)
    d.to_csv(SP + f"/work/mtracks/{base}__{name.replace(' ', '_')}.csv", index=False)
    print(base, name, "frames", len(d), "good", int(d.good.sum()) if len(d) else 0)
