from common import *
rep = pd.read_csv(SP + "/work/repro.csv")
t = test()
labv = t[t.video_source == "lab"].groupby("video_id").agg(cats=("category", lambda s: ",".join(sorted(set(s)))), prior=("prior", "first")).reset_index()
W = 1280.0
fov = lambda f: np.degrees(2 * np.arctan(W / 2 / f))
# per video: solo f from the prior with Claude's extents (S3 size priors) / motion priors (D3, flagged)
rows = []
calib = pd.read_csv(SP + "/work/calib_balls.csv")
calib = calib[(calib.note.fillna("") == "") & (calib.cover > 0.5)]
gtc = pd.read_csv(SP + "/work/gtcal.csv")
g = gt_on_test()
for r in labv.itertuples():
    x = rep[rep.vid == r.video_id]
    base = base_of(r.video_id)
    solo = x[x.m_solo.isin(["3d_focal_from_prior", "3d_focal_assumed_depth"])]
    f_solo = float(solo.f_solo.median()) if len(solo) else np.nan
    sens = float(x.sens.median()) if len(x) else np.nan
    cb = calib[calib.base == base]
    f_mask = float(cb.f_c.median()) if len(cb) else np.nan
    # GT-implied (val clips, measurement only): f_map * geo / GT over size targets with own depth
    xs = x[(x.kind == "size") & x.qid.isin(g)].copy()
    if len(xs):
        xs["ans"] = xs.qid.map(lambda q: g[q][0])
        xs = xs[~xs["flags"].fillna("").str.contains("target_depth_from_prior|endpoint")]
        fg = xs.f_map * xs.geo / xs.ans
        fg = fg[(fg > 400) & (fg < 1200)]
        f_gt = float(fg.median()) if len(fg) else np.nan
    else:
        f_gt = np.nan
    rows.append(dict(video_id=r.video_id, base=base, category=r.cats, width=1280, height=720, prior=r.prior,
                     f_px_prior_claude=round(f_solo, 1), prior_f_sensitivity=round(sens, 2), n_q=len(x),
                     f_px_prior_mask=round(f_mask, 1), n_mask=len(cb), f_px_gt_val=round(f_gt, 1),
                     f_px_used_v2=round(float(x.f_map.median()), 1) if len(x) else np.nan,
                     f_px_recommended=722.0, f_over_width_recommended=round(722.0 / 1280, 4), fov_deg_recommended=round(fov(722.0), 2)))
d = pd.DataFrame(rows)
d["note"] = ""
d.loc[d.base.isin(["captured_0034b"]), "note"] = "depth_info belongs to the 0034a camera (same event, second view): prior implies FOV ~127 deg"
d.loc[d.base.isin(["captured_0040"]), "note"] = "depth_info white cup 8420 m = decimal slip (0.8420 m)"
d.loc[d.category.str.contains("D3") & d.f_px_prior_claude.notna(), "note"] += "; D3 motion prior: f weakly determined (see sensitivity)"
d.to_csv(SP + "/lab_focal.csv", index=False)
s3 = d[d.category == "S3"]
print(d.head(3).to_string())
print("S3 clips: median f prior(claude) %.0f, prior(mask) %.0f (n=%d clips), GT-implied val %.0f" % (
    s3.f_px_prior_claude.median(), d.drop_duplicates("base").f_px_prior_mask.median(), d.drop_duplicates("base").f_px_prior_mask.notna().sum(), d.f_px_gt_val.median()))
print(d[d.f_px_gt_val.notna()][["video_id", "f_px_gt_val", "f_px_prior_claude", "f_px_used_v2"]])
