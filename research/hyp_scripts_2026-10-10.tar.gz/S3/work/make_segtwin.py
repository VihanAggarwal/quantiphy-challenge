"""Variant: S3 questions of a segmented (background-removed) simulation clip take the answer of the same
question on the original clip (same scene, same geometry, more visual cues)."""
from common import *
sub = v2()
t = test()
t["twin"] = t.video_id.str.replace("_segmented", "", regex=False)
t["nq"] = t.question.map(normq)
val_of = dict(zip(sub.id, sub.parsed_value))
orig = t[~t.video_id.str.endswith("_segmented")].set_index(["twin", "nq"]).qid
orig = orig[~orig.index.duplicated()]
new = dict(val_of)
changed = []
for r in t[(t.category == "S3") & t.video_id.str.endswith("_segmented")].itertuples():
    q = orig.get((r.twin, r.nq))
    if q is None: continue
    tc = t.set_index("qid").loc[int(q)]
    if tc.category != "S3" or tc.prior != r.prior: continue
    nv = val_of[int(q)]
    if np.isfinite(nv) and nv > 0 and not np.isclose(nv, val_of[r.qid]):
        changed.append((r.qid, val_of[r.qid], nv)); new[r.qid] = nv
out = sub.copy(); out["parsed_value"] = out.id.map(new)
out.to_csv(SP + "/variants/S3_segtwin.csv", index=False)
c = pd.DataFrame(changed, columns=["qid", "old", "new"])
print("changed", len(c), "median ratio new/old", float(np.median(c.new / c.old)), "median |log ratio|", float(np.median(np.abs(np.log(c.new / c.old)))))
# sanity: only S3 changed
cat = t.set_index("qid").category
diff = sub.set_index("id").parsed_value.sub(out.set_index("id").parsed_value).abs() > 1e-12
print("categories changed:", cat[diff[diff].index].value_counts().to_dict())
