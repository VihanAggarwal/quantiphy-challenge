from common import *
t = test(); v = val()
for x in (t, v):
    x["twin"] = x.video_id.str.replace("_segmented", "", regex=False).map(base_of); x["nq"] = x.question.map(normq)
gt = v.set_index(["twin", "nq"]).answer; gt = gt[~gt.index.duplicated()]
t["ans"] = [gt.get((a, b), np.nan) for a, b in zip(t.twin, t.nq)]
# 0034b: same event as 0034a (val clip 0034as) -> its GT (assumption, reported separately)
v34 = v[v.video_id == "captured_0034as"].set_index("nq").answer
t["ans34b"] = [v34.get(n, np.nan) if vid.startswith("captured_0034b") else np.nan for vid, n in zip(t.video_id, t.nq)]
e = t[(t.category == "S3")]
names = ["v2", "S3_segtwin", "S3_labfix", "S3_combo_noc", "S3_combo", "S3_combo_cons"]
for nm in names:
    p = (v2() if nm == "v2" else pd.read_csv(SP + f"/variants/{nm}.csv")).set_index("id").parsed_value
    x = e[e.ans.notna()]; y = e[e.ans34b.notna()]
    lab = x[x.video_source == "lab"]; nl = x[x.video_source != "lab"]
    print(f"{nm:15s} val-on-test S3 n={len(x)} {mra(p[x.qid], x.ans):.3f} | lab n={len(lab)} {mra(p[lab.qid], lab.ans):.3f} | nonlab n={len(nl)} {mra(p[nl.qid], nl.ans):.3f} || 0034b (GT:=0034a) n={len(y)} {mra(p[y.qid], y.ans34b):.3f}")
