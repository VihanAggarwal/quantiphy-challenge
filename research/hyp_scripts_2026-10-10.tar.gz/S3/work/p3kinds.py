from common import *
import pickle
t = test()
run = run_csv().set_index("id")
p3 = pd.read_csv("/home/user/quantiphy-challenge/submissions/trackA_probe3_s2maxext_d2denseoff_labdirect.csv").set_index("id").parsed_value
pv = v2().set_index("id").parsed_value
lab = t[(t.video_source == "lab") & t.category.isin(["S3", "D3"])].copy()
# kinds: need specs for D3 too
from common import anns_for
specs = pickle.load(open(SP + "/work/specs.pkl", "rb"))
lab["kind"] = lab.qid.map(lambda q: specs[q].target.kind if q in specs else "?")
lab["v2"] = lab.qid.map(pv); lab["p3"] = lab.qid.map(p3)
lab["geo"] = lab.qid.map(run.geo_value); lab["dir"] = lab.qid.map(run.direct_value)
lab["chg"] = ~np.isclose(lab.v2, lab.p3)
lab["lr"] = np.log(lab.v2 / lab.p3)
lab["grp"] = lab.kind.map(lambda k: "size" if k in ("size", "other") else "distance" if k == "distance" else "motion")
pd.to_pickle(lab, SP + "/work/p3lab.pkl")
for c in ("S3", "D3"):
    x = lab[(lab.category == c) & lab.chg]
    print(c, "changed", len(x))
    print(x.groupby("kind").agg(n=("qid", "size"), med_lr=("lr", "median"), mean_abs=("lr", lambda s: np.mean(np.abs(s))), big=("lr", lambda s: int((np.abs(s) > np.log(1.25)).sum()))).round(3))
