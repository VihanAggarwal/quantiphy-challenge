from common import *
import cv2, vidio
obs = pd.read_pickle(SP + "/work/obs.pkl")
# (base, obj-name regex for Claude loc, frame, range, true diameter)  -- val GT sizes (measurement only)
items = [("captured_0034a", "soccer", 0, 0.894, 0.175), ("captured_0034a", "soccer", 12, 0.894, 0.175),
         ("captured_0034a", "soccer", 29, 0.894, 0.175), ("captured_0034a", "soccer", 48, 0.894, 0.175),
         ("captured_0061", "yoga", 14, 2.133, 0.522), ("captured_0061", "soccer", 14, 1.937, 0.175),
         ("captured_0061", "soccer", 22, 1.585, 0.175), ("captured_0041", "soccer", 36, 2.544, 0.175),
         ("captured_0041", "soccer", 38, 2.074, 0.175)]
rows = []
for base, pat, k, Z, D in items:
    o = obs[(obs.base == base) & obs.obj.str.contains(pat) & ((obs.t * 24 - k).abs() <= 2.5)]
    cs = [((b[0] + b[2]) / 2, (b[1] + b[3]) / 2) for b in o.box if b is not None] or [tuple(p) for p in o.point if p is not None]
    if not cs:
        o = obs[(obs.base == base) & obs.obj.str.contains(pat)]
        cs = [((b[0] + b[2]) / 2, (b[1] + b[3]) / 2) for b in o.box if b is not None]
    c0 = np.median(np.array(cs), axis=0)
    fit = vidio.fit_ball(vidio.fgmask(base, k), c0, 740 * D / 2 / Z)
    if fit is None: print(base, k, "nofit"); continue
    c, r, cov = fit; d = 2 * r + 1
    rows.append(dict(base=base, obj=pat, k=k, Z=Z, D=D, cx=c[0], cy=c[1], dpx=d, cover=cov, f_gt_c=d * Z / D, f_gt_s=d * (Z + D / 2) / D))
d = pd.DataFrame(rows); print(d.round(2).to_string())
d.to_csv(SP + "/work/gtcal.csv", index=False)
