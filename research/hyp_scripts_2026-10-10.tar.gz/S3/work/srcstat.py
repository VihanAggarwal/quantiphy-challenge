from common import *
t = test()
lab = t[(t.video_source == "lab") & (t.category == "S3")]
anns, recs = anns_for(lab)
rows = []
for q, a in anns.items():
    k = a.spec.target.kind
    if k not in ("speed", "acceleration", "displacement", "path_length"): continue
    tr = [x for x in a.tracks if x.role == "target"]
    src = tr[0].source if tr else "none"; n = len(tr[0].obs) if tr else 0
    rows.append((q, k, src, n))
d = pd.DataFrame(rows, columns=["qid", "kind", "src", "nobs"])
print(d.groupby(["kind", "src"]).agg(n=("qid", "size"), med_obs=("nobs", "median")))
