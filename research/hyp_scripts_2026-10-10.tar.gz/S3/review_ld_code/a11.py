import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
lab = pd.read_pickle(SP + "/work/p3lab.pkl")
print(pd.crosstab([lab.category, lab.kind], lab.chg))
def solve(lab, statkinds):
    A=[];b=[]
    for c,(dlt,n) in {"S3":(0.012,578),"D3":(-0.011,969)}.items():
        x = lab[(lab.category==c)&lab.chg]
        s = x.kind.isin(statkinds).sum(); m = len(x)-s
        A.append([s,m]); b.append(dlt*n)
    A=np.array(A,float); sol=np.linalg.solve(A,np.array(b))
    return A, sol
for sk in [["size","other","distance"], ["size","other","distance","camera_distance"], ["size","other"], ["size","other","distance","camera_distance","displacement"]]:
    A, s = solve(lab, sk); print(sk, A.tolist(), s.round(3), "split gain S3 (76 reverted):", round(-s[0]*76/578,4))
# alternative: category-specific uniform effects
for c,(dlt,n) in {"S3":(0.012,578),"D3":(-0.011,969)}.items():
    x = lab[(lab.category==c)&lab.chg]; print(c, "uniform per-answer effect", round(dlt*n/len(x),3))
