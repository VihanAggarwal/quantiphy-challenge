import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
import pickle, re
pd.set_option("display.width", 250); pd.set_option("display.max_colwidth", 140); pd.set_option("display.max_rows", 1000)
t = test()
specs = pickle.load(open(SP + "/work/specs.pkl", "rb"))
lab = t[(t.video_source=="lab") & t.category.isin(["S3","D3"])].copy()
lab["kind"] = lab.qid.map(lambda q: specs[q].target.kind)
lab["dim"] = lab.qid.map(lambda q: specs[q].target.dimension)
lab["pkind"] = lab.qid.map(lambda q: specs[q].prior.kind)
print(pd.crosstab(lab.kind, lab.category))
# generic question template: replace numbers
lab["tmpl"] = lab.question.str.replace(r"\d+(\.\d+)?", "#", regex=True)
for k, g in lab.groupby("kind"):
    print("=====", k, len(g))
    print(g.groupby(["category","tmpl"]).size().sort_values(ascending=False).head(60).to_string())
lab.to_pickle("lab_kinds.pkl")
