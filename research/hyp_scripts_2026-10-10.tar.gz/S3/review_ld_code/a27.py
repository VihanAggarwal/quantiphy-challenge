import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
from qp.geometry import solve
from qp.spec import DepthEntry
import copy
t = test(); run = run_csv().set_index("id")
lf = pd.read_csv(SP + "/work/labfix_changes.csv").set_index("qid")
x = t[t.video_id.str.startswith("captured_0040") & (t.category=="S3")]
anns, recs = anns_for(x)
for q in x.qid:
    a = anns[q]; vid = t.set_index("qid").loc[q,"video_id"]; m = recs[vid]["meta"]
    sp = copy.deepcopy(a.spec)
    ch = [e.distance_m for e in sp.depth if e.distance_m > 100]
    sp.depth = [DepthEntry(object=e.object, distance_m=(0.842 if e.distance_m > 100 else e.distance_m), time=e.time) for e in sp.depth]
    A = solve(sp, a.tracks, tuple(m["image_size"]), float(m["fps"]), camera_fov_deg=84.0, seen_scale=float(m.get("scale") or 1.0))
    print(q, vid, sp.target.kind, sp.target.objects, "bad entries", ch, f"fixed geo {A.value:.3f} run geo {run.loc[q,'geo_value']:.3f} dec {lf.new.get(q, np.nan):.3f} dt={A.debug.get('depth_target')}")
