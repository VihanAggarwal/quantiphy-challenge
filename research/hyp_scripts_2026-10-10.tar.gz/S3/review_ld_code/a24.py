import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
pd.set_option("display.width", 260); pd.set_option("display.max_colwidth", 70); pd.set_option("display.max_rows", 500)
d = pd.read_pickle("resolve_s3lab.pkl")
sf = pd.read_pickle("sf_lab_changes.pkl")
rev = sf[sf.attr=="=v2"].index
x = d[d.qid.isin(rev)]
# show depth link names vs target objects
x = x.assign(t0=x.tobj.str[0], t1=x.tobj.map(lambda o: o[1] if len(o)>1 else ""))
print(x[["qid","vid","kind","t0","dt","t1","dt2","val","flags"]].to_string())
