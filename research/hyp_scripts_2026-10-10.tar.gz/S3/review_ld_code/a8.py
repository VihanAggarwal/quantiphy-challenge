import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
pd.set_option("display.width", 260); pd.set_option("display.max_colwidth", 70); pd.set_option("display.max_rows", 1000)
d = pd.read_pickle("sf_lab_changes.pkl")
c = ["video_id","kind","meth","dir","geo","v2","p3","dir_base","new","attr","question"]
print(d[d.attr=="other"][c].to_string())
print("--- static =dir_base on s/x")
print(d[(d.attr=="=dir_base") & d.static][c].to_string())
