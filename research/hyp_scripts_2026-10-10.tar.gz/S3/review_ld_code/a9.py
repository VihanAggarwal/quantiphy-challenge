import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
import pickle
pd.set_option("display.width", 260); pd.set_option("display.max_colwidth", 80); pd.set_option("display.max_rows", 1000)
lab = pd.read_pickle("labS3.pkl")
VD = SP + "/variants_labdirect/"
sf = pd.read_csv(VD + "S3p3_split_full.csv").set_index("id").parsed_value
df_ = pd.read_csv(VD + "S3p3_direct_full.csv").set_index("id").parsed_value
lab["sf"] = lab.qid.map(sf); lab["df"] = lab.qid.map(df_)
c = ["qid","video_id","kind","meth","dir","geo","v2","sf","df","question","prior"]
x = lab[lab.twin.isin(["captured_0034a","captured_0034b"])].sort_values(["question","video_id"])
print(x[c].to_string())
print(x.groupby("twin").depth_info.unique().to_dict())
print("== 0040")
x = lab[lab.twin=="captured_0040"].sort_values(["question","video_id"])
print(x[c].to_string())
for v, g in x.groupby("video_id"): print(v, g.depth_info.unique())
