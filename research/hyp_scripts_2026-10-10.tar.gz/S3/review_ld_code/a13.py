import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
pd.set_option("display.width", 260); pd.set_option("display.max_colwidth", 60); pd.set_option("display.max_rows", 1000)
lab = pd.read_pickle("labS3.pkl")
run = run_csv().set_index("id")
VD = SP + "/variants_labdirect/"
sf = pd.read_csv(VD + "S3p3_split_full.csv").set_index("id").parsed_value
lab["sf"] = lab.qid.map(sf); lab["fls"] = lab.qid.map(run["flags"])
lab["static"] = lab.kind.isin(["size","other","distance"])
st = lab[lab.static]
fam = st.groupby(["twin","nq"])
mixed = fam.filter(lambda g: g.meth.str.startswith("geometry").nunique() > 1)
mixed = mixed.assign(m=mixed.meth.str.replace("geometry:3d_focal_from_prior","geo"), fl=mixed.fls.str.replace(r"geo:","",regex=False).str.slice(0,110))
print(mixed.sort_values(["twin","nq","var"])[["qid","video_id","kind","m","dir","geo","p3","sf","fl"]].to_string())
