import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
lab = pd.read_pickle(SP + "/work/p3lab.pkl")
run = run_csv().set_index("id")
lab["gm"] = lab.qid.map(run.geo_method); lab["meth"]=lab.qid.map(run.method)
x = lab[lab.chg]
x = x.assign(st=x.kind.isin(["size","other","distance"]))
print(pd.crosstab([x.category, x.st], x.gm))
x["lr"] = np.log(x.p3/x.v2)
print(x.groupby(["category","st"]).lr.agg(["median", lambda s: np.mean(np.abs(s)), "size"]).round(3))
