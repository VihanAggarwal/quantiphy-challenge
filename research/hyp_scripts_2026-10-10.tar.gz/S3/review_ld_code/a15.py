import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
pd.set_option("display.width", 260); pd.set_option("display.max_colwidth", 60); pd.set_option("display.max_rows", 1000)
lab = pd.read_pickle("labS3.pkl").set_index("qid")
VD = SP + "/variants_labdirect/"
P3F = "/home/user/quantiphy-challenge/submissions/trackA_probe3_s2maxext_d2denseoff_labdirect.csv"
p3 = pd.read_csv(P3F).set_index("id").parsed_value
lf = pd.read_csv(SP + "/work/labfix_changes.csv").set_index("qid")
dec = lf[lf.why.str.startswith("a_")].new
STATIC = {"size","other","distance"}
orig = {(r.twin, r.nq): q for q, r in lab.iterrows() if r["var"] == ""}
def expect(split, render, b34):
    e = {}
    for q, r in lab.iterrows():
        o = orig.get((r.twin, r.nq))
        dirv = lab.loc[o, "dir"] if (render and o is not None) else r.dir
        if split and r.kind in STATIC and r.twin != "captured_0034b":
            if q in dec.index: e[q] = dec[q]; continue
            if r.meth.startswith("geometry"): e[q] = r.geo; continue
        e[q] = dirv
    if b34:
        for q, r in lab[(lab.twin=="captured_0034b") & lab.kind.isin(STATIC)].iterrows():
            sib = lab[(lab.twin=="captured_0034a") & (lab.nq==r.nq) & (lab.prior==r.prior) & (lab.depth_info==r.depth_info)]
            e[q] = float(np.exp(np.median(np.log([e[s] for s in sib.index]))))
    return pd.Series(e)
for name, args in [("S3p3_split_full",(1,1,1)),("S3p3_direct_full",(0,1,1)),("S3p3_split_only",(1,0,0)),("S3p3_segtwin_only",(0,0,0)),("S3p3_segtwin_render",(0,1,0))]:
    v = pd.read_csv(VD+name+".csv").set_index("id").parsed_value
    e = expect(*args)
    bad = e.index[~np.isclose(e.values, v.loc[e.index].values, rtol=1e-9)]
    print(name, "lab mismatches vs independent spec:", len(bad), list(bad)[:10])
