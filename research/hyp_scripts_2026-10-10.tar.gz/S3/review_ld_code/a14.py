import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
pd.set_option("display.width", 260); pd.set_option("display.max_colwidth", 140); pd.set_option("display.max_rows", 1000)
lab = pd.read_pickle("labS3.pkl")
run = run_csv().set_index("id")
VD = SP + "/variants_labdirect/"
sf = pd.read_csv(VD + "S3p3_split_full.csv").set_index("id").parsed_value
lab["sf"] = lab.qid.map(sf); lab["fls"] = lab.qid.map(run["flags"]).str.replace("geo:","")
st = lab[lab.kind.isin(["size","other","distance"]) & (lab.meth=="direct")]
print(st.sort_values(["twin","nq","var"])[["qid","video_id","kind","dir","geo","sf","fls"]].to_string())
