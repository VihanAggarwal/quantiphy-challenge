import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
pd.set_option("display.width", 260); pd.set_option("display.max_colwidth", 75); pd.set_option("display.max_rows", 1000)
t = test().copy(); run = run_csv().set_index("id")
P3F = "/home/user/quantiphy-challenge/submissions/trackA_probe3_s2maxext_d2denseoff_labdirect.csv"
p3 = pd.read_csv(P3F).set_index("id").parsed_value
VD = SP + "/variants_labdirect/"
sf = pd.read_csv(VD + "S3p3_split_full.csv").set_index("id").parsed_value
t["twin"] = t.video_id.str.replace("_segmented","",regex=False).map(base_of); t["nq"]=t.question.map(normq)
S = t[t.category=="S3"]
seg = S[S.video_id.str.endswith("_segmented")]
print("S3 segmented rows:", len(seg), "videos", seg.video_id.nunique())
allo = t[~t.video_id.str.endswith("_segmented")]
rows=[]
for r in seg.itertuples():
    m = allo[(allo.twin==r.twin)&(allo.nq==r.nq)]
    rows.append(dict(qid=r.qid, vid=r.video_id, n_match=len(m), cats=",".join(m.category), srcs=",".join(m.video_source),
        prior_eq=",".join(str(x==r.prior) for x in m.prior), dep_eq=",".join(str(x==r.depth_info) for x in m.depth_info),
        oq=",".join(map(str,m.qid)), p3=p3[r.qid], o_p3=",".join(f"{p3[q]:.4g}" for q in m.qid), new=sf[r.qid], q=r.question))
d = pd.DataFrame(rows)
d["changed"] = ~np.isclose(d.p3, d.new)
print(d.groupby(["n_match","cats","prior_eq","dep_eq","changed"]).size())
print(d[~d.changed].to_string())
print(d[d.changed].head(12).to_string())
# segmented clips whose originals not S3?
