import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
import pickle
pd.set_option("display.width", 250); pd.set_option("display.max_colwidth", 120); pd.set_option("display.max_rows", 500)
t = test()
print(t.columns.tolist())
print(t.head(3).T)
S = t[t.category=="S3"]
print(S.video_source.value_counts())
print(S[S.video_source=="lab"].video_id.str.replace(r"captured_\d+","",regex=True).value_counts())
print(S[S.video_id.str.endswith("_segmented")].video_source.value_counts())
specs = pickle.load(open(SP + "/work/specs.pkl", "rb"))
print(type(specs), len(specs))
q0 = S.qid.iloc[0]; print(specs[q0])
