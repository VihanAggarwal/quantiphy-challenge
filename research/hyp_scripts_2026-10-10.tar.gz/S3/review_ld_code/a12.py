import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
pd.set_option("display.width", 260); pd.set_option("display.max_colwidth", 85); pd.set_option("display.max_rows", 1000)
d = pd.read_pickle("sf_lab_changes.pkl")
x = d[d.attr=="=v2"]
print("v2==geo:", np.isclose(x.v2, x.geo).all(), "meth:", x.meth.value_counts().to_dict())
x = x.assign(r=x.new/x.p3)
print(x.sort_values(["video_id"])[["video_id","kind","dim","dir","geo","new","r","question"]].to_string())
