import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
import pickle
t = test()
specs = pickle.load(open(SP + "/work/specs.pkl", "rb"))
ks = set(specs)
tt = t.set_index("qid")
sub = tt.loc[[q for q in ks if q in tt.index]]
print(sub.groupby(["category","video_source"]).size())
lab = t[(t.video_source=="lab") & t.category.isin(["S3","D3"])]
miss = lab[~lab.qid.isin(ks)]
print("lab S3/D3 qids missing in specs:", len(miss), miss.groupby("category").size().to_dict())
print(miss[["qid","video_id","category","question"]].head(30).to_string())
q = lab.qid.iloc[0]; print(specs[q])
