import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
pd.set_option("display.width", 250)
lab = pd.read_pickle(SP + "/work/labdir.pkl")   # has ans (val GT on test rows), dir, kind, var
run = run_csv().set_index("id")
lab["geo"] = lab.qid.map(run.geo_value); lab["meth"] = lab.qid.map(run.method); lab["v2"]=lab.qid.map(run.parsed_value)
lab["isgeo"] = lab.meth.str.startswith("geometry")
ob = lab[lab["var"]==""].set_index(["twin","nq"])
lab["geo_base"] = [ob.geo.get((a,b), np.nan) for a,b in zip(lab.twin, lab.nq)]
lab["geo_med"] = np.exp(lab.groupby(["twin","nq"]).geo.transform(lambda s: np.median(np.log(s.dropna())) if s.notna().any() else np.nan))
e = lab[lab.ans.notna() & (lab["var"]!="") & lab.isgeo]
print("known s/x rows routed to geometry:", len(e), e.groupby(["category","grp"]).size().to_dict(), "clips", e.twin.nunique(), sorted(e.twin.unique()))
for c in ["S3","D3"]:
    for g in ["static","motion"]:
        x = e[(e.category==c)&(e.grp==g)&e.geo_base.notna()]
        if len(x)==0: continue
        print(f"{c} {g} n={len(x)} own geo {mra(x.geo,x.ans):.3f} | base-render geo {mra(x.geo_base,x.ans):.3f} | median3 geo {mra(x.geo_med,x.ans):.3f} | own dir {mra(x.dir,x.ans):.3f} | base dir {mra(x.dir_base,x.ans):.3f}")
# test-wide spread of s/x geo vs base geo for S3 static rows routed to geometry
t3 = lab[(lab.category=="S3") & (lab.grp=="static") & lab.isgeo & (lab["var"]!="")]
t3 = t3.assign(r=t3.geo/t3.geo_base)
print(t3[np.abs(np.log(t3.r))>np.log(1.25)][["qid","video_id","kind","geo","geo_base","geo_med","dir","dir_base","question"]].to_string())
