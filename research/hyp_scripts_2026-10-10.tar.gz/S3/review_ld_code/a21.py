import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
pd.set_option("display.width", 260); pd.set_option("display.max_colwidth", 150); pd.set_option("display.max_rows", 500)
d = pd.read_pickle("sf_lab_changes.pkl")
run = run_csv().set_index("id")
d["fls"] = d.index.map(run["flags"]).str.replace("geo:","")
x = d[d.attr=="=v2"]
from collections import Counter
c = Counter(f for s in x.fls for f in s.split(";")); print(c)
print(x[~x.fls.isin(["f_camera_prior;reused_track","f_camera_prior"])][["video_id","kind","geo","dir","fls"]].to_string())
# all lab S3/D3 rows with target_depth_from_target2 routed to geometry
lab = pd.read_pickle(SP + "/work/p3lab.pkl"); lab["fls"]=lab.qid.map(run["flags"]); lab["meth"]=lab.qid.map(run.method)
y = lab[lab.fls.str.contains("target_depth_from_target2") ]
print(y[["qid","category","video_id","kind","meth","geo","dir","chg","question"]].to_string())
