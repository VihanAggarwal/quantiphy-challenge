import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
import pickle
pd.set_option("display.width", 250); pd.set_option("display.max_colwidth", 200)
t = test(); run = run_csv().set_index("id")
specs = pickle.load(open(SP + "/work/specs.pkl","rb"))
x = t[t.video_id.str.startswith("captured_0027")]
print(x[["qid","video_id","category","question","prior"]].to_string())
print(repr(x.depth_info.iloc[0]))
for q in x.qid:
    if q in specs: print(q, specs[q].target, run.loc[q,"method"], run.loc[q,"geo_value"], run.loc[q,"direct_value"])
    print("   notes:", specs[q].notes if q in specs else "")
