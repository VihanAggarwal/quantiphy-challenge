import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
from qp.geometry import solve
from qp.spec import DepthEntry
import copy, pickle
t = test(); run = run_csv().set_index("id")
lab = t[(t.video_source=="lab") & (t.category=="S3")]
anns, recs = anns_for(lab)
rows = []
for r in lab.itertuples():
    a = anns.get(r.qid)
    if a is None: continue
    m = recs[r.video_id]["meta"]
    try:
        A = solve(a.spec, a.tracks, tuple(m["image_size"]), float(m["fps"]), camera_fov_deg=84.0, seen_scale=float(m.get("scale") or 1.0))
        rows.append(dict(qid=r.qid, vid=r.video_id, val=A.value, method=A.method, flags=";".join(sorted(A.flags)),
                         dt=str(A.debug.get("depth_target")), dt2=str(A.debug.get("depth_target2")), dp=str(A.debug.get("depth_prior")),
                         tobj=a.spec.target.objects, pobj=a.spec.prior.objects, kind=a.spec.target.kind,
                         rng_t=A.debug.get("range_target_m"), rng_t2=A.debug.get("range_target2_m")))
    except Exception as e:
        rows.append(dict(qid=r.qid, vid=r.video_id, val=np.nan, method="ERR "+type(e).__name__))
d = pd.DataFrame(rows)
d["geo_run"] = d.qid.map(run.geo_value)
d["repro"] = np.isclose(d.val, d.geo_run, rtol=1e-6) | (d.val.isna() & d.geo_run.isna())
print("reproduced:", d.repro.sum(), "of", len(d))
d.to_pickle("resolve_s3lab.pkl")
