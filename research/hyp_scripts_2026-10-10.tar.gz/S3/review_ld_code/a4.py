import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
pd.set_option("display.width", 250); pd.set_option("display.max_colwidth", 100); pd.set_option("display.max_rows", 1000)
lab = pd.read_pickle("lab_kinds.pkl")
lab["twin"] = lab.video_id.map(base_of); lab["nq"] = lab.question.map(normq)
lab["static"] = lab.kind.isin(["size","other","distance"])
g = lab.groupby(["category","twin","nq","prior"])
inc = g.filter(lambda x: x.static.nunique() > 1 or x.kind.nunique()>1)
print(inc.sort_values(["category","twin","question","video_id"])[["qid","category","video_id","kind","dim","question","prior"]].to_string())
