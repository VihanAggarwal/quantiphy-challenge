import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
pd.set_option("display.width", 260); pd.set_option("display.max_colwidth", 80); pd.set_option("display.max_rows", 1000)
VD = SP + "/variants_labdirect/"
P3F = "/home/user/quantiphy-challenge/submissions/trackA_probe3_s2maxext_d2denseoff_labdirect.csv"
p3 = pd.read_csv(P3F).set_index("id").parsed_value
lab = pd.read_pickle("labS3.pkl").set_index("qid")
t = test().set_index("qid")
V = {n: pd.read_csv(VD + n + ".csv").set_index("id").parsed_value for n in ["S3p3_split_full","S3p3_direct_full","S3p3_split_only","S3p3_segtwin_only","S3p3_segtwin_render"]}
for n, s in V.items():
    ch = s.index[~np.isclose(s.values, p3.loc[s.index].values, rtol=1e-12)]
    print(n, len(ch), t.loc[ch].groupby(["category","video_source"]).size().to_dict())
sf = V["S3p3_split_full"]
ch = sf.index[~np.isclose(sf.values, p3.loc[sf.index].values, rtol=1e-12)]
labch = [q for q in ch if q in lab.index]
d = lab.loc[labch].copy()
d["new"] = sf.loc[labch]
# attribute
dbase = {}
o = lab[lab["var"]==""].reset_index().set_index(["twin","nq"])
d["dir_base"] = [o.loc[(a,b),"dir"] if (a,b) in o.index else np.nan for a,b in zip(d.twin,d.nq)]
def attr(r):
    tags=[]
    if np.isclose(r.new, r.v2): tags.append("=v2")
    if np.isclose(r.new, r.dir_base) if np.isfinite(r.dir_base) else False: tags.append("=dir_base")
    return ",".join(tags) or "other"
d["attr"] = d.apply(attr, axis=1)
d["static"] = d.kind.isin(["size","other","distance"])
print(pd.crosstab([d.static, d["var"]!=""], d.attr))
d.to_pickle("sf_lab_changes.pkl")
