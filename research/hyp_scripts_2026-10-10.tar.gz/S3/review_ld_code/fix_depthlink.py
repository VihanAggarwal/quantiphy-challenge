"""Corrected S3 split variants: static lab rows that the split sends to geometry but whose geometry borrowed the
target's depth from target2 (flag target_depth_from_target2: the question's object name, e.g. 'white ball',
did not match its depth_info entry, e.g. 'ping_pong_ball'), so the depth gap between the two objects was dropped.
Generic repair: the one depth_info object not claimed by target2 / the prior is the target's; re-solve."""
import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
from qp.geometry import solve, name_score, DEPTH_MATCH_MIN
from qp.spec import DepthEntry
import copy
OUT = SP + "/review_ld_code"
VD = SP + "/variants_labdirect/"
P3F = "/home/user/quantiphy-challenge/submissions/trackA_probe3_s2maxext_d2denseoff_labdirect.csv"
t = test(); run = run_csv().set_index("id"); tq = t.set_index("qid")
p3 = pd.read_csv(P3F).set_index("id").parsed_value
sf = pd.read_csv(VD + "S3p3_split_full.csv").set_index("id").parsed_value
# rows the split moved to geometry (static, geometry-routed) whose geometry borrowed target depth from target2
cand = [q for q in tq.index[(tq.category == "S3") & (tq.video_source == "lab")]
        if str(run.loc[q, "method"]).startswith("geometry") and "geo:target_depth_from_target2" in str(run.loc[q, "flags"])
        and np.isclose(sf[q], run.loc[q, "geo_value"]) and not np.isclose(sf[q], p3[q])]
print("candidates:", cand)
anns, recs = anns_for(t[t.qid.isin(cand)])
fix = {}
for q in cand:
    a = anns[q]; m = recs[tq.loc[q, "video_id"]]["meta"]; sp = copy.deepcopy(a.spec)
    claimers = list(sp.target.objects[1:2]) + list(sp.prior.objects or [])
    objs = list(dict.fromkeys(e.object for e in sp.depth))
    unclaimed = [o for o in objs if max((name_score(c, o) for c in claimers), default=0) < DEPTH_MATCH_MIN]
    if len(unclaimed) != 1: print(q, "skip, unclaimed:", unclaimed); continue
    sp.depth = [DepthEntry(object=(sp.target.objects[0] if e.object == unclaimed[0] else e.object), distance_m=e.distance_m, time=e.time) for e in sp.depth]
    A = solve(sp, a.tracks, tuple(m["image_size"]), float(m["fps"]), camera_fov_deg=84.0, seen_scale=float(m.get("scale") or 1.0))
    bad = {"target_depth_from_target2", "target_depth_from_prior", "target_depth_scene_median"} & set(A.flags)
    if bad or not np.isfinite(A.value): print(q, "skip, flags", A.flags); continue
    fix[q] = float(A.value)
    print(f"{q} {tq.loc[q,'video_id']}: depth entry '{unclaimed[0]}' -> '{sp.target.objects[0]}'; geometry {run.loc[q,'geo_value']:.2f} -> {A.value:.2f} (direct {run.loc[q,'direct_value']})")
for name in ["S3p3_split_full", "S3p3_split_only"]:
    df = pd.read_csv(VD + name + ".csv")
    df["parsed_value"] = [fix.get(i, v) for i, v in zip(df.id, df.parsed_value)]
    base = pd.read_csv(P3F)
    ch = ~np.isclose(df.parsed_value.values, base.parsed_value.values, rtol=1e-12)
    cats = tq.loc[df.id[ch], "category"].value_counts().to_dict(); assert set(cats) <= {"S3"}, cats
    assert df.parsed_value.notna().all() and (df.parsed_value > 0).all()
    df.to_csv(f"{OUT}/{name}_depthfix.csv", index=False)
    r = df.parsed_value[ch].values / base.parsed_value[ch].values
    print(f"{name}_depthfix: changed vs probe3 {int(ch.sum())} {cats}, median new/old {np.median(r):.3f}")
