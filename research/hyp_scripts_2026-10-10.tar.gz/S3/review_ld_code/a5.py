import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
import pickle
pd.set_option("display.width", 250); pd.set_option("display.max_colwidth", 90); pd.set_option("display.max_rows", 1000)
t = test(); run = run_csv().set_index("id")
P3F = "/home/user/quantiphy-challenge/submissions/trackA_probe3_s2maxext_d2denseoff_labdirect.csv"
p3 = pd.read_csv(P3F).set_index("id").parsed_value
pv = v2().set_index("id").parsed_value
lab = pd.read_pickle("lab_kinds.pkl")
lab = lab[lab.category=="S3"].copy()
lab["twin"] = lab.video_id.map(base_of); lab["nq"] = lab.question.map(normq)
lab["var"] = [v[len(b):] for v, b in zip(lab.video_id, lab.twin)]
lab["dir"] = lab.qid.map(run.direct_value); lab["meth"] = lab.qid.map(run.method); lab["geo"]=lab.qid.map(run.geo_value)
lab["runv"] = lab.qid.map(run.parsed_value)
lab["v2"] = lab.qid.map(pv); lab["p3"] = lab.qid.map(p3)
print("v2 == run value on S3 lab:", np.isclose(lab.v2, lab.runv).all(), (~np.isclose(lab.v2, lab.runv)).sum())
print("p3 == run direct on S3 lab:", np.isclose(lab.p3, lab.dir).all(), (~np.isclose(lab.p3, lab.dir)).sum())
print(lab[~np.isclose(lab.p3, lab.dir)][["qid","video_id","kind","meth","dir","p3","v2"]])
print("meth counts:", lab.meth.str.split(":").str[0].value_counts().to_dict())
print("changed in probe3 (v2!=p3):", (~np.isclose(lab.v2, lab.p3)).sum())
# original-render duplicates
o = lab[lab["var"]==""]
d = o[o.duplicated(["twin","nq"], keep=False)]
print("duplicate (twin,nq) in original renders:", len(d)); print(d[["qid","video_id","question","prior","depth_info"]].to_string())
# match s/x to original: same prior/depth_info?
om = o.drop_duplicates(["twin","nq"]).set_index(["twin","nq"])
sx = lab[lab["var"]!=""]
rows=[]
for r in sx.itertuples():
    if (r.twin, r.nq) not in om.index: rows.append((r.qid, r.video_id, "NO_ORIG", r.question)); continue
    b = om.loc[(r.twin, r.nq)]
    if b.prior != r.prior or b.depth_info != r.depth_info:
        rows.append((r.qid, r.video_id, f"prior_eq={b.prior==r.prior} depth_eq={b.depth_info==r.depth_info}", r.question))
print("s/x rows:", len(sx), "mismatched:", len(rows))
for x in rows: print(x)
lab.to_pickle("labS3.pkl")
