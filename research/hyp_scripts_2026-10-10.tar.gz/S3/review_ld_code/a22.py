import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
import pickle
specs = pickle.load(open(SP + "/work/specs.pkl","rb"))
t = test().set_index("qid")
for q in [2525, 2531, 2536, 2542, 2548, 2554]:
    s = specs[q]
    print(q, t.loc[q,"video_id"], repr(t.loc[q,"depth_info"]))
    print("   target", s.target.objects, s.target.time, "| depth", [(e.object, e.distance_m, e.time) for e in s.depth])
recs = load_records(videos={"captured_0031x","captured_0032","captured_0031"})
for v, r in recs.items():
    for qq in r.get("response", {}).get("questions", []) if isinstance(r.get("response"), dict) else []:
        pass
print(list(recs["captured_0031x"].keys()))
