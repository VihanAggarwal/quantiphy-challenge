import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
pd.set_option("display.width", 250); pd.set_option("display.max_colwidth", 90); pd.set_option("display.max_rows", 1000)
lab = pd.read_pickle("labS3.pkl")
for v in ["captured_0029","captured_0031","captured_0032"]:
    x = lab[lab.twin==v]
    print(x[["qid","video_id","kind","question","prior"]].sort_values("question").to_string())
