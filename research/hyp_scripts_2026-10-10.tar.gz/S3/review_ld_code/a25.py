import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
from qp.geometry import solve
from qp.spec import DepthEntry
import copy
t = test(); run = run_csv().set_index("id")
Q = [2525, 2531, 2536, 2542, 2548, 2554]
lab = t[t.qid.isin(Q)]
anns, recs = anns_for(lab)
for q in Q:
    a = anns[q]; vid = t.set_index("qid").loc[q,"video_id"]; m = recs[vid]["meta"]
    sp = copy.deepcopy(a.spec)
    sp.depth = [DepthEntry(object=("white ball" if e.object=="ping pong ball" else e.object), distance_m=e.distance_m, time=e.time) for e in sp.depth]
    A = solve(sp, a.tracks, tuple(m["image_size"]), float(m["fps"]), camera_fov_deg=84.0, seen_scale=float(m.get("scale") or 1.0))
    print(q, vid, f"run geo {run.loc[q,'geo_value']:.2f}  alias-fixed geo {A.value:.2f}  direct {run.loc[q,'direct_value']}  flags {sorted(A.flags)} dt={A.debug.get('depth_target')} ranges {A.debug.get('range_target_m')}, {A.debug.get('range_target2_m')}")
