import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
VD = SP + "/variants_labdirect/"
P3F = "/home/user/quantiphy-challenge/submissions/trackA_probe3_s2maxext_d2denseoff_labdirect.csv"
a = pd.read_csv(P3F); t = test().set_index("qid")
for n in ["S3p3_split_full","S3p3_direct_full","S3p3_split_only","S3p3_segtwin_only"]:
    b = pd.read_csv(VD+n+".csv")
    assert list(a.columns)==list(b.columns) and (a.id.values==b.id.values).all(), n
    diff = a.parsed_value.values != b.parsed_value.values
    print(n, len(b), "exact diffs:", diff.sum(), t.loc[b.id[diff]].category.value_counts().to_dict(), "nan:", b.parsed_value.isna().sum(), "nonpos:", (b.parsed_value<=0).sum())
# raw text lines check for non-S3
import csv
la = open(P3F).read().splitlines(); lb = open(VD+"S3p3_split_full.csv").read().splitlines()
ndiff = [i for i,(x,y) in enumerate(zip(la,lb)) if x!=y]
print("text-line diffs:", len(ndiff), "header", la[0], lb[0])
