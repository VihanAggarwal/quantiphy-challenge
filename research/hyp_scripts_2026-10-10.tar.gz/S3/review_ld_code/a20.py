import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
v = val(); print(sorted(v[v.video_source=="lab"].video_id.unique()))
run = run_csv().set_index("id")
for q in [2525,2531,2536]:
    print(q, run.loc[q, "flags"], run.loc[q,"geo_value"], run.loc[q,"direct_value"])
t = test(); print(t[t.video_id.str.startswith("captured_0031")][["qid","video_id","depth_info"]].drop_duplicates("video_id").to_string())
