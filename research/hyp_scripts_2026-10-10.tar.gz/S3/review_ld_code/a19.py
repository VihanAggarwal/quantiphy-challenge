import sys, re; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
pd.set_option("display.width", 250); pd.set_option("display.max_colwidth", 110); pd.set_option("display.max_rows", 500)
lab = pd.read_pickle(SP + "/work/p3lab.pkl")
def rx(q):
    s = q.lower()
    if re.search(r"velocity|speed|acceleration|displacement|travel|moved|rebounce|maximum height", s): return "motion"
    if re.search(r"from the camera", s): return "camdist"
    if re.search(r"diameter|width|length|height|long |breadth|distance between|distance from|initial distance", s): return "static"
    return "?"
lab["rx"] = lab.question.map(rx)
lab["st"] = np.where(lab.kind.isin(["size","other","distance"]), "static", np.where(lab.kind=="camera_distance","camdist","motion"))
print(pd.crosstab([lab.category, lab.st], [lab.rx, lab.chg]))
d = lab[lab.rx != lab.st]
print(d[["qid","category","video_id","kind","st","rx","chg","question"]].to_string())
