from rv_common import *
t, vh, amb = known()
t = t.set_index('qid', drop=False)
b = load_sub(V2)
V = {'v2': b}
for nm in ['S3_combo', 'S3_labfix', 'S3_segtwin', 'S3_combo_cons', 'S3_combo_noc']:
    V[nm] = load_sub(f"{SP}/variants/{nm}.csv")
cat = t.category
for nm, p in V.items():
    d = (p - b).abs() > 1e-9 * b.abs()
    ch = d[d].index
    print(f"{nm:14s} changed {len(ch):4d} cats {cat[ch].value_counts().to_dict()} srcs {t.loc[ch].video_source.value_counts().to_dict()}")
# loose known (simulation_0015 typo-fixed depth_info)
vh2 = vh.copy(); t2 = t.copy()
for d in (vh2, t2):
    d['k3'] = list(zip(d.bclip, d.question.map(nq), d.prior.map(nt), d.depth_info.map(lambda s: nt(s).replace('distance_thecenteral', 'distance_the_central'))))
gl = vh2.groupby('k3').answer.first()
t['ans_loose'] = t2.k3.map(gl)
k = t[(t.category == 'S3') & t.ans.notna()]
kl = t[(t.category == 'S3') & t.ans_loose.notna()]
print(f"\nS3 known rows strict n={len(k)}, loose n={len(kl)}")
rows = []
for nm, p in V.items():
    r = {'variant': nm, 'all': mra(p[k.qid], k.ans), 'loose_all': mra(p[kl.qid], kl.ans_loose)}
    for s, g in k.groupby('video_source'):
        r[s] = mra(p[g.qid], g.ans)
    for s, g in k.groupby('video_id'):
        r[s] = mra(p[g.qid], g.ans)
    rows.append(r)
R = pd.DataFrame(rows).set_index('variant')
pd.set_option('display.width', 250)
print(R[['all', 'loose_all', 'lab', 'segmentation', 'simulation']].round(3).to_string())
print(R.drop(columns=['all', 'loose_all', 'lab', 'segmentation', 'simulation']).T.round(3).to_string())
print(k.video_source.value_counts().to_dict())
