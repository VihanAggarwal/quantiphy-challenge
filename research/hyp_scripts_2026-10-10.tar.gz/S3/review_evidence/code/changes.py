from rv_common import *
t, vh, amb = known()
t = t.set_index('qid', drop=False)
b = load_sub(V2)
run = pd.read_csv('/home/user/quantiphy-challenge/runs/test_v1_high_854/test.csv').set_index('id')
lab = pd.read_csv(SP + '/work/labfix_changes.csv').set_index('qid')
combo = load_sub(SP + '/variants/S3_combo.csv'); cons = load_sub(SP + '/variants/S3_combo_cons.csv')
d = (combo - b).abs() > 1e-9 * b.abs(); ch = d[d].index
C = pd.DataFrame({'qid': ch, 'vid': t.loc[ch].video_id.values, 'old': b[ch].values, 'new': combo[ch].values})
C['rule'] = [lab.loc[q, 'why'][:1] if q in lab.index else 'seg' for q in ch]
C['known'] = t.loc[ch].ans.notna().values
C['ans'] = t.loc[ch].ans.values
C['r'] = C.new / C.old
C['method'] = run.loc[ch, 'method'].values
C['q'] = t.loc[ch].question.str[:70].values
C['gt_old'] = [item_scores([o], [a])[0] if a == a else np.nan for o, a in zip(C.old, C.ans)]
C['gt_new'] = [item_scores([o], [a])[0] if a == a else np.nan for o, a in zip(C.new, C.ans)]
pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 70)
print(C.groupby(['rule', 'known']).agg(n=('qid', 'size'), med_r=('r', 'median'), gt10=('r', lambda x: int((np.abs(np.log(x)) > np.log(1.1)).sum())), gt2x=('r', lambda x: int((np.abs(np.log(x)) > np.log(2)).sum())), sold=('gt_old', 'sum'), snew=('gt_new', 'sum')).to_string())
print(C.sort_values(['rule', 'vid', 'qid']).to_string())
C.to_csv(RE + '/combo_changes_annotated.csv', index=False)
# consensus extra
d2 = (cons - combo).abs() > 1e-9 * combo.abs(); ch2 = d2[d2].index
r2 = cons[ch2] / combo[ch2]
print('\ncons extra changes', len(ch2), 'known', int(t.loc[ch2].ans.notna().sum()), '>10%', int((np.abs(np.log(r2)) > np.log(1.1)).sum()), '>25%', int((np.abs(np.log(r2)) > np.log(1.25)).sum()), 'med', float(r2.median()))
