from rv_common import *
t, vh, amb = known(); t = t.set_index('qid', drop=False)
b = load_sub(V2); c = load_sub(SP + '/variants/S3_combo.csv')
run = pd.read_csv('/home/user/quantiphy-challenge/runs/test_v1_high_854/test.csv').set_index('id')
t['v2'] = b[t.qid].values; t['dir'] = run.loc[t.qid, 'direct_value'].values; t['meth'] = run.loc[t.qid, 'method'].values
t['nq'] = t.question.map(nq)
motion = lambda u: any(s in str(u) for s in ['/s'])
t['motion'] = t.target_unit.map(motion) | t.question.str.lower().str.contains('distance travel|traveled|travelled|displacement')
# ---- 0034b under GT(0034a)
g34 = vh[vh.video_id == 'captured_0034as']; g = dict(zip(g34.question.map(nq), g34.answer))
x = t[t.video_id.str.startswith('captured_0034b')]; gg = x.nq.map(g)
print(f"0034b n={len(x)}: v2 {mra(x.v2, gg):.3f} combo {mra(c[x.qid], gg):.3f} direct {mra(x.dir, gg):.3f} geo {mra(run.loc[x.qid,'geo_value'], gg):.3f}")
# ---- rule (c) cross-category: lab s/x renders, direct-routed motion, own vs original render (known rows, all cats)
lab = t[(t.video_source == 'lab') & t.ans.notna()].copy()
lab['bkey'] = list(zip(lab.bclip, lab.nq))
orig = lab[lab.video_id == lab.bclip].set_index('bkey')
sx = lab[(lab.video_id != lab.bclip)]
for cat in ['S3', 'D3']:
    for meth in ['direct', 'geo']:
        s = sx[(sx.category == cat) & sx.motion & ((sx.meth == 'direct') if meth == 'direct' else (sx.meth != 'direct'))]
        s = s[s.bkey.isin(orig.index)]
        if not len(s): print(cat, meth, 'none'); continue
        o = orig.loc[s.bkey]
        print(f"rule c {cat} {meth}-routed motion on s/x n={len(s)} clips={sorted(s.video_id.unique())}: own v2 {mra(s.v2, s.ans):.3f} | orig-render v2 {mra(o.v2.values, s.ans):.3f} | own direct {mra(s.dir, s.ans):.3f} orig direct {mra(o.dir.values, s.ans):.3f} | logmedian-3 direct {mra(np.exp((np.log(s.dir.values)*2+np.log(o.dir.values))/3), s.ans):.3f}")
# all renders: direct answers per render on all known lab motion questions: is the original render direct better?
for cat in ['S3', 'D3']:
    s = lab[(lab.category == cat) & lab.motion]
    print(cat, 'direct by render type (all known lab motion q):', {k: (len(g_), round(mra(g_.dir, g_.ans), 3)) for k, g_ in s.groupby(s.video_id.str[-1].map(lambda ch: ch if ch in 'sx' else 'orig'))})
    s = lab[(lab.category == cat) & ~lab.motion]
    print(cat, 'direct by render type (all known lab size q):', {k: (len(g_), round(mra(g_.dir, g_.ans), 3)) for k, g_ in s.groupby(s.video_id.str[-1].map(lambda ch: ch if ch in 'sx' else 'orig'))})
# ---- segtwin cross-category on known rows
k = t[t.ans.notna() & t.video_source.isin(['simulation', 'segmentation'])].copy()
k['key4'] = k.key
seg = k[k.video_id.str.endswith('_segmented')]; org = k[~k.video_id.str.endswith('_segmented')].set_index('key4')
seg = seg[seg.key4.isin(org.index)]
o = org.loc[seg.key4]
seg = seg.assign(v2o=o.v2.values, diro=o.dir.values)
print('\nsegmented known rows with original twin:', len(seg), seg.groupby('category').size().to_dict(), sorted(seg.video_id.unique()))
for (cat, mo), g_ in seg.groupby(['category', 'motion']):
    print(f"  {cat} motion={mo} n={len(g_)} clips={g_.video_id.nunique()}: seg own {mra(g_.v2, g_.ans):.3f} orig {mra(g_.v2o, g_.ans):.3f}")
for vid, g_ in seg.groupby('video_id'):
    print(f"  {vid} n={len(g_)} cats={g_.category.unique()} motion={g_.motion.mean():.2f}: seg own {mra(g_.v2, g_.ans):.3f} orig {mra(g_.v2o, g_.ans):.3f}")
print(f"  ALL n={len(seg)}: seg {mra(seg.v2, seg.ans):.3f} orig {mra(seg.v2o, seg.ans):.3f}; excluding simulation_0170_segmented: ", end='')
s2 = seg[seg.video_id != 'simulation_0170_segmented']; print(f"n={len(s2)} seg {mra(s2.v2, s2.ans):.3f} orig {mra(s2.v2o, s2.ans):.3f}")
