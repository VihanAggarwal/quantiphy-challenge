import cv2, sys, numpy as np
out, times = sys.argv[1], [float(x) for x in sys.argv[2].split(',')]
vids = sys.argv[3:]
rows = []
for v in vids:
    cap = cv2.VideoCapture(f"/home/user/quantiphy-challenge/data/QuantiPhy/{v}.mp4")
    fps = cap.get(cv2.CAP_PROP_FPS); n = cap.get(cv2.CAP_PROP_FRAME_COUNT)
    row = []
    for tt in times:
        cap.set(cv2.CAP_PROP_POS_FRAMES, int(round(tt * fps)))
        ok, f = cap.read()
        if not ok: f = np.zeros((360, 640, 3), np.uint8)
        f = cv2.resize(f, (480, int(480 * f.shape[0] / f.shape[1])))
        cv2.putText(f, f"{v} t={tt}", (5, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 0, 255), 2)
        row.append(f)
    h = min(r.shape[0] for r in row); row = [r[:h] for r in row]
    rows.append(np.hstack(row)); print(v, fps, n, n / fps)
w = min(r.shape[1] for r in rows)
cv2.imwrite(out, np.vstack([r[:, :w] for r in rows]), [cv2.IMWRITE_JPEG_QUALITY, 80])
