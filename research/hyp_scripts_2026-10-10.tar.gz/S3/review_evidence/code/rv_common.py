import sys, re, os
sys.path.insert(0, '/home/user/quantiphy-challenge')
os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
import numpy as np, pandas as pd
from qp.data import load_split
from qp.mra import item_scores
SP = "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3"
RE = SP + "/review_evidence"
V2 = "/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv"

def base_clip(v):
    v = re.sub(r"_segmented$", "", v)
    v = re.sub(r"^(captured_\d+[ab]?)[sx]$", r"\1", v)
    return v

def nt(s):
    return re.sub(r"\s+", "", str(s if s == s else "")).lower()
def nq(s):
    return re.sub(r"[^a-z0-9.]", "", str(s).lower())

def known():
    t = load_split('test'); vh = load_split('val_hires'); v = load_split('val')
    assert (vh.answer.values == v.answer.values).all()
    for d in (t, vh):
        d['bclip'] = d.video_id.map(base_clip)
        d['key'] = list(zip(d.bclip, d.question.map(nq), d.prior.map(nt), d.depth_info.map(nt)))
    g = vh.groupby('key').answer.agg(['first', 'nunique', 'size'])
    amb = g[g['nunique'] > 1]
    gt = g['first'].to_dict()
    t['ans'] = t.key.map(gt)
    t['amb'] = t.key.isin(amb.index)
    t['val_qid'] = t.key.map(vh.groupby('key').qid.first())
    return t, vh, amb

def mra(p, g):
    return float(np.mean(item_scores(np.asarray(p, float), np.asarray(g, float))))

def load_sub(path):
    return pd.read_csv(path).set_index('id').parsed_value
