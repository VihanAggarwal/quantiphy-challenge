import cv2, numpy as np, sys
D="/home/user/quantiphy-challenge/data/QuantiPhy/"
s=sys.argv[1]
ca=cv2.VideoCapture(D+s+".mp4"); cb=cv2.VideoCapture(D+s+"_segmented.mp4")
_,a=ca.read(); _,b=cb.read()
g=cv2.cvtColor(b,cv2.COLOR_BGR2GRAY); fg=np.abs(g.astype(int)-np.median(g))>25
for k in range(4):
    for flip in (False, True):
        x=np.rot90(a,k); x=x[:, ::-1] if flip else x
        if x.shape!=b.shape: continue
        print(k, flip, round(np.abs(x.astype(int)-b.astype(int)).mean(axis=2)[fg].mean(),1))
