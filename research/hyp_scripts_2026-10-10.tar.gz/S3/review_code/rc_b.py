import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
pd.set_option("display.width", 250); pd.set_option("display.max_colwidth", 200)
t = test(); t["nq"] = t.question.map(normq)
rep = pd.read_csv(SP + "/work/repro.csv")
rep["ratio"] = rep.prior_meas / rep.pval
cr = rep[rep.cat == "S3"].groupby("vid").ratio.agg(["median","size","min","max"])
print(cr.sort_values("median").to_string())
# D3 too for interest
cr3 = rep[rep.cat == "D3"].groupby("vid").ratio.median()
print("D3 extreme:", cr3[(cr3<1/1.75)|(cr3>1.75)])
b0 = v2().set_index("id").parsed_value
run = run_csv().set_index("id")
x = t[t.video_id.str.startswith("captured_0034")]
print(x.groupby(["video_id","category"]).size())
for vid in ["captured_0034b"]:
    for r in x[(x.video_id==vid)].itertuples():
        sib = x[(x.video_id.str.startswith("captured_0034a")) & (x.nq == r.nq) & (x.prior==r.prior) & (x.depth_info==r.depth_info)]
        print(r.qid, r.category, r.question, "| prior:", r.prior, "| v2", round(b0[r.qid],3), run.loc[r.qid,"method"], "| sibs", [(s.qid, s.video_id, round(b0[s.qid],3), run.loc[s.qid,"method"]) for s in sib.itertuples()])
print(x[x.video_id=="captured_0034b"].depth_info.iloc[0])
print(x[x.video_id=="captured_0034a"].depth_info.iloc[0] if (x.video_id=="captured_0034a").any() else "no 0034a")
