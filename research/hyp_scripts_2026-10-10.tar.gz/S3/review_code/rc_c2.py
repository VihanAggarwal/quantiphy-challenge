import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
import pickle
specs = pickle.load(open(SP + '/work/specs.pkl', 'rb'))
t = test(); t["nq"] = t.question.map(normq)
run = run_csv().set_index("id"); b0 = v2().set_index("id").parsed_value
lc = pd.read_csv(SP + "/work/labfix_changes.csv").set_index("qid")
lab = t[(t.video_source=="lab")&(t.category=="S3")]
print("S3 lab rows", len(lab), "methods:", run.loc[lab.qid,"method"].value_counts().to_dict())
kinds = pd.Series({q: specs[q].target.kind for q in lab.qid})
print(pd.crosstab(kinds, run.loc[lab.qid,"method"].str.split(":").str[0]))
sx = lab[lab.video_id != lab.base]
for r in sx.itertuples():
    if run.loc[r.qid,"method"]=="direct":
        k = specs[r.qid].target.kind
        o = lab[(lab.video_id==r.base)&(lab.nq==r.nq)]
        print(r.qid, r.video_id, k, r.question[:70], "| own", b0[r.qid], "| orig", [(x, run.loc[x,'method'], round(b0[x],3)) for x in o.qid], "| changed:", lc.loc[r.qid,"why"] if r.qid in lc.index else "-")
