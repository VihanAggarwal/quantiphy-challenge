import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
import pickle
specs = pickle.load(open(SP + '/work/specs.pkl', 'rb'))
pd.set_option("display.width", 250); pd.set_option("display.max_colwidth", 200)
t = test(); t["nq"] = t.question.map(normq)
ti = t.set_index("qid")
b0 = v2().set_index("id").parsed_value
run = run_csv().set_index("id")
lc = pd.read_csv(SP + "/work/labfix_changes.csv")
for r in lc[lc.why.str.startswith("c")].itertuples():
    q = ti.loc[r.qid]
    base = t[(t.video_id == q.base) & (t.nq == q.nq)]
    o = base.iloc[0]
    iss = []
    if o.prior != q.prior: iss.append("PRIOR")
    if o.depth_info != q.depth_info: iss.append("DEPTH")
    if o.question != q.question: iss.append("QTEXT")
    sp = specs[r.qid]; spo = specs.get(o.qid)
    print(r.qid, q.video_id, "<-", o.qid, o.video_id, "|", q.question, "| prior", q.prior, "|", f"{r.old:.4g} -> {r.new:.4g}", "own:", run.loc[r.qid, ["geo_value","direct_value","method","flags"]].to_dict(), "| orig:", run.loc[o.qid, ["geo_value","direct_value","method"]].to_dict(), "kind", sp.target.kind, spo.target.kind if spo else None, iss)
    if iss: print("   ", q.depth_info, "\n   ", o.depth_info)
