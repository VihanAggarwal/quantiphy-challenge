import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
import pickle
specs = pickle.load(open(SP + '/work/specs.pkl', 'rb'))
t = test()
run = run_csv().set_index("id")
b0 = v2().set_index("id").parsed_value
x = t[t.video_id.str.startswith("captured_0040")]
for r in x.itertuples():
    sp = specs.get(r.qid)
    print(r.qid, r.video_id, r.category, "|", r.question, "|", r.prior)
    print("   depth_info:", r.depth_info)
    if sp is not None:
        print("   spec depth:", [(e.object, e.distance_m, e.time) for e in sp.depth], "target", sp.target.kind, sp.target.object if hasattr(sp.target,'object') else '')
    print("   run:", run.loc[r.qid, ["geo_value","direct_value","method","flags"]].to_dict(), "v2", b0[r.qid])
