import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
tt = test()
for v in ["simulation_0022", "simulation_0027", "simulation_0034", "simulation_0048"]:
    for vid in (v, v + "_segmented"):
        x = tt[tt.video_id == vid]
        print("==", vid, len(x))
        for r in x.itertuples(): print("  ", r.qid, r.category, r.question, "|", r.prior, "|", r.depth_info.replace("\n", "; ")[:150])
