import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
t = test(); v = val()
for x in (t, v):
    x["twin"] = x.video_id.str.replace("_segmented", "", regex=False).map(base_of); x["nq"] = x.question.map(normq)
vv = v.drop_duplicates(["twin","nq"])
gt = vv.set_index(["twin", "nq"])
t = t.merge(vv[["twin","nq","answer","prior","depth_info"]].rename(columns={"answer":"ans","prior":"vprior","depth_info":"vdepth"}), on=["twin","nq"], how="left")
k = t[t.ans.notna() & (t.category=="S3")]
print("known S3 rows", len(k), "prior mismatch", (k.prior!=k.vprior).sum(), "depth mismatch", (k.depth_info!=k.vdepth).sum())
b0 = v2().set_index("id").parsed_value
combo = pd.read_csv(SP+"/variants/S3_combo.csv").set_index("id").parsed_value
lc = pd.read_csv(SP+"/work/labfix_changes.csv").set_index("qid")
seg = pd.read_csv(SP+"/variants/S3_segtwin.csv").set_index("id").parsed_value
k = k.set_index("qid")
def rule(q):
    if q in lc.index: return lc.loc[q,"why"][:1]
    if abs(seg[q]-b0[q])>1e-12: return "seg"
    return "-"
k["rule"] = [rule(q) for q in k.index]
k["s0"] = item_scores(b0[k.index].values, k.ans.values); k["s1"] = item_scores(combo[k.index].values, k.ans.values)
print(k.groupby("rule").agg(n=("s0","size"), v2=("s0","mean"), combo=("s1","mean"), clips=("video_id", lambda s: sorted(set(s)))))
print("overall", k.s0.mean(), k.s1.mean(), len(k))
print(k[k.rule!="-"][["video_id","question","ans","s0","s1"]].assign(v2=b0[k[k.rule!='-'].index].values, new=combo[k[k.rule!='-'].index].values).to_string())
import re
norm = lambda s: re.sub(r"\s+", "", str(s).lower())
print("after whitespace norm: prior mismatch", (k.prior.map(norm)!=k.vprior.map(norm)).sum(), "depth mismatch", (k.depth_info.map(norm)!=k.vdepth.map(norm)).sum())
for q in [1866, 2468, 1717, 2591 if 2591 in k.index else 1717]:
    print(repr(k.loc[q,"prior"]), repr(k.loc[q,"vprior"])); print(repr(k.loc[q,"depth_info"])); print(repr(k.loc[q,"vdepth"]))
mm = k[k.depth_info.map(norm)!=k.vdepth.map(norm)]
for q in mm.index[:5]: print(q, repr(k.loc[q,"depth_info"]), "|", repr(k.loc[q,"vdepth"]))
