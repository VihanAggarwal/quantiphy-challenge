"""S3_combo with the segmented-twin rule restricted to twins that show the same view: the twin's
foreground must agree pixelwise with the original (simulation_0019's original is the segmented clip
rotated 90 deg, so it is excluded). Byte-identical to v2 except changed S3 parsed_values."""
import csv, io
V2 = "/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv"
SRC = "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/review_integrity/S3_combo_clean.csv"
OUT = "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/review_code/S3_combo_strict.csv"
B = list(csv.reader(open(V2, newline=""))); R = list(csv.reader(open(SRC, newline="")))
drop = {"simulation_0019_segmented"}
n = 0
for i in range(1, len(R)):
    if R[i][1] in drop and R[i][-1] != B[i][-1]:
        R[i][-1] = B[i][-1]; n += 1
s = io.StringIO(); csv.writer(s, lineterminator="\n").writerows(R); open(OUT, "w", newline="").write(s.getvalue())
diff = sum(R[i] != B[i] for i in range(1, len(B)))
print("reverted", n, "rows; total rows differing from v2:", diff)
