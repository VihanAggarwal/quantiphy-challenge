import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
t = test().set_index("qid")
base = v2(); b0 = base.set_index("id").parsed_value
c = pd.read_csv(SP + "/variants/S3_combo.csv")
print("same ids/order:", (c.id.values == base.id.values).all(), c.shape, base.shape, list(c.columns))
cv = c.set_index("id").parsed_value
d = (cv - b0).abs() > 1e-12
ids = d[d].index
seg = pd.read_csv(SP + "/variants/S3_segtwin.csv").set_index("id").parsed_value
lab = pd.read_csv(SP + "/work/labfix_changes.csv").set_index("qid")
s_ids = set(((seg - b0).abs() > 1e-12).pipe(lambda s: s[s].index))
print(len(ids), len(s_ids), len(lab), len(s_ids | set(lab.index)), set(ids) == (s_ids | set(lab.index)))
for q in lab.index: assert np.isclose(cv[q], lab.loc[q, "new"])
for q in s_ids: assert np.isclose(cv[q], seg[q])
print(t.loc[ids].groupby(["category","video_source"]).size())
# S3 segmented coverage
tt = test(); s3seg = tt[(tt.category=="S3") & tt.video_id.str.endswith("_segmented")]
print("S3 segmented questions:", len(s3seg), "changed:", len(set(s3seg.qid) & s_ids))
tt["twin"] = tt.video_id.str.replace("_segmented","",regex=False); tt["nq"] = tt.question.map(normq)
orig = tt[~tt.video_id.str.endswith("_segmented")]
nomatch = []; same = []
for r in s3seg.itertuples():
    if r.qid in s_ids: continue
    m = orig[(orig.twin == tt.set_index("qid").loc[r.qid,"twin"]) & (orig.nq == normq(r.question))]
    if len(m) == 0: nomatch.append((r.qid, r.video_id, r.question))
    else: same.append((r.qid, r.video_id, b0[r.qid], [b0[x] for x in m.qid], list(m.category), [p == r.prior for p in m.prior]))
print("no twin:", len(nomatch)); [print("  ", x) for x in nomatch[:40]]
print("twin but unchanged:", len(same)); [print("  ", x) for x in same]
# check no NaN and positive
print(c.parsed_value.isna().sum(), (c.parsed_value<=0).sum())
