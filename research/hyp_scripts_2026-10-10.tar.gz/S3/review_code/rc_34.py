import cv2, numpy as np
D="/home/user/quantiphy-challenge/data/QuantiPhy/"
rows=[]
for v in ["captured_0034a","captured_0034b"]:
    c = cv2.VideoCapture(D+v+".mp4"); n=int(c.get(7)); fps=c.get(5); print(v, n, fps, c.get(3), c.get(4))
    fr=[]
    for i in range(n):
        ok,f=c.read()
        if not ok: break
        if i in (0, int(0.6*fps), int(1.2*fps), int(1.8*fps), n-1): fr.append(cv2.resize(f,(320,180)))
    rows.append(np.hstack(fr))
cv2.imwrite("/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/review_code/c34.jpg", np.vstack(rows))
