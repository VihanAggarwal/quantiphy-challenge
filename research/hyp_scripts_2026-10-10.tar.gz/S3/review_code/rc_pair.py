import cv2, sys, numpy as np
D="/home/user/quantiphy-challenge/data/QuantiPhy/"
s=sys.argv[1]; idx=[int(x) for x in sys.argv[2].split(",")]
rows=[]
for v in (s, s+"_segmented"):
    c=cv2.VideoCapture(D+v+".mp4"); fr=[]
    for i in range(max(idx)+1):
        ok,f=c.read()
        if i in idx: fr.append(cv2.resize(f,(400,int(400*f.shape[0]/f.shape[1]))))
    rows.append(np.hstack(fr))
cv2.imwrite(f"/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/review_code/{s}_pair.jpg", np.vstack(rows))
