import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
pd.set_option("display.width", 250)
t = test(); t["nq"] = t.question.map(normq)
lab = t[(t.video_source=="lab")&(t.category=="S3")]
dup = lab[lab.duplicated(["video_id","nq"], keep=False)]
print("dup (video,nq) rows:", len(dup)); print(dup[["qid","video_id","question","prior"]].to_string()[:3000])
# groups with differing prior/depth_info across renders
g = lab.groupby(["base","nq"]).agg(np=("prior","nunique"), nd=("depth_info","nunique"), n=("qid","size"))
print("groups with differing prior/depth:", g[(g.np>1)|(g.nd>1)])
combo = pd.read_csv(SP+"/variants/S3_combo.csv").set_index("id").parsed_value
cons = pd.read_csv(SP+"/variants/S3_combo_cons.csv").set_index("id").parsed_value
d = (cons-combo).abs()>1e-12; ids=d[d].index
run = run_csv().set_index("id")
r = (cons[ids]/combo[ids]); big = r[np.abs(np.log(r))>np.log(1.25)]
print("cons changed", len(ids), "big >25%:", len(big))
ti = t.set_index("qid")
for q in big.index:
    b = ti.loc[q,"base"]; nq = ti.loc[q,"nq"]
    grp = lab[(lab.base==b)&(lab.nq==nq)]
    print(q, ti.loc[q,"video_id"], ti.loc[q,"question"][:60], f"{combo[q]:.3g}->{cons[q]:.3g}", [(x, ti.loc[x,'video_id'][-6:], round(combo[x],3), run.loc[x,'method'][:12]) for x in grp.qid])
