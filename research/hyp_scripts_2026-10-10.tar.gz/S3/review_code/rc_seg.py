import sys; sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
pd.set_option("display.width", 250); pd.set_option("display.max_colwidth", 120)
t = test().set_index("qid")
b0 = v2().set_index("id").parsed_value
V = {n: pd.read_csv(SP + f"/variants/{n}.csv").set_index("id").parsed_value for n in ["S3_combo","S3_segtwin","S3_labfix","S3_combo_cons"]}
seg = V["S3_segtwin"]; d = (seg - b0).abs() > 1e-12; ids = d[d].index
print("segtwin changed", len(ids))
tt = test().copy(); tt["twin"] = tt.video_id.str.replace("_segmented","",regex=False); tt["nq"] = tt.question.map(normq)
orig = tt[~tt.video_id.str.endswith("_segmented")]
probs = 0
for q in ids:
    r = tt.set_index("qid").loc[q]
    m = orig[(orig.twin == r.twin) & (orig.nq == r.nq)]
    o = m.iloc[0]
    issues = []
    if o.question != r.question: issues.append("QTEXT")
    if o.prior != r.prior: issues.append("PRIOR")
    if o.depth_info != r.depth_info: issues.append("DEPTH")
    if o.fps != r.fps: issues.append(f"FPS {o.fps} vs {r.fps}")
    if o.video_type != r.video_type: issues.append(f"VT {o.video_type} vs {r.video_type}")
    if o.inference_type != r.inference_type: issues.append("IT")
    if len(m) > 1: issues.append(f"MULTI{len(m)}")
    print(q, r.video_id, "<-", o.qid, o.video_source, f"{b0[q]:.4g} -> {seg[q]:.4g} (v2 orig {b0[o.qid]:.4g})", issues)
    if issues: probs += 1
    if issues and "DEPTH" in issues:
        print("   seg depth:", r.depth_info[:300]); print("   org depth:", o.depth_info[:300])
print("rows with issues", probs)
