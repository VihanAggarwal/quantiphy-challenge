import cv2, sys
D="/home/user/quantiphy-challenge/data/QuantiPhy/"
for s in sys.argv[1:]:
    for v in (s, s+"_segmented"):
        c = cv2.VideoCapture(D+v+".mp4")
        print(v, int(c.get(cv2.CAP_PROP_FRAME_COUNT)), c.get(cv2.CAP_PROP_FPS), int(c.get(3)), int(c.get(4)))
