import cv2, sys, numpy as np
D="/home/user/quantiphy-challenge/data/QuantiPhy/"
for s in sys.argv[1:]:
    ca = cv2.VideoCapture(D+s+".mp4"); cb = cv2.VideoCapture(D+s+"_segmented.mp4")
    res=[]
    for i in range(0, 200):
        oka, a = ca.read(); okb, b = cb.read()
        if not (oka and okb): break
        if i % 20: continue
        g = cv2.cvtColor(b, cv2.COLOR_BGR2GRAY)
        bg = np.median(g)  # background value
        fg = np.abs(g.astype(int) - bg) > 25
        diff = np.abs(a.astype(int) - b.astype(int)).mean(axis=2)
        res.append((i, fg.mean(), diff[fg].mean() if fg.any() else -1, diff[~fg].mean()))
    print(s, [(i, round(f,3), round(d1,1), round(d2,1)) for i,f,d1,d2 in res])
    cv2.imwrite(f"/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/review_code/{s}_pair.jpg", cv2.resize(np.hstack([a if a is not None else b, b]), None, fx=0.3, fy=0.3) if oka else np.zeros((10,10,3)))
