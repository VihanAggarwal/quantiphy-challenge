import sys, re, numpy as np, pandas as pd
sys.path.insert(0, "/home/user/quantiphy-challenge")
from qp.data import load_split
t = load_split("test"); v = load_split("val")
print(v.columns.tolist())
r = v[v.video_id=="simulation_0170_segmented"].iloc[0]
m = t[(t.video_id=="simulation_0170_segmented")]
print(repr(r.question), repr(r.prior), repr(r.depth_info)[:200])
print(m[["qid","question","prior"]].head(3).to_string()); print(repr(m.depth_info.iloc[0])[:200])
