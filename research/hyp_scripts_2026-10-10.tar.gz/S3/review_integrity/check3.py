import sys, re, numpy as np, pandas as pd
sys.path.insert(0, "/home/user/quantiphy-challenge")
from qp.data import load_split
t = load_split("test")
print(t.columns.tolist())
s3 = t[t.category=="S3"]
print(s3.depth_info.iloc[0][:300])
print(s3[s3.video_id.str.startswith("captured_0040")].depth_info.iloc[0])
