from common import *
from qp.geometry import solve
t = test()
lab = t[(t.video_source == "lab") & t.category.isin(["S3", "D3"])]
anns, recs = anns_for(lab)
run = run_csv().set_index("id")
rows = []
for r in lab.itertuples():
    a = anns.get(r.qid)
    if a is None:
        continue
    m = recs[r.video_id]["meta"]
    kw = dict(seen_scale=float(m.get("scale") or 1.0))
    A = solve(a.spec, a.tracks, tuple(m["image_size"]), float(m["fps"]), camera_fov_deg=84.0, **kw)
    B = solve(a.spec, a.tracks, tuple(m["image_size"]), float(m["fps"]), **kw)
    rows.append(dict(qid=r.qid, vid=r.video_id, cat=r.category, kind=a.spec.target.kind, pkind=a.spec.prior.kind,
                     geo=A.value, geo_run=run.loc[r.qid, "geo_value"], f_map=A.debug.get("f_px"),
                     f_solo=B.debug.get("f_px"), m_solo=B.method, prior_meas=A.debug.get("prior_measured_si"),
                     pval=a.spec.prior.value_si, sens=B.debug.get("f_sensitivity"), flags=";".join(B.flags)))
d = pd.DataFrame(rows)
d.to_csv(OUT + "/work/repro.csv", index=False)
ok = np.isclose(d.geo.astype(float), d.geo_run.astype(float), rtol=1e-3) | (d.geo.isna() & d.geo_run.isna())
print("reproduced", ok.sum(), "of", len(d))
print(d[~ok][["qid", "vid", "kind", "geo", "geo_run"]].head(20))
