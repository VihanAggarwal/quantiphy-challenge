import sys, numpy as np, pandas as pd
sys.path.insert(0, "/home/user/quantiphy-challenge")
from qp.data import load_split
t = load_split("test").set_index("qid")
v2 = pd.read_csv("/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv")
b = v2.set_index("id").parsed_value
V = "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/variants/"
d = pd.read_csv(V+"S3_segtwin.csv").set_index("id").parsed_value
diff = (d-b).abs()>0
ids = diff[diff].index
x = t.loc[ids][["video_id","category","video_source"]].assign(old=b[ids].map(repr), new=d[ids].map(repr))
print(x[x.category!="S3"].to_string()); print(x[x.video_source=="lab"].to_string())
# raw text compare
import csv
raw_b = {r[0]:r[-1] for r in csv.reader(open("/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv"))}
for nm in ["S3_combo","S3_labfix","S3_segtwin","S3_combo_cons"]:
    raw = {r[0]:r[-1] for r in csv.reader(open(V+nm+".csv"))}
    dd = [k for k in raw if raw[k]!=raw_b.get(k)]
    nonS3 = [k for k in dd if k!="id" and t.loc[int(k),"category"]!="S3"]
    print(nm, "text-diff rows", len(dd), "non-S3 text diffs", [(k, raw_b[k], raw[k]) for k in nonS3][:10])
