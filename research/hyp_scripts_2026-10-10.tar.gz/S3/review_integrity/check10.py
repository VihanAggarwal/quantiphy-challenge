import sys, re, numpy as np, pandas as pd
sys.path.insert(0, "/home/user/quantiphy-challenge")
from qp.data import load_split
from qp.mra import item_scores
t = load_split("test"); v = load_split("val")
norm = lambda q: re.sub(r"[^a-z0-9.]", "", str(q).lower())
base_of = lambda x: re.sub(r"(captured_\d+[ab]?)[sxX]?$", r"\1", x)
for d in (t,v):
    d["nq"]=d.question.map(norm); d["base"]=d.video_id.map(base_of); d["np_"]=d.prior.map(norm); d["nd"]=d.depth_info.fillna("").map(norm)
# known rows: test rows whose base clip+nq+prior+depth_info equals a val row (any render)
k = t.merge(v[["base","nq","np_","nd","answer","qid","video_id"]], on=["base","nq","np_","nd"], suffixes=("","_val"), how="inner")
# segmented: val clip id is the segmented id itself, base_of leaves it unchanged -> exact match only
print("known test rows (identical text/prior/depth):", len(k), k.category.value_counts().to_dict())
v2 = pd.read_csv("/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv").set_index("id").parsed_value
V = "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/variants/"
S3k = k[k.category=="S3"]
print("S3 known rows by clip:", S3k.video_id.value_counts().to_dict())
for nm in ["v2","S3_segtwin","S3_labfix","S3_combo","S3_combo_cons"]:
    s = v2 if nm=="v2" else pd.read_csv(V+nm+".csv").set_index("id").parsed_value
    sc = item_scores(s[S3k.qid].values, S3k.answer.astype(float).values)
    ch = (s[S3k.qid]-v2[S3k.qid]).abs().values>1e-9
    lab = (S3k.video_source=="lab").values
    print(f"{nm:14s} S3 known n={len(S3k)} {np.mean(sc):.3f} lab {np.mean(sc[lab]):.3f} (n={lab.sum()}) nonlab {np.mean(sc[~lab]):.3f} (n={(~lab).sum()}); known rows changed: {ch.sum()}")
# which known rows are changed by combo, and new vs GT
s = pd.read_csv(V+"S3_combo.csv").set_index("id").parsed_value
x = S3k.assign(old=v2[S3k.qid].values, new=s[S3k.qid].values)
x = x[(x.new-x.old).abs()>1e-9]
x["sc_old"]=item_scores(x.old.values, x.answer.astype(float).values); x["sc_new"]=item_scores(x.new.values, x.answer.astype(float).values)
pd.set_option("display.width",250)
print(x[["qid","video_id","question","answer","old","new","sc_old","sc_new"]].to_string())
