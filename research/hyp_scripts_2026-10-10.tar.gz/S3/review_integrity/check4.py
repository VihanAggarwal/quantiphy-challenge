import sys, re, numpy as np, pandas as pd
sys.path.insert(0, "/home/user/quantiphy-challenge")
from qp.data import load_split
t = load_split("test")
num = re.compile(r"distance\w*\s*=\s*([0-9]*\.?[0-9]+)\s*(m|cm|mm|km)?", re.I)
hits = []; nclip=0
for (vid, di), g in t[t.depth_info.notna() & (t.depth_info.astype(str).str.len()>0)].groupby(["video_id","depth_info"]):
    ds = [float(x) for x,u in num.findall(di)]
    if len(ds) < 2: continue
    nclip+=1
    for i, d in enumerate(ds):
        others = np.median([x for j,x in enumerate(ds) if j!=i])
        if d > 20*others or d < others/20:
            hits.append((vid, g.category.unique().tolist(), g.video_source.iloc[0], d, others, len(g)))
h = pd.DataFrame(hits, columns=["vid","cats","src","d","others_med","nq"])
print(nclip, "clip/depth groups checked"); print(h.to_string())
# also lower threshold 10x
