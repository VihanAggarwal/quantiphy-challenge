import sys, re, numpy as np, pandas as pd
sys.path.insert(0, "/home/user/quantiphy-challenge")
from qp.data import load_split
t = load_split("test").set_index("qid")
W = "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work/"
rep = pd.read_csv(W+"repro.csv")
ok = np.isclose(rep.geo.astype(float), rep.geo_run.astype(float), rtol=1e-3) | (rep.geo.isna() & rep.geo_run.isna())
print("repro reproduced", ok.sum(), "/", len(rep))
rep["ratio"] = rep.prior_meas/rep.pval
for cat in ["S3","D3"]:
    cr = rep[rep.cat==cat].groupby("vid").ratio.agg(["median","size"]).sort_values("median")
    print(cat, "clip ratio distribution:"); print(cr.head(6).to_string()); print(cr.tail(6).to_string())
lc = pd.read_csv(W+"labfix_changes.csv")
lc["vid"] = lc.qid.map(t.video_id); lc["q"] = lc.qid.map(t.question); lc["prior"]=lc.qid.map(t.prior)
pd.set_option("display.width",250); pd.set_option("display.max_colwidth",70)
print(lc[["qid","vid","why","old","new","q"]].to_string())
print("0034b questions by category:", t[t.video_id.str.startswith("captured_0034b")].category.value_counts().to_dict())
