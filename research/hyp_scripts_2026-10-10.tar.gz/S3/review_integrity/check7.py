import sys, re, numpy as np, pandas as pd
sys.path.insert(0, "/home/user/quantiphy-challenge")
from qp.data import load_split
v = load_split("val")
print(v.video_id.unique().tolist())
seg = v[v.video_id.str.endswith("_segmented")]
print("val segmented clips:", seg.video_id.unique().tolist())
norm = lambda q: re.sub(r"[^a-z0-9.]", "", str(q).lower())
v["nq"] = v.question.map(norm)
for vid in seg.video_id.unique():
    tw = vid.replace("_segmented","")
    a = v[v.video_id==vid].set_index("nq"); b = v[v.video_id==tw].set_index("nq")
    j = a.join(b, rsuffix="_o", how="inner")
    print(vid, "n", len(a), "orig in val:", tw in set(v.video_id), "joined", len(j), "GT equal:", np.isclose(j.answer, j.answer_o).sum() if len(j) else None)
# lab renders in val
print([x for x in v.video_id.unique() if x.startswith("captured")])
