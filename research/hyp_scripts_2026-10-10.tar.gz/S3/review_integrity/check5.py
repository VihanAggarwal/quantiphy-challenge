import csv
V = "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/variants/"
B = list(csv.reader(open("/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv")))
for nm in ["S3_combo","S3_labfix","S3_segtwin","S3_combo_cons"]:
    R = list(csv.reader(open(V+nm+".csv")))
    assert len(R)==len(B)
    bad = [(i,j,B[i][j],R[i][j]) for i in range(len(B)) for j in range(len(B[0])-1) if B[i][j]!=R[i][j]]
    print(nm, "non-value field diffs:", len(bad), bad[:5])
import subprocess
print(subprocess.run(["file", V+"S3_combo.csv", "/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv"],capture_output=True,text=True).stdout)
