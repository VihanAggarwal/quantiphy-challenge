import sys, re, numpy as np, pandas as pd
sys.path.insert(0, "/home/user/quantiphy-challenge")
from qp.data import load_split
t = load_split("test").set_index("qid")
v2 = pd.read_csv("/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv").set_index("id").parsed_value
V = "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/variants/"
s = pd.read_csv(V+"S3_segtwin.csv").set_index("id").parsed_value
ch = [q for q in s.index if abs(s[q]-v2[q])>1e-9*abs(v2[q]) and t.loc[q,"category"]=="S3"]
print("segtwin changed", len(ch))
probs = []
for q in ch:
    r = t.loc[q]
    tw = r.video_id.replace("_segmented","")
    cand = t[(t.video_id==tw)]
    # find candidates whose answer equals new value
    m = cand[np.isclose(v2[cand.index], s[q], rtol=1e-12)]
    m2 = m[(m.question==r.question)]
    ok = len(m2)>0 and (m2.prior==r.prior).all() and (m2.depth_info.fillna("")==("" if pd.isna(r.depth_info) else r.depth_info)).all() and (m2.category=="S3").all()
    if not ok: probs.append((q, r.video_id, r.question, r.prior, len(m), len(m2)))
    else:
        pass
print("pairs not identical in (question, prior, depth_info, category):", len(probs))
for p in probs: print(p)
# show raw difference type
for q in ch:
    r = t.loc[q]; tw = r.video_id.replace("_segmented","")
    cand = t[(t.video_id==tw)]
    m = cand[np.isclose(v2[cand.index], s[q], rtol=1e-12)]
    if len(m) and (m.question.iloc[0]!=r.question or m.depth_info.iloc[0]!=r.depth_info):
        print("DIFF", q, repr(r.question), repr(m.question.iloc[0]), repr(r.depth_info)[:120], "||", repr(m.depth_info.iloc[0])[:120])
# list clips
print(t.loc[ch].video_id.value_counts().to_dict())
