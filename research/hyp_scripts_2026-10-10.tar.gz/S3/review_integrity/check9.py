import sys, re, numpy as np, pandas as pd
sys.path.insert(0, "/home/user/quantiphy-challenge")
from qp.data import load_split
t = load_split("test").set_index("qid")
v = load_split("val")
run = pd.read_csv("/home/user/quantiphy-challenge/runs/test_v1_high_854/test.csv").set_index("id")
v2 = pd.read_csv("/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv").set_index("id").parsed_value
V = "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/variants/"
gtvals = v.answer.astype(float).values
for nm in ["S3_combo","S3_combo_cons"]:
    s = pd.read_csv(V+nm+".csv").set_index("id").parsed_value
    ch = s.index[(s-v2).abs()>1e-9*v2.abs()]
    hits=[]
    for q in ch:
        eq = np.isclose(gtvals, s[q], rtol=1e-6)
        if eq.any():
            # is the new value also present in the test run's own outputs (direct/geo) of some question?
            src_dir = np.isclose(run.direct_value.astype(float), s[q], rtol=1e-9).sum()
            src_geo = np.isclose(run.geo_value.astype(float), s[q], rtol=1e-9).sum()
            src_v2 = np.isclose(v2.astype(float), s[q], rtol=1e-9).sum()
            hits.append((q, t.loc[q,"video_id"], s[q], v.qid.values[eq].tolist(), src_dir, src_geo, src_v2))
    print(nm, "changed", len(ch), "new values that coincide with some val GT:", len(hits))
    for h in hits: print("  ", h)
    # every new value must come from a model output: v2 value of another qid, run direct/geo value, or a log-median/re-solve
    notfound=[]
    for q in ch:
        x=s[q]
        if not (np.isclose(v2.drop(q).astype(float), x, rtol=1e-9).any() or np.isclose(run.direct_value.astype(float), x, rtol=1e-9).any()):
            notfound.append(q)
    print("  new values not equal to any v2 answer/direct value elsewhere:", len(notfound), t.loc[notfound].video_id.value_counts().to_dict())
