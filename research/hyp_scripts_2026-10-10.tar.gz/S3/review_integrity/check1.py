import sys, numpy as np, pandas as pd
sys.path.insert(0, "/home/user/quantiphy-challenge")
from qp.data import load_split
t = load_split("test").set_index("qid")
tmpl = pd.read_csv("/home/user/quantiphy-challenge/data/submission_template/quantiphy_submission_template.csv")
v2 = pd.read_csv("/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv")
print("v2 cols", list(v2.columns), len(v2), "template", len(tmpl), "test", len(t))
print("v2 ids == template ids (ordered):", (v2.id.values == tmpl.id.values).all() if len(v2)==len(tmpl) else False)
b = v2.set_index("id").parsed_value
V = "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/review_integrity/"
for nm in ["S3_combo_clean","S3_labfix_clean","S3_segtwin_clean","S3_combo_cons_clean"]:
    d = pd.read_csv(V+nm+".csv")
    ok_cols = list(d.columns)==list(v2.columns)
    ok_ids = len(d)==len(tmpl) and (d.id.values==tmpl.id.values).all()
    dup = d.id.duplicated().sum()
    vals = pd.to_numeric(d.parsed_value, errors="coerce")
    fin = np.isfinite(vals).all(); pos = (vals>0).all()
    s = d.set_index("id").parsed_value
    diff = (s - b).abs() > 0   # strict any difference
    ids = diff[diff].index
    cats = t.loc[ids,"category"].value_counts().to_dict()
    srcs = t.loc[ids,"video_source"].value_counts().to_dict()
    r = s[ids]/b[ids]
    print(f"{nm}: cols {ok_cols} ids {ok_ids} dup {dup} finite {fin} pos {pos} n_changed {len(ids)} cats {cats} srcs {srcs} median ratio {r.median():.3f} min {r.min():.3f} max {r.max():.3f} min val {vals.min():.4g} max {vals.max():.4g}")
    # check other columns identical to v2 (only id, parsed_value expected)
