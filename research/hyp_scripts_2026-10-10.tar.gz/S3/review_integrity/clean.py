"""Write byte-clean copies: identical to v2 text except the parsed_value of rows whose value really changed (rel > 1e-9).
Removes the float re-serialisation noise (1-ULP diff on D3 qid 2281, ~25 cosmetic text diffs)."""
import csv, io, sys, math
sys.path.insert(0, "/home/user/quantiphy-challenge")
from qp.data import load_split
cat = dict(zip(load_split("test").qid, load_split("test").category))
V2 = "/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv"
V = "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/variants/"
OUT = "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/review_integrity/"
raw = open(V2, newline="").read()
B = list(csv.reader(io.StringIO(raw)))
def dump(rows):
    s = io.StringIO(); w = csv.writer(s, lineterminator="\n"); w.writerows(rows); return s.getvalue()
assert dump(B) == raw, "writer does not round-trip v2"
for nm in ["S3_combo", "S3_labfix", "S3_segtwin", "S3_combo_cons"]:
    R = list(csv.reader(open(V + nm + ".csv", newline="")))
    out = [list(r) for r in B]; n = 0; cats = {}
    for i in range(1, len(B)):
        assert R[i][:-1] == B[i][:-1]
        a, b = float(B[i][-1]), float(R[i][-1])
        if abs(b - a) > 1e-9 * abs(a):
            assert math.isfinite(b) and b > 0
            out[i][-1] = R[i][-1]; n += 1; c = cat[int(B[i][0])]; cats[c] = cats.get(c, 0) + 1
    open(OUT + nm + "_clean.csv", "w", newline="").write(dump(out))
    print(nm, "changed", n, cats)
