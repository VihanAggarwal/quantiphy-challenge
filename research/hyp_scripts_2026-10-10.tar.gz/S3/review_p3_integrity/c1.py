import sys, csv, math, numpy as np, pandas as pd
sys.path.insert(0, "/home/user/quantiphy-challenge")
from qp.data import load_split
t = load_split("test").set_index("qid")
tmpl = pd.read_csv("/home/user/quantiphy-challenge/data/submission_template/quantiphy_submission_template.csv")
P3 = "/home/user/quantiphy-challenge/submissions/trackA_probe3_s2maxext_d2denseoff_labdirect.csv"
V = "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/variants_labdirect/"
print("template cols", list(tmpl.columns), len(tmpl))
Braw = list(csv.reader(open(P3, newline="")))
print("p3 header", Braw[0], len(Braw)-1)
for nm in ["S3p3_split_full","S3p3_direct_full","S3p3_split_only","S3p3_segtwin_only","S3p3_segtwin_render"]:
    R = list(csv.reader(open(V+nm+".csv", newline="")))
    assert R[0] == Braw[0], R[0]
    assert len(R) == len(Braw)
    ids_ok = all(R[i][0] == Braw[i][0] for i in range(1, len(R)))
    tmpl_ok = [int(r[0]) for r in R[1:]] == list(tmpl.id)
    textdiff = [i for i in range(1, len(R)) if R[i] != Braw[i]]
    valdiff = [i for i in range(1, len(R)) if float(R[i][-1]) != float(Braw[i][-1])]
    cats_text = pd.Series([t.loc[int(R[i][0]), "category"] for i in textdiff]).value_counts().to_dict()
    cats_val = pd.Series([t.loc[int(R[i][0]), "category"] for i in valdiff]).value_counts().to_dict()
    vals = np.array([float(r[-1]) for r in R[1:]])
    rel = [abs(float(R[i][-1])/float(Braw[i][-1]) - 1) for i in valdiff]
    tiny = sum(r < 1e-9 for r in rel)
    print(f"{nm}: ids==p3 {ids_ok} ids==template {tmpl_ok} finite {np.isfinite(vals).all()} pos {(vals>0).all()} min {vals.min():.4g} max {vals.max():.4g} | textdiff {len(textdiff)} {cats_text} | valdiff {len(valdiff)} {cats_val} tiny(<1e-9) {tiny}")
    # other columns? only id,parsed_value
    nonS3 = [(R[i][0], Braw[i][-1], R[i][-1]) for i in textdiff if t.loc[int(R[i][0]), "category"] != "S3"]
    if nonS3: print("   non-S3 text diffs:", nonS3[:10])
    r = np.array([float(R[i][-1])/float(Braw[i][-1]) for i in valdiff])
    print(f"   median ratio {np.median(r):.3f}  >10%: {(np.abs(np.log(r))>np.log(1.1)).sum()} src", pd.Series([t.loc[int(R[i][0]), 'video_source'] for i in valdiff]).value_counts().to_dict())
