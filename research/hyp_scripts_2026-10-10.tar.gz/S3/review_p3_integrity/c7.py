import sys, csv
sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
t = test(); v = val()
print("test columns:", list(t.columns))
for x in (t, v):
    x["twin"] = x.video_id.str.replace("_segmented", "", regex=False).map(base_of); x["nq"] = x.question.map(normq)
gt = v.set_index(["twin", "nq"]).answer; gt = gt[~gt.index.duplicated()]
t["ans"] = [gt.get((a, b), np.nan) for a, b in zip(t.twin, t.nq)]
allgt = set(np.round(v.answer.astype(float), 6))
P3F = "/home/user/quantiphy-challenge/submissions/trackA_probe3_s2maxext_d2denseoff_labdirect.csv"
p3 = pd.read_csv(P3F).set_index("id").parsed_value
pv = v2().set_index("id").parsed_value
V = SP + "/variants_labdirect/"
S = t[t.category == "S3"].set_index("qid")
for nm in ["S3p3_split_full", "S3p3_direct_full", "S3p3_split_only", "S3p3_segtwin_only"]:
    f = pd.read_csv(V + nm + ".csv").set_index("id").parsed_value
    ch = [q for q in S.index if f[q] != p3[q]]
    known = [q for q in ch if np.isfinite(S.loc[q, "ans"])]
    eq_new = sum(np.isclose(f[q], S.loc[q, "ans"], rtol=1e-6, atol=0) for q in known)
    eq_old = sum(np.isclose(p3[q], S.loc[q, "ans"], rtol=1e-6, atol=0) for q in known)
    eq_v2 = sum(np.isclose(pv[q], S.loc[q, "ans"], rtol=1e-6, atol=0) for q in known)
    anygt_new = sum(round(f[q], 6) in allgt for q in ch); anygt_old = sum(round(p3[q], 6) in allgt for q in ch)
    print(f"{nm}: changed {len(ch)} known {len(known)} | new==its GT {eq_new}  old==its GT {eq_old}  v2==GT {eq_v2} | new value in any val GT {anygt_new} vs old {anygt_old}")
    if eq_new:
        for q in known:
            if np.isclose(f[q], S.loc[q, "ans"], rtol=1e-6, atol=0): print("   ", q, S.loc[q, "video_id"], S.loc[q, "question"], f[q], "old", p3[q])
# 0034b mapping check vs 0034as GT
b = t[t.video_id.str.startswith("captured_0034b")]
v34 = v[v.video_id == "captured_0034as"].set_index("nq").answer
fs = pd.read_csv(V + "S3p3_split_full.csv").set_index("id").parsed_value
fd = pd.read_csv(V + "S3p3_direct_full.csv").set_index("id").parsed_value
a = t[t.video_id.str.startswith("captured_0034a")]
for r in b.itertuples():
    sib = a[a.nq == r.nq]
    print(r.qid, r.video_id, r.question[:45], "| split", round(fs[r.qid], 4), "direct", round(fd[r.qid], 4), "p3", round(p3[r.qid], 4), "| med(0034a v2)", round(float(np.exp(np.median(np.log(pv[sib.qid])))), 4), "0034a p3", [round(p3[q], 3) for q in sib.qid], "| 0034as GT", v34.get(r.nq))
