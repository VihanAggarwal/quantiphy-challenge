import sys, csv
sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
t = test(); pv = v2().set_index("id").parsed_value; run = run_csv().set_index("id")
P3F = "/home/user/quantiphy-challenge/submissions/trackA_probe3_s2maxext_d2denseoff_labdirect.csv"
p3 = pd.read_csv(P3F).set_index("id").parsed_value
d = t[(t.depth_info == t[t.video_id=="captured_0034b"].depth_info.iloc[0])]
print("rows sharing 0034b depth_info:", d.video_id.value_counts().to_dict())
c = t[t.question.str.contains("white cup", case=False) & t.video_id.str.match(r"captured_00(3[6-9]|4[01])")]
for r in c.itertuples(): print(r.qid, r.video_id, r.category, r.question.strip(), "| v2", round(pv[r.qid], 2), run.method[r.qid], "geo", round(run.geo_value[r.qid], 2), "dir", run.direct_value[r.qid])
f = pd.read_csv(SP + "/variants_labdirect/S3p3_segtwin_only.csv").set_index("id").parsed_value
s19 = t[t.video_id == "simulation_0019_segmented"]
t["nq"] = t.question.map(normq)
for r in s19.itertuples():
    o = t[(t.video_id == "simulation_0019") & (t.nq == normq(r.question))]
    print(r.qid, r.category, r.question.strip()[:70], "| p3", round(p3[r.qid], 3), "-> new", round(f[r.qid], 3), "| orig", o.qid.tolist(), o.category.tolist())
# all non-value columns identical vs probe 3
B = list(csv.reader(open(P3F)))
for nm in ["S3p3_split_full", "S3p3_direct_full", "S3p3_split_only", "S3p3_segtwin_only"]:
    R = list(csv.reader(open(SP + f"/variants_labdirect/{nm}.csv")))
    print(nm, "non-value columns identical:", all(R[i][:-1] == B[i][:-1] for i in range(len(B))))
