import sys
sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
from qp.geometry import solve
from qp import combine
from qp.spec import DepthEntry
import copy
t = test(); run = run_csv().set_index("id")
pv = v2().set_index("id").parsed_value
V = SP + "/variants_labdirect/"
sf = pd.read_csv(V + "S3p3_split_full.csv").set_index("id").parsed_value
so = pd.read_csv(V + "S3p3_split_only.csv").set_index("id").parsed_value
x = t[t.video_id.str.startswith("captured_0040")]
anns, recs = anns_for(x)
for q, a in sorted(anns.items()):
    m = recs[t.set_index("qid").loc[q, "video_id"]]["meta"]
    A0 = solve(a.spec, a.tracks, tuple(m["image_size"]), float(m["fps"]), camera_fov_deg=84.0, seen_scale=float(m["scale"]))
    sp = copy.deepcopy(a.spec)
    sp.depth = [DepthEntry(object=e.object, distance_m=(0.842 if e.distance_m == 8420.0 else e.distance_m), time=e.time) for e in a.spec.depth]
    A = solve(sp, a.tracks, tuple(m["image_size"]), float(m["fps"]), camera_fov_deg=84.0, seen_scale=float(m["scale"]))
    fl = [f for f in str(run.loc[q, "flags"]).split(";") if not f.startswith("geo:") and f != "geo_rejected_implausible"] + [f"geo:{f}" for f in A.flags]
    v, how, add = combine.choose(A.value, run.loc[q, "direct_value"], fl, True, "lab", A.method)
    print(q, a.spec.target.kind, f"orig geo {A0.value!s:.8} run.geo {run.loc[q,'geo_value']} meth {run.loc[q,'method']} | fixed geo {A.value:.6g} choose {v:.6g} {how} | v2 {pv[q]} split_full {sf[q]:.6g} split_only {so[q]:.6g} | flags0 {A0.flags} run flags {run.loc[q,'flags']}")
