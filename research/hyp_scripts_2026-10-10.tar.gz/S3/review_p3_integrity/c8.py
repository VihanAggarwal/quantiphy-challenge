import sys
sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
t = test()
P3F = "/home/user/quantiphy-challenge/submissions/trackA_probe3_s2maxext_d2denseoff_labdirect.csv"
p3 = pd.read_csv(P3F).set_index("id").parsed_value
f = pd.read_csv(SP + "/variants_labdirect/S3p3_segtwin_only.csv").set_index("id").parsed_value
S = t[t.category == "S3"]
ch = S[[f[q] != p3[q] for q in S.qid]]
print(ch.groupby(["video_id", "video_source"]).size().to_dict())
seg = S[S.video_id.str.endswith("_segmented")]
print("S3 segmented rows", len(seg), "clips", seg.video_id.nunique(), "changed", len(ch))
uncovered = seg[~seg.qid.isin(ch.qid)]
print("segmented S3 rows not changed:", uncovered.groupby("video_id").size().to_dict())
# for changed: source of original
t["nq"] = t.question.map(normq)
o = t[~t.video_id.str.endswith("_segmented")].set_index(["video_id","nq"])
src = {}
for r in ch.itertuples():
    k = (r.video_id.replace("_segmented",""), normq(r.question))
    if k in o.index: src[o.loc[k].category if isinstance(o.loc[k], pd.Series) else tuple(o.loc[[k]].category)] = src.get(o.loc[k].category, 0) + 1
print("original twin categories:", src)
# same depth string as 0034b, outside 0034 family
d = t[(t.depth_info == t[t.video_id=="captured_0034b"].depth_info.iloc[0])]
print("rows sharing 0034b depth_info:", d.video_id.value_counts().to_dict())
