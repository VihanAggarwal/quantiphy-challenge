import sys, csv
sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
import pickle
specs = pickle.load(open(SP + "/work/specs.pkl", "rb"))
t = test(); run = run_csv().set_index("id")
S = t[(t.category == "S3") & (t.video_source == "lab")].copy()
S["kind"] = S.qid.map(lambda q: specs[q].target.kind)
for k in ("distance", "other"):
    print(k, S[S.kind == k].question.str.strip().value_counts().to_dict())
# question words that look like motion inside static kinds, or static in motion kinds
mot = S.question.str.contains("velocity|speed|travel|acceleration|moved|displacement", case=False)
print("static-kind rows with motion words:", S[S.kind.isin(["size","other","distance"]) & mot][["qid","question"]].values.tolist())
print("motion-kind rows without motion words:", S[~S.kind.isin(["size","other","distance"]) & ~mot][["qid","kind","question"]].values.tolist())
# D3 lab same check
specsD = {q: s for q, s in specs.items()}
D = t[(t.category == "D3") & (t.video_source == "lab")].copy(); D["kind"] = D.qid.map(lambda q: specs[q].target.kind)
motD = D.question.str.contains("velocity|speed|travel|acceleration|moved|displacement", case=False)
print("D3 static-kind w/ motion words:", int((D.kind.isin(["size","other","distance"]) & motD).sum()), " D3 motion-kind w/o motion words:", int((~D.kind.isin(["size","other","distance"]) & ~motD).sum()))
print("D3 kinds", D.kind.value_counts().to_dict())
# exact equality with v2 text for the 'v2' rows
P3F = "/home/user/quantiphy-challenge/submissions/trackA_probe3_s2maxext_d2denseoff_labdirect.csv"
V2F = "/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv"
txt = lambda f: {int(r[0]): r[-1] for r in list(csv.reader(open(f)))[1:]}
p3t, v2t = txt(P3F), txt(V2F)
dec = pd.read_csv(SP + "/work/labfix_changes.csv").set_index("qid"); dec = dec[dec.why.str.startswith("a_")].new
for nm in ["S3p3_split_full", "S3p3_split_only"]:
    ft = txt(SP + f"/variants_labdirect/{nm}.csv")
    st = S[S.kind.isin(["size","other","distance"]) & ~S.video_id.str.startswith("captured_0034b")]
    geo = st[run.method[st.qid].str.startswith("geometry").values]
    exact_txt = sum(ft[q] == v2t[q] for q in geo.qid); exact_f = sum(float(ft[q]) == float(v2t[q]) for q in geo.qid)
    dd = [(q, ft[q], repr(float(dec[q]))) for q in dec.index]
    dec_exact = sum(float(ft[q]) == float(dec[q]) for q in dec.index)
    print(f"{nm}: static non-0034b lab rows {len(st)}, v2-geometry rows {len(geo)}: text==v2 {exact_txt} float==v2 {exact_f}; dec rows exact {dec_exact}/{len(dec)}")
    bad = [(q, ft[q], v2t[q]) for q in geo.qid if ft[q] != v2t[q]]
    print("   text mismatches:", bad[:5])
    print("   v2 geometry rows where v2 == p3 (unchanged):", sum(float(v2t[q]) == float(p3t[q]) for q in geo.qid))
    nongeo = st[~run.method[st.qid].str.startswith("geometry").values & ~st.qid.isin(dec.index)]
    print("   static non-geometry non-dec rows:", len(nongeo), "of which ==p3:", sum(float(ft[q]) == float(p3t[q]) for q in nongeo.qid), "== v2:", sum(float(ft[q]) == float(v2t[q]) for q in nongeo.qid))
