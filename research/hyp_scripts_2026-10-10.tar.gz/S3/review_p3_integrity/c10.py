import sys
sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
lab = pd.read_pickle(SP + "/work/p3lab.pkl")
x = lab[lab.chg]
print(pd.crosstab([x.category, x.grp], x.kind))
print("changed per category:", x.category.value_counts().to_dict())
# fraction of changed answers with >25% disagreement by cat x grp
print(x.assign(big=np.abs(x.lr) > np.log(1.25)).groupby(["category","grp"]).big.agg(["size","mean"]).round(3))
