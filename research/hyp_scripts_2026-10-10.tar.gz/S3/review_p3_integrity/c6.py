import sys
sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
pd.set_option("display.width", 250)
t = test(); t["nq"] = t.question.map(normq)
rep = pd.read_csv(SP + "/work/repro.csv"); rep["ratio"] = rep.prior_meas / rep.pval
for c in ("S3", "D3"):
    cr = rep[rep.cat == c].groupby("vid").ratio.agg(["median", "size"])
    print(c, "clips", len(cr), "flagged (<1/1.75 or >1.75):", cr[(cr["median"] < 1/1.75) | (cr["median"] > 1.75)].round(3).to_dict("index"))
    s = cr["median"].sort_values()
    print("   most extreme 4 each side:", s.head(4).round(3).to_dict(), s.tail(4).round(3).to_dict())
x = t[t.video_id.str.startswith("captured_0034")]
print(x.groupby(["video_id", "category"]).size().to_dict())
for v in sorted(x.video_id.unique()):
    print(v, "| depth:", x[x.video_id == v].depth_info.unique().tolist(), "| priors:", x[x.video_id == v].prior.unique().tolist())
a = x[x.video_id == "captured_0034a"]; b = x[x.video_id == "captured_0034b"]
print("0034a qs:", a.question.tolist()); print("0034b qs:", b.question.tolist())
v = val(); print("val 0034 clips:", v[v.video_id.str.startswith("captured_0034")].video_id.unique().tolist())
