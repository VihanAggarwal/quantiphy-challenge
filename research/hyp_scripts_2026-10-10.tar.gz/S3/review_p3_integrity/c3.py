import sys
sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
import pickle
specs = pickle.load(open(SP + "/work/specs.pkl", "rb"))
t = test(); run = run_csv().set_index("id")
P3F = "/home/user/quantiphy-challenge/submissions/trackA_probe3_s2maxext_d2denseoff_labdirect.csv"
p3 = pd.read_csv(P3F).set_index("id").parsed_value
pv = v2().set_index("id").parsed_value
t["twin"] = t.video_id.str.replace("_segmented", "", regex=False).map(base_of); t["nq"] = t.question.map(normq)
S = t[t.category == "S3"].copy()
S["kind"] = S.qid.map(lambda q: specs[q].target.kind if q in specs else "?")
print("kinds S3 lab:", S[S.video_source=="lab"].kind.value_counts().to_dict())
lab = S[S.video_source == "lab"].copy()
lab["var"] = [v[len(b):] for v, b in zip(lab.video_id, lab.twin)]
print("vars:", lab["var"].value_counts().to_dict())
orig = lab[lab["var"] == ""].set_index(["twin","nq"])
mism = 0; missing = 0
for r in lab[lab["var"] != ""].itertuples():
    if (r.twin, r.nq) not in orig.index: missing += 1; continue
    o = orig.loc[(r.twin, r.nq)]
    if o.prior != r.prior or o.depth_info != r.depth_info:
        mism += 1; print("MISMATCH", r.qid, r.video_id, "|", r.prior, "|", o.prior, "|", r.depth_info[:80], "|", o.depth_info[:80])
print("s/x rows", (lab["var"]!="").sum(), "no original", missing, "prior/depth mismatch", mism)
dec = pd.read_csv(SP + "/work/labfix_changes.csv").set_index("qid"); dec = dec[dec.why.str.startswith("a_")].new
V = SP + "/variants_labdirect/"
for nm in ["S3p3_split_full", "S3p3_direct_full", "S3p3_split_only", "S3p3_segtwin_only"]:
    f = pd.read_csv(V + nm + ".csv").set_index("id").parsed_value
    ch = S[~np.isclose(f[S.qid].values, p3[S.qid].values, rtol=1e-12, atol=0)]
    prov = {}
    for r in ch.itertuples():
        x = f[r.qid]; tags = []
        if r.video_source == "lab":
            if np.isclose(x, pv[r.qid], rtol=1e-12, atol=0): tags.append("v2")
            if r.qid in dec.index and np.isclose(x, dec[r.qid], rtol=1e-12, atol=0): tags.append("dec")
            if (r.twin, r.nq) in orig.index and np.isclose(x, run.direct_value[orig.loc[(r.twin, r.nq)].qid], rtol=1e-12, atol=0): tags.append("dir_orig")
            if r.twin == "captured_0034b": tags.append("0034b")
        else:
            tags.append("segtwin")
        k = (r.video_source, "static" if r.kind in ("size","other","distance") else "motion", "+".join(tags) or "UNEXPLAINED")
        prov[k] = prov.get(k, 0) + 1
    print(nm, len(ch))
    for k, v in sorted(prov.items()): print("   ", k, v)
