import sys
sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
import pickle
specs = pickle.load(open(SP + "/work/specs.pkl", "rb"))
t = test(); run = run_csv().set_index("id")
P3F = "/home/user/quantiphy-challenge/submissions/trackA_probe3_s2maxext_d2denseoff_labdirect.csv"
p3 = pd.read_csv(P3F).set_index("id").parsed_value
pv = v2().set_index("id").parsed_value
t["twin"] = t.video_id.str.replace("_segmented", "", regex=False).map(base_of); t["nq"] = t.question.map(normq)
print("run cols", list(run.columns))
lab = t[(t.video_source == "lab") & t.category.isin(["S3","D3"])].copy()
lab["dir"] = lab.qid.map(run.direct_value); lab["meth"] = lab.qid.map(run.method); lab["geo"] = lab.qid.map(run.geo_value)
lab["p3"] = lab.qid.map(p3); lab["v2"] = lab.qid.map(pv)
for c in ("S3","D3"):
    x = lab[lab.category == c]
    print(c, "n", len(x), "p3==run.direct exact:", int((x.p3 == x.dir).sum()), "isclose:", int(np.isclose(x.p3, x.dir, rtol=1e-9, atol=0).sum()))
    g = x[x.meth.str.startswith("geometry")]
    print("  meth geometry n", len(g), "v2==geo exact", int((g.v2 == g.geo).sum()), "isclose", int(np.isclose(g.v2, g.geo, rtol=1e-9, atol=0).sum()))
    d = x[~x.meth.str.startswith("geometry")]
    print("  meth non-geometry n", len(d), d.meth.value_counts().to_dict(), "v2==dir isclose", int(np.isclose(d.v2, d.dir, rtol=1e-9, atol=0).sum()))
# duplicate (twin, nq) with different prior/depth_info among lab S3
S = lab[lab.category == "S3"]
g = S.groupby(["video_id", "nq"])
dups = g.filter(lambda d: len(d) > 1)
print("S3 lab rows sharing (video_id,nq):", len(dups))
if len(dups):
    print(dups[["qid","video_id","prior","depth_info","question"]].head(20).to_string())
# any original-render dup keys
