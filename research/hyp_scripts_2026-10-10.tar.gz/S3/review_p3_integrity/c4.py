import sys
sys.path.insert(0, "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S3/work")
from common import *
import pickle, re
specs = pickle.load(open(SP + "/work/specs.pkl", "rb"))
t = test()
# 1. raw depth_info of 0040 rows
x = t[t.video_id.str.startswith("captured_0040")]
print(x.groupby(["video_id","category"]).size().to_dict())
for di in x.depth_info.unique(): print("DEPTH_INFO 0040:", di)
for r in x[x.category=="S3"].itertuples(): print(r.qid, r.video_id, r.question, "| prior:", r.prior)
# 2. generic detector over every test question with depth_info: raw-text numbers in metres
def nums(s):
    return [float(m) for m in re.findall(r"(\d+(?:\.\d+)?)\s*m\b", str(s))]
hits = []
d = t[t.depth_info.notna() & (t.depth_info.astype(str).str.len() > 0)]
for di, g in d.groupby("depth_info"):
    ns = nums(di)
    for i, n in enumerate(ns):
        others = [y for j, y in enumerate(ns) if j != i]
        if not others: continue
        med = np.median(others)
        if n > 20 * med: hits.append((g.video_id.unique().tolist()[:6], n, med, di[:160]))
print("raw-text detector hits (any test 3D row):", len(hits))
for h in hits: print("  ", h)
# 3. same detector on spec depth entries (Claude's parsed depth), all lab/all 3D
hs = {}
for q, sp in specs.items():
    ds = [e.distance_m for e in sp.depth]
    for e in sp.depth:
        others = [y for y in ds if y is not e.distance_m]
        if not others: continue
        if e.distance_m > 20 * np.median(others):
            vid = t.set_index("qid").loc[q, "video_id"] if q in set(t.qid) else "?"
            hs.setdefault(vid, set()).add((e.object, e.distance_m))
print("spec detector hits by video:", {k: sorted(v) for k, v in hs.items()})
print("specs cover", len(specs), "questions; categories", t[t.qid.isin(specs.keys())].category.value_counts().to_dict())
