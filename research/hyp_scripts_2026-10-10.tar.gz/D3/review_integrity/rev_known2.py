import sys
W='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/work'
sys.path.insert(0,W)
import warnings; warnings.filterwarnings('ignore')
import pandas as pd, numpy as np, re
from harness import known, nk
from load import base_id
from qp.data import load_split
v=load_split('val').set_index('qid')
k=known(); k=k[k.category=='D3']
k['vdepth']=k.val_qid.map(v.depth_info)
norm=lambda s: re.sub(r'\s+','',str(s))
k['same_depth']=k.depth_info.map(norm)==k.vdepth.map(norm)
print('known D3 rows',len(k),'same depth_info',k.same_depth.sum())
print(k[~k.same_depth][['qid','val_qid','video_id','depth_info','vdepth']].to_string())
print(k.groupby(['video_source','base']).size())
