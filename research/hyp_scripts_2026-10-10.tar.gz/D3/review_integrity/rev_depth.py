import sys; sys.path.insert(0,'/home/user/quantiphy-challenge')
from qp.data import load_split
import pandas as pd
t=load_split('test')
for vids in [('simulation_0023','simulation_0025','simulation_0026'),('simulation_0029','simulation_0035','simulation_0036'),('simulation_0021','simulation_0033'),('simulation_0039','simulation_0040','simulation_0042'),('simulation_0299','simulation_0300','simulation_0301','simulation_0310','simulation_0311')]:
    print('#########',vids)
    for v in vids:
        g=t[t.video_id==v]
        print('---',v, g.category.unique(), g.video_type.unique())
        for di in g.depth_info.unique(): print('  DEPTH:', di.replace('\n',' | '))
        for p in g.prior.unique(): print('  PRIOR:', p.replace('\n',' | '))
