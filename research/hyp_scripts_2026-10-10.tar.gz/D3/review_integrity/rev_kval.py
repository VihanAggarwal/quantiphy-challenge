import sys
W='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/work'
sys.path.insert(0,W)
import warnings; warnings.filterwarnings('ignore')
import pandas as pd, numpy as np
from kval import *
for name,(sp,rn) in runs.items():
    try: m=load_run(sp,rn)
    except Exception as e: print(name,'ERR',e); continue
    m=m[~m.qid.isin(SUS)]
    d=m[(m.category=='D3')&(m.video_source=='lab')].copy()
    if 'method' not in d: print(name,'no method col'); continue
    kk=video_k(d,min_n=2); kv=np.exp(kk['median'])
    sel=(d.method=='direct')&d.kind.isin(('size','distance'))&d.video_id.isin(kv.index)&d.direct_value.notna()
    new=d.parsed_value.astype(float).copy()
    new[sel]=d.loc[sel,'direct_value']*d.loc[sel,'video_id'].map(kv)
    s0=item_scores(d.parsed_value.astype(float),d.answer); s1=item_scores(new,d.answer)
    print('%-12s lab D3 n=%d  rows touched %d (videos %s)  old %.3f new %.3f  | touched rows old %.3f new %.3f'%(name,len(d),sel.sum(),sorted(d.loc[sel,'video_id'].unique()),np.mean(s0),np.mean(s1), np.mean(np.array(s0)[sel.values]) if sel.any() else np.nan, np.mean(np.array(s1)[sel.values]) if sel.any() else np.nan))
