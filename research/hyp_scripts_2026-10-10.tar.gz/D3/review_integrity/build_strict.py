"""D3_main_transfer with the sibling transfer restricted to what the bundle claims: the target object's own
depth_info entries (time, distance) must be identical in the asking clip and the prior's clip."""
import sys, os, re
os.environ['ANTHROPIC_API_KEY']=''; os.environ['ANTHROPIC_BASE_URL']='http://127.0.0.1:9'
W='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/work'
sys.path.insert(0,W)
import warnings; warnings.filterwarnings('ignore')
from steps import *
import transfer as TR
from qp.data import load_split
OUT='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/review_integrity/'
ALIAS={'person':'human','people':'human','man':'human','woman':'human'}
ENT=re.compile(r'(?:t\s*=\s*([\d.]+)\s*s[^,|]*,\s*)?distance_([a-z0-9_]+?)_camera\s*=\s*([\d.]+)', re.I)
def obj_entries(di, obj):
    toks=[ALIAS.get(w,w) for w in obj.split()]
    out=set()
    for line in str(di).split('\n'):
        for tm,name,val in ENT.findall(line):
            nt=[ALIAS.get(w,w) for w in name.lower().split('_')]
            if set(toks)<=set(nt) or set(nt)<=set(toks):
                out.add((tm, val))
    return out
t=load_split('test'); t['base']=t.video_id.map(base_id)
DI={b: '\n'.join(g.depth_info.unique()) for b,g in t.groupby('base')}
def sibling_transfer_strict(m):
    c=TR.candidates(); keep={}; drop=[]
    for r in c.itertuples():
        pq=TR.parse_q(r.question); obj=pq[1]
        b=base_id(r.video_id)
        mine=obj_entries(DI[b],obj)
        ok=bool(mine) and all(obj_entries(DI[s],obj)==mine for s in r.src.split(','))
        (keep.__setitem__(r.qid,r.transfer) if ok else drop.append((r.qid,r.video_id,r.question,r.src,sorted(mine),[sorted(obj_entries(DI[s],obj)) for s in r.src.split(',')])))
    print('strict keep',len(keep),'drop',len(drop))
    for d in drop: print('  DROP',d)
    sel=m.qid.isin(list(keep))&(m.category=='D3')
    m.loc[sel,'ans']=m.loc[sel,'qid'].map(keep); m.loc[sel,'method']='transfer'
    return m,int(sel.sum())
m=base_table()
for f in [lab_relink,lab_notime,lab_kcal_static,lab_render_direct_motion,sibling_transfer_strict,segtwin]:
    m,n=f(m); print(f.__name__,n)
v2=pd.read_csv(R+'/submissions/trackA_opus55_high_v2.csv')
upd=dict(zip(m.loc[m.category=='D3','qid'], m.loc[m.category=='D3','ans']))
new=v2.copy(); sel=new.id.isin(list(upd)); new.loc[sel,'parsed_value']=new.loc[sel,'id'].map(upd)
cats=t.set_index('qid').loc[new.id,'category'].values
ch=~np.isclose(v2.parsed_value.values,new.parsed_value.values,rtol=1e-12)
assert set(cats[ch])<={'D3'}
assert list(new.id)==list(v2.id) and np.isfinite(new.parsed_value).all() and (new.parsed_value>0).all()
out=OUT+'D3_main_transfer_strict.csv'; new.to_csv(out,index=False)
r=new.parsed_value.values[ch]/v2.parsed_value.values[ch]
main=pd.read_csv('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/D3_main_transfer.csv')
dm=~np.isclose(main.parsed_value.values,new.parsed_value.values,rtol=1e-12)
print('wrote',out,'changed vs v2',ch.sum(),'median ratio %.4f'%np.median(r),'| differs from D3_main_transfer on',dm.sum(),'rows:',list(new.id[dm]), list(zip(main.parsed_value[dm],new.parsed_value[dm])))
