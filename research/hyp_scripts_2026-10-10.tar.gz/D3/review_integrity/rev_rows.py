import sys
W='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/work'
sys.path.insert(0,W)
import warnings; warnings.filterwarnings('ignore')
import pickle, pandas as pd, numpy as np
from harness import known, SUS
pd.set_option('display.width',300); pd.set_option('display.max_colwidth',70); pd.set_option('display.max_rows',500)
log=pickle.load(open('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/review_integrity/repro.pkl','rb'))
m=log['D3_main_transfer']
k=known(); k=k[k.category=='D3']
m['known']=m.qid.isin(k.qid)
c=m[(m.category=='D3')&(m.step!='')].copy()
c['ratio']=c.ans/c.v2
print(c.groupby('step').size())
for st,g in c.groupby('step'):
    print('=====',st)
    print(g[['qid','video_id','kind','question','v2','ans','ratio','method','known']].round(3).to_string(index=False))
