import sys
W='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/work'
sys.path.insert(0,W)
import warnings; warnings.filterwarnings('ignore')
import pickle, pandas as pd, numpy as np
from harness import known, SUS
from qp.mra import item_scores
pd.set_option('display.width',300); pd.set_option('display.max_colwidth',70)
log=pickle.load(open('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/review_integrity/repro.pkl','rb'))
k=known(); k=k[k.category=='D3']
print('known D3 rows',len(k),'excl sus',(~k.val_qid.isin(SUS)).sum(), 'dup qids', k.qid.duplicated().sum())
kk=k[~k.val_qid.isin(SUS)]
for name,m in log.items():
    x=kk.merge(m[['qid','ans','v2','step']],on='qid')
    x['s_new']=item_scores(x.ans,x.answer); x['s_old']=item_scores(x.v2,x.answer)
    ch=x[~np.isclose(x.ans,x.v2)]
    print('==',name,'known n',len(x),'old %.3f new %.3f'%(x.s_old.mean(),x.s_new.mean()),'changed known rows',len(ch))
    print(ch[['qid','val_qid','video_id','question','v2','ans','answer','s_old','s_new','step']].round(3).to_string(index=False))
    y=x[~x.base.isin(['captured_0013'])]
    print('   excluding 0013 rows: n',len(y),'old %.3f new %.3f'%(y.s_old.mean(),y.s_new.mean()))
# suspicious-labelled known rows changed?
xs=k[k.val_qid.isin(SUS)].merge(log['D3_main_transfer'][['qid','ans','v2']],on='qid')
print('SUS known rows changed:', (~np.isclose(xs.ans,xs.v2)).sum(), xs[~np.isclose(xs.ans,xs.v2)][['qid','val_qid','video_id','v2','ans','answer']].to_string())
