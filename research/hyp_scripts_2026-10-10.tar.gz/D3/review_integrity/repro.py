import sys, os
os.environ['ANTHROPIC_API_KEY']=''; os.environ['ANTHROPIC_BASE_URL']='http://127.0.0.1:9'
os.environ['QP_LEDGER']='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/review_integrity/ledger.jsonl'
W='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/work'
sys.path.insert(0,W)
import warnings; warnings.filterwarnings('ignore')
from steps import *
import pandas as pd, numpy as np, pickle
OUT='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/review_integrity/'
SPD='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/'
V={
 'D3_main_transfer':[lab_relink,lab_notime,lab_kcal_static,lab_render_direct_motion,sibling_transfer,segtwin],
 'D3_main':[lab_relink,lab_notime,lab_kcal_static,lab_render_direct_motion,segtwin],
 'D3_main_transfer_geomed':[lab_relink,lab_notime,lab_kcal_static,lab_render_direct_motion,lab_render_geo_median,sibling_transfer,segtwin],
 'D3_segtwin_only':[segtwin],
}
m0=base_table()
print('base_table rows',len(m0),'cats',m0.category.value_counts().to_dict())
print('columns',list(m0.columns))
print('answer col in test?', 'answer' in m0.columns, m0['answer'].notna().sum() if 'answer' in m0.columns else None)
# v2 vs run on D3 lab and non-lab
d=m0[m0.category=='D3']
print('D3 v2==run value lab:', np.isclose(d[d.video_source=='lab'].v2, d[d.video_source=='lab'].parsed_value).mean(), ' nonlab v2==direct:', np.isclose(d[d.video_source!='lab'].v2, d[d.video_source!='lab'].direct_value).mean())
log={}
for name,steps in V.items():
    m=base_table(); m['step']=''
    for f in steps:
        before=m.ans.copy()
        m,n=f(m)
        chg=~np.isclose(before,m.ans,rtol=1e-12)
        m.loc[chg,'step']=m.loc[chg,'step']+f.__name__+';'
    pub=pd.read_csv(SPD+name+'.csv').set_index('id').parsed_value
    dd=m[m.category=='D3'].set_index('qid')
    diff=~np.isclose(pub.loc[dd.index].values, dd.ans.values, rtol=1e-9)
    print(name,'repro mismatch on D3:',diff.sum())
    log[name]=m
pickle.dump(log,open(OUT+'repro.pkl','wb'))
