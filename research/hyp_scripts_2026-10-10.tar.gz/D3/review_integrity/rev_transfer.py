import sys
W='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/work'
sys.path.insert(0,W)
import warnings; warnings.filterwarnings('ignore')
import pandas as pd, numpy as np, re
import transfer as TR
from scenes import scene_links
pd.set_option('display.width',300); pd.set_option('display.max_colwidth',120); pd.set_option('display.max_rows',500)
t,comps,shared=scene_links()
print('n scene comps',len(comps))
for c in comps: print(c, [len(shared.get(tuple(sorted((a,b))),())) for i,a in enumerate(c) for b in c[i+1:]])
c=TR.candidates()
v2=pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv')[['id','parsed_value']]
c=c.merge(v2,left_on='qid',right_on='id')
for r in c.itertuples():
    b=TR.base_id(r.video_id) if hasattr(TR,'base_id') else re.sub(r'(_segmented|[sxX])$','',r.video_id)
    ns={s:len(shared.get(tuple(sorted((b,s))),())) for s in r.src.split(',')}
    print(r.qid, r.video_id, '|Q:', r.question, '| qtime', r.qtime, '| ->', r.transfer, 'v2', r.parsed_value, '| src', r.src, 'shared#', ns, '| PRIOR:', r.pline)
