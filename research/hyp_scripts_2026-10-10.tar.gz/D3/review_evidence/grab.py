import cv2, sys, glob, os
V='/home/user/quantiphy-challenge/data/QuantiPhy/'
idx={os.path.splitext(os.path.basename(p))[0].strip():p for p in glob.glob(V+'**/*.mp4',recursive=True)}
vid=sys.argv[1]; ts=[float(x) for x in sys.argv[2].split(',')]; scale=float(sys.argv[3]) if len(sys.argv)>3 else 0.5
cap=cv2.VideoCapture(idx[vid]); fps=cap.get(cv2.CAP_PROP_FPS); n=cap.get(cv2.CAP_PROP_FRAME_COUNT)
W=cap.get(cv2.CAP_PROP_FRAME_WIDTH); H=cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
print(vid,'fps',fps,'frames',n,'dur',n/fps,'size',W,H)
ims=[]
for t in ts:
    cap.set(cv2.CAP_PROP_POS_FRAMES,int(round(t*fps)))
    ok,im=cap.read()
    if not ok: print('fail',t); continue
    im=cv2.resize(im,None,fx=scale,fy=scale)
    cv2.putText(im,'t=%.2f'%t,(10,30),cv2.FONT_HERSHEY_SIMPLEX,1,(0,0,255),2)
    ims.append(im)
import numpy as np
out=np.vstack(ims) if len(ims)<=2 else np.vstack([np.hstack(ims[i:i+2]) if i+1<len(ims) else np.hstack([ims[i],np.zeros_like(ims[i])]) for i in range(0,len(ims),2)])
p='frames/%s.jpg'%vid; cv2.imwrite(p,out,[cv2.IMWRITE_JPEG_QUALITY,80]); print(p,out.shape)
