from known import *
H='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/'
CSV={'v2':R+'/submissions/trackA_opus55_high_v2.csv',
 'main_transfer':H+'D3_main_transfer.csv','main':H+'D3_main.csv','segtwin_only':H+'D3_segtwin_only.csv','transfer_geomed':H+'D3_main_transfer_geomed.csv',
 'probe3':R+'/submissions/trackA_probe3_s2maxext_d2denseoff_labdirect.csv'}
def load(p): return pd.read_csv(p).set_index('id').parsed_value
if __name__=='__main__':
    for num in (False,True):
      k=known(num=num); k=k[k.category=='D3']
      for sus in (True,False):
        kk=k[~k.val_qid.isin(SUS)] if sus else k
        print('=== num=%s exclSUS=%s n=%d'%(num,sus,len(kk)))
        rows=[]
        for n,p in CSV.items():
            s=load(p); x=kk.copy(); x['p']=s.loc[x.qid].values; x['sc']=item_scores(x.p,x.answer)
            r={'variant':n,'all':x.sc.mean()}
            for src,g in x.groupby('video_source'): r[src]=g.sc.mean()
            for vid,g in x.groupby('val_vid'): r[vid[-6:]]=g.sc.mean()
            rows.append(r)
        print(pd.DataFrame(rows).round(3).to_string())
