import sys, re
sys.path.insert(0,'/home/user/quantiphy-challenge')
import pandas as pd, numpy as np
from qp.data import load_split
from qp.mra import item_scores
R='/home/user/quantiphy-challenge'
SUS={403, 2349, 2607, 3049, 3051, 1123, 1130, 1354, 1355, 3054, 139, 2276}
def base_old(v):
    v=str(v).strip()
    v=re.sub(r'_segmented$','',v)
    m=re.match(r'^(captured_\d+)[a-zA-Z]?$',v)
    if m: return m.group(1)
    return v
def nt(x, num=False):
    x=str(x).lower().replace('？','?')
    x=re.sub(r'\s+','',x).strip()
    x=x.rstrip('?.,')
    if num: x=re.sub(r'(\d+)\.0+(?!\d)',r'\1',x)
    return x
def ndi(x):
    return re.sub(r'\s+','',str(x).lower())
def known(strict=True, num=False):
    v=load_split('val'); vh=load_split('val_hires')
    assert (v.qid.values==vh.qid.values).all() and np.allclose(v.answer, vh.answer)
    t=load_split('test')
    for d in (v,t):
        d['b']=d.video_id.map(base); d['nq']=d.question.map(lambda q: nt(q,num)); d['np']=d.prior.map(lambda q: nt(q,num)); d['nd']=d.depth_info.map(ndi)
    keys=['b','nq','np','nd'] if strict else ['b','nq','np']
    k=t.merge(v[keys+['answer','qid','video_id']].rename(columns={'qid':'val_qid','video_id':'val_vid'}),on=keys)
    return k
if __name__=='__main__':
    k=known()
    print(len(k), k.groupby(['category','video_source']).size())
    d=k[k.category=='D3']
    print(d.groupby(['video_source','val_vid','video_id']).size().to_string())
    print('dup qid', d.qid.duplicated().sum(), 'sus', d.val_qid.isin(SUS).sum())
    k2=known(False); d2=k2[k2.category=='D3']; print('loose D3', len(d2), 'strict', len(d))
    x=d2[~d2.qid.isin(d.qid)]; print(x[['qid','video_id','val_vid','question']].to_string())
def base(v):
    v=re.sub(r'_segmented$','',str(v).strip())
    m=re.match(r'^(captured_\d+[ab]?)[sxX]?$',v)
    return m.group(1) if m else v
