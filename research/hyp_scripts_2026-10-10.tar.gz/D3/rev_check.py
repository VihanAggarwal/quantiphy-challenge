import sys; sys.path.insert(0,'/home/user/quantiphy-challenge')
import pandas as pd, numpy as np
from qp.data import load_split
R='/home/user/quantiphy-challenge'
SP='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/'
import glob
tmpl=[p for p in glob.glob(R+'/data/**/*template*',recursive=True)]+[p for p in glob.glob(R+'/**/*sample*submission*',recursive=True)]
print('templates',tmpl[:5])
v2=pd.read_csv(R+'/submissions/trackA_opus55_high_v2.csv')
t=load_split('test'); cat=t.set_index('qid').category
print('v2 cols',list(v2.columns), len(v2))
for f in ['D3_main_transfer','D3_main','D3_segtwin_only','D3_main_transfer_geomed']:
    d=pd.read_csv(SP+f+'.csv')
    ok_ids = list(d.id)==list(v2.id)
    vals=d.parsed_value.astype(float)
    fin=np.isfinite(vals).all(); pos=(vals>0).all()
    ch=~np.isclose(v2.parsed_value.values, vals.values, rtol=1e-12, atol=0)
    cats=cat.loc[d.id[ch]].value_counts().to_dict()
    print(f, 'cols',list(d.columns),'n',len(d),'ids==v2',ok_ids,'finite',fin,'pos',pos,'changed',ch.sum(),cats, 'dtype',d.parsed_value.dtype, 'min',vals.min())
