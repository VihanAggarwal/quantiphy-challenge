import pandas as pd, numpy as np
R='/home/user/quantiphy-challenge'
SP='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/'
T=pd.read_csv(R+'/data/submission_template/quantiphy_submission_template.csv')
print('template cols',list(T.columns),len(T))
v2=pd.read_csv(R+'/submissions/trackA_opus55_high_v2.csv')
print('v2 ids == template ids', list(v2.id)==list(T.id))
for f in ['D3_main_transfer','D3_main','D3_segtwin_only','D3_main_transfer_geomed']:
    d=pd.read_csv(SP+f+'.csv')
    oc=[c for c in d.columns if c!='parsed_value']
    same=all((d[c].fillna('NA').astype(str)==v2[c].fillna('NA').astype(str)).all() for c in oc)
    tc=[c for c in T.columns if c in d.columns and c!='parsed_value']
    samet=all((d[c].fillna('NA').astype(str)==T[c].fillna('NA').astype(str)).all() for c in tc)
    print(f,'ids==template',list(d.id)==list(T.id),'other cols == v2',same,'== template',samet, 'dup ids', d.id.duplicated().sum())
# raw bytes check: same header line
for f in ['D3_main_transfer']:
    print(open(SP+f+'.csv').readline().strip()); print(open(R+'/submissions/trackA_opus55_high_v2.csv').readline().strip())
