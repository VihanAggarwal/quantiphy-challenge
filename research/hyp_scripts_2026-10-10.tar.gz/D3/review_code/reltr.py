import sys; sys.path.insert(0,'/home/user/quantiphy-challenge')
import pickle, numpy as np, math
d=pickle.load(open('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/work/lab_test_anns.pkl','rb')); a=d['anns']; meta=d['meta']; df=d['df'].set_index('qid')
from qp.geometry import _depth_groups, DepthFn
for q in [2151,2156,2162,2167,2172,2177,2182,2187]:
    x=a[q]; vid=df.loc[q,'video_id']; W,H=meta[vid]['image_size']; f=(W/2)/math.tan(math.radians(84)/2)
    g=[gg for gg in _depth_groups(x.spec.depth) if len({t for t,_ in gg[1] if t is not None})>=2]
    D=DepthFn(g)
    for tr in x.tracks:
        if tr.role!='target': continue
        o=tr.obs; print(q, vid, tr.object, 'nobs',len(o), type(o[0]).__name__ if o else None)
        rows=[]
        for ob in o:
            ob=ob if isinstance(ob,dict) else vars(ob)
            t=ob.get('t'); b=ob.get('box') or ob.get('bbox')
            if b is None: continue
            w=b[2]-b[0]; h=b[3]-b[1]
            z=float(D(t)[0]); rows.append((round(t,3), round(w,1), round(h,1), round(z,3), round(max(w,h)*z/f*100,1)))
        print('   t, w, h, z_ext, size_cm:', rows[:40])
        if rows: print('   median size', np.median([r[4] for r in rows]))
