import cv2, sys, numpy as np
R='/home/user/quantiphy-challenge/data/QuantiPhy/'
def grab(vid, t):
    cap=cv2.VideoCapture(R+vid+'.mp4'); fps=cap.get(cv2.CAP_PROP_FPS); n=cap.get(cv2.CAP_PROP_FRAME_COUNT)
    cap.set(cv2.CAP_PROP_POS_FRAMES, int(t*fps)); ok,im=cap.read()
    print(vid, fps, n, im.shape)
    return im
out=sys.argv[1]; specs=sys.argv[2:]
ims=[]
for s in specs:
    v,t=s.split('@'); im=grab(v,float(t))
    im=cv2.resize(im,(960,int(960*im.shape[0]/im.shape[1])))
    cv2.putText(im,s,(10,30),cv2.FONT_HERSHEY_SIMPLEX,0.9,(0,0,255),2); ims.append(im)
cv2.imwrite(out, np.vstack(ims))
