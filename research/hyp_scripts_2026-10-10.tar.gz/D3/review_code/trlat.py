import sys, warnings, re; warnings.filterwarnings('ignore')
sys.path.insert(0,'/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/work')
import transfer as TR, pandas as pd
pd.set_option('display.width',250); pd.set_option('display.max_colwidth',120)
t,comps,shared=TR.scene_links()
comp_of={b:i for i,c in enumerate(comps) for b in c}
print('components:'); [print('  ',c) for c in comps]
t['scene']=t.base.map(comp_of)
rows=[]
for r in t.drop_duplicates(['base','prior']).itertuples():
    for line in str(r.prior).split('\n'):
        mm=TR.PRIOR_RE.match(line)
        rows.append(dict(base=r.base,scene=r.scene,line=line.strip(),parsed=bool(mm),timed=bool(re.match(r'^\s*t\s*=',line))))
P=pd.DataFrame(rows)
print(P[P.scene.notna()].to_string())
# D3 questions in scenes that parse
q=t[(t.category=='D3')&t.scene.notna()]
q['pq']=q.question.map(TR.parse_q)
print('D3 q in scenes', len(q), 'parsed', q.pq.notna().sum())
print(q[q.pq.notna()&q.pq.map(lambda x: x is not None and x[2] is not None)][['qid','video_id','question']].to_string())
