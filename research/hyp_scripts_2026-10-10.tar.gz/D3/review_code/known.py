import sys, warnings; warnings.filterwarnings('ignore')
sys.path.insert(0,'/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/work')
from harness import *
import pickle
d=pickle.load(open('steplog.pkl','rb')); m=d['m']; L=d['L']
k=known()
print('known rows all cats', len(k), 'dup qids', k.qid.duplicated().sum())
kd=k[k.category=='D3']
print('D3 known', len(kd), 'dup', kd.qid.duplicated().sum())
# strict: also require identical depth_info
v=load_split('val'); v['base']=v.video_id.map(base_id); v['nq']=v.question.map(nk); v['np']=v.prior.map(nk); v['nd']=v.depth_info.map(nk)
t=load_split('test'); t['base']=t.video_id.map(base_id); t['nq']=t.question.map(nk); t['np']=t.prior.map(nk); t['nd']=t.depth_info.map(nk)
ks=t.merge(v[['base','nq','np','nd','answer','qid']].rename(columns={'qid':'val_qid'}),on=['base','nq','np','nd'])
ks=ks[ks.category=='D3']
print('strict D3 known', len(ks), 'non-strict-only', set(kd.qid)-set(ks.qid))
kk=ks[~ks.val_qid.isin(SUS)]
x=kk.merge(m[['qid','v2ans','ans']],on='qid')
x['s0']=item_scores(x.v2ans,x.answer); x['s1']=item_scores(x.ans,x.answer)
print('strict known n',len(x),'v2 %.3f new %.3f'%(x.s0.mean(),x.s1.mean()))
# per-step: attribute each changed row to its last step
last=L[L.changed].groupby('qid').step.agg(lambda s: '+'.join(s))
x['step']=x.qid.map(last)
y=x[x.step.notna()]
pd.set_option('display.width',250)
print(y[['qid','video_id','step','v2ans','ans','answer','s0','s1']].round(3).to_string())
print(y.groupby('step')[['s0','s1']].agg(['sum','count']).round(3))
print('sus known rows changed:', k[(k.category=='D3')&k.val_qid.isin(SUS)&k.qid.isin(L[L.changed].qid)][['qid','video_id','val_qid']].to_string())
