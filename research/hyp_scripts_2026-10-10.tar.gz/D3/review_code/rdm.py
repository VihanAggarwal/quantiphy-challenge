import pickle, pandas as pd, numpy as np
pd.set_option('display.width',300); pd.set_option('display.max_colwidth',75); pd.set_option('display.max_rows',500)
d=pickle.load(open('steplog.pkl','rb')); m=d['m']; L=d['L']
x=L[L.step=='lab_render_direct_motion']
rows=[]
for r in x.itertuples():
    me=m[m.qid==r.qid].iloc[0]
    g=m[(m.base==me.base)&(m.nq==me.nq)&(m.prior==me.prior)&(m.depth_info==me.depth_info)&(m.target_unit==me.target_unit)]
    b=g[g.video_id==g.base].iloc[0]
    rows.append(dict(qid=r.qid,vid=r.video_id,kind=me.kind,q=me.nq,before=r.before,after=r.after,base_qid=b.qid,base_kind=b.kind,base_v2m=b.v2method,base_m_at_step=None,base_direct=b.direct_value,base_geo=b.geo_value,own_geo=me.geo_value))
X=pd.DataFrame(rows)
# base method at time of rdm: v2method unless relinked/notime
mm=dict(zip(L[L.step.isin(['lab_relink','lab_notime'])].qid,L[L.step.isin(['lab_relink','lab_notime'])].ma))
X['base_m_at_step']=[mm.get(q, m[m.qid==q].v2method.iloc[0]) for q in X.base_qid]
print(X.round(3).to_string())
