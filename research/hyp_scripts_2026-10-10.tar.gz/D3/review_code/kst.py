import sys, warnings; warnings.filterwarnings('ignore')
sys.path.insert(0,'/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/work')
from kcal import *
import pickle
pd.set_option('display.width',300); pd.set_option('display.max_colwidth',90); pd.set_option('display.max_rows',500)
d=pickle.load(open('steplog.pkl','rb')); m=d['m']
dd=m[(m.category=='D3')&(m.video_source=='lab')].copy()
# reconstruct state before kstatic: v2 + relink + notime -> use method column from v2 except relinked/notime
L=d['L']; pre=dd.copy()
pre['method']=pre['v2method']
for r in L[L.step.isin(['lab_relink','lab_notime'])].itertuples():
    pre.loc[pre.qid==r.qid,'method']=r.ma
k=video_k(pre)
print(np.exp(k['median']).round(3).to_string())
a=pre[anchors_mask(pre)]
a=a[a.video_id.isin(['captured_0013','captured_0013s','captured_0013x','captured_0020','captured_0020s','captured_0020x','captured_0054a','captured_0054as','captured_0054ax'])]
a['r']=a.geo_value/a.direct_value
print(a[['qid','video_id','kind','nq','direct_value','geo_value','r','method']].to_string())
