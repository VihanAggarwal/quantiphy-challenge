import pickle, pandas as pd, numpy as np
pd.set_option('display.width',300); pd.set_option('display.max_colwidth',70); pd.set_option('display.max_rows',500)
d=pickle.load(open('steplog.pkl','rb')); m=d['m']; L=d['L']
x=L[L.step=='segtwin']
rows=[]
for r in x.itertuples():
    me=m[m.qid==r.qid].iloc[0]
    g=m[(m.category=='D3')&(m.base==me.base)&(m.nq==me.nq)&(m.prior==me.prior)&(m.depth_info==me.depth_info)&(m.target_unit==me.target_unit)]
    o=g[~g.video_id.str.endswith('_segmented')]
    rows.append(dict(qid=r.qid,vid=r.video_id,src=me.video_source,kind=me.kind,q=me.nq[:60],before=r.before,after=r.after,oqid=o.qid.iloc[0],ovid=o.video_id.iloc[0],osrc=o.video_source.iloc[0],ov2=o.v2ans.iloc[0],ochg=o.ans.iloc[0]!=o.v2ans.iloc[0],ratio=r.after/r.before))
X=pd.DataFrame(rows)
print(X.round(3).to_string())
print(X.ratio.describe())
seg=m[(m.category=='D3')&(m.video_id.str.endswith('_segmented'))]
print('D3 segmented rows', len(seg), 'touched', len(X), 'sources', seg.video_source.value_counts().to_dict())
un=seg[~seg.qid.isin(X.qid)]
for r in un.itertuples():
    o=m[(m.category=='D3')&(m.video_id==r.base)]
    same_q=o[o.nq==r.nq]
    why='no orig clip in D3' if len(o)==0 else ('no same q' if len(same_q)==0 else ('prior differs' if (same_q.prior!=r.prior).all() else ('depth differs' if (same_q.depth_info!=r.depth_info).all() else 'unit/other')))
    print('UNMATCHED',r.qid,r.video_id,r.nq[:60],why)
