import sys, pickle, pandas as pd, numpy as np
pd.set_option('display.width',300); pd.set_option('display.max_colwidth',200); pd.set_option('display.max_rows',500)
d=pickle.load(open('steplog.pkl','rb')); m=d['m']; L=d['L']
step=sys.argv[1]
x=L[L.step==step].merge(m[['qid','question','prior','depth_info','kind','target_unit','direct_value','geo_value','flags','video_type','category','video_source']],on='qid')
for r in x.itertuples():
    print(f"--- qid {r.qid} {r.video_id} {r.video_type} {r.category}/{r.video_source} kind={r.kind} unit={r.target_unit}  {r.before:.4g} -> {r.after:.4g}  ({r.mb} -> {r.ma}) direct={r.direct_value} geo={r.geo_value}")
    print('   Q:',r.question.replace('\n',' | '))
    print('   P:',str(r.prior).replace('\n',' | '))
    if len(sys.argv)>2: print('   D:',str(r.depth_info).replace('\n',' | ')[:600]); print('   F:',r.flags)
