import sys, warnings; warnings.filterwarnings('ignore')
sys.path.insert(0,'/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/work')
import pickle, pandas as pd, numpy as np
d=pickle.load(open('steplog.pkl','rb')); m=d['m']
lab=m[(m.category=='D3')&(m.video_source=='lab')]
run=pd.read_csv('/home/user/quantiphy-challenge/runs/test_v1_high_854/test.csv')
x=lab.merge(run[['id','parsed_value']].rename(columns={'parsed_value':'runv'}),left_on='qid',right_on='id')
print('lab D3 v2 vs run equal:', np.isclose(x.v2ans,x.runv).mean(), len(x))
print(lab.v2method.value_counts().to_dict())
print('direct rows where direct_value != v2:', ((lab.v2method=='direct')&~np.isclose(lab.direct_value,lab.v2ans)).sum())
import solve_lab as S
SP='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/'
r=S.run(SP+'work/lab_test_anns.pkl')
y=r.merge(lab[['qid','geo_value']],on='qid')
ok=np.isclose(y.geo.astype(float),y.geo_value.astype(float),rtol=1e-6)|(y.geo.isna()&y.geo_value.isna())
print('re-solve reproduces run geo_value:', ok.mean(), (~ok).sum())
print(y[~ok][['qid','video_id','geo','geo_value','method']].head(20).to_string())
