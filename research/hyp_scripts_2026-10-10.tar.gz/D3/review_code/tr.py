import sys, warnings; warnings.filterwarnings('ignore')
sys.path.insert(0,'/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/work')
import transfer as TR
import pandas as pd, pickle
pd.set_option('display.width',300); pd.set_option('display.max_colwidth',200); pd.set_option('display.max_rows',500)
c=TR.candidates()
t,comps,shared=TR.scene_links()
d=pickle.load(open('steplog.pkl','rb')); m=d['m']
for r in c.itertuples():
    me=m[m.qid==r.qid].iloc[0]
    print(f"=== qid {r.qid} {r.video_id} {me.category}/{me.video_source} kind={me.kind} v2={me.v2ans:.4g} -> {r.transfer:.4g}  src={r.src}")
    print('  Q:', r.question.strip())
    print('  P(own):', str(me.prior).replace('\n',' | '))
    print('  D(own):', str(me.depth_info).replace('\n',' | ')[:400])
    for s in r.src.split(','):
        sp=t[t.base==s]
        print(f'  SRC {s} prior:', sp.prior.iloc[0].replace('\n',' | '), ' cat', sp.category.iloc[0])
        print(f'  SRC {s} D:', sp.depth_info.iloc[0].replace('\n',' | ')[:400])
        sh=shared.get(tuple(sorted((me.base,s))),set())
        print('  shared numbers:', sorted(sh))
