import sys, pickle, pandas as pd, numpy as np
pd.set_option('display.width',300); pd.set_option('display.max_colwidth',80); pd.set_option('display.max_rows',500)
d=pickle.load(open('steplog.pkl','rb')); m=d['m']
bases=sys.argv[1].split(',')
x=m[m.base.isin(bases)&(m.category=='D3')].sort_values(['base','nq','video_id'])
print(x[['qid','video_id','video_type','kind','nq','v2ans','ans','v2method','method','direct_value','geo_value']].to_string())
