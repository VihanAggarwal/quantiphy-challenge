import sys, warnings; warnings.filterwarnings('ignore')
sys.path.insert(0,'/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/work')
from steps import *
import pickle
m=base_table()
m['v2ans']=m['ans'].copy(); m['v2method']=m['method'].copy()
log=[]
for f in [lab_relink,lab_notime,lab_kcal_static,lab_render_direct_motion,sibling_transfer,segtwin]:
    before=m['ans'].copy(); bm=m['method'].copy()
    m,n=f(m)
    ch=~np.isclose(before.astype(float),m['ans'].astype(float),rtol=1e-9)
    touched=(m['method'].astype(str)!=bm.astype(str))|ch
    for i in m.index[ch|touched]:
        log.append(dict(step=f.__name__,qid=int(m.at[i,'qid']),video_id=m.at[i,'video_id'],before=float(before[i]),after=float(m.at[i,'ans']),changed=bool(ch[i]),mb=bm[i],ma=m.at[i,'method']))
    print(f.__name__, n, int(ch.sum()))
L=pd.DataFrame(log)
pickle.dump({'m':m,'L':L},open('steplog.pkl','wb'))
d=pd.read_csv('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/D3_main_transfer.csv')
mm=m[m.category=='D3'].set_index('qid').ans
dd=d.set_index('id').parsed_value
print('repro max abs diff vs csv', float((dd.loc[mm.index]-mm).abs().max()))
