import sys, warnings; warnings.filterwarnings('ignore')
sys.path.insert(0,'/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/work')
import pandas as pd, pickle
pd.set_option('display.width',300); pd.set_option('display.max_colwidth',120); pd.set_option('display.max_rows',500)
import relink as RL
SP='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/'
d=pickle.load(open(SP+'work/lab_test_anns.pkl','rb'))
print(d['df'].category.value_counts().to_dict(), len(d['anns']))
x=RL.run(SP+'work/lab_test_anns.pkl')
x=x.merge(d['df'][['qid','category']],on='qid')
print(x[['qid','video_id','category','kind','geo_new','direct','sel_new','how','changed']].to_string())
for q in [2151,2162,2178]:
    a=d['anns'][q]; print(q, a.spec.prior, a.spec.target)
    for t in a.tracks: print('   ',t.role,t.object,t.depth_name, len(getattr(t,'points',[]) or []))
