from steps import *
from harness import *
import json, warnings; warnings.filterwarnings('ignore')
k=known(); k=k[(k.category=='D3')&~k.val_qid.isin(SUS)]
def sc(m):
    x=k.merge(m[['qid','ans']],on='qid'); x['s']=item_scores(x.ans,x.answer)
    return round(x.s.mean(),3), round(x[x.video_source=='lab'].s.mean(),3), round(x[x.video_source!='lab'].s.mean(),3)
V={
 'D3_main_transfer':[lab_relink,lab_notime,lab_kcal_static,lab_render_direct_motion,sibling_transfer,segtwin],
 'D3_main':[lab_relink,lab_notime,lab_kcal_static,lab_render_direct_motion,segtwin],
 'D3_main_transfer_geomed':[lab_relink,lab_notime,lab_kcal_static,lab_render_direct_motion,lab_render_geo_median,sibling_transfer,segtwin],
 'D3_segtwin_only':[segtwin],
}
res={}
for name,steps in V.items():
    m=base_table(); ns={}
    for f in steps:
        m,n=f(m); ns[f.__name__]=n
    st=write(m,name); st['steps']=ns; st['known_rows_all_lab_nonlab']=sc(m)
    res[name]=st
print(json.dumps(res,indent=1))
json.dump(res,open(SP+'work/final_stats.json','w'),indent=1)
