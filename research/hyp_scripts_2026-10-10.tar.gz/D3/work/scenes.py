from load import *
import re, itertools
from collections import defaultdict
def scene_links(min_digits=3):
    t=load_split('test')
    t=t[t.video_type.str[1]=='3'].copy()
    t['base']=t.video_id.map(base_id)
    ent=defaultdict(set)
    for v,g in t.groupby('base'):
        for di in g.depth_info.unique():
            for num in re.findall(r'=\s*([0-9]+\.[0-9]{%d,})'%min_digits, di):
                ent[v].add(num)
    num2b=defaultdict(set)
    for b,s in ent.items():
        for n in s: num2b[n].add(b)
    parent={b:b for b in ent}
    def find(x):
        while parent[x]!=x: parent[x]=parent[parent[x]]; x=parent[x]
        return x
    shared=defaultdict(set)
    for n,bs in num2b.items():
        bs=sorted(bs)
        for a in bs[1:]:
            parent[find(a)]=find(bs[0])
        if len(bs)>1:
            for a,b in itertools.combinations(bs,2): shared[(a,b)].add(n)
    comp=defaultdict(list)
    for b in ent: comp[find(b)].append(b)
    comps=[sorted(v) for v in comp.values() if len(v)>1]
    return t, comps, shared
if __name__=='__main__':
    t,comps,shared=scene_links()
    for c in comps:
        g=t[t.base.isin(c)]
        print('SCENE', c)
        for b in c:
            h=g[g.base==b]
            print('   ',b, h.category.iloc[0], '|prior:', h.prior.iloc[0][:60], '|', h.video_source.iloc[0])
    print(len(comps))
