from scenes import *
import sys
sys.path.insert(0,'/home/user/quantiphy-challenge')
from qp.geometry import _tokens
PRIOR_RE=re.compile(r'^\s*(?:t\s*=\s*[\d.]+s?,\s*)?(height|length|width|diameter|speed|velocity|size)\s+of\s+(?:the\s+)?(.+?)\s*=\s*(-?[\d.]+)\s*(m/s\^2|m/s|cm|mm|m)\b', re.I)
Q_RE=re.compile(r'what\s+is\s+the\s+(height|length|width|diameter|speed|velocity|size)\s+of\s+(?:the\s+)?(.+?)(?:\s+at\s+([\d.]+)\s*s)?\s+in\s+(meters|m|cm|mm|m/s|cm/s)\b', re.I)
UNIT={'m':1,'cm':0.01,'mm':0.001,'m/s':1,'meters':1,'cm/s':0.01}
def parse_prior(p):
    out=[]
    for line in str(p).split('\n'):
        mm=PRIOR_RE.match(line)
        if mm:
            q,obj,val,u=mm.groups()
            q=q.lower().replace('velocity','speed')
            out.append((q,' '.join(_tokens(obj)),float(val)*UNIT[u.lower()], u, line))
    return out
def parse_q(q):
    mm=Q_RE.search(str(q))
    if not mm: return None
    qq,obj,tm,u=mm.groups()
    return (qq.lower().replace('velocity','speed'),' '.join(_tokens(obj)), tm, UNIT[u.lower()])
def candidates():
    t,comps,shared=scene_links()
    comp_of={b:i for i,c in enumerate(comps) for b in c}
    t['scene']=t.base.map(comp_of)
    priors=[]
    for r in t.drop_duplicates(['base','prior']).itertuples():
        if pd.isna(r.scene): continue
        for pp in parse_prior(r.prior): priors.append((r.scene,r.base)+pp)
    P=pd.DataFrame(priors,columns=['scene','pbase','pq','pobj','pval','punit','pline'])
    rows=[]
    for r in t[t.category=='D3'].itertuples():
        if pd.isna(r.scene): continue
        pq=parse_q(r.question)
        if pq is None: continue
        q,obj,tm,u=pq
        c=P[(P.scene==r.scene)&(P.pq==q)&(P.pobj==obj)&(P.pbase!=r.base)]
        if len(c):
            vals=c.pval.unique()
            if len(vals)==1:
                rows.append(dict(qid=r.qid,video_id=r.video_id,question=r.question,qtime=tm,transfer=vals[0]/u,src=','.join(c.pbase.unique()),pline=c.pline.iloc[0]))
    return pd.DataFrame(rows)
if __name__=='__main__':
    pd.set_option('display.width',250); pd.set_option('display.max_colwidth',90)
    c=candidates()
    v2=pd.read_csv(R+'/submissions/trackA_opus55_high_v2.csv')[['id','parsed_value']]
    c=c.merge(v2,left_on='qid',right_on='id')
    c['ratio']=c.transfer/c.parsed_value
    print(c[['qid','video_id','question','qtime','transfer','parsed_value','ratio','src','pline']].round(3).to_string())
