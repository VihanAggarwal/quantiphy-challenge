import sys, json, math
sys.path.insert(0, '/home/user/quantiphy-challenge')
import pandas as pd, numpy as np
from qp.data import load_split
R='/home/user/quantiphy-challenge'
def test_d3():
    df = load_split('test')
    run = pd.read_csv(R+'/runs/test_v1_high_854/test.csv')
    v2 = pd.read_csv(R+'/submissions/trackA_opus55_high_v2.csv')
    m = df.merge(run, left_on='qid', right_on='id', how='left').merge(v2[['id','parsed_value']].rename(columns={'parsed_value':'v2'}), on='id', how='left')
    return m
import glob, os
def records(split_dir=R+'/runs/test_v1_high_854/test/records'):
    out={}
    for f in glob.glob(split_dir+'/*.json'):
        r=json.load(open(f))
        out[r['video_id']]=r
    return out
def qinfo(recs):
    rows={}
    for v,r in recs.items():
        p=r.get('parsed') or {}
        for q in p.get('questions',[]):
            s=q['spec']
            rows[int(q['qid'])]=dict(kind=s['target']['kind'], tobj=','.join(s['target']['objects']), pkind=s['prior']['kind'],
               pobj=','.join(s['prior']['objects']), conf=q.get('confidence'), direct=q.get('direct_answer'), ntr=len(q.get('tracks',[])))
    return pd.DataFrame.from_dict(rows, orient='index')
import re
def base_id(v):
    return re.sub(r'(_segmented|[sxX])$','',v)
def norm_q(q):
    return re.sub(r'\s+',' ',str(q).strip().lower()).rstrip('?. ')
