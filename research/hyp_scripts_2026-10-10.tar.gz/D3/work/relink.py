"""Single-object lab videos: link the moving object's tracks to the one depth_info object with >=2 timed entries."""
import sys, pickle, copy, math
sys.path.insert(0,'/home/user/quantiphy-challenge')
import numpy as np, pandas as pd
from qp.geometry import solve, _depth_groups, match_depth, _tokens
import qp.combine as C
from qp.spec import KIND_DIM

def compatible(a, b):
    A, B = set(_tokens(a)), set(_tokens(b))
    return bool(A) and bool(B) and (A <= B or B <= A)

def relink(spec, tracks, video_type):
    if str(video_type)[2:3] != 'S':
        return None
    groups = _depth_groups(spec.depth)
    moving = [g for g in groups if len({t for t, _ in g[1] if t is not None}) >= 2]
    if len(moving) != 1:
        return None
    mname = moving[0][0]
    pobj = (spec.prior.objects or [''])[0]
    new = copy.deepcopy(tracks); changed = []
    for tr in new:
        if tr.depth_name:
            continue
        if match_depth([tr.object], groups) is not None:   # already matched by name
            continue
        if tr.role == 'prior' or compatible(tr.object, pobj):
            tr.depth_name = mname; changed.append((tr.role, tr.object, mname))
    return (new, changed) if changed else None

def run(pk, fov=84.0):
    d = pickle.load(open(pk, 'rb')); df = d['df']; anns = d['anns']; meta = d['meta']
    rows = []
    for r in df.itertuples():
        a = anns.get(int(r.qid))
        if a is None: continue
        res = relink(a.spec, a.tracks, r.video_type)
        if res is None: continue
        tracks, changed = res
        m = meta[r.video_id]
        ans = solve(a.spec, tracks, tuple(m['image_size']), float(m['fps']), seen_scale=float(m.get('scale') or 1.0), camera_fov_deg=fov)
        flags = [f'geo:{f}' for f in ans.flags]
        geo = ans.value
        if geo is not None and ans.debug.get('value_si', 0) > C.GEO_MAX_SI.get(KIND_DIM.get(a.spec.target.kind, 'L'), math.inf):
            flags.append('geo_rejected_implausible')
        val, how, added = C.choose(geo, a.direct_answer, flags, True, 'lab', ans.method)
        rows.append(dict(qid=int(r.qid), video_id=r.video_id, kind=a.spec.target.kind, geo_new=geo, direct=a.direct_answer,
                         sel_new=val, how=how, changed=str(changed), flags=';'.join(flags + added)))
    return pd.DataFrame(rows)
