import os, sys, pickle, json
os.environ['ANTHROPIC_API_KEY']=''; os.environ['ANTHROPIC_BASE_URL']='http://127.0.0.1:9'
os.environ['QP_LEDGER']='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/ledger.jsonl'
sys.path.insert(0,'/home/user/quantiphy-challenge/scripts'); sys.path.insert(0,'/home/user/quantiphy-challenge')
import run_claude as rc
from qp.data import load_split
SP='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/'
split=sys.argv[1]; runname=sys.argv[2]; sources=sys.argv[3].split(','); cats=sys.argv[4].split(','); out=sys.argv[5]
dense=sys.argv[6] if len(sys.argv)>6 else 'motion'
df=load_split(split)
df=df[df.video_source.isin(sources)&df.category.isin(cats)]
recs=rc.load_records(rc.ROOT/'runs'/runname/split/'records') if not runname.startswith('/') else rc.load_records(rc.Path(runname))
recs={k:v for k,v in recs.items() if k in set(df.video_id)}
print(len(df), len(recs))
dc = SP+'dense_cache/'+split
anns=rc.annotations(df, recs, dense=dense, dense_cache=dc)
precs=rc.prepare_records(df, recs)
pickle.dump({'df':df,'anns':anns,'meta':{v:r['meta'] for v,r in precs.items()}}, open(out,'wb'))
print('done', len(anns))
