from steps import *
from harness import *
import itertools, warnings; warnings.filterwarnings('ignore')
k=known(); k=k[(k.category=='D3')&~k.val_qid.isin(SUS)]
def sc(m):
    x=k.merge(m[['qid','ans']],on='qid')
    x['s']=item_scores(x.ans,x.answer)
    return x.s.mean(), x[x.video_source=='lab'].s.mean(), x[x.video_source!='lab'].s.mean()
combos={
 'v2':[],
 'segtwin':[segtwin],
 'labfix':[lab_relink,lab_notime,lab_kcal],
 'rdm':[lab_render_direct_motion],
 'geomed':[lab_render_geo_median],
 'labfix+rdm':[lab_relink,lab_notime,lab_kcal,lab_render_direct_motion],
 'labfix+rdm+geomed':[lab_relink,lab_notime,lab_kcal,lab_render_direct_motion,lab_render_geo_median],
 'labfix+rdm+geomed+segtwin':[lab_relink,lab_notime,lab_kcal,lab_render_direct_motion,lab_render_geo_median,segtwin],
 'labfix+segtwin':[lab_relink,lab_notime,lab_kcal,segtwin],
 'rdm+labfix':[lab_render_direct_motion,lab_relink,lab_notime,lab_kcal],
}
for name,steps in combos.items():
    m=base_table(); ns=[]
    for f in steps:
        m,n=f(m); ns.append(n)
    a,l,nl=sc(m)
    print('%-28s all %.3f lab %.3f nonlab %.3f  changes %s'%(name,a,l,nl,ns))
print('---')
combos2={
 'kstatic':[lab_kcal_static],
 'relink+notime+kstatic':[lab_relink,lab_notime,lab_kcal_static],
 'relink+notime+kstatic+rdm':[lab_relink,lab_notime,lab_kcal_static,lab_render_direct_motion],
 'relink+notime+kstatic+rdm+segtwin':[lab_relink,lab_notime,lab_kcal_static,lab_render_direct_motion,segtwin],
 'relink+notime+kstatic+rdm+geomed+segtwin':[lab_relink,lab_notime,lab_kcal_static,lab_render_direct_motion,lab_render_geo_median,segtwin],
}
for name,steps in combos2.items():
    m=base_table(); ns=[]
    for f in steps:
        m,n=f(m); ns.append(n)
    a,l,nl=sc(m)
    print('%-28s all %.3f lab %.3f nonlab %.3f  changes %s'%(name,a,l,nl,ns))
