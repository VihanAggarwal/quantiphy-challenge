import os, sys, pickle, math
sys.path.insert(0,'/home/user/quantiphy-challenge')
import numpy as np, pandas as pd
from qp.geometry import solve
import qp.geometry as G
def run(pk, fov=84.0, **kw):
    d=pickle.load(open(pk,'rb')); df=d['df']; anns=d['anns']; meta=d['meta']
    rows=[]
    for r in df.itertuples():
        a=anns.get(int(r.qid))
        if a is None: continue
        m=meta[r.video_id]
        ans=solve(a.spec, a.tracks, tuple(m['image_size']), float(m['fps']), seen_scale=float(m.get('scale') or 1.0),
                  **({'camera_fov_deg':fov} if fov else {}), **kw)
        rows.append(dict(qid=int(r.qid), video_id=r.video_id, geo=ans.value, method=ans.method, fl=';'.join(ans.flags),
                         f=ans.debug.get('f_px'), fov=ans.debug.get('fov_deg'), pm=ans.debug.get('prior_measured_si'),
                         pv=a.spec.prior.value_si, kind=a.spec.target.kind, pkind=a.spec.prior.kind, sens=ans.debug.get('f_sensitivity'),
                         direct=a.direct_answer, W=m['image_size'][0], debug=ans.debug))
    return pd.DataFrame(rows)
