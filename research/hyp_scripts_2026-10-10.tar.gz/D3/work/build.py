import sys, json
from kcal import *
import relink as RL
SP='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/'
KK=('size','distance','displacement','path_length','speed')

def base_table():
    m=test_d3(); recs=records(); qi=qinfo(recs); m=m.join(qi,on='qid')
    m['base']=m.video_id.map(base_id); m['nq']=m.question.map(norm_q)
    m['ans']=m['v2'].astype(float)
    return m

def lab_relink(m, kinds=('size','displacement')):
    x=RL.run(SP+'work/lab_test_anns.pkl')
    x=x[x.kind.isin(kinds) & x.how.str.startswith('geometry') & x.geo_new.notna()]
    upd=dict(zip(x.qid, x.geo_new))
    sel=m.qid.isin(list(upd))
    m.loc[sel,'ans']=m.loc[sel,'qid'].map(upd)
    m.loc[sel,'method']='geometry:relinked'
    return m, int(sel.sum())

def lab_notime(m):
    import pickle
    d=pickle.load(open(SP+'work/lab_test_anns.pkl','rb')); anns=d['anns']
    q=[k for k,a in anns.items() if a.spec.target.kind in ('speed','acceleration') and a.spec.target.time is None and not a.spec.target.window]
    sel=m.qid.isin(q)&m.method.str.startswith('geometry')&m.direct_value.notna()
    m.loc[sel,'ans']=m.loc[sel,'direct_value']; m.loc[sel,'method']='direct'
    return m, int(sel.sum())

def lab_kcal(m, min_n=2):
    d=m[(m.category=='D3')&(m.video_source=='lab')]
    k=video_k(d,min_n=min_n)
    kv=np.exp(k['median'])
    sel=(m.category=='D3')&(m.video_source=='lab')&(m.method=='direct')&m.kind.isin(KK)&m.video_id.isin(kv.index)&m.direct_value.notna()
    m.loc[sel,'ans']=m.loc[sel,'direct_value']*m.loc[sel,'video_id'].map(kv)
    return m, int(sel.sum())

def pool(m, sources=('lab','simulation','segmentation')):
    d=m[(m.category=='D3')&m.video_source.isin(sources)]
    key=['base','nq','prior','depth_info','target_unit']
    n=0
    for _,g in d.groupby(key):
        if len(g)<2: continue
        lv=np.log(g.ans.values.astype(float))
        if not np.isfinite(lv).all(): continue
        v=np.exp(np.median(lv))   # median of 3; geometric mean of 2
        m.loc[g.index,'ans']=v; n+=len(g)
    return m, n

def write(m, name):
    v2=pd.read_csv(R+'/submissions/trackA_opus55_high_v2.csv')
    upd=dict(zip(m.loc[m.category=='D3','qid'], m.loc[m.category=='D3','ans']))
    new=v2.copy()
    sel=new.id.isin(list(upd))
    new.loc[sel,'parsed_value']=new.loc[sel,'id'].map(upd)
    out=SP+name+'.csv'
    new.to_csv(out,index=False)
    old=v2.parsed_value.values; nv=new.parsed_value.values
    ch=~np.isclose(old,nv,rtol=1e-9)
    r=nv[ch]/old[ch]
    cats=load_split('test').set_index('qid').loc[new.id,'category'].values
    assert set(cats[ch])<= {'D3'}, 'non-D3 changed'
    stats=dict(csv=out, answers_changed=int(ch.sum()), answers_changed_gt2pct=int((np.abs(np.log(r))>0.02).sum()),
               median_ratio_changed=float(np.median(r)) if ch.any() else None,
               ratio_q10_q90=[float(np.quantile(r,.1)),float(np.quantile(r,.9))] if ch.any() else None)
    return stats

if __name__=='__main__':
    res={}
    m=base_table(); m,n=pool(m); res['D3_pool']=write(m,'D3_pool'); res['D3_pool']['pooled_rows']=n
    m=base_table(); m,n1=lab_relink(m); m,n0=lab_notime(m); m,n2=lab_kcal(m); m,n3=pool(m); res['D3_labfix_pool']=write(m,'D3_labfix_pool'); res['D3_labfix_pool'].update(relinked=n1,notime=n0,kcal=n2,pooled_rows=n3)
    m=base_table(); m,n1=lab_relink(m); m,n0=lab_notime(m); m,n2=lab_kcal(m); res['D3_labfix']=write(m,'D3_labfix'); res['D3_labfix'].update(relinked=n1,notime=n0,kcal=n2)
    m=base_table(); m,n=pool(m,sources=('lab',)); res['D3_pool_labonly']=write(m,'D3_pool_labonly'); res['D3_pool_labonly']['pooled_rows']=n
    print(json.dumps(res,indent=1))
