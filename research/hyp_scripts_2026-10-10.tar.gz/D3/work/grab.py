import cv2, sys, numpy as np
R='/home/user/quantiphy-challenge/data/QuantiPhy/'
out='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/frames/'
def grab(vid, frames, scale=0.5, name=None):
    cap=cv2.VideoCapture(R+vid+'.mp4')
    n=int(cap.get(cv2.CAP_PROP_FRAME_COUNT)); fps=cap.get(cv2.CAP_PROP_FPS)
    imgs=[]
    for f in frames:
        cap.set(cv2.CAP_PROP_POS_FRAMES, f); ok,im=cap.read()
        if not ok: continue
        im=cv2.resize(im,None,fx=scale,fy=scale)
        cv2.putText(im,f'{vid} f{f}',(10,30),cv2.FONT_HERSHEY_SIMPLEX,0.8,(0,0,255),2)
        imgs.append(im)
    rows=[np.hstack(imgs[i:i+2]) if len(imgs[i:i+2])==2 else np.hstack([imgs[i],np.zeros_like(imgs[i])]) for i in range(0,len(imgs),2)]
    cv2.imwrite(out+(name or vid)+'.jpg', np.vstack(rows))
    return n,fps
if __name__=='__main__':
    vid=sys.argv[1]; fr=[int(x) for x in sys.argv[2].split(',')]
    print(grab(vid,fr,float(sys.argv[3]) if len(sys.argv)>3 else 0.5))
