from build import *
MOTION=('speed','acceleration','displacement','path_length')
def key_cols(): return ['base','nq','prior','depth_info','target_unit']
def segtwin(m):
    """D3 rows of a *_segmented clip take the original clip's answer for the identical question/prior/depth_info."""
    d=m[m.category=='D3']; n=0
    for _,g in d.groupby(key_cols()):
        orig=g[~g.video_id.str.endswith('_segmented')]; seg=g[g.video_id.str.endswith('_segmented')]
        if len(orig)==1 and len(seg)>=1:
            m.loc[seg.index,'ans']=float(orig.ans.iloc[0]); m.loc[seg.index,'method']=orig.method.iloc[0]; n+=len(seg)
    return m,n
def lab_render_direct_motion(m, kinds=MOTION):
    """lab s/x renders: direct-routed motion answers take the base render's answer."""
    d=m[(m.category=='D3')&(m.video_source=='lab')]; n=0
    for _,g in d.groupby(key_cols()):
        base=g[g.video_id==g.base]
        if len(base)!=1: continue
        oth=g[(g.video_id!=g.base)&(g.method=='direct')&g.kind.isin(kinds)]
        if len(oth):
            m.loc[oth.index,'ans']=float(base.ans.iloc[0]); n+=len(oth)
    return m,n
def lab_render_geo_median(m):
    """lab: groups where every render is geometry-routed take the median over the renders."""
    d=m[(m.category=='D3')&(m.video_source=='lab')]; n=0
    for _,g in d.groupby(key_cols()):
        if len(g)<3 or not g.method.astype(str).str.startswith('geometry').all(): continue
        v=float(np.exp(np.median(np.log(g.ans.astype(float))))); m.loc[g.index,'ans']=v; n+=len(g)
    return m,n
def lab_kcal_static(m, min_n=2):
    d=m[(m.category=='D3')&(m.video_source=='lab')]
    k=video_k(d,min_n=min_n); kv=np.exp(k['median'])
    sel=(m.category=='D3')&(m.video_source=='lab')&(m.method=='direct')&m.kind.isin(('size','distance'))&m.video_id.isin(kv.index)&m.direct_value.notna()
    m.loc[sel,'ans']=m.loc[sel,'direct_value']*m.loc[sel,'video_id'].map(kv)
    return m,int(sel.sum())
def sibling_transfer(m):
    """Simulation clips re-rendered from one scene (identical object-camera distances at identical times in depth_info):
    a D3 size/speed question about an object whose same quantity is stated as the prior of a sibling clip takes that value."""
    import transfer as TR
    c=TR.candidates()
    upd=dict(zip(c.qid,c.transfer))
    sel=m.qid.isin(list(upd))&(m.category=='D3')
    m.loc[sel,'ans']=m.loc[sel,'qid'].map(upd); m.loc[sel,'method']='transfer'
    return m,int(sel.sum())
