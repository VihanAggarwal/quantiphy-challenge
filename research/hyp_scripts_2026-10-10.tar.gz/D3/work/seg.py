import cv2, numpy as np, sys
V='/home/user/quantiphy-challenge/data/QuantiPhy/'
def frames(vid):
    cap=cv2.VideoCapture(V+vid+'.mp4'); out=[]
    while True:
        ok,im=cap.read()
        if not ok: break
        out.append(im)
    return out
def blobs(mask, min_area=30):
    n,lab,st,cen=cv2.connectedComponentsWithStats(mask.astype(np.uint8),8)
    res=[]
    for i in range(1,n):
        x,y,w,h,a=st[i]
        if a>=min_area: res.append(dict(cx=cen[i][0],cy=cen[i][1],x=x,y=y,w=w,h=h,area=a,deq=2*np.sqrt(a/np.pi)))
    return sorted(res,key=lambda b:-b['area'])
