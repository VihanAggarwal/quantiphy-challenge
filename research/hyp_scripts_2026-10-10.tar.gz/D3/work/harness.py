from load import *
from qp.mra import item_scores
SUS={403, 2349, 2607, 3049, 3051, 1123, 1130, 1354, 1355, 3054, 139, 2276}
def nk(x):
    return re.sub(r'[^a-z0-9.]','',str(x).lower().replace('？','?')).rstrip('.')
def known():
    """test D3 rows whose clip (any render/twin) is a validation clip and whose question text+prior match a val question."""
    v=load_split('val'); v['base']=v.video_id.map(base_id); v['nq']=v.question.map(nk)
    v['np']=v.prior.map(nk)
    t=load_split('test'); t['base']=t.video_id.map(base_id); t['nq']=t.question.map(nk); t['np']=t.prior.map(nk)
    k=t.merge(v[['base','nq','np','answer','qid']].rename(columns={'qid':'val_qid'}),on=['base','nq','np'])
    return k
def score_csv(path, k, cat='D3', excl_sus=True):
    s=pd.read_csv(path)[['id','parsed_value']]
    x=k[k.category==cat].merge(s,left_on='qid',right_on='id')
    if excl_sus: x=x[~x.val_qid.isin(SUS)]
    x['sc']=item_scores(x.parsed_value,x.answer)
    return x
if __name__=='__main__':
    k=known(); print(k.groupby(['category','video_source']).size())
    d=k[k.category=='D3']; print(d.groupby('video_id').size())
