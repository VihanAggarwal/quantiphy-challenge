from load import *
ASSUMED_T = ('geo:target_depth_from_prior','geo:target_depth_scene_median','geo:target2_depth_from_target',
             'geo:target_depth_claude_estimate','geo:target2_depth_claude_estimate','geo:target_depth_from_target2','geo:3d_without_depth')
def anchors_mask(d, kinds=('size','distance')):
    fl=d['flags'].astype(str)
    ok=d.method.str.startswith('geometry') & d.kind.isin(kinds) & d.geo_value.notna() & d.direct_value.notna()
    ok&= ~d.geo_method.astype(str).eq('depth_direct')
    for f in ASSUMED_T: ok&=~fl.str.contains(f, regex=False)
    return ok
def video_k(d, kinds=('size','distance'), min_n=2):
    a=d[anchors_mask(d,kinds)]
    lr=np.log(a.geo_value/a.direct_value)
    g=lr.groupby(a.video_id).agg(['median','count','std'])
    g=g[g['count']>=min_n]
    return g
BAD_F=('geo:default_focal','geo:prior_depth_assumed_scene_median','geo:f_ill_conditioned','geo:prior_depth_claude_estimate','geo_rejected_implausible')
def anchors_any(d, kinds=('size',), strict_f=True):
    fl=d['flags'].astype(str)
    ok=d.kind.isin(kinds) & d.geo_value.notna() & d.direct_value.notna() & (d.geo_value>0) & (d.direct_value>0)
    ok&= ~d.geo_method.astype(str).eq('depth_direct')
    for f in ASSUMED_T + (BAD_F if strict_f else ()): ok&=~fl.str.contains(f, regex=False)
    return ok
def video_k_any(d, kinds=('size',), min_n=2, strict_f=True):
    a=d[anchors_any(d,kinds,strict_f)]
    lr=np.log(a.geo_value/a.direct_value)
    g=lr.groupby(a.video_id).agg(['median','count','std'])
    return g[g['count']>=min_n]
