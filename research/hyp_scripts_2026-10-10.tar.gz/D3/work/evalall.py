from harness import *
import sys, glob
SP='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/D3/'
k=known()
paths=[R+'/submissions/trackA_opus55_high_v2.csv', R+'/submissions/trackA_probe3_s2maxext_d2denseoff_labdirect.csv', R+'/submissions/trackA_probe2_geo_nonlab3d.csv']+sorted(glob.glob(SP+'D3_*.csv'))
for p in paths:
    x=score_csv(p,k)
    lab=x[x.video_source=='lab']; nl=x[x.video_source!='lab']
    print('%-45s all %.3f (n=%d) | lab %.3f (n=%d) | nonlab %.3f (n=%d)'%(p.split('/')[-1][:45], x.sc.mean(), len(x), lab.sc.mean(), len(lab), nl.sc.mean(), len(nl)))
