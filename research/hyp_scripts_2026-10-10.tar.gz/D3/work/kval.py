from kcal import *
from qp.mra import item_scores
SUS={403, 2349, 2607, 3049, 3051, 1123, 1130, 1354, 1355, 3054, 139, 2276}
runs={'hr_v1_high':('val_hires','val_hr_v1_high'),'opus_high':('val','val_opus_high'),'opus_med':('val','val_opus_med'),'opus_med2':('val','val_opus_med2'),'opus_low':('val','val_opus_low'),'hr_v2_high':('val_hires','val_hr_v2_high'),'fable_high':('val','val_fable_high')}
def load_run(sp,rn):
    df=load_split(sp); r=pd.read_csv(R+'/runs/'+rn+'/'+sp+'.csv'); m=df.merge(r,left_on='qid',right_on='id')
    recs=records(R+'/runs/'+rn+'/'+sp+'/records'); qi=qinfo(recs); m=m.join(qi,on='qid')
    return m
