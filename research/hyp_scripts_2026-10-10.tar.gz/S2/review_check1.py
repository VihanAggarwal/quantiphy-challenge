import sys, numpy as np, pandas as pd
sys.path.insert(0,'/home/user/quantiphy-challenge')
from qp.data import load_split
H='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/'
t=load_split('test'); cat=t.set_index('qid').category
print('test cols', list(t.columns))
v2=pd.read_csv('submissions/trackA_opus55_high_v2.csv')
tmpl_candidates=[]
import glob
print(glob.glob('submissions/*')[:30])
for f in ['s2_pad08_segtwin','s2_segtwin','s2_pad08','s2_pad08_maxext_segtwin','s2_pad08_maxext']:
    d=pd.read_csv(H+f+'.csv')
    ok_ids = list(d.id)==list(v2.id)
    vals=pd.to_numeric(d.parsed_value,errors='coerce')
    fin=np.isfinite(vals).all(); pos=(vals>0).all()
    r=vals/v2.parsed_value
    ch=~np.isclose(vals,v2.parsed_value,rtol=1e-12,atol=0)
    cats=cat.reindex(d.id[ch]).value_counts().to_dict()
    print(f, len(d), list(d.columns), 'ids==v2', ok_ids, 'finite',fin,'pos',pos,'changed',ch.sum(),cats,'median',np.median(r[ch]).round(4), 'min/max ratio', r[ch].min().round(3), r[ch].max().round(3), 'dups', d.id.duplicated().sum())
