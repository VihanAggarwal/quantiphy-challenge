import sys, re, copy
H='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2'
sys.path.insert(0,H+'/tools')
from h import *
src=open(H+'/t2/make_variant.py').read()
head=src.split("anns, df, recs = load(")[0]
head=head.replace("NAME, K = sys.argv[1], float(sys.argv[2])","NAME,K='x',0.8").replace("MAXEXT = len(sys.argv) > 3 and sys.argv[3] == 'maxext'","MAXEXT=False")
ns={}; exec(head, ns); pad_anns=ns['pad_anns']; is_marking=ns['is_marking']
anns, df, recs = load(H+'/s2_test_anns.pkl')
R=pd.read_pickle('res_k.pkl')
recs2=rc.prepare_records(df,recs)
vid=dict(zip(df.qid,df.video_id)); qq=dict(zip(df.qid,df.question)); pr=dict(zip(df.qid,df.prior))
A={k:pad_anns(anns,df,recs,k)[0] for k in (0.0,0.8)}
rows=[]
for q in df.qid:
    rec=recs2[vid[q]]; sc=float(rec['meta'].get('scale') or 1.0); d=0.8/sc
    dbg={}
    for k in (0.0,0.8):
        a=A[k][q]
        ans=G.solve(a.spec,a.tracks,tuple(rec['meta']['image_size']),float(rec['meta']['fps']),seen_scale=sc)
        dbg[k]=(ans.value, ans.debug.get('prior_px'), ans.debug.get('target_px'), ans.flags, ans.method)
    a=anns[q]
    rows.append(dict(qid=q,vid=vid[q],tk=a.spec.target.kind,pk=a.spec.prior.kind,pobj='|'.join(a.spec.prior.objects),tobj='|'.join(a.spec.target.objects),
        pmark=is_marking(a.spec.prior),tmark=is_marking(a.spec.target),sc=sc,d=d,
        g0=dbg[0.0][0],g8=dbg[0.8][0],p0=dbg[0.0][1],p8=dbg[0.8][1],t0=dbg[0.0][2],t8=dbg[0.8][2],flags=';'.join(dbg[0.0][3]),method=dbg[0.0][4],
        v0=R[0.0].parsed_value[q],v8=R[0.8].parsed_value[q],how0=R[0.0].method[q],how8=R[0.8].method[q]))
V=pd.DataFrame(rows)
V['dp']=V.p8-V.p0; V['dt']=V.t8-V.t0
V['r']=V.v8/V.v0
V.to_pickle('verify.pkl')
pd.set_option('display.width',260); pd.set_option('display.max_colwidth',40); pd.set_option('display.max_rows',500)
ch=V[~np.isclose(V.v0,V.v8,rtol=1e-12,atol=0)]
print('changed',len(ch))
# expected deltas
pad_p = (V.pk.isin(['size','other','distance'])) & ~V.pmark
pad_t = (V.tk.isin(['size','other'])) & ~V.tmark
V['exp_dp']=np.where(pad_p,V.d,0.0); V['exp_dt']=np.where(pad_t,V.d,0.0)
bad=V[(V.p0.notna()) & ((~np.isclose(V.dp.fillna(0),V.exp_dp,atol=1e-6)) | ((V.t0.notna()) & ~np.isclose(V.dt.fillna(0),V.exp_dt,atol=1e-6)))]
print('rows whose px deltas deviate from the rule:',len(bad))
print(bad[['qid','vid','pk','tk','pobj','tobj','pmark','tmark','d','dp','dt','flags']].to_string())
print(ch.how0.value_counts(), (ch.how0!=ch.how8).sum())
nonch=V[np.isclose(V.v0,V.v8,rtol=1e-12,atol=0)]
print('unchanged by kind/marks', nonch.groupby(['pk','tk','pmark','tmark','how0']).size())
