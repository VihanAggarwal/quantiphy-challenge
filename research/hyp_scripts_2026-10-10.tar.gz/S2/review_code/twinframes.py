import sys, cv2, numpy as np, pandas as pd
sys.path.insert(0,'/home/user/quantiphy-challenge')
from qp.data import load_split
t=load_split('test')
D=pd.read_pickle('segrev.pkl')
vids=sorted(set(D.vid))
vp=dict(zip(t.video_id,t.video_path)); fps=dict(zip(t.video_id,t.fps))
for s in vids:
    o=s.replace('_segmented','')
    r=[]
    for v in (s,o):
        c=cv2.VideoCapture(vp[v]); r.append((int(c.get(cv2.CAP_PROP_FRAME_COUNT)), round(c.get(cv2.CAP_PROP_FPS),2), int(c.get(cv2.CAP_PROP_FRAME_WIDTH)), int(c.get(cv2.CAP_PROP_FRAME_HEIGHT)), fps[v])); c.release()
    print(s, r[0], o, r[1], 'SAME' if r[0]==r[1] else 'DIFF')
