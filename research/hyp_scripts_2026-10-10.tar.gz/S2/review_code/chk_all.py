import sys, numpy as np, pandas as pd
sys.path.insert(0,'/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/t2')
from segtwin import *
cat=t.set_index('qid').category
v2=pd.read_csv(V2)
for b,n in ((V2,'s2_segtwin'),(H+'/s2_pad08.csv','s2_pad08_segtwin'),(H+'/s2_pad08_maxext.csv','s2_pad08_maxext_segtwin')):
    out,ch=apply(pd.read_csv(b)); s=pd.read_csv(f'{H}/{n}.csv')
    same=np.allclose(out.parsed_value,s.parsed_value,rtol=1e-12,atol=0)
    d=~np.isclose(s.parsed_value,v2.parsed_value,rtol=1e-12,atol=0)
    print(n,'reproduced',same,'ids same',list(s.id)==list(v2.id),'changed',d.sum(),'non-S2 changed',int((d & (s.id.map(cat)!='S2')).sum()),'nan',s.parsed_value.isna().sum(),'<=0',(s.parsed_value<=0).sum())
