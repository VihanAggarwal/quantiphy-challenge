import sys, re, numpy as np, pandas as pd
sys.path.insert(0,'/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/t2')
from segtwin import *
pd.set_option('display.width',300); pd.set_option('display.max_colwidth',120); pd.set_option('display.max_rows',500)
base=pd.read_csv(H+'/s2_pad08.csv')
out,ch=apply(base)
ship=pd.read_csv(H+'/s2_pad08_segtwin.csv')
print('reproduces shipped:', np.allclose(out.parsed_value, ship.parsed_value, rtol=1e-12, atol=0), len(ch))
T=t.set_index('qid')
orig=t[~t.video_id.str.endswith('_segmented')]
from collections import defaultdict
kk=defaultdict(list)
for r in orig.itertuples(): kk[(r.twin,r.nq,r.pv)].append(r.qid)
dups={k:v for k,v in kk.items() if len(v)>1}
print('duplicate original keys:', len(dups))
for k,v in list(dups.items())[:20]:
    print('  ',k[0], v, [T.question[x] for x in v], [base.set_index('id').parsed_value[x] for x in v])
rows=[]
key={k:v[-1] for k,v in kk.items()}
for r in ch.itertuples():
    s=T.loc[r.qid]; q=key[(s.twin,s.nq,s.pv)]; o=T.loc[q]
    rows.append(dict(seg=r.qid,orig=q,vid=r.vid,same_q=s.question==o.question,same_p=str(s.prior)==str(o.prior),
        same_dep=str(s.depth_info)==str(o.depth_info), qs=s.question, qo=o.question, ps=s.prior, po=o.prior, old=r.old,new=r.new, cat_o=o.category, vt_s=s.video_type, vt_o=o.video_type))
D=pd.DataFrame(rows)
print(D[['same_q','same_p','same_dep']].value_counts())
print(D[~(D.same_q&D.same_p)][['seg','orig','vid','qs','qo','ps','po']].to_string())
print(D.groupby('vid').apply(lambda g: pd.Series(dict(n=len(g), med=np.median(g.new/g.old)))).to_string())
D.to_pickle('segrev.pkl')
# unmatched S2 seg rows
s=t[(t.category=='S2')&t.video_id.str.endswith('_segmented')]
nm=s[[(a,b,c) not in key for a,b,c in zip(s.twin,s.nq,s.pv)]]
print('S2 seg total',len(s),'unmatched',len(nm))
for r in nm.itertuples():
    cands=orig[(orig.twin==r.twin)]
    best=[c for c in cands.itertuples() if c.nq==r.nq]
    print('  ',r.qid,r.video_id,'|',r.question,'|',r.prior,'| same-q orig:',[(c.qid,c.prior) for c in best])
