"""S2_pad08_segtwin with the marking regex applied to the head noun only ('car on leftmost lane' is a car)."""
import sys, numpy as np, pandas as pd
H='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2'
sys.path.insert(0,H+'/t2')
from segtwin import apply, t
res=pd.read_pickle('res_fixmark.pkl')        # fixmark.py: K=0.8, head-noun marking test, base repo
v2=pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv')
s2=set(t[t.category=='S2'].qid); assert set(res.index)==s2
base=v2.copy(); base['parsed_value']=[res.parsed_value[i] if i in s2 else v for i,v in zip(base.id,base.parsed_value)]
out,ch=apply(base)
out.to_csv('s2_pad08_segtwin_fixmark.csv',index=False)
main=pd.read_csv(H+'/s2_pad08_segtwin.csv'); integ=pd.read_csv(H+'/review_integrity/s2_pad08_segtwin_fixregex.csv')
d=~np.isclose(out.parsed_value,main.parsed_value,rtol=1e-12,atol=0)
cat=t.set_index('qid').category
dv=~np.isclose(out.parsed_value,v2.parsed_value,rtol=1e-12,atol=0)
r=out.parsed_value/v2.parsed_value
print('vs main differs',int(d.sum()),list(out.id[d]),'| vs integrity fix identical',np.allclose(out.parsed_value,integ.parsed_value,rtol=1e-12,atol=0),
      '| vs v2 changed',int(dv.sum()),'non-S2',int((dv&(out.id.map(cat)!='S2')).sum()),'median ratio %.4f'%np.median(r[dv]),'nan',out.parsed_value.isna().sum(),'ids',list(out.id)==list(v2.id))
