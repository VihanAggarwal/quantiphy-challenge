"""Re-derive the mask reference of t2/twins3.py with a rotation-robust caliper: Feret width along Claude's
direction (twins3's reference) vs the minimum Feret width within +-8 deg of it (the object's own dimension
for convex elongated shapes; equal for round ones)."""
import sys, math, cv2, numpy as np, pandas as pd
cv2.setNumThreads(1)
from pathlib import Path
sys.path.insert(0, '/home/user/quantiphy-challenge'); sys.path.insert(0, '/home/user/quantiphy-challenge/scripts')
import run_claude as rc
from qp.data import load_split
from qp import claude_annotate as ca
df = load_split('test')
segs = sorted(v for v in set(df.video_id) if v.endswith('_segmented') and v.startswith('simulation') and v[:-10] in set(df.video_id))
vids = set(segs) | {s[:-10] for s in segs}
sub = df[df.video_id.isin(vids)]
recs = rc.load_records(Path('/home/user/quantiphy-challenge/runs/test_v1_high_854/test/records'))
recs = {v: r for v, r in recs.items() if v in vids}
precs = rc.prepare_records(sub, recs)
anns = ca.load_annotations(precs)
paths = dict(zip(sub.video_id, sub.video_path))

def read_frames(path, idxs):
    out, cap, i, want = {}, cv2.VideoCapture(path), 0, set(idxs)
    last = max(want) if want else -1
    while i <= last and cap.grab():
        if i in want:
            ok, im = cap.retrieve()
            if ok: out[i] = im
        i += 1
    return out

ANG = np.deg2rad(np.arange(-8, 8.01, 0.25))
def refs(seg, box, ext):
    H_, W_ = seg.shape[:2]
    dev = (255 - seg.astype(np.int16)).max(axis=2).astype(np.float32)
    x0, y0, x1, y1 = box
    m = 0.25 * max(x1 - x0, y1 - y0) + 8
    wx0, wy0 = max(0, int(x0 - m)), max(0, int(y0 - m)); wx1, wy1 = min(W_, int(math.ceil(x1 + m))), min(H_, int(math.ceil(y1 + m)))
    win = dev[wy0:wy1, wx0:wx1]
    mk = (win > 40).astype(np.uint8)
    if mk.sum() < 4: return None
    n, lab, st, _ = cv2.connectedComponentsWithStats(mk, connectivity=8)
    bx0, by0, bx1, by1 = int(x0 - wx0 - 2), int(y0 - wy0 - 2), int(x1 - wx0 + 2), int(y1 - wy0 + 2)
    inbox = lab[max(0, by0):max(0, by1), max(0, bx0):max(0, bx1)]
    keep = [k for k in range(1, n) if (inbox == k).sum() >= max(3, 0.3 * st[k, cv2.CC_STAT_AREA])]
    if not keep: return None
    sel = np.isin(lab, keep).astype(np.uint8)
    ys, xs = np.nonzero(sel)
    if xs.min() == 0 and wx0 > 0 or ys.min() == 0 and wy0 > 0 or xs.max() == win.shape[1] - 1 and wx1 < W_ or ys.max() == win.shape[0] - 1 and wy1 < H_:
        return None
    er = cv2.erode(sel, np.ones((3, 3), np.uint8), iterations=2).astype(bool)
    D = float(np.median(win[er])) if er.sum() >= 5 else float(np.median(win[sel.astype(bool)]))
    zone = cv2.dilate(sel, np.ones((3, 3), np.uint8), iterations=2).astype(bool)
    mm = zone & (win > 0.5 * D)
    yy, xx = np.nonzero(mm)
    X = xx + wx0 + 0.5; Y = yy + wy0 + 0.5
    e = np.asarray(ext, float); u = e[1] - e[0]; L = np.linalg.norm(u); a0 = math.atan2(u[1], u[0])
    fer = []
    for da in ANG:
        c, s = math.cos(a0 + da), math.sin(a0 + da)
        p = X * c + Y * s
        fer.append(p.max() - p.min() + abs(c) + abs(s))
    fer = np.array(fer)
    i0 = len(ANG) // 2
    return dict(f_u=fer[i0], f_min=fer.min(), a_min=float(np.rad2deg(ANG[fer.argmin()])), f_max=fer.max())

items = {}
seen = set()
for r in sub.sort_values('qid').itertuples():
    a = anns.get(int(r.qid))
    if a is None: continue
    for tr in a.tracks:
        q = a.spec.prior if tr.role in ('prior', 'prior2') else a.spec.target
        if q.kind != 'size' or tr.role not in ('prior', 'target'): continue
        for o in tr.obs:
            if o.extent is None or o.box is None: continue
            key = (r.video_id, tr.role, tr.object, round(o.t, 3), tuple(np.round(np.ravel(o.extent), 1)))
            if key in seen: continue
            seen.add(key)
            items.setdefault(r.video_id, []).append(dict(vid=r.video_id, seg=r.video_id.endswith('_segmented'), qid=int(r.qid), role=tr.role,
                obj=tr.object, dim=q.dimension, frame=int(round(o.t * float(r.fps))), ext=o.extent, box=o.box, scale=float(precs[r.video_id]['meta']['scale'])))
rows = []
for vid, its in items.items():
    orig = vid[:-10] if vid.endswith('_segmented') else vid
    fr = sorted({it['frame'] for it in its})
    segf = read_frames(paths[orig + '_segmented'], fr)
    for it in its:
        sg = segf.get(it['frame'])
        if sg is None: continue
        rf = refs(sg, it['box'], it['ext'])
        if rf is None: continue
        e = np.asarray(it['ext'], float)
        row = {k: v for k, v in it.items() if k not in ('ext', 'box')}
        row['claude'] = float(np.linalg.norm(e[1] - e[0])); row.update(rf)
        rows.append(row)
    print(vid, len(its), flush=True)
out = pd.DataFrame(rows); out.to_pickle('feret.pkl'); print(len(out))
