import sys, re, copy
H='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2'
sys.path.insert(0,H+'/tools')
from h import *
src=open(H+'/t2/make_variant.py').read()
head=src.split("anns, df, recs = load(")[0]
head=head.replace("NAME, K = sys.argv[1], float(sys.argv[2])","NAME,K='x',0.8").replace("MAXEXT = len(sys.argv) > 3 and sys.argv[3] == 'maxext'","MAXEXT=False")
ns={}; exec(head, ns); pad_anns=ns['pad_anns']; MARKING=ns['MARKING']
MOD = re.compile(r"\s+\b(on|in|at|near|closest to|nearest to|next to|beside|along|by|crossing|inside|within)\b.*$", re.I)
def is_marking_head(q):
    return any(MARKING.search(MOD.sub('', o or '')) for o in (q.objects or []))
anns, df, recs = load(H+'/s2_test_anns.pkl')
# which quantities flip
flip=[]
for q,a in anns.items():
    for role,quant in (('prior',a.spec.prior),('target',a.spec.target)):
        if ns['is_marking'](quant)!=is_marking_head(quant): flip.append((q,role,quant.kind,quant.objects))
print('flipped quantities', flip)
pad_anns.__globals__['is_marking']=is_marking_head
pa,n=pad_anns(anns,df,recs,0.8)
res=rc.build_results(df,recs,anns=pa).set_index('id')
ship=pd.read_csv(H+'/s2_pad08.csv').set_index('id').parsed_value
d=~np.isclose(res.parsed_value.values, ship[res.index].values, rtol=1e-12, atol=0)
qq=dict(zip(df.qid,df.question))
for q in res.index[d]: print(q, qq[q], ship[q], res.parsed_value[q], res.parsed_value[q]/ship[q])
res.to_pickle('res_fixmark.pkl')
