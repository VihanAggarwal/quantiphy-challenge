import sys, re, collections
H='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2'
sys.path.insert(0,H+'/tools')
from h import *
anns, df, recs = load(H+'/s2_test_anns.pkl')
vid=dict(zip(df.qid,df.video_id)); qq=dict(zip(df.qid,df.question)); pr=dict(zip(df.qid,df.prior))
MARKING = re.compile(r"\b(lanes?|courts?|lines?|circles?|field|pitch|goal|calibre|caliber|ruler|markings?|road|crosswalk)\b", re.I)
rows=[]
for q,a in anns.items():
    for role,quant in (('prior',a.spec.prior),('target',a.spec.target)):
        mk=any(MARKING.search(o or '') for o in (quant.objects or []))
        trs=[t for t in a.tracks if (t.role.startswith('prior'))==(role=='prior')]
        next_=sum(1 for t in trs for o in t.obs if o.extent is not None)
        nbox=sum(1 for t in trs for o in t.obs if o.box is not None)
        rows.append(dict(qid=q,vid=vid[q],role=role,kind=quant.kind,objs='|'.join(quant.objects or []),dim=quant.dimension,mark=mk,ntr=len(trs),next=next_,nbox=nbox,roles=','.join(t.role for t in trs)))
R=pd.DataFrame(rows)
R.to_pickle('enum.pkl')
pd.set_option('display.width',250); pd.set_option('display.max_colwidth',70); pd.set_option('display.max_rows',500)
print(R.groupby(['role','kind','mark']).size())
print(R[R.kind.isin(['other','distance'])].to_string())
