import sys, re, copy, json
H='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2'
sys.path.insert(0,H+'/tools'); sys.path.insert(0,H+'/t2')
from h import *
import importlib.util
spec=importlib.util.spec_from_file_location('mv_src', H+'/t2/make_variant.py')
src=open(H+'/t2/make_variant.py').read()
head=src.split("anns, df, recs = load(")[0]
head=head.replace("NAME, K = sys.argv[1], float(sys.argv[2])","NAME,K='x',0.8").replace("MAXEXT = len(sys.argv) > 3 and sys.argv[3] == 'maxext'","MAXEXT=False")
ns={}; exec(head, ns)
pad_anns=ns['pad_anns']; is_marking=ns['is_marking']
anns, df, recs = load(H+'/s2_test_anns.pkl')
v2=pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv').set_index('id').parsed_value
out={}
for k in (0.0,0.8):
    pa,n=pad_anns(anns,df,recs,k)
    res=rc.build_results(df,recs,anns=pa).set_index('id')
    out[k]=res
    d=~np.isclose(res.parsed_value.values, v2[res.index].values, rtol=1e-12, atol=0)
    print('K',k,'padded',n,'differ from v2',int(d.sum()))
    if k==0.0:
        for q in res.index[d][:20]: print('   drift',q, v2[q], res.parsed_value[q], res.method[q])
ship=pd.read_csv(H+'/s2_pad08.csv').set_index('id').parsed_value
r8=out[0.8]
d=~np.isclose(r8.parsed_value.values, ship[r8.index].values, rtol=1e-12, atol=0)
print('K0.8 vs shipped s2_pad08 differ', int(d.sum()))
pd.to_pickle(out,'res_k.pkl')
