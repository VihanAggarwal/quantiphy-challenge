import re, sys, numpy as np, pandas as pd
sys.path.insert(0,'/home/user/quantiphy-challenge')
from qp.data import load_split
from qp.mra import item_scores
H='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/'
def base(v, inet_seg):
    m=re.match(r'^simulation_(\d+)(_segmented)?$',v)
    if m: return 'simulation_'+m.group(1)
    m=re.match(r'^internet_(\d+)(_segmented)?$',v)
    if m: return ('internet_'+m.group(1)) if (inet_seg or not m.group(2)) else v
    m=re.match(r'^captured_(\d+)[a-zA-Z]*$',v)
    if m: return 'captured_'+m.group(1)
    return v
ws=lambda s: re.sub(r'\s+','',str(s)).strip().lower()
def nql(q):
    q=re.sub(r"(\d+)\.0+(?!\d)", r"\1", str(q).lower()); return re.sub(r"[^a-z0-9.]","",q)
v=load_split('val'); t=load_split('test')
files={'v2':'/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv'}
for n in ['s2_pad08','s2_segtwin','s2_pad08_segtwin','s2_pad08_maxext_segtwin','s2_pad08_maxext']: files[n]=H+n+'.csv'
import os
for extra in sys.argv[1:]: files[os.path.basename(extra)[:-4]]=extra
P={n:pd.read_csv(f).set_index('id').parsed_value for n,f in files.items()}
for label,inet_seg,qf in (('strict(sim/lab rerenders, exact q/prior/depth)',False,ws),('incl internet_seg',True,ws),('incl internet_seg, loose q',True,nql)):
    for d in (v,t): d['k']=['\x1f'.join((base(a,inet_seg),qf(b),ws(c),ws(e))) for a,b,c,e in zip(d.video_id,d.question,d.prior,d.depth_info)]
    amap=v.groupby('k').answer.first()
    k=t[(t.category=='S2')&t.k.isin(amap.index)].copy(); k['ans']=k.k.map(amap)
    seg=k.video_id.str.endswith('_segmented').values
    print(f'== {label}: n={len(k)} (seg {seg.sum()}) clips', k.video_id.value_counts().to_dict())
    for n,p in P.items():
        sc=item_scores(p[k.qid].values,k.ans.values)
        print(f'  {n:28s} all {sc.mean():.4f}  orig {sc[~seg].mean():.4f}  seg {sc[seg].mean() if seg.any() else float("nan"):.4f}')
    if label.startswith('strict'):
        k.to_pickle('known_strict_s2.pkl')
