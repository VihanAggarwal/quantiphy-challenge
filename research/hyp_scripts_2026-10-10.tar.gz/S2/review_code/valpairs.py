import sys, numpy as np, pandas as pd
sys.path.insert(0,'/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/t2')
from segtwin import *
pd.set_option('display.width',300); pd.set_option('display.max_colwidth',90); pd.set_option('display.max_rows',500)
v=load_split('val')
v['twin']=v.video_id.str.replace('_segmented','',regex=False); v['nq']=v.question.map(normq); v['pv']=v.prior.map(pval)
print('val videos', sorted(v.video_id.unique()))
seg=v[v.video_id.str.endswith('_segmented')]; o=v[~v.video_id.str.endswith('_segmented')]
m=seg.merge(o,on=['twin','nq'],suffixes=('_s','_o'))
print('val seg/orig pairs same question:',len(m))
print(m[['qid_s','qid_o','video_id_s','category_s','question_s','prior_s','prior_o','answer_s','answer_o']].to_string())
# also all-test: do seg and orig test clips have same frame counts / fps
t2=t.copy()
print(t2.columns.tolist())
