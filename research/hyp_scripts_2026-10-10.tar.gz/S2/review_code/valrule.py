import sys, re, copy
H='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2'
sys.path.insert(0,H+'/tools')
from valrun import *
src=open(H+'/t2/make_variant.py').read()
head=src.split("anns, df, recs = load(")[0]
head=head.replace("NAME, K = sys.argv[1], float(sys.argv[2])","NAME,K='x',0.8").replace("MAXEXT = len(sys.argv) > 3 and sys.argv[3] == 'maxext'","MAXEXT=False")
ns={}; exec(head, ns); pad_anns=ns['pad_anns']; MARKING=ns['MARKING']
MOD = re.compile(r"\s+\b(on|in|at|near|closest to|nearest to|next to|beside|along|by|crossing|inside|within)\b.*$", re.I)
def head_mark(q): return any(MARKING.search(MOD.sub('', o or '')) for o in (q.objects or []))
orig_mark=ns['is_marking']
out=[]
for run in RUNS:
    anns, df, recs = load(f'{H}/val2d_{run}.pkl')
    split='val_hires' if 'hr_' in run else 'val'
    for label,k,mk in (('k0',0.0,orig_mark),('pad08',0.8,orig_mark),('pad08fix',0.8,head_mark)):
        pad_anns.__globals__['is_marking']=mk
        pa,n=pad_anns(anns,df,recs,k)
        res=rc.build_results(df,recs,anns=pa)
        m=df.merge(res,left_on='qid',right_on='id')
        if 'answer' not in m.columns: m=m.merge(VAL[split][['qid','answer']],on='qid')
        m['mra']=item_scores(m.parsed_value,m.answer); m['run']=run; m['v']=label
        out.append(m[['qid','category','run','v','parsed_value','answer','mra']])
o=pd.concat(out); o.to_pickle('valrule.pkl')
print(o.groupby(['category','v']).mra.mean().unstack().round(4))
print(o[o.category=='S2'].groupby(['run','v']).mra.mean().unstack().round(4))
