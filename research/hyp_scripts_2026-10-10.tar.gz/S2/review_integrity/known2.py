import sys, re, numpy as np, pandas as pd
sys.path.insert(0,'/home/user/quantiphy-challenge')
from qp.data import load_split
from qp.mra import item_scores
from qp.claude_annotate import prior_si
pd.set_option('display.width',250); pd.set_option('display.max_colwidth',70); pd.set_option('display.max_rows',300)
t=load_split('test'); v=load_split('val')
fam=lambda x: re.sub(r'_segmented$','',x)
def ws(s): return re.sub(r'\s+',' ',str(s if s==s else '')).strip().lower()
def pv(p):
    x=prior_si(p); return round(x[0],9) if x else ws(p).replace(' ','')
for d in (t,v):
    d['fam']=d.video_id.map(fam); d['qq']=d.question.map(ws); d['pr']=d.prior.map(pv); d['dep']=d.depth_info.map(ws).str.replace(' ','')
vk=v.set_index(['fam','qq','pr','dep']).answer
assert not vk.index.duplicated().any()
e=t[t.category=='S2'].copy()
e['ans']=[vk.get(k,np.nan) for k in zip(e.fam,e.qq,e.pr,e.dep)]
e=e[e.ans.notna()].copy()
print('S2 known rows:', len(e), 'seg', e.video_id.str.endswith('_segmented').sum(), 'clips', e.video_id.nunique())
print(e.video_id.value_counts().sort_index().to_string())
e.to_pickle('known_s2.pkl')
H='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/'
files={'v2':'/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv','probe3':'/home/user/quantiphy-challenge/submissions/trackA_probe3_s2maxext_d2denseoff_labdirect.csv'}
for n in ['s2_pad08','s2_segtwin','s2_pad08_segtwin','s2_pad08_maxext','s2_pad08_maxext_segtwin']: files[n]=H+n+'.csv'
seg=e.video_id.str.endswith('_segmented').values
rows=[]
for n,f in files.items():
    p=pd.read_csv(f).set_index('id').parsed_value
    sc=item_scores(p[e.qid].values,e.ans.values)
    rows.append(dict(name=n,n=len(e),all=sc.mean(),orig=sc[~seg].mean(),seg=sc[seg].mean(),nseg=int(seg.sum())))
print(pd.DataFrame(rows).round(4).to_string())
