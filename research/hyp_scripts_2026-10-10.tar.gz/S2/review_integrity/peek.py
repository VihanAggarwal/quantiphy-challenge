import sys, re, numpy as np, pandas as pd
sys.path.insert(0,'/home/user/quantiphy-challenge')
from qp.data import load_split
t=load_split('test'); v=load_split('val')
for vid in ['internet_0001','simulation_0163','internet_0027']:
    for d,n in ((v,'VAL'),(t,'TEST')):
        s=d[d.video_id.str.replace('_segmented','')==vid]
        for r in s.itertuples(): print(n, r.video_id, r.category, repr(r.question), repr(r.prior), repr(r.depth_info))
