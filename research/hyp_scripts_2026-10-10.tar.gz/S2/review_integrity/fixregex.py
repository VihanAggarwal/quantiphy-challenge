import os, sys, re, copy
H = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2'
R = H + '/review_integrity'
sys.path.insert(0, H + '/tools')
from h import *  # noqa
src = open(H + '/t2/make_variant.py').read()
ns = {}
exec(src.split("anns, df, recs = load(")[0].split("from h import *")[1].replace("# noqa  (sets sys.path to QP_REPO, loads run_claude)", ""), globals(), ns)
MARKING = ns['MARKING']
MOD = re.compile(r"\s+\b(on|in|at|near|closest to|nearest to|next to|beside|along|by)\b.*$", re.I)
def is_marking_head(q):
    return any(MARKING.search(MOD.sub('', o or '')) for o in (q.objects or []))
ns['is_marking'] = is_marking_head
# rebind global used inside pad_anns
pad_anns = ns['pad_anns']; pad_anns.__globals__['is_marking'] = is_marking_head
anns, df, recs = load(H + '/s2_test_anns.pkl')
pa, n = pad_anns(anns, df, recs, 0.8)
res = rc.build_results(df, recs, anns=pa).set_index('id')
old = pd.read_pickle(R + '/res_base_0.8.pkl')
d = ~np.isclose(res.parsed_value.values, old.parsed_value[res.index].values, rtol=1e-12, atol=0)
vid = dict(zip(df.qid, df.video_id)); qq = dict(zip(df.qid, df.question))
print('padded', n, 'answers differing from shipped pad08:', int(d.sum()))
for q in res.index[d]:
    print(q, vid[q], qq[q], old.parsed_value[q], res.parsed_value[q], res.parsed_value[q]/old.parsed_value[q])
res.to_pickle(R + '/res_fixregex_0.8.pkl')
