import sys, re, numpy as np, pandas as pd
sys.path.insert(0,'/home/user/quantiphy-challenge')
from qp.data import load_split
from qp.mra import item_scores
H='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/'
e=pd.read_pickle('known_s2.pkl')
v=load_split('val'); v['fam']=v.video_id.str.replace('_segmented','',regex=False)
ws=lambda s: re.sub(r'\s+','',str(s)).lower()
vp=v.groupby('fam').prior.first().map(ws)
e['strict_prior']=[ws(p)==vp[f] for p,f in zip(e.prior,e.fam)]
F={'v2':'/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv'}
for n in ['s2_pad08','s2_segtwin','s2_pad08_segtwin','s2_pad08_maxext_segtwin']: F[n]=H+n+'.csv'
out={}
for n,f in F.items():
    p=pd.read_csv(f).set_index('id').parsed_value
    e[n]=item_scores(p[e.qid].values,e.ans.values)
print(e.groupby('video_id')[list(F)].mean().round(3).to_string())
s=e[e.strict_prior]
print('strict-prior known rows', len(s), s[list(F)].mean().round(4).to_dict())
