import sys, numpy as np, pandas as pd
sys.path.insert(0,'/home/user/quantiphy-challenge')
from qp.data import load_split
pd.set_option('display.width',250); pd.set_option('display.max_colwidth',75); pd.set_option('display.max_rows',300)
t=load_split('test').set_index('qid')
v2=pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv').set_index('id').parsed_value
st=pd.read_csv('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/s2_segtwin.csv').set_index('id').parsed_value
raw=pd.read_csv('/home/user/quantiphy-challenge/runs/test_v1_high_854/test.csv').set_index('id')
r=st/v2; ch=r[np.abs(np.log(r))>0.15].index
d=pd.DataFrame({'vid':t.video_id[ch],'q':t.question[ch],'prior':t.prior[ch],'v2':v2[ch].round(3),'new':st[ch].round(3),'direct_seg':raw.direct_value[ch].round(3),'flags':raw['flags'][ch].str[:60]})
print(d.to_string())
