import os, sys, re, copy
H = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2'
R = H + '/review_integrity'
sys.path.insert(0, H + '/tools')
from h import *  # noqa
src = open(H + '/t2/make_variant.py').read()
ns = {}
exec(src.split("anns, df, recs = load(")[0].split("from h import *")[1].replace("# noqa  (sets sys.path to QP_REPO, loads run_claude)", ""), globals(), ns)
pad_anns = ns['pad_anns']
anns, df, recs = load(H + '/s2_test_anns.pkl')
e = pd.read_pickle(R + '/known_s2.pkl').set_index('qid')
base = pd.read_pickle(R + '/res_base_0.8.pkl').parsed_value
v2 = pd.read_pickle(R + '/res_base_0.0.pkl').parsed_value
terms = {'none': None, 'all_but_ruler': r"lanes?|courts?|lines?|circles?|field|pitch|goal|markings?|road|crosswalk",
         'all_but_lane': r"courts?|lines?|circles?|field|pitch|goal|calibre|caliber|ruler|markings?|road|crosswalk"}
def score(p): return item_scores(p[e.index].values, e.ans.values).mean()
print('known rows: v2 %.4f  shipped pad08 %.4f' % (score(v2), score(base)))
for name, pat in terms.items():
    rx = re.compile(r"\b(" + pat + r")\b", re.I) if pat else None
    pad_anns.__globals__['is_marking'] = (lambda q, rx=rx: bool(rx) and any(rx.search(o or '') for o in (q.objects or [])))
    pa, n = pad_anns(anns, df, recs, 0.8)
    res = rc.build_results(df, recs, anns=pa).set_index('id').parsed_value
    d = ~np.isclose(res.values, base[res.index].values, rtol=1e-12, atol=0)
    kd = [q for q in res.index[d] if q in e.index]
    print(f'{name}: padded {n}, answers differing from shipped pad08 {int(d.sum())}, known rows differing {len(kd)}, known-row score {score(res):.4f}')
