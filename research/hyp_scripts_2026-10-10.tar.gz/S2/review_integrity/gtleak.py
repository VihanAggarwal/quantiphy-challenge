import sys, numpy as np, pandas as pd
sys.path.insert(0,'/home/user/quantiphy-challenge')
from qp.data import load_split
H='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/'
v=load_split('val'); vh=load_split('val_hires')
gts=np.unique(np.concatenate([v.answer.values.astype(float), vh.answer.values.astype(float)]))
v2=pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv').set_index('id').parsed_value
e=pd.read_pickle('known_s2.pkl').set_index('qid')
for n in ['s2_pad08_segtwin','s2_segtwin','s2_pad08','s2_pad08_maxext_segtwin']:
    p=pd.read_csv(H+n+'.csv').set_index('id').parsed_value
    ch=p.index[~np.isclose(p.values,v2.values,rtol=1e-12,atol=0)]
    near=[q for q in ch if np.any(np.isclose(p[q],gts,rtol=1e-6,atol=0))]
    # known rows: rel error distribution of changed known rows
    kr=[q for q in ch if q in e.index]
    exact=[q for q in kr if np.isclose(p[q],e.ans[q],rtol=1e-4)]
    print(n,'changed',len(ch),'changed values equal to some val GT (rtol 1e-6):',near,'| changed known rows',len(kr),'within 0.01% of their GT:',exact)
    for q in near: print('   ',q,p[q],v2[q])
