import sys, numpy as np, pandas as pd
sys.path.insert(0,'/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/t2')
import segtwin as S
H='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/'
R=H+'review_integrity/'
v2=pd.read_csv(S.V2, float_precision='round_trip')
res=pd.read_pickle(R+'res_fixregex_0.8.pkl').parsed_value
s2=set(S.t.qid[S.t.category=='S2']); assert set(res.index)==s2 and len(s2)==579
base=v2.copy(); base['parsed_value']=[res[i] if i in s2 else x for i,x in zip(base.id,base.parsed_value)]
out,ch=S.apply(base)
out.to_csv(R+'s2_pad08_segtwin_fixregex.csv',index=False)
a=pd.read_csv(S.V2,dtype=str); b=pd.read_csv(R+'s2_pad08_segtwin_fixregex.csv',dtype=str)
cat=S.t.set_index('qid').category
assert list(a.columns)==list(b.columns) and all((a[c].fillna('NA')==b[c].fillna('NA')).all() for c in a.columns if c!='parsed_value')
td=a.parsed_value!=b.parsed_value
print('text diffs vs v2 by category', cat[a.id.astype(int)[td]].value_counts().to_dict())
main=pd.read_csv(H+'s2_pad08_segtwin.csv',float_precision='round_trip'); f=pd.read_csv(R+'s2_pad08_segtwin_fixregex.csv',float_precision='round_trip'); v=pd.read_csv(S.V2,float_precision='round_trip')
assert np.isfinite(f.parsed_value).all() and (f.parsed_value>0).all() and len(f)==3289
dv=~np.isclose(f.parsed_value,v.parsed_value,rtol=1e-12,atol=0); dm=~np.isclose(f.parsed_value,main.parsed_value,rtol=1e-12,atol=0)
print('segtwin changes',len(ch),'| numeric vs v2',int(dv.sum()),'median ratio %.4f'%np.median((f.parsed_value/v.parsed_value)[dv]),'| vs main',int(dm.sum()),list(f.id[dm]), (f.parsed_value/main.parsed_value)[dm].round(4).tolist())
