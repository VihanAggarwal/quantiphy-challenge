import sys, re, collections
H='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2'
sys.path.insert(0,H+'/tools')
from h import *
anns, df, recs = load(H+'/s2_test_anns.pkl')
vid=dict(zip(df.qid,df.video_id))
MARKING = re.compile(r"\b(lanes?|courts?|lines?|circles?|field|pitch|goal|calibre|caliber|ruler|markings?|road|crosswalk)\b", re.I)
hits=collections.defaultdict(set); kinds=collections.Counter(); padded_kind=collections.Counter()
dist_ext=collections.defaultdict(set)
for q,a in anns.items():
    for role,quant in (('prior',a.spec.prior),('target',a.spec.target)):
        objs=quant.objects or []
        m=[MARKING.search(o or '') for o in objs]
        if any(m):
            for mm,o in zip(m,objs):
                if mm: hits[mm.group(1).lower()].add((vid[q],role,o, quant.kind))
        kinds[(role,quant.kind)]+=1
        if quant.kind=='distance' and not any(m):
            dist_ext[vid[q]].add((role, tuple(objs), len(objs)))
for k,v in hits.items():
    print(k, len(v)); [print('   ',x) for x in sorted(v)[:12]]
print(kinds)
print('distance quantities padded (not marking):')
for v,s in dist_ext.items(): print(' ',v,s)
