import os, sys, re, copy, json
H = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2'
R = H + '/review_integrity'
MAXEXT = len(sys.argv) > 1 and sys.argv[1] == 'maxext'
if MAXEXT:
    os.environ['QP_REPO'] = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/probe3/maxext/repo'
sys.path.insert(0, H + '/tools'); sys.path.insert(0, H + '/t2')
from h import *  # noqa
import importlib.util
src = open(H + '/t2/make_variant.py').read()
# pull only defs (MARKING, is_marking, pad_anns) without running the top-level script
ns = {}
exec(src.split("anns, df, recs = load(")[0].split("from h import *")[1].replace("# noqa  (sets sys.path to QP_REPO, loads run_claude)", ""), globals(), ns)
pad_anns = ns['pad_anns']; globals().update(ns)
anns, df, recs = load(H + '/s2_test_anns.pkl')
v2 = pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv').set_index('id').parsed_value
raw = pd.read_csv('/home/user/quantiphy-challenge/runs/test_v1_high_854/test.csv').set_index('id').parsed_value
out = {}
for K in (0.0, 0.8):
    pa, n = pad_anns(anns, df, recs, K)
    res = rc.build_results(df, recs, anns=pa).set_index('id')
    out[K] = res
    p = res.parsed_value
    d0 = ~np.isclose(p.values, v2[p.index].values, rtol=1e-12, atol=0)
    d1 = ~np.isclose(p.values, raw[p.index].values, rtol=1e-12, atol=0)
    print('maxext' if MAXEXT else 'base', 'K', K, 'padded', n, 'diff vs v2 S2:', int(d0.sum()), 'diff vs raw test.csv:', int(d1.sum()))
    res.to_pickle(f'{R}/res_{"maxext" if MAXEXT else "base"}_{K}.pkl')
