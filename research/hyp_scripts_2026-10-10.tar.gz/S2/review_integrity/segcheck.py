import sys, re, numpy as np, pandas as pd
sys.path.insert(0,'/home/user/quantiphy-challenge')
from qp.data import load_split
from qp.claude_annotate import prior_si
pd.set_option('display.width',250); pd.set_option('display.max_colwidth',80); pd.set_option('display.max_rows',300)
H='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/'
t=load_split('test')
def ws(s): return re.sub(r'\s+',' ',str(s)).strip().lower()
def nq_loose(q):
    q = re.sub(r"(\d+)\.0+(?!\d)", r"\1", str(q).lower()); return re.sub(r"[^a-z0-9.]", "", q)
def pv(p):
    x=prior_si(p); return round(x[0],9) if x else ws(p)
t['fam']=t.video_id.str.replace('_segmented','',regex=False); t['pv']=t.prior.map(pv)
t['dep']=t.depth_info.fillna('').map(ws)
cat=t.set_index('qid').category
def apply(base, keyf):
    vals=dict(zip(base.id,base.parsed_value))
    o=t[~t.video_id.str.endswith('_segmented')]
    key={}
    for r in o.itertuples():
        k=(r.fam,keyf(r.question),r.pv,r.dep); key.setdefault(k,[]).append(r.qid)
    new=dict(vals); ch=[]
    for r in t[(t.category=='S2')&t.video_id.str.endswith('_segmented')].itertuples():
        qs=key.get((r.fam,keyf(r.question),r.pv,r.dep))
        if not qs: continue
        if len(qs)>1: print('AMBIG',r.qid,qs)
        q=qs[0]
        if cat[q]!='S2': continue
        if not np.isclose(vals[q],vals[r.qid]): ch.append((r.qid,r.video_id,r.question,vals[r.qid],vals[q])); new[r.qid]=vals[q]
    out=base.copy(); out['parsed_value']=out.id.map(new); return out, pd.DataFrame(ch,columns=['qid','vid','q','old','new'])
pairs=[('/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv','s2_segtwin'),(H+'s2_pad08.csv','s2_pad08_segtwin'),(H+'s2_pad08_maxext.csv','s2_pad08_maxext_segtwin')]
for b,n in pairs:
    base=pd.read_csv(b)
    for kn,kf in (('loose',nq_loose),('ws',ws)):
        out,ch=apply(base,kf)
        shipped=pd.read_csv(H+n+'.csv')
        d=~np.isclose(out.parsed_value.values,shipped.parsed_value.values,rtol=1e-12,atol=0)
        print(n,kn,'changes',len(ch),'diff vs shipped',int(d.sum()))
    if n=='s2_segtwin':
        out,ch=apply(base,nq_loose); _,chs=apply(base,ws)
        print('loose-only matches:', sorted(set(ch.qid)-set(chs.qid)))
        ch['r']=ch.new/ch.old
        print(ch.groupby('vid').r.agg(['count','median','min','max']).round(3).to_string())
# seg S2 rows with no twin match
o=t[~t.video_id.str.endswith('_segmented')]
keys=set(zip(o.fam,o.question.map(nq_loose),o.pv))
s=t[(t.category=='S2')&t.video_id.str.endswith('_segmented')]
nm=s[[ (a,nq_loose(b),c) not in keys for a,b,c in zip(s.fam,s.question,s.pv)]]
print('S2 seg rows total',len(s),'unmatched',len(nm)); print(nm.groupby('video_id').size().to_string())
