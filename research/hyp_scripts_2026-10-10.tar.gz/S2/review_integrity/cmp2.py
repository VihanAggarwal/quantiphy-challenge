import sys, numpy as np, pandas as pd
H='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/'
R=H+'review_integrity/'
sys.path.insert(0,'/home/user/quantiphy-challenge')
from qp.data import load_split
t=load_split('test'); s2=set(t.qid[t.category=='S2'])
v2=pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv').set_index('id').parsed_value
p3=pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_probe3_s2maxext_d2denseoff_labdirect.csv').set_index('id').parsed_value
def eq(a,b): return int((~np.isclose(a.values,b.values,rtol=1e-12,atol=0)).sum())
for tag,K,csv in [('base',0.8,'s2_pad08'),('maxext',0.8,'s2_pad08_maxext'),('maxext',0.0,None)]:
    r=pd.read_pickle(f'{R}res_{tag}_{K}.pkl').parsed_value
    if csv:
        c=pd.read_csv(H+csv+'.csv').set_index('id').parsed_value
        print(tag,K,'vs',csv,'S2 diffs',eq(r,c[r.index]))
    else:
        print(tag,K,'vs probe3 S2 diffs',eq(r,p3[r.index]))
