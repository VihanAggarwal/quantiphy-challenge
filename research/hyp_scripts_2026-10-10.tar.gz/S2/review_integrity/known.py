import sys, re, numpy as np, pandas as pd
sys.path.insert(0,'/home/user/quantiphy-challenge')
from qp.data import load_split
from qp.mra import item_scores
pd.set_option('display.width',250); pd.set_option('display.max_colwidth',60); pd.set_option('display.max_rows',300)
t=load_split('test'); v=load_split('val')
print('val cols', list(v.columns)); print(v.video_id.value_counts().sort_index().to_string())
def fam(x): return re.sub(r'_segmented$','',x)
for d in (t,v):
    d['fam']=d.video_id.map(fam)
    d['dep']=d.depth_info.fillna('').astype(str).str.strip()
    d['pr']=d.prior.fillna('').astype(str).str.strip()
    d['qq']=d.question.astype(str).str.strip()
# val duplicates within family with same q+prior+depth but different answers
g=v.groupby(['fam','qq','pr','dep']).answer.agg(['count','nunique','min','max'])
print('val families with same q/prior/depth across twins:', (g['count']>1).sum(), 'with differing answers:', (g['nunique']>1).sum())
print(g[g['nunique']>1])
# known rows (exact match of q text, prior, depth within family)
vk=v.groupby(['fam','qq','pr','dep']).answer.agg(lambda s: s.iloc[0] if s.nunique()==1 else np.nan)
e=t[t.category=='S2'].copy()
e['ans']=[vk.get((a,b,c,d),np.nan) for a,b,c,d in zip(e.fam,e.qq,e.pr,e.dep)]
e=e[e.ans.notna()]
print('S2 known rows (exact):', len(e), 'seg', e.video_id.str.endswith('_segmented').sum(), 'clips', e.video_id.nunique())
print(e.video_id.value_counts().to_string())
e.to_pickle('known_s2.pkl')
