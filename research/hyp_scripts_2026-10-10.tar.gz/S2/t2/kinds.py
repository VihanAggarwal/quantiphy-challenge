import pickle, sys, pandas as pd, numpy as np
sys.path.insert(0,'/home/user/quantiphy-challenge')
H='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2'
d=pickle.load(open(H+'/s2_test_anns.pkl','rb')); a=d['anns']; df=d['df']
v2=pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv')[['id','parsed_value']]
p3=pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_probe3_s2maxext_d2denseoff_labdirect.csv')[['id','parsed_value']]
df=df.merge(v2.rename(columns={'parsed_value':'v2'}),left_on='qid',right_on='id').merge(p3.rename(columns={'parsed_value':'p3'})[['id','p3']],on='id')
df['tkind']=[a[q].spec.target.kind if q in a else 'NA' for q in df.qid]
df['tt']=[('t' if a[q].spec.target.time is not None else '')+('w' if a[q].spec.target.window else '') for q in df.qid]
print(pd.crosstab(df.tkind, df.video_source, margins=True))
df['r']=df.p3/df.v2
ch=df[np.abs(np.log(df.r))>1e-6]
print('probe3 changed S2:',len(ch),'median ratio',ch.r.median(), ch.r.describe())
print(ch.groupby('video_id').r.agg(['count','median']).round(3).to_string())
df.to_pickle(H+'/t2/s2q.pkl')
