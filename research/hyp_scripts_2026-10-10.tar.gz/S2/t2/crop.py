"""crop.py VID [role] : crops (x4 upscale) around Claude's prior boxes at each obs time, with extent drawn"""
import sys; sys.path.insert(0,'/home/user/quantiphy-challenge')
import pickle, sys, math, cv2, numpy as np
H='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2'
d=pickle.load(open(H+'/s2_test_anns.pkl','rb'))
vid=sys.argv[1]; role=sys.argv[2] if len(sys.argv)>2 else 'prior'
df=d['df']; g=df[df.video_id==vid]; q=g.qid.min(); an=d['anns'][q]
fps=float(g.fps.iloc[0]); path=g.video_path.iloc[0].replace(H+'/base/repo','/home/user/quantiphy-challenge')
cap=cv2.VideoCapture(path)
tiles=[]
for tr in an.tracks:
    if tr.role!=role: continue
    for o in tr.obs[:6]:
        cap.set(cv2.CAP_PROP_POS_FRAMES,int(round(o.t*fps))); ok,f=cap.read()
        if not ok: continue
        b=o.box or [min(o.extent[0][0],o.extent[1][0]),min(o.extent[0][1],o.extent[1][1]),max(o.extent[0][0],o.extent[1][0]),max(o.extent[0][1],o.extent[1][1])]
        w=b[2]-b[0]; h=b[3]-b[1]; m=max(w,h)*0.6+10
        x0=int(max(0,b[0]-m)); y0=int(max(0,b[1]-m)); x1=int(min(f.shape[1],b[2]+m)); y1=int(min(f.shape[0],b[3]+m))
        c=f[y0:y1,x0:x1].copy(); s=min(4.0,400/max(c.shape[:2])); s=max(s,1.0) if max(c.shape[:2])<400 else 400/max(c.shape[:2])
        c=cv2.resize(c,None,fx=s,fy=s,interpolation=cv2.INTER_NEAREST if s>1 else cv2.INTER_AREA)
        if o.extent:
            p=[(int((x-x0)*s),int((y-y0)*s)) for x,y in o.extent]; cv2.line(c,p[0],p[1],(0,0,255),1)
        if o.box: cv2.rectangle(c,(int((b[0]-x0)*s),int((b[1]-y0)*s)),(int((b[2]-x0)*s),int((b[3]-y0)*s)),(0,255,0),1)
        cv2.putText(c,f't={o.t:.2f}',(3,15),cv2.FONT_HERSHEY_SIMPLEX,0.5,(255,0,255),1)
        t=np.zeros((410,410,3),np.uint8); t[:c.shape[0],:c.shape[1]]=c[:410,:410]; tiles.append(t)
while len(tiles)%3: tiles.append(np.zeros_like(tiles[0]))
img=np.vstack([np.hstack(tiles[i:i+3]) for i in range(0,len(tiles),3)])
out=f'{H}/img/crop_{vid}_{role}.jpg'; cv2.imwrite(out,img,[cv2.IMWRITE_JPEG_QUALITY,85]); print(out)
