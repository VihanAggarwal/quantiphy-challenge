"""make_variant.py NAME K [maxext]
S2-only test variant: Claude's size extents and boxes (object sizes, not marking spacings) padded by K px of
the annotator's (854 px) view, then the repo's geometry / combine (base repo, or the probe-3 maxext repo).
Writes SP/NAME.csv from submissions/trackA_opus55_high_v2.csv with only S2 answers replaced."""
import os, sys, re, copy, json
H = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2'
NAME, K = sys.argv[1], float(sys.argv[2])
MAXEXT = len(sys.argv) > 3 and sys.argv[3] == 'maxext'
if MAXEXT:
    os.environ['QP_REPO'] = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/probe3/maxext/repo'
sys.path.insert(0, H + '/tools')
from h import *  # noqa  (sets sys.path to QP_REPO, loads run_claude)

MARKING = re.compile(r"\b(lanes?|courts?|lines?|circles?|field|pitch|goal|calibre|caliber|ruler|markings?|road|crosswalk)\b", re.I)


def is_marking(q):
    return any(MARKING.search(o or '') for o in (q.objects or []))


def pad_anns(anns, df, recs, k):
    anns = copy.deepcopy(anns)
    vid = dict(zip(df.qid, df.video_id))
    n = 0
    for q, a in anns.items():
        sc = float(recs[vid[q]]['meta'].get('scale') or 1.0)
        p = k / sc / 2.0          # original px added at each end
        for tr in a.tracks:
            quant = a.spec.prior if tr.role.startswith('prior') else a.spec.target
            if quant.kind not in ('size', 'other', 'distance') or is_marking(quant):
                continue
            for o in tr.obs:
                if o.extent is not None:
                    e = np.asarray(o.extent, float); u = e[1] - e[0]; L = float(np.linalg.norm(u))
                    if L > 0:
                        d = u / L * p
                        o.extent = [list(e[0] - d), list(e[1] + d)]
                        n += 1
                if o.box is not None:
                    o.box = [o.box[0] - p, o.box[1] - p, o.box[2] + p, o.box[3] + p]
    return anns, n


anns, df, recs = load(H + '/s2_test_anns.pkl')
pa, n = pad_anns(anns, df, recs, K)
res = rc.build_results(df, recs, anns=pa)
v2 = pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv')
new = dict(zip(res.id, res.parsed_value))
s2 = set(df.qid)
assert len(s2) == 579 and set(res.id) == s2
out = v2.copy()
out['parsed_value'] = [new[i] if i in s2 else v for i, v in zip(out.id, out.parsed_value)]
assert out.parsed_value.notna().all()
out.to_csv(f'{H}/{NAME}.csv', index=False)
r = out.parsed_value / v2.parsed_value
ch = np.abs(np.log(r)) > 1e-9
other = ch & ~out.id.isin(s2)
print(f'{NAME}: padded extents {n}; changed {int(ch.sum())} (non-S2 changed {int(other.sum())}); median ratio changed {np.median(r[ch]):.4f}; '
      f'>2%: {int((np.abs(np.log(r)) > 0.02).sum())}, >5%: {int((np.abs(np.log(r)) > 0.05).sum())}')
m = df.merge(res, left_on='qid', right_on='id').merge(v2[['id', 'parsed_value']].rename(columns={'parsed_value': 'v2'}), on='id')
m['tk'] = [anns[q].spec.target.kind for q in m.qid]
m['r'] = m.parsed_value / m.v2
print(m[np.abs(np.log(m.r)) > 1e-9].groupby(['video_source', 'tk']).r.agg(['count', 'median']).round(4).to_string())
json.dump({'changed': int(ch.sum()), 'median_ratio': float(np.median(r[ch]))}, open(f'{H}/{NAME}.json', 'w'))
