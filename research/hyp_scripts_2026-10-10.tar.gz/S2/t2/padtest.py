import sys
sys.path.insert(0, '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/t2')
sys.path.insert(0, '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/tools')
from padexp import *
anns, df, recs = load(H + '/s2_test_anns.pkl')
attach_scale(anns, df, recs)
v2 = pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv')[['id', 'parsed_value']].rename(columns={'parsed_value': 'v2'})
out = {}
for k in [float(x) for x in sys.argv[1].split(',')]:
    roles = sys.argv[2].split(',') if len(sys.argv) > 2 and sys.argv[2] != 'all' else None
    m = results(pad_anns(anns, recs, k, roles), df, recs).merge(v2, on='id')
    m['tk'] = [anns[q].spec.target.kind for q in m.qid]
    out[k] = m
    r = m.parsed_value / m.v2
    ch = np.abs(np.log(r)) > 1e-6
    print(f'k={k}: changed {ch.sum()} median ratio {np.median(r[ch]) if ch.any() else 1:.4f}; >2%: {(np.abs(np.log(r))>0.02).sum()} >5%: {(np.abs(np.log(r))>0.05).sum()}')
    print(m[ch].groupby('tk').apply(lambda g: pd.Series({'n': len(g), 'med': np.median(g.parsed_value / g.v2)})).round(4))
pickle.dump(out, open(H + f'/t2/padtest_{sys.argv[1]}_{sys.argv[2] if len(sys.argv)>2 else "all"}.pkl', 'wb'))
