"""variants of twin use: seg := geometric mean(orig, seg); both := geometric mean"""
import sys
sys.path.insert(0,'/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/t2')
from segtwin import *
base = pd.read_csv(sys.argv[1]); name = sys.argv[2]; both = len(sys.argv) > 3
vals = dict(zip(base.id, base.parsed_value)); new = dict(vals)
orig = t[~t.video_id.str.endswith('_segmented')]
key = {(r.twin, r.nq, r.pv): r.qid for r in orig.itertuples()}
n = 0
for r in t[(t.category == 'S2') & t.video_id.str.endswith('_segmented')].itertuples():
    q = key.get((r.twin, r.nq, r.pv))
    if q is None or t.set_index('qid').category[q] != 'S2': continue
    g = float(np.sqrt(vals[q] * vals[r.qid])); new[r.qid] = g; n += 1
    if both: new[q] = g
out = base.copy(); out['parsed_value'] = out.id.map(new); out.to_csv(f'{H}/{name}.csv', index=False); print(name, n)
