"""Twin study 2: per Claude size obs in segmented-twin sim videos (2D and 3D), the mask reference on the
segmented twin (component by threshold 40, extent along Claude's line at half the object's contrast)
vs extent methods run on the annotated video itself: Claude, ring-profile, GrabCut, snap.
-> t2/twins2.pkl"""
import sys, math, pickle, cv2, numpy as np, pandas as pd
from pathlib import Path
sys.path.insert(0, '/home/user/quantiphy-challenge'); sys.path.insert(0, '/home/user/quantiphy-challenge/scripts')
H = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2'
sys.path.insert(0, H + '/t2')
import run_claude as rc
from qp.data import load_split
from qp import claude_annotate as ca
from qp import dense_track as dt
from qp.open.cv_track import dimension_mode
from extent_cv import ring_profile_extent

df = load_split('test')
segs = sorted(v for v in set(df.video_id) if v.endswith('_segmented') and v.startswith('simulation') and v[:-10] in set(df.video_id))
vids = set(segs) | {s[:-10] for s in segs}
sub = df[df.video_id.isin(vids)]
recs = rc.load_records(Path('/home/user/quantiphy-challenge/runs/test_v1_high_854/test/records'))
recs = {v: r for v, r in recs.items() if v in vids}
precs = rc.prepare_records(sub, recs)
anns = ca.load_annotations(precs)
paths = dict(zip(sub.video_id, sub.video_path))


def read_frames(path, idxs):
    out, cap, i, want = {}, cv2.VideoCapture(path), 0, set(idxs)
    last = max(want) if want else -1
    while i <= last and cap.grab():
        if i in want:
            ok, im = cap.retrieve()
            if ok:
                out[i] = im
        i += 1
    return out


def mask_ref(seg, box, ext):
    H_, W_ = seg.shape[:2]
    dev = (255 - seg.astype(np.int16)).max(axis=2).astype(np.float32)
    x0, y0, x1, y1 = box
    m = 0.25 * max(x1 - x0, y1 - y0) + 8
    wx0, wy0 = max(0, int(x0 - m)), max(0, int(y0 - m)); wx1, wy1 = min(W_, int(math.ceil(x1 + m))), min(H_, int(math.ceil(y1 + m)))
    win = dev[wy0:wy1, wx0:wx1]
    mk = (win > 40).astype(np.uint8)
    if mk.sum() < 4:
        return None
    n, lab, st, _ = cv2.connectedComponentsWithStats(mk, connectivity=8)
    bx0, by0, bx1, by1 = int(x0 - wx0 - 2), int(y0 - wy0 - 2), int(x1 - wx0 + 2), int(y1 - wy0 + 2)
    inbox = lab[max(0, by0):max(0, by1), max(0, bx0):max(0, bx1)]
    keep = [k for k in range(1, n) if (inbox == k).sum() >= max(3, 0.3 * st[k, cv2.CC_STAT_AREA])]
    if not keep:
        return None
    sel = np.isin(lab, keep).astype(np.uint8)
    ys, xs = np.nonzero(sel)
    if xs.min() == 0 and wx0 > 0 or ys.min() == 0 and wy0 > 0 or xs.max() == win.shape[1] - 1 and wx1 < W_ or ys.max() == win.shape[0] - 1 and wy1 < H_:
        return None  # touches window
    er = cv2.erode(sel, np.ones((3, 3), np.uint8), iterations=2).astype(bool)
    D = float(np.median(win[er])) if er.sum() >= 5 else float(np.median(win[sel.astype(bool)]))
    zone = cv2.dilate(sel, np.ones((3, 3), np.uint8), iterations=2).astype(bool)
    e = np.asarray(ext, float); u = e[1] - e[0]; L = np.linalg.norm(u)
    u = u / L
    foot = abs(u[0]) + abs(u[1])
    res = {}
    for name, thr in (('m40', 40.0), ('m50', 0.5 * D)):
        mm = zone & (win > thr)
        yy, xx = np.nonzero(mm)
        p = (xx + wx0 + 0.5) * u[0] + (yy + wy0 + 0.5) * u[1]
        res[name] = float(p.max() - p.min() + foot)
    res['D'] = D
    res['area'] = int(sel.sum())
    return res


rows, seen = [], set()
by_vid = {}
for r in sub.sort_values('qid').itertuples():
    a = anns.get(int(r.qid))
    if a is None:
        continue
    for tr in a.tracks:
        q = a.spec.prior if tr.role in ('prior', 'prior2') else a.spec.target
        if q.kind != 'size' or tr.role not in ('prior', 'target'):
            continue
        for o in tr.obs:
            if o.extent is None or o.box is None:
                continue
            key = (r.video_id, tr.role, tr.object, round(o.t, 3), tuple(np.round(np.ravel(o.extent), 1)))
            if key in seen:
                continue
            seen.add(key)
            by_vid.setdefault(r.video_id, []).append(dict(vid=r.video_id, seg=r.video_id.endswith('_segmented'), cat=r.category,
                qid=int(r.qid), role=tr.role, obj=tr.object, dim=q.dimension, t=o.t, frame=int(round(o.t * float(r.fps))),
                ext=o.extent, box=o.box, scale=float(precs[r.video_id]['meta']['scale'])))

for vid, items in by_vid.items():
    orig = vid[:-10] if vid.endswith('_segmented') else vid
    fr = sorted({it['frame'] for it in items})
    own = read_frames(paths[vid], fr)
    segf = own if vid.endswith('_segmented') else read_frames(paths[orig + '_segmented'], fr)
    for it in items:
        im, sg = own.get(it['frame']), segf.get(it['frame'])
        if im is None or sg is None:
            continue
        e = np.asarray(it['ext'], float)
        L = float(np.linalg.norm(e[1] - e[0]))
        row = {k: v for k, v in it.items() if k not in ('ext', 'box')}
        row['claude'] = L
        ref = mask_ref(sg, it['box'], it['ext'])
        if ref is None:
            continue
        row.update(ref)
        ne, inf = ring_profile_extent(im, it['box'], it['ext'], it['scale'])
        row['ring'] = float(np.linalg.norm(np.subtract(ne[1], ne[0]))) if ne else np.nan
        row['ring_why'] = inf.get('why')
        # GrabCut / snap via dense_track on a crop
        Wd, Hd = im.shape[1], im.shape[0]
        cb = dt._seg_crop_box(it['box'], Wd, Hd)
        x0, y0, x1, y1 = max(0, cb[0]), max(0, cb[1]), min(Wd, cb[2]), min(Hd, cb[3])
        crop = im[y0:y1, x0:x1]
        mode = dimension_mode(it['dim'], it['obj'])
        try:
            g, gi = dt.grabcut_extent(crop, [it['box'][0] - x0, it['box'][1] - y0, it['box'][2] - x0, it['box'][3] - y0], mode or 'length', it['obj'])
        except Exception as ex:  # noqa
            g, gi = None, {'why': str(ex)[:30]}
        row['grabcut'] = float(np.linalg.norm(np.subtract(g[1], g[0]))) if g else np.nan
        search = max(3.0 / max(it['scale'], 1e-6), 0.08 * L)
        s_, si = dt.snap_extent(crop, [[p[0] - x0, p[1] - y0] for p in it['ext']], search)
        row['snap'] = float(np.linalg.norm(np.subtract(s_[1], s_[0]))) if s_ else np.nan
        row['mode'] = mode
        rows.append(row)
    print(vid, len(items), flush=True)

out = pd.DataFrame(rows)
out.to_pickle(H + '/t2/twins2.pkl')
print(len(out))
