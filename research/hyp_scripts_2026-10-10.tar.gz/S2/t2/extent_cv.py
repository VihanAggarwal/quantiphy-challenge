"""Sub-pixel extent re-measurement along the annotator's extent line.

ring_profile_extent(img, box, ext, seen_scale) -> (new_ext | None, info)

Background colour = median of a ring around the box (box grown by RING_IN..RING_OUT of its long side);
object contrast D = 80th percentile of the colour distance to the background inside the inner part of
the box. Along the annotator's line (extended past each end), the colour distance on 3 parallel lines
gives a coverage profile alpha = dist / D. Each end moves to the alpha = 0.5 crossing (linear
interpolation) nearest the annotator's end, searched within +-search px; an end with no clear
crossing (no inside > 0.7 / outside < 0.3 pair) is kept.
"""
from __future__ import annotations

import math

import cv2
import numpy as np

RING_IN, RING_OUT = 0.15, 0.45


def _ring_bg(img, box):
    H, W = img.shape[:2]
    x0, y0, x1, y1 = box
    L = max(x1 - x0, y1 - y0)
    gi, go = RING_IN * L + 2, RING_OUT * L + 6
    X0, Y0, X1, Y1 = int(max(0, x0 - go)), int(max(0, y0 - go)), int(min(W, x1 + go)), int(min(H, y1 + go))
    crop = img[Y0:Y1, X0:X1].astype(np.float32)
    yy, xx = np.mgrid[Y0:Y1, X0:X1] + 0.5
    inner = (xx > x0 - gi) & (xx < x1 + gi) & (yy > y0 - gi) & (yy < y1 + gi)
    ring = ~inner
    if ring.sum() < 20:
        return None, None
    bg = np.median(crop[ring], axis=0)
    spread = float(np.median(np.linalg.norm(crop[ring] - bg, axis=1)))
    return bg, spread


def ring_profile_extent(img, box, ext, seen_scale=1.0, search=None, nlines=3):
    e = np.asarray(ext, float)
    L = float(np.linalg.norm(e[1] - e[0]))
    if L < 3 or box is None:
        return None, {"why": "short"}
    bg, spread = _ring_bg(img, box)
    if bg is None:
        return None, {"why": "ring"}
    x0, y0, x1, y1 = box
    # object level inside the box (central part)
    cx0, cy0 = x0 + 0.2 * (x1 - x0), y0 + 0.2 * (y1 - y0)
    cx1, cy1 = x1 - 0.2 * (x1 - x0), y1 - 0.2 * (y1 - y0)
    H, W = img.shape[:2]
    inner = img[int(max(0, cy0)):int(min(H, math.ceil(cy1))), int(max(0, cx0)):int(min(W, math.ceil(cx1)))]
    if inner.size == 0:
        return None, {"why": "inner"}
    dist_in = np.linalg.norm(inner.reshape(-1, 3).astype(np.float32) - bg, axis=1)
    D = float(np.percentile(dist_in, 80))
    if D < max(25.0, 4.0 * spread):
        return None, {"why": "contrast", "D": D, "spread": spread}
    u = (e[1] - e[0]) / L
    n = np.array([-u[1], u[0]])
    if search is None:
        search = max(3.0 / max(seen_scale, 1e-6), 0.12 * L)
    step = 0.1
    s = np.arange(-search - 2, L + search + 2 + step / 2, step)
    img32 = img.astype(np.float32)
    prof = []
    offs = [0.0] if nlines == 1 else list(np.linspace(-1.0, 1.0, nlines))
    for off in offs:
        pts = (e[0][None] + s[:, None] * u[None] + off * n[None] - 0.5).astype(np.float32)
        smp = cv2.remap(img32, pts[:, 0].reshape(1, -1), pts[:, 1].reshape(1, -1), cv2.INTER_LINEAR,
                        borderMode=cv2.BORDER_REPLICATE).reshape(len(s), 3)
        prof.append(np.linalg.norm(smp - bg, axis=1))
    a = np.clip(np.median(np.array(prof), axis=0) / D, 0, 1.5)
    out, info = e.copy(), {"D": round(D, 1), "spread": round(spread, 1)}
    for end in (0, 1):
        target = 0.0 if end == 0 else L
        sel = np.flatnonzero(np.abs(s - target) <= search)
        best = None
        for i in sel[:-1]:
            j = i + 1
            if (a[i] - 0.5) * (a[j] - 0.5) <= 0 and a[i] != a[j]:
                # require a clean transition: inside side > 0.7 and outside side < 0.3 within 3 px
                k = int(round(3 / step))
                lo, hi = max(0, i - k), min(len(s), j + k + 1)
                left, right = a[lo:i + 1], a[j:hi]
                if end == 0:
                    ok = left.min() < 0.3 and right.max() > 0.7 and a[j] >= a[i]
                else:
                    ok = left.max() > 0.7 and right.min() < 0.3 and a[j] <= a[i]
                if not ok:
                    continue
                x = s[i] + (0.5 - a[i]) / (a[j] - a[i]) * step
                if best is None or abs(x - target) < abs(best - target):
                    best = x
        if best is None:
            info[f"end{end}"] = "none"
            continue
        out[end] = e[0] + best * u
        info[f"end{end}"] = round(float(best - target), 2)
    if info.get("end0") == "none" and info.get("end1") == "none":
        return None, {**info, "why": "noedge"}
    return out.tolist(), {**info, "why": "ok"}
