import sys, numpy as np, pandas as pd
sys.path.insert(0,'/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/t2')
from segtwin import *
e = val_on_test()
H2 = H + '/'
names = {'v2': V2, 'probe3': '/home/user/quantiphy-challenge/submissions/trackA_probe3_s2maxext_d2denseoff_labdirect.csv'}
for n in sys.argv[1:]: names[n] = H2 + n + '.csv'
rows = []
for n, f in names.items():
    p = pd.read_csv(f).set_index('id').parsed_value
    sc = item_scores(p[e.qid].values, e.ans.values)
    seg = e.video_id.str.endswith('_segmented').values
    sim = (e.video_source.values == 'simulation') | (seg & e.video_id.str.startswith('simulation').values)
    rows.append(dict(name=n, n=len(e), all=sc.mean(), orig=sc[~seg].mean(), seg=sc[seg].mean(), n_seg=seg.sum(), sim=sc[sim].mean(), internet=sc[~sim].mean()))
print(pd.DataFrame(rows).round(4).to_string())
if '-v' in sys.argv[0]: pass
