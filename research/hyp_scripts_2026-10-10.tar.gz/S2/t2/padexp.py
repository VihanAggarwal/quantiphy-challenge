"""+k px (annotator-view) extent padding experiment on all val 2D runs and test S2."""
import sys, os, copy, math, pickle
sys.path.insert(0, '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/tools')
from valrun import *
from qp.spec import Obs

def pad_anns(anns, recs, k, roles=None, boxes=True, only_size=True):
    anns = copy.deepcopy(anns)
    for q, a in anns.items():
        vid = None
        for tr in a.tracks:
            if roles and tr.role not in roles: continue
            quant = a.spec.prior if tr.role.startswith('prior') else a.spec.target
            if only_size and quant.kind not in ('size', 'other', 'distance'): continue
            sc = tr._scale
            for o in tr.obs:
                if o.extent is not None:
                    e = np.asarray(o.extent, float); u = e[1] - e[0]; L = np.linalg.norm(u)
                    if L > 0:
                        d = u / L * (k / sc / 2)
                        o.extent = [list(e[0] - d), list(e[1] + d)]
                if boxes and o.box is not None:
                    p = k / sc / 2
                    o.box = [o.box[0] - p, o.box[1] - p, o.box[2] + p, o.box[3] + p]
    return anns

def attach_scale(anns, df, recs):
    vid = dict(zip(df.qid, df.video_id))
    for q, a in anns.items():
        s = float(recs[vid[q]]['meta'].get('scale') or 1.0)
        for tr in a.tracks: tr._scale = s

def results(anns, df, recs):
    res = rc.build_results(df, recs, anns=copy.deepcopy(anns))
    return df.merge(res, left_on='qid', right_on='id')

if __name__ == '__main__':
    K = [float(x) for x in sys.argv[1].split(',')]
    roles = sys.argv[2].split(',') if len(sys.argv) > 2 and sys.argv[2] != 'all' else None
    out = []
    for run in RUNS:
        anns, df, recs = load(f'{H}/val2d_{run}.pkl')
        attach_scale(anns, df, recs)
        split = 'val_hires' if 'hr_' in run else 'val'
        for k in K:
            m = results(pad_anns(anns, recs, k, roles), df, recs)
            if 'answer' not in m.columns:
                m = m.merge(VAL[split][['qid', 'answer']], on='qid')
            m['run'] = run; m['k'] = k
            m['tk'] = [anns[q].spec.target.kind if q in anns else '' for q in m.qid]
            m['mra'] = item_scores(m.parsed_value, m.answer); m['mg'] = item_scores(m.geo_value, m.answer)
            out.append(m)
    o = pd.concat(out)
    o.to_pickle(f'{H}/t2/padexp_{sys.argv[1]}_{sys.argv[2] if len(sys.argv)>2 else "all"}_{os.environ.get("TAG","base")}.pkl')
    print(o.groupby(['category', 'k', 'run']).mra.mean().unstack(1).round(3).to_string())
    print(o.groupby(['category', 'k']).mra.mean().unstack(1).round(4).to_string())
    print(o[o.tk == 'size'].groupby(['category', 'k']).mra.mean().unstack(1).round(4).to_string())
