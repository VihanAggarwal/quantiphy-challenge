"""bgsize.py VID [role] : per-frame size of the tracked object by temporal-median background subtraction"""
import sys, math, pickle, cv2, numpy as np
sys.path.insert(0,'/home/user/quantiphy-challenge')
H='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2'
d=pickle.load(open(H+'/s2_test_anns.pkl','rb'))
vid=sys.argv[1]; role=sys.argv[2] if len(sys.argv)>2 else 'prior'
df=d['df']; g=df[df.video_id==vid]
fps=float(g.fps.iloc[0]); path=g.video_path.iloc[0].replace(H+'/base/repo','/home/user/quantiphy-challenge')
cap=cv2.VideoCapture(path); fr=[]
while True:
    ok,f=cap.read()
    if not ok: break
    fr.append(f)
fr=np.array(fr); bg=np.median(fr,axis=0).astype(np.float32)
# track points from any motion track of the same object
pts=[]
for q in g.qid:
    a=d['anns'][q]
    for tr in a.tracks:
        for o in tr.obs:
            p=o.point if o.point is not None else ([(o.box[0]+o.box[2])/2,(o.box[1]+o.box[3])/2] if o.box else None)
            if p is not None: pts.append((o.t,p[0],p[1],tr.role,tr.object))
pts=sorted(set((round(t,3),round(x,1),round(y,1),r,ob) for t,x,y,r,ob in pts))
obj=sys.argv[3] if len(sys.argv)>3 else None
for t,x,y,r,ob in pts:
    if obj and ob!=obj: continue
    i=int(round(t*fps));
    if i>=len(fr): continue
    diff=np.abs(fr[i].astype(np.float32)-bg).max(axis=2)
    R=80; x0,y0=int(max(0,x-R)),int(max(0,y-R)); x1,y1=int(min(diff.shape[1],x+R)),int(min(diff.shape[0],y+R))
    w=diff[y0:y1,x0:x1]
    thr=0.5*np.percentile(w,99.5)
    m=(w>thr).astype(np.uint8)
    n,lab,st,cen=cv2.connectedComponentsWithStats(m)
    if n<2: print(t,'none'); continue
    k=1+np.argmax(st[1:,4])
    ys,xs=np.nonzero(lab==k)
    print(f"t={t:5.2f} {r:7s} {ob:15s} pt=({x:7.1f},{y:7.1f}) area={st[k,4]:5d} eqd={2*math.sqrt(st[k,4]/math.pi):6.2f} w={st[k,2]} h={st[k,3]} thr={thr:.0f}")
