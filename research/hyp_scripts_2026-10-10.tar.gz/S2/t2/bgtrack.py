"""bgtrack.py VID QID role : dense per-frame centroid+size track of the object by temporal-median bg subtraction,
seeded by the Claude track (nearest point in time). Prints poly fits."""
import sys, math, pickle, cv2, numpy as np
sys.path.insert(0,'/home/user/quantiphy-challenge')
H='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2'
def load_frames(path):
    cap=cv2.VideoCapture(path); fr=[]
    while True:
        ok,f=cap.read()
        if not ok: break
        fr.append(f)
    return np.array(fr)
def track(fr, fps, T, P, R=None, size=None):
    bg=np.median(fr,axis=0).astype(np.float32)
    out=[]
    R=R or 60
    for i in range(len(fr)):
        t=i/fps
        if t<T.min()-1e-6 or t>T.max()+1e-6: continue
        x=np.interp(t,T,P[:,0]); y=np.interp(t,T,P[:,1])
        diff=np.abs(fr[i].astype(np.float32)-bg).max(axis=2)
        x0,y0=int(max(0,x-R)),int(max(0,y-R)); x1,y1=int(min(diff.shape[1],x+R)),int(min(diff.shape[0],y+R))
        w=diff[y0:y1,x0:x1]
        thr=0.5*np.percentile(w,99.5)
        if thr<8: continue
        m=(w>thr).astype(np.uint8)
        n,lab,st,cen=cv2.connectedComponentsWithStats(m)
        if n<2: continue
        k=1+np.argmax(st[1:,4])
        # touches window edge?
        if st[k,0]==0 or st[k,1]==0 or st[k,0]+st[k,2]>=w.shape[1] or st[k,1]+st[k,3]>=w.shape[0]: continue
        sel=(lab==k)
        ww=w*sel
        cx=(ww*np.arange(w.shape[1])[None,:]).sum()/ww.sum()+x0+0.5; cy=(ww*np.arange(w.shape[0])[:,None]).sum()/ww.sum()+y0+0.5
        out.append((t,cx,cy,2*math.sqrt(st[k,4]/math.pi),st[k,2],st[k,3]))
    return np.array(out)
if __name__=='__main__':
    d=pickle.load(open(H+'/s2_test_anns.pkl','rb'))
    vid=sys.argv[1]; q=int(sys.argv[2]); role=sys.argv[3]
    df=d['df']; g=df[df.video_id==vid]
    fps=float(g.fps.iloc[0]); path=g.video_path.iloc[0].replace(H+'/base/repo','/home/user/quantiphy-challenge')
    a=d['anns'][q]; tr=[t for t in a.tracks if t.role==role][0]
    T=np.array([o.t for o in tr.obs if o.point is not None]); P=np.array([o.point for o in tr.obs if o.point is not None])
    fr=load_frames(path)
    o=track(fr,fps,T,P)
    t=o[:,0]; XY=o[:,1:3]
    u=(XY[-1]-XY[0])/np.linalg.norm(XY[-1]-XY[0]); s=(XY-XY[0])@u
    print('n',len(t),'size eqd median',np.median(o[:,3]).round(2),'first/last',o[:3,3].round(1),o[-3:,3].round(1))
    for deg in (2,3,4):
        c=np.polyfit(t,s,deg); r=s-np.polyval(c,t)
        print(' deg',deg,'rms',r.std().round(3),'acc',np.polyval(np.polyder(c,2),[0.5,1,1.5,1.75,2.0]).round(1), 'v',np.polyval(np.polyder(c,1),[0.5,1,1.5,2.0]).round(1))
    np.save(H+f'/t2/bgtrack_{vid}_{q}.npy',o)
