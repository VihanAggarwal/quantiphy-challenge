"""per-video table of S2 test prior tracks"""
import pickle, sys, math, numpy as np, pandas as pd
sys.path.insert(0,'/home/user/quantiphy-challenge')
H='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2'
d=pickle.load(open(H+'/s2_test_anns.pkl','rb'))
a=d['anns']; df=d['df']; R=d['records']
rows=[]
for vid,g in df.groupby('video_id'):
    q=g.qid.min(); an=a[q]; meta=R[vid]['meta']
    pr=[t for t in an.tracks if t.role=='prior']
    ext=[]; boxes=[]
    for t in pr:
        for o in t.obs:
            if o.extent is not None: ext.append(math.hypot(o.extent[1][0]-o.extent[0][0],o.extent[1][1]-o.extent[0][1]))
            if o.box is not None: boxes.append(o.box)
    ext=np.array(ext)
    W,Hh=meta['image_size']
    rows.append(dict(vid=vid,src=g.video_source.iloc[0],nq=len(g),prior=g.prior.iloc[0][:60],dim=an.spec.prior.dimension,pobj=an.spec.prior.objects,
      W=W,H=Hh,scale=meta['scale'],nobs=len(ext),med=np.median(ext) if len(ext) else np.nan,mn=ext.min() if len(ext) else np.nan,mx=ext.max() if len(ext) else np.nan,
      ntr=len(pr)))
t=pd.DataFrame(rows); t['med854']=t.med*t.scale; t['spread']=t.mx/t.mn
pd.set_option('display.width',250); pd.set_option('display.max_colwidth',60); pd.set_option('display.max_rows',500)
print(t.round(2).to_string())
t.to_pickle(H+'/t2/vtab.pkl')
