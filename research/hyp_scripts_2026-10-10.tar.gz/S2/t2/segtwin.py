"""S2 segtwin: an S2 question of a segmented clip takes the original clip's answer for the same (normalised)
question with the same prior value (same scene; the original keeps the background cues).
usage: segtwin.py BASE_CSV OUT_NAME   (BASE_CSV: v2 or one of my S2 variants)
Also prints the val-on-test S2 evaluation (test answers of val clips and their twins, val GT by question text)."""
import sys, re, numpy as np, pandas as pd
sys.path.insert(0, '/home/user/quantiphy-challenge')
from qp.data import load_split
from qp.mra import item_scores
from qp.claude_annotate import prior_si
H = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2'
V2 = '/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv'


def normq(q):
    q = re.sub(r"(\d+)\.0+(?!\d)", r"\1", str(q).lower())   # 1.0s == 1s
    return re.sub(r"[^a-z0-9.]", "", q)


def pval(p):
    x = prior_si(p)
    return round(x[0], 9) if x else str(p).strip().lower()


t = load_split('test')
t['twin'] = t.video_id.str.replace('_segmented', '', regex=False)
t['nq'] = t.question.map(normq)
t['pv'] = t.prior.map(pval)


def apply(base):
    vals = dict(zip(base.id, base.parsed_value))
    orig = t[~t.video_id.str.endswith('_segmented')]
    key = {(r.twin, r.nq, r.pv): r.qid for r in orig.itertuples()}
    new, ch = dict(vals), []
    for r in t[(t.category == 'S2') & t.video_id.str.endswith('_segmented')].itertuples():
        q = key.get((r.twin, r.nq, r.pv))
        if q is None:
            continue
        if t.set_index('qid').category[q] != 'S2':
            continue
        nv = vals[q]
        if np.isfinite(nv) and nv > 0 and not np.isclose(nv, vals[r.qid]):
            ch.append((r.qid, r.video_id, vals[r.qid], nv)); new[r.qid] = nv
    out = base.copy(); out['parsed_value'] = out.id.map(new)
    return out, pd.DataFrame(ch, columns=['qid', 'vid', 'old', 'new'])


def val_on_test():
    v = load_split('val')
    v['twin'] = v.video_id.str.replace('_segmented', '', regex=False); v['nq'] = v.question.map(normq)
    gt = v.set_index(['twin', 'nq']).answer; gt = gt[~gt.index.duplicated()]
    e = t[t.category == 'S2'].copy()
    e['ans'] = [gt.get((a, b), np.nan) for a, b in zip(e.twin, e.nq)]
    return e[e.ans.notna()]


if __name__ == '__main__':
    base = pd.read_csv(sys.argv[1]); name = sys.argv[2]
    out, ch = apply(base)
    out.to_csv(f'{H}/{name}.csv', index=False)
    v2 = pd.read_csv(V2)
    r = out.parsed_value / v2.parsed_value
    allch = np.abs(np.log(r)) > 1e-9
    cat = t.set_index('qid').category
    print(name, 'segtwin changed', len(ch), 'median new/old %.3f' % np.median(ch.new / ch.old) if len(ch) else '',
          '| vs v2 changed', int(allch.sum()), 'median %.4f' % np.median(r[allch]),
          '| categories changed', cat[out.id[allch]].value_counts().to_dict())
    print(ch.groupby('vid').apply(lambda g: np.median(g.new / g.old)).round(3).to_dict())
