import sys, cv2, numpy as np
D='/home/user/quantiphy-challenge/data/QuantiPhy/'
H='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2'
v=sys.argv[1]; t=float(sys.argv[2]) if len(sys.argv)>2 else 0.5
ims=[]
for p in (v, v+'_segmented'):
    c=cv2.VideoCapture(D+p+'.mp4'); fps=c.get(5); n=c.get(7); print(p, c.get(3), c.get(4), fps, n)
    c.set(cv2.CAP_PROP_POS_FRAMES,int(t*fps)); ok,f=c.read(); f=cv2.resize(f,(960,int(960*f.shape[0]/f.shape[1]))); ims.append(f)
cv2.imwrite(f'{H}/img/pair_{v}.jpg',np.vstack(ims))
