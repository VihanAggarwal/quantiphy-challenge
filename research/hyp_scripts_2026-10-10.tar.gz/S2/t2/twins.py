"""Twin-mask study: Claude's size extents (orig + segmented sim videos) vs the SAM mask in the segmented twin.
Writes t2/twins.pkl (one row per unique obs)."""
import sys, math, pickle, cv2, numpy as np, pandas as pd
sys.path.insert(0, '/home/user/quantiphy-challenge'); sys.path.insert(0, '/home/user/quantiphy-challenge/scripts')
import run_claude as rc
from qp.data import load_split
from qp import claude_annotate as ca
from pathlib import Path
H = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2'
df = load_split('test')
segs = sorted(v for v in set(df.video_id) if v.endswith('_segmented') and v.startswith('simulation') and v[:-10] in set(df.video_id))
vids = set(segs) | {s[:-10] for s in segs}
sub = df[df.video_id.isin(vids)]
recs = rc.load_records(Path('/home/user/quantiphy-challenge/runs/test_v1_high_854/test/records'))
recs = {v: r for v, r in recs.items() if v in vids}
precs = rc.prepare_records(sub, recs)
anns = ca.load_annotations(precs)

def mask_of(img):
    # segmented videos: white background
    d = 255 - img.astype(np.int16)
    return (d.max(axis=2) > 40).astype(np.uint8)

def measure(mask, box, ext):
    H_, W_ = mask.shape
    x0, y0, x1, y1 = box
    m = 0.25 * max(x1 - x0, y1 - y0) + 8
    wx0, wy0 = max(0, int(x0 - m)), max(0, int(y0 - m)); wx1, wy1 = min(W_, int(math.ceil(x1 + m))), min(H_, int(math.ceil(y1 + m)))
    win = mask[wy0:wy1, wx0:wx1]
    if win.size == 0 or win.sum() < 4:
        return None
    n, lab, st, _ = cv2.connectedComponentsWithStats(win, connectivity=8)
    bx0, by0, bx1, by1 = int(x0 - wx0 - 2), int(y0 - wy0 - 2), int(x1 - wx0 + 2), int(y1 - wy0 + 2)
    inbox = lab[max(0, by0):max(0, by1), max(0, bx0):max(0, bx1)]
    keep = [k for k in range(1, n) if (inbox == k).sum() >= max(3, 0.3 * st[k, cv2.CC_STAT_AREA])]
    if not keep:
        return None
    sel = np.isin(lab, keep)
    ys, xs = np.nonzero(sel)
    xs = xs + wx0 + 0.5; ys = ys + wy0 + 0.5
    e = np.asarray(ext, float); u = e[1] - e[0]; L = np.linalg.norm(u)
    if L < 1e-6:
        return None
    u = u / L
    p = xs * u[0] + ys * u[1]
    q = -xs * u[1] + ys * u[0]
    foot = abs(u[0]) + abs(u[1])
    touch = int(xs.min() - 0.5 <= wx0 + 0.5 and wx0 > 0) + int(xs.max() + 0.5 >= wx1 - 0.5 and wx1 < W_) + \
            int(ys.min() - 0.5 <= wy0 + 0.5 and wy0 > 0) + int(ys.max() + 0.5 >= wy1 - 0.5 and wy1 < H_)
    return dict(mask_len=float(p.max() - p.min() + foot), mask_w=float(xs.max() - xs.min() + 1), mask_h=float(ys.max() - ys.min() + 1),
                mask_area=int(sel.sum()), mask_perp=float(q.max() - q.min() + foot), touch=touch,
                mask_eqd=2 * math.sqrt(sel.sum() / math.pi))

rows = []
cache = {}
def frame(path, f):
    k = (path, f)
    if k not in cache:
        if len(cache) > 400: cache.clear()
        cap = cv2.VideoCapture(path); cap.set(cv2.CAP_PROP_POS_FRAMES, f); ok, im = cap.read(); cache[k] = im if ok else None
    return cache[k]
seen = set()
paths = dict(zip(sub.video_id, sub.video_path))
for r in sub.sort_values('qid').itertuples():
    a = anns.get(int(r.qid))
    if a is None: continue
    orig = r.video_id[:-10] if r.video_id.endswith('_segmented') else r.video_id
    segp = paths[orig + '_segmented']
    for tr in a.tracks:
        q = a.spec.prior if tr.role in ('prior', 'prior2') else a.spec.target
        if q.kind != 'size' or tr.role not in ('prior', 'target'):
            continue
        for o in tr.obs:
            if o.extent is None or o.box is None: continue
            key = (r.video_id, tr.role, tr.object, round(o.t, 3), tuple(np.round(np.ravel(o.extent), 1)))
            if key in seen: continue
            seen.add(key)
            f = int(round(o.t * float(r.fps)))
            im = frame(segp, f)
            if im is None: continue
            res = measure(mask_of(im), o.box, o.extent)
            L = math.hypot(o.extent[1][0] - o.extent[0][0], o.extent[1][1] - o.extent[0][1])
            row = dict(vid=r.video_id, orig=orig, seg=r.video_id.endswith('_segmented'), cat=r.category, qid=int(r.qid), role=tr.role, obj=tr.object,
                       dim=q.dimension, t=o.t, frame=f, claude_len=L, box_w=o.box[2] - o.box[0], box_h=o.box[3] - o.box[1],
                       ux=(o.extent[1][0] - o.extent[0][0]) / max(L, 1e-9), uy=(o.extent[1][1] - o.extent[0][1]) / max(L, 1e-9),
                       scale=precs[r.video_id]['meta']['scale'], W=precs[r.video_id]['meta']['image_size'][0])
            if res: row.update(res)
            rows.append(row)
out = pd.DataFrame(rows)
out.to_pickle(H + '/t2/twins.pkl')
print(len(out), out.mask_len.notna().sum())
