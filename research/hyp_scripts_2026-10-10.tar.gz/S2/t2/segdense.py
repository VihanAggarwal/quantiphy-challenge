"""segdense.py SEGVID [role] : dense per-frame mask extents (vertical, horizontal, major axis) of the prior object in a
segmented video, the component nearest the Claude track (interpolated box centre)."""
import sys, math, pickle, cv2, numpy as np
sys.path.insert(0,'/home/user/quantiphy-challenge')
H='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2'
d=pickle.load(open(H+'/s2_test_anns.pkl','rb'))
vid=sys.argv[1]; role=sys.argv[2] if len(sys.argv)>2 else 'prior'
df=d['df']; g=df[df.video_id==vid]; fps=float(g.fps.iloc[0])
path='/home/user/quantiphy-challenge/data/QuantiPhy/'+vid+'.mp4'
an=d['anns'][g.qid.min()]
tr=[t for t in an.tracks if t.role==role][0]
cl=[(o.t, math.hypot(o.extent[1][0]-o.extent[0][0],o.extent[1][1]-o.extent[0][1]) if o.extent else None, o.box) for o in tr.obs]
print('claude', [(round(t,2), round(L,1) if L else None) for t,L,b in cl], an.spec.prior.dimension)
# centre track: any track of same object with points/boxes across questions
pts=[]
for q in g.qid:
    for t2 in d['anns'][q].tracks:
        if t2.object==tr.object:
            for o in t2.obs:
                if o.box: pts.append((o.t,(o.box[0]+o.box[2])/2,(o.box[1]+o.box[3])/2))
                elif o.point: pts.append((o.t,o.point[0],o.point[1]))
pts=np.array(sorted(set(pts)))
cap=cv2.VideoCapture(path); i=0; rows=[]
while True:
    ok,f=cap.read()
    if not ok: break
    t=i/fps; i+=1
    cx=np.interp(t,pts[:,0],pts[:,1]); cy=np.interp(t,pts[:,0],pts[:,2])
    m=((255-f.astype(np.int16)).max(axis=2)>40).astype(np.uint8)
    n,lab,st,cen=cv2.connectedComponentsWithStats(m)
    if n<2: continue
    big=[k for k in range(1,n) if st[k,4]>=20]
    if not big: continue
    k=min(big,key=lambda k: math.hypot(cen[k][0]-cx,cen[k][1]-cy))
    ys,xs=np.nonzero(lab==k)
    pts2=np.column_stack([xs,ys]).astype(np.float32)
    (rcx,rcy),(rw,rh),ang=cv2.minAreaRect(pts2)
    rows.append((t,st[k,2],st[k,3],max(rw,rh)+1,st[k,4], math.hypot(cen[k][0]-cx,cen[k][1]-cy)))
r=np.array(rows)
print('n frames',len(r),' bbox w: med %.1f max %.1f | h: med %.1f p90 %.1f max %.1f | major: med %.1f p90 %.1f max %.1f | dist med %.1f'%(
 np.median(r[:,1]),r[:,1].max(),np.median(r[:,2]),np.percentile(r[:,2],90),r[:,2].max(),np.median(r[:,3]),np.percentile(r[:,3],90),r[:,3].max(),np.median(r[:,5])))
for row in r[::max(1,len(r)//16)]: print('  t=%.2f w=%d h=%d major=%.1f area=%d d=%.1f'%tuple(row))
