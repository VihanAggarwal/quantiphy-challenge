import sys, glob, numpy as np, pandas as pd
H='/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/'
tm=[f for f in glob.glob('/home/user/quantiphy-challenge/data/submission_template/*') if f.endswith('.csv')]
print(tm)
T=pd.read_csv(tm[0]); print(T.shape, list(T.columns))
v2=pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv', dtype=str)
for f in ['s2_pad08_segtwin','s2_segtwin','s2_pad08','s2_pad08_maxext_segtwin']:
    d=pd.read_csv(H+f+'.csv', dtype=str)
    print(f, 'ids==template', list(d.id.astype(int))==list(T.id.astype(int)) if 'id' in T.columns else None,
      'cols==v2', list(d.columns)==list(v2.columns),
      'other cols identical', all((d[c].fillna('NA')==v2[c].fillna('NA')).all() for c in d.columns if c!='parsed_value'))
    # template columns identical?
    common=[c for c in T.columns if c in d.columns and c not in ('parsed_value',)]
    Ts=pd.read_csv(tm[0],dtype=str)
    print('   template cols diffs', {c:int((d[c].fillna('NA')!=Ts[c].fillna('NA')).sum()) for c in common})
# raw text line differences
import difflib
a=open('/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv').read().splitlines()
b=open(H+'s2_pad08_segtwin.csv').read().splitlines()
print(len(a),len(b)); print(a[0]); print(b[0]); print(a[1]); print(b[1])
