import sys, cv2, numpy as np
sys.path.insert(0, "/home/user/quantiphy-challenge")
from qp.data import load_split
H = "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2"
df = load_split("test"); s = df[df.category == "S2"]
vids = sorted(set(s.video_id)); vids = [v for v in vids if not v.endswith("_segmented")]
tiles = []
for v in vids:
    p = s[s.video_id == v].video_path.iloc[0]
    cap = cv2.VideoCapture(p); n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)); cap.set(cv2.CAP_PROP_POS_FRAMES, n // 2); ok, f = cap.read()
    if not ok: continue
    h, w = f.shape[:2]; sc = min(320 / w, 240 / h); f = cv2.resize(f, (int(w * sc), int(h * sc)))
    t = np.zeros((260, 320, 3), np.uint8); t[:f.shape[0], :f.shape[1]] = f
    cv2.putText(t, v.replace("simulation", "sim").replace("internet", "int"), (2, 255), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
    tiles.append(t)
per = 20
for k in range(0, len(tiles), per):
    ch = tiles[k:k + per]
    while len(ch) % 4: ch.append(np.zeros_like(tiles[0]))
    rows = [np.hstack(ch[i:i + 4]) for i in range(0, len(ch), 4)]
    cv2.imwrite(f"{H}/img/sheet{k // per}.jpg", np.vstack(rows), [cv2.IMWRITE_JPEG_QUALITY, 75])
print(len(tiles))
