"""cmp.py VARIANT_DIR [kinds] : test S2 + val 2D comparison of a variant repo vs base."""
import sys, os, subprocess, json
V = sys.argv[1]
H = "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2"
code = r'''
import sys, json
from valrun import *
out = {}
m = run(H + "/s2_test_anns.pkl")
out["test"] = m[["qid","video_id","video_source","question","parsed_value","geo_value","direct_value","method","flags"]].to_dict("list")
v = all_val()
out["val"] = v[["run","qid","category","video_id","question","answer","parsed_value","geo_value","direct_value","flags"]].to_dict("list")
import pickle; pickle.dump(out, open(sys.argv[1], "wb"))
'''
def get(repo, path):
    if not os.path.exists(path):
        env = dict(os.environ, QP_REPO=repo, ANTHROPIC_API_KEY="", ANTHROPIC_BASE_URL="http://127.0.0.1:9", QP_LEDGER=H + "/base/ledger.jsonl")
        subprocess.run(["/home/user/quantiphy-challenge/.venv/bin/python", "-c", code, path], env=env, check=True, cwd=H + "/tools")
    import pickle
    return pickle.load(open(path, "rb"))
base = get(H + "/base/repo", H + "/out_base.pkl")
var = get(V + "/repo", V + "/out.pkl")
import pandas as pd, numpy as np
sys.path.insert(0, "/home/user/quantiphy-challenge")
from qp.mra import item_scores
bt, vt = pd.DataFrame(base["test"]), pd.DataFrame(var["test"])
x = bt.merge(vt[["qid","parsed_value","flags"]], on="qid", suffixes=("", "_v"))
x["ratio"] = x.parsed_value_v / x.parsed_value
ch = x[(np.abs(np.log(x.ratio)) > 1e-6) | (x.parsed_value.isna() != x.parsed_value_v.isna())]
pd.set_option("display.width", 250); pd.set_option("display.max_colwidth", 70); pd.set_option("display.max_rows", 500)
print("TEST S2 changed:", len(ch), "median ratio %.3f" % np.nanmedian(ch.ratio) if len(ch) else "")
print(ch[["qid","video_id","question","parsed_value","parsed_value_v","direct_value","ratio"]].to_string())
bv, vv = pd.DataFrame(base["val"]), pd.DataFrame(var["val"])
y = bv.merge(vv[["run","qid","parsed_value"]], on=["run","qid"], suffixes=("", "_v"))
y["m0"] = item_scores(y.parsed_value, y.answer); y["m1"] = item_scores(y.parsed_value_v, y.answer)
print("VAL per run/category (base -> variant):")
print(y.groupby(["category","run"]).apply(lambda g: pd.Series({"n_changed": int((np.abs(g.parsed_value_v/g.parsed_value-1)>1e-6).sum()), "base": g.m0.mean(), "var": g.m1.mean()})).round(4).to_string())
yc = y[np.abs(y.parsed_value_v / y.parsed_value - 1) > 1e-6]
print(yc[["run","qid","question","answer","parsed_value","parsed_value_v","m0","m1"]].to_string())
