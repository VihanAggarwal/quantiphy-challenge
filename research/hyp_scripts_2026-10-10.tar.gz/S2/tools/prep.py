"""Build post-step annotations (refine + dense motion from cache) for one category of a split; pickle.
usage: prep.py REPO RUNS_ROOT RUN_NAME SPLIT CATEGORY OUT.pkl [dense]"""
import sys, os, pickle
REPO, RUNS, NAME, SPLIT, CAT, OUT = sys.argv[1:7]
DENSE = sys.argv[7] if len(sys.argv) > 7 else "motion"
sys.path.insert(0, REPO); sys.path.insert(0, REPO + "/scripts")
import run_claude as rc
from qp.data import load_split
from qp import claude_annotate as ca
df = load_split(SPLIT)
cats = CAT.split(",")
sub = df[df.category.isin(cats)] if CAT != "all" else df
vids = set(sub.video_id)
recs = rc.load_records(__import__("pathlib").Path(RUNS) / NAME / SPLIT / "records")
recs = {v: r for v, r in recs.items() if v in vids}
dfv = df[df.video_id.isin(vids)]
precs = rc.prepare_records(dfv, recs)
anns = ca.load_annotations(precs)
qids = set(sub.qid)
anns = {q: a for q, a in anns.items() if q in qids}
rc.post_steps(anns, dfv, precs, dense=DENSE, dense_cache=os.path.join(RUNS, "_dense_cache", SPLIT), dense_workers=1)
pickle.dump({"anns": anns, "df": sub, "records": precs}, open(OUT, "wb"))
print("saved", len(anns), "anns from", len(recs), "videos")
