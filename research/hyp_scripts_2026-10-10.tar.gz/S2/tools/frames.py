"""frames.py VIDEO_ID [t1 t2 ...] -> one jpg grid (max width 1600) with annotation overlays for chosen qids"""
import sys, cv2, numpy as np, json, os
sys.path.insert(0, "/home/user/quantiphy-challenge")
from qp.data import load_split
H = "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2"
vid = sys.argv[1]; times = [float(x) for x in sys.argv[2:]] or None
df = load_split("test"); path = df[df.video_id == vid].video_path.iloc[0]
cap = cv2.VideoCapture(path); n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)); fps = cap.get(cv2.CAP_PROP_FPS)
W = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)); Hh = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
if times is None: times = [i * (n - 1) / fps / 3 for i in range(4)]
imgs = []
for t in times:
    cap.set(cv2.CAP_PROP_POS_FRAMES, min(int(round(t * fps)), n - 1)); ok, f = cap.read()
    if not ok: continue
    cv2.putText(f, f"t={t:.2f}", (20, 60), cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 0, 255), 4)
    imgs.append(f)
s = 800 / W
imgs = [cv2.resize(i, (int(W * s), int(Hh * s))) for i in imgs]
rows = [np.hstack(imgs[i:i + 2]) if len(imgs[i:i+2]) == 2 else np.hstack([imgs[i], np.zeros_like(imgs[i])]) for i in range(0, len(imgs), 2)]
out = f"{H}/img/{vid}.jpg"; cv2.imwrite(out, np.vstack(rows), [cv2.IMWRITE_JPEG_QUALITY, 80]); print(out, W, Hh, n, fps)
