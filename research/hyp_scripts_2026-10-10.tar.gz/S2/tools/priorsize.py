"""Re-measure S2 prior extents with dense_track size mode (GrabCut, full-res) -> pickle of {qid: (claude_ext, cv_ext, info)}"""
import sys, os, pickle, copy
sys.path.insert(0, os.path.dirname(__file__))
from h import *
from qp import dense_track as dt
anns, df, recs = load(H + "/s2_test_anns.pkl")
paths, meta = rc.video_maps(df, recs, anns)
# one question per video (prior tracks are shared within a video)
first = {}
for r in df.sort_values("qid").itertuples():
    first.setdefault(r.video_id, r.qid)
sub = {q: copy.deepcopy(anns[q]) for q in first.values()}
before = {q: [(o.t, o.extent, o.box) for tr in a.tracks if tr.role == "prior" for o in tr.obs] for q, a in sub.items()}
log = []
dt.densify_annotations(sub, paths, meta, what="size", roles=("prior",), cache_dir=H + "/base/runs/_dense_cache/test_size", log=log, workers=1)
after = {q: [(o.t, o.extent, o.box) for tr in a.tracks if tr.role == "prior" for o in tr.obs] for q, a in sub.items()}
pickle.dump({"before": before, "after": after, "log": log, "first": first}, open(H + "/priorsize.pkl", "wb"))
print("done", len(sub))
