"""In-process harness: pickled post-step annotations -> build_results with the repo's (or patched) geometry."""
import sys, os, pickle, copy, math
REPO = os.environ.get("QP_REPO", "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/base/repo")
sys.path.insert(0, REPO); sys.path.insert(0, REPO + "/scripts")
os.environ["ANTHROPIC_API_KEY"] = ""; os.environ["ANTHROPIC_BASE_URL"] = "http://127.0.0.1:9"
import numpy as np, pandas as pd
import run_claude as rc
from qp import geometry as G
from qp.mra import item_scores
H = "/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2"

def load(pkl):
    d = pickle.load(open(pkl, "rb"))
    return d["anns"], d["df"], d["records"]

def run(pkl, rule=None):
    anns, df, recs = load(pkl)
    res = rc.build_results(df, recs, anns=copy.deepcopy(anns), **({"rule": rule} if rule else {}))
    return df.merge(res, left_on="qid", right_on="id")

def v2():
    return pd.read_csv("/home/user/quantiphy-challenge/runs/test_v1_high_854/test.csv")

def mra_cols(m):
    for c in ("parsed_value", "geo_value", "direct_value"):
        m["mra_" + c.split("_")[0]] = item_scores(m[c], m["answer"])
    return m
