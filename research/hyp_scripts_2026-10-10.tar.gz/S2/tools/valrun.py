from h import *
from qp.data import load_split
VAL = {"val": load_split("val"), "val_hires": load_split("val_hires")}
RUNS = ["val_opus_low", "val_opus_med", "val_opus_med2", "val_opus_high", "val_opus_xhigh", "val_hr_v1_high", "val_hr_v2_high", "val_fable_high"]
def val_results(run):
    anns, df, recs = load(f"{H}/val2d_{run}.pkl")
    split = "val_hires" if "hr_" in run else "val"
    res = rc.build_results(df, recs, anns=copy.deepcopy(anns))
    m = df.merge(res, left_on="qid", right_on="id")
    if "answer" not in m.columns:
        m = m.merge(VAL[split][["qid", "answer"]], on="qid")
    m["run"] = run
    return mra_cols(m)
def all_val():
    return pd.concat([val_results(r) for r in RUNS], ignore_index=True)
