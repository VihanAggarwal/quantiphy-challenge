import sys
sys.path.insert(0, '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/review_evidence')
from known import *
H = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/'
R = '/home/user/quantiphy-challenge/'
k, t, v = known_rows()
kn = set(k.qid) | {2990, 2991, 2992, 2993, 2994, 2949}  # include ext + near rows
v2 = pd.read_csv(R + 'submissions/trackA_opus55_high_v2.csv')
tmpl = pd.read_csv(R + 'data/submission_template/quantiphy_submission_template.csv')
assert (v2.id.values == tmpl.id.values).all()
cat = t.set_index('qid').category
src = t.set_index('qid').video_source
vid = t.set_index('qid').video_id
for n in ['s2_pad08', 's2_segtwin', 's2_pad08_segtwin', 's2_pad08_maxext_segtwin', 's2_pad08_maxext']:
    d = pd.read_csv(H + n + '.csv')
    assert list(d.columns) == list(v2.columns) and d.drop(columns='parsed_value').fillna('').astype(str).equals(v2.drop(columns='parsed_value').fillna('').astype(str))
    assert d.parsed_value.notna().all() and np.isfinite(d.parsed_value).all() and (d.parsed_value > 0).all()
    r = d.parsed_value.values / v2.parsed_value.values
    lr = np.abs(np.log(r))
    ch = lr > 1e-9
    ids = d.id.values
    cats = cat[ids].values
    out = ch & ~np.isin(ids, list(kn))
    print(f'{n}: changed {ch.sum()} (non-S2 {(ch & (cats != "S2")).sum()}), outside-known {out.sum()}, '
          f'median ratio {np.median(r[out]):.4f}, >2% {(lr[out] > .02).sum()}, >5% {(lr[out] > .05).sum()}, >10% {(lr[out] > np.log(1.1)).sum()}, '
          f'frac<1 {(r[out] < 1).mean():.2f}')
    s = pd.DataFrame(dict(id=ids[out], r=r[out], src=src[ids[out]].values, vid=vid[ids[out]].values))
    print('   by source:', s.groupby('src').r.agg(['count', 'median', lambda x: (np.abs(np.log(x)) > .05).sum()]).round(4).to_dict('index'))
