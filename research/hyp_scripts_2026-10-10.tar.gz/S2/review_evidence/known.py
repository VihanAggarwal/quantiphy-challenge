"""Independent known-row matcher: test rows whose base clip is a val clip, identical normalised question,
prior and depth_info. Answers from load_split('val') and ('val_hires') (must agree)."""
import re, sys
import numpy as np, pandas as pd
sys.path.insert(0, '/home/user/quantiphy-challenge')
from qp.data import load_split

def base_clip(v):
    v = v.strip()
    m = re.match(r'^(simulation|internet)_(\d+)(_segmented)?$', v)
    if m: return f'{m.group(1)}_{m.group(2)}'
    m = re.match(r'^captured_(\d+)([a-zA-Z]*)$', v)
    if m: return f'captured_{m.group(1)}'
    return v

def nq(q):
    q = str(q).lower().strip()
    q = re.sub(r'\s+', ' ', q)
    return q

def nq_loose(q):
    q = str(q).lower()
    q = re.sub(r"(\d+)\.0+(?!\d)", r"\1", q)
    return re.sub(r"[^a-z0-9.]", "", q)

def ns(s):
    return re.sub(r'\s+', '', str(s).strip().lower())

def known_rows(loose=False):
    v = load_split('val'); vh = load_split('val_hires')
    assert (v.qid.values == vh.qid.values).all() and np.allclose(v.answer, vh.answer)
    t = load_split('test')
    f = nq_loose if loose else nq
    for d in (v, t):
        d['base'] = d.video_id.map(base_clip)
        d['k'] = [ (b, f(q), ns(p), ns(di)) for b, q, p, di in zip(d.base, d.question, d.prior, d.depth_info)]
    g = v.groupby('k').answer.agg(['first', 'nunique', 'count'])
    if (g['nunique'] > 1).any():
        print('WARNING conflicting val answers', g[g['nunique'] > 1])
    amap = g['first'].to_dict()
    vq = v.set_index('k').qid; vq = vq[~vq.index.duplicated()].to_dict()
    vv = v.set_index('k').video_id; vv = vv[~vv.index.duplicated()].to_dict()
    t['answer'] = t.k.map(amap)
    t['val_qid'] = t.k.map(vq)
    t['val_vid'] = t.k.map(vv)
    return t[t.answer.notna()].copy(), t, v

if __name__ == '__main__':
    k, t, v = known_rows()
    kl, _, _ = known_rows(loose=True)
    print('known rows strict', len(k), 'loose', len(kl))
    print(k.groupby(['category']).size())
    s2 = k[k.category == 'S2']
    pd.set_option('display.width', 250)
    print(s2[['qid', 'video_id', 'val_vid', 'val_qid', 'video_source', 'question', 'answer']].to_string())
    # unmatched val S2 rows
    vs = v[v.category == 'S2']
    print('val S2 qids not matched to any test row:', sorted(set(vs.qid) - set(k.val_qid)))
    extra = set(kl.qid) - set(k.qid)
    print('extra loose-only:', t[t.qid.isin(extra)][['qid','video_id','category','question']].to_string())
