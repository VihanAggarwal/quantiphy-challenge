import numpy as np, pandas as pd
from qp.mra import item_scores
H = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/'
def smooth_mra(p, g, sig):
    z = np.linspace(-3, 3, 61); w = np.exp(-z**2 / 2); w /= w.sum()
    p = np.asarray(p, float); g = np.asarray(g, float)
    return sum(wi * item_scores(p * np.exp(sig * zi), g) for zi, wi in zip(z, w))
if __name__ == '__main__':
    S = pd.read_pickle(H + 'review_evidence/known_scores.pkl')
    P = {n: pd.read_csv(f).set_index('id').parsed_value for n, f in [('v2', '/home/user/quantiphy-challenge/submissions/trackA_opus55_high_v2.csv'), ('pad', H + 's2_pad08.csv'), ('seg', H + 's2_segtwin.csv'), ('main', H + 's2_pad08_segtwin.csv'), ('maxext_main', H + 's2_pad08_maxext_segtwin.csv')]}
    for nm in ('strict', 'ext'):
        k = S[nm]
        rows = []
        for n, p in P.items():
            pp = p[k.qid].values; g = k.answer.values
            le = np.log(pp / g)
            d = dict(set=nm, name=n, mra=item_scores(pp, g).mean())
            for s in (0.01, 0.03, 0.05):
                d[f'sm{s}'] = smooth_mra(pp, g, s).mean()
            d['mean_abs_le'] = np.abs(le).mean(); d['med_abs_le'] = np.median(np.abs(le))
            d['mean_le'] = le.mean()
            rows.append(d)
        print(pd.DataFrame(rows).round(4).to_string())
