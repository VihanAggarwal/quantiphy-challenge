import sys
sys.path.insert(0, '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/review_evidence')
from known import *
from qp.mra import item_scores
H = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/'
R = '/home/user/quantiphy-challenge/'
files = {'v2': R + 'submissions/trackA_opus55_high_v2.csv',
         'probe3': R + 'submissions/trackA_probe3_s2maxext_d2denseoff_labdirect.csv',
         'pad08': H + 's2_pad08.csv', 'segtwin': H + 's2_segtwin.csv',
         'pad08_segtwin': H + 's2_pad08_segtwin.csv', 'pad08_maxext': H + 's2_pad08_maxext.csv',
         'pad08_maxext_segtwin': H + 's2_pad08_maxext_segtwin.csv'}
for a in sys.argv[1:]:
    n, f = a.split('=') ; files[n] = f
k, t, v = known_rows()
# extended: prior value equal instead of text (internet_0027_segmented)
from qp.claude_annotate import prior_si
def pv(p):
    x = prior_si(p); return round(x[0], 9) if x else ns(p)
v['k2'] = [(b, nq(q), pv(p), ns(d)) for b, q, p, d in zip(v.base, v.question, v.prior, v.depth_info)]
t['k2'] = [(b, nq(q), pv(p), ns(d)) for b, q, p, d in zip(t.base, t.question, t.prior, t.depth_info)]
am = v.drop_duplicates('k2').set_index('k2').answer.to_dict()
t['ans2'] = t.k2.map(am)
ke = t[t.ans2.notna()].copy(); ke['answer'] = ke.ans2
S = {}
for nm, kk in (('strict', k), ('ext', ke)):
    kk = kk[kk.category == 'S2'].copy()
    kk['grp'] = np.where(kk.video_id.str.endswith('_segmented'), 'seg', kk.video_source)
    rows = []
    for n, f in files.items():
        p = pd.read_csv(f).set_index('id').parsed_value
        sc = item_scores(p[kk.qid].values, kk.answer.values)
        kk[n] = sc
        d = dict(set=nm, name=n, n=len(kk), all=sc.mean())
        for g in ['simulation', 'internet', 'seg']:
            d[g] = sc[kk.grp.values == g].mean(); d['n_' + g] = (kk.grp.values == g).sum()
        rows.append(d)
    print(pd.DataFrame(rows).round(4).to_string())
    S[nm] = kk
pd.to_pickle(S, H + 'review_evidence/known_scores.pkl')
