import sys
sys.path.insert(0, '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/review_evidence')
from known import *
from qp.mra import item_scores
from qp.claude_annotate import prior_si
R = '/home/user/quantiphy-challenge/'
k, t, v = known_rows()
def pv(p):
    x = prior_si(p); return round(x[0], 9) if x else ns(p)
for d in (v, t):
    d['k2'] = [(b, nq_loose(q), pv(p), ns(di)) for b, q, p, di in zip(d.base, d.question, d.prior, d.depth_info)]
am = v.drop_duplicates('k2').set_index('k2').answer.to_dict()
t['ans'] = t.k2.map(am)
v2 = pd.read_csv(R + 'submissions/trackA_opus55_high_v2.csv').set_index('id').parsed_value
t['p'] = v2[t.qid].values
t['seg'] = t.video_id.str.endswith('_segmented')
orig = t[~t.seg & t.video_source.isin(['simulation', 'internet'])]
seg = t[t.seg]
m = seg.merge(orig[['k2', 'qid', 'p', 'category']], on='k2', suffixes=('', '_o'))
print('twin pairs total (test):', len(m), m.groupby('category').size().to_dict())
mk = m[m.ans.notna()].copy()
print('known twin pairs:', len(mk), mk.groupby(['category']).size().to_dict(), mk.video_id.nunique(), 'clips', mk.video_id.unique())
mk['own_seg'] = item_scores(mk.p.values, mk.ans.values)
mk['copy_to_seg'] = item_scores(mk.p_o.values, mk.ans.values)
mk['own_orig'] = item_scores(mk.p_o.values, mk.ans.values)
mk['copy_to_orig'] = item_scores(mk.p.values, mk.ans.values)
mk['gm'] = item_scores(np.sqrt(mk.p.values * mk.p_o.values), mk.ans.values)
print(mk.groupby('category')[['own_seg', 'copy_to_seg', 'gm']].mean().round(3))
print(mk.groupby('video_id')[['own_seg', 'copy_to_seg', 'gm']].agg(['mean']).round(3).assign(n=mk.groupby('video_id').size()))
print('all', mk[['own_seg', 'copy_to_seg', 'gm']].mean().round(3).to_dict())
# log error: which of seg/orig is closer per pair
mk['le_s'] = np.abs(np.log(mk.p / mk.ans)); mk['le_o'] = np.abs(np.log(mk.p_o / mk.ans))
print('pairs where orig closer:', (mk.le_o < mk.le_s).sum(), 'seg closer', (mk.le_s < mk.le_o).sum(), 'tie', (mk.le_s == mk.le_o).sum())
print('median abs log err seg %.3f orig %.3f' % (mk.le_s.median(), mk.le_o.median()))
# outside known: distribution of seg/orig ratio
o = m[m.ans.isna() & (m.category == 'S2')]
r = o.p_o / o.p
print('S2 outside-known twin pairs', len(o), 'ratio orig/seg quantiles', np.round(np.quantile(r, [.05, .25, .5, .75, .95]), 3), '>10%', (np.abs(np.log(r)) > np.log(1.1)).sum())
print(o.assign(r=r).groupby('video_id').r.agg(['count', 'median', 'min', 'max']).round(3).to_string())
mk['motion'] = mk.question.str.contains(r'speed|velocity|acceleration|displacement', case=False)
print(mk.groupby(['motion'])[['own_seg', 'copy_to_seg', 'gm']].agg(['mean', 'size']).round(3))
print(mk.groupby(['category', 'motion'])[['own_seg', 'copy_to_seg', 'gm']].mean().round(3))
o = m[(m.category == 'S2')].copy()
o['motion'] = o.question.str.contains(r'speed|velocity|acceleration|displacement', case=False)
o['r'] = o.p_o / o.p
o['known'] = o.ans.notna()
print('S2 twin pairs by motion/known:', o.groupby(['motion', 'known']).r.agg(['size', 'median', lambda x: (np.abs(np.log(x)) > np.log(1.1)).sum()]).round(3))
