import sys, re, pickle
sys.path.insert(0, '/home/user/quantiphy-challenge')
import numpy as np, pandas as pd
from qp.mra import item_scores
from qp.data import load_split
OUT = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/verify_lab3d/rerun/'
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500); pd.set_option('display.max_colwidth', 60)
P = pd.read_pickle(OUT + 'priors2.pkl')
Pt = P[(P.split == 'test') & (P.kind != 'seg_accel')].copy()
dyn = Pt[~Pt.gravity.astype(bool)].copy()
dyn['ratio'] = dyn.fit / dyn.stated
dyn['mra'] = item_scores(dyn.fit, dyn.stated)
print('dyn renders', len(dyn), 'fitted', dyn.fit.notna().sum())
print('MRA all (unfitted=0):', dyn.mra.mean().round(3), ' fitted only:', dyn[dyn.fit.notna()].mra.mean().round(3))
f = dyn[dyn.fit.notna()]
print('rms log ratio fitted:', np.sqrt(np.mean(np.log(f.ratio) ** 2)).round(3), 'median |log|', np.median(np.abs(np.log(f.ratio))).round(3))
print('by kind:'); print(f.groupby('kind').apply(lambda g: pd.Series({'n': len(g), 'mra': g.mra.mean(), 'med_ratio': g.ratio.median(), 'rmslog': np.sqrt(np.mean(np.log(g.ratio)**2))})).round(3))
print(dyn[['vid', 'prior', 't', 'stated', 'fit', 'ratio', 'mra', 'mode', 'model', 'n_seg']].round(3).to_string())
# free-fall segment table per family
seg = P[(P.split == 'test') & (P.kind == 'seg_accel')]
ff = seg[(seg.ang <= 30) & (seg.n_seg >= 7)]
print('\nfree-flight-like segments (ang<=30, n>=7):', len(ff), ' with |a|>=4:', (ff.fit >= 4).sum())
print(ff.groupby('fam').fit.agg(['count', 'median', 'min', 'max']).round(2))
# family grav medians with and without the |a|>=4 filter (both splits, as gate.py does)
segall = P[(P.kind == 'seg_accel') & (P.ang <= 30) & (P.n_seg >= 7)]
w = segall[segall.fit >= 4].groupby('fam').fit.median(); wo = segall.groupby('fam').fit.median()
cmp = pd.DataFrame({'with_filter': w, 'without': wo})
cmp['pass_with'] = cmp.with_filter.between(7.5, 12.5); cmp['pass_without'] = cmp.without.between(7.5, 12.5)
print(cmp.round(2))
