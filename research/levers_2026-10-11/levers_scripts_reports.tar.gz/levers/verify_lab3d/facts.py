import sys, re
sys.path.insert(0, '/home/user/quantiphy-challenge')
import numpy as np, pandas as pd
from qp.data import load_split
OUT = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/verify_lab3d/'
T = pd.read_pickle(OUT + 'rerun/test_gated.pkl')
t = load_split('test')
lab = t[t.video_source == 'lab']
def family(vid):
    m = re.match(r'captured_(\d+[ab]?)', vid); return m.group(1) if m else vid
lab = lab.assign(fam=lab.video_id.map(family))
UNIT = {'m': 1, 'cm': 100, 'mm': 1000, 'm/s': 1, 'cm/s': 100, 'mm/s': 1000, 'km/h': 3.6, 'm/s^2': 1, 'cm/s^2': 100, 'mm/s^2': 1000}
num = re.compile(r'([-+]?\d*\.?\d+)')
# all numbers in each family's prior texts (raw), to detect exact transfers
famnums = {}
for fam, g in lab.groupby('fam'):
    s = set()
    for p in g.prior.unique():
        for x in num.findall(str(p)):
            s.add(float(x))
    famnums[fam] = (s, list(g.prior.unique()))
R = T[T['rep']].copy()
hits = []
for _, r in R.iterrows():
    nums, pri = famnums.get(r.fam, (set(), []))
    u = UNIT.get(r.unit, 1)
    cand = []
    for x in nums:
        for f in (1, 100, 1000, 0.01, 0.001, 3.6, 1/3.6):
            if x > 0 and abs(r.cur - x * f) / (x * f) < 1e-4:
                cand.append((x, f))
    if cand:
        hits.append((r.vid, r.qid, r.cat, r.question, r.cur, r.fam_med, cand, pri))
print('replaced rows whose current value equals a number in a family prior text:', len(hits))
for h in hits:
    print(h)
# also: test questions whose text matches family prior quantity
print()
print('priors in families with replaced rows:')
for fam in sorted(R.fam.unique()):
    print(fam, famnums[fam][1])
