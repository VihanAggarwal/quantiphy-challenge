import sys, re
import numpy as np, pandas as pd
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500); pd.set_option('display.max_colwidth', 75)
OUT = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/verify_lab3d/rerun/'
A = pd.read_pickle(OUT + 'gated.pkl')
T = pd.read_pickle(OUT + 'test_gated.pkl').set_index('qid')
A['event'] = A.fam.str.replace(r'[ab]$', '', regex=True)
A['view'] = A.fam.str.extract(r'([ab])$')[0]
A['cur'] = A.qid.map(T.cur)
A['rep'] = A.qid.map(T['rep']).fillna(False)
X = A[A.view.notna()]
rows = []
for (ev, qn), g in X.groupby(['event', 'qn']):
    if g.view.nunique() < 2:
        continue
    d = {}
    for vw, h in g.groupby('view'):
        d[vw] = dict(fit=h.fit.median(), fam_med=h.fam_med.iloc[0], gate=h.gate.any(), rep=h.rep.any(), cur=h.cur.median(),
                     n=len(h))
    rows.append(dict(event=ev, q=qn[:60], a_fit=d['a']['fit'], b_fit=d['b']['fit'], a_cur=d['a']['cur'], b_cur=d['b']['cur'],
                     a_rep=d['a']['rep'], b_rep=d['b']['rep']))
D = pd.DataFrame(rows)
D['fit_b/a'] = D.b_fit / D.a_fit; D['cur_b/a'] = D.b_cur / D.a_cur
print(D.round(3).to_string())
ok = D['fit_b/a'].notna()
print('cross-VIEW fit ratio |log|: median', np.median(np.abs(np.log(D.loc[ok, 'fit_b/a']))).round(3), 'within 1.25x:', (np.abs(np.log(D.loc[ok, 'fit_b/a'])) < np.log(1.25)).mean().round(3), 'n', ok.sum())
ok2 = D['cur_b/a'].notna()
print('cross-VIEW current ratio |log|: median', np.median(np.abs(np.log(D.loc[ok2, 'cur_b/a']))).round(3), 'within 1.25x:', (np.abs(np.log(D.loc[ok2, 'cur_b/a'])) < np.log(1.25)).mean().round(3), 'n', ok2.sum())
