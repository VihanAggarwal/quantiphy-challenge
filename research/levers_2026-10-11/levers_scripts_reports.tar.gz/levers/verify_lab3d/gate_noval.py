import sys
sys.path.insert(0, '/home/user/quantiphy-challenge')
sys.path.insert(0, '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/verify_lab3d/rerun')
import numpy as np, pandas as pd
import gate as G
OUT = G.OUT
A0 = pd.read_pickle(OUT + 'answers2.pkl'); P0 = pd.read_pickle(OUT + 'priors2.pkl')
# rebuild with test-only rows: monkeypatch read_pickle inputs
A0[A0.split == 'test'].to_pickle(OUT + 'answers_testonly.pkl'); P0[P0.split == 'test'].to_pickle(OUT + 'priors_testonly.pkl')
A, fp, fpr, fg = G.build('_testonly')
base = pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_probe7b_p5_ens_famext.csv').set_index('id').parsed_value
A['cur'] = A.qid.map(base); A['ratio'] = A.fam_med / A.cur
A['rep'] = A.gate & (A.ratio <= 3) & (A.ratio >= 1/3) & A.fam_med.notna()
T = pd.read_pickle(OUT + 'test_gated.pkl').set_index('qid')
A = A.set_index('qid')
d = A.join(T[['rep', 'fam_med']], rsuffix='_orig')
print('replaced with val duplicates excluded:', int(A.rep.sum()), ' original:', int(T.rep.sum()))
print('rows whose decision changes:', int((d.rep != d.rep_orig).sum()))
chg = d[d.rep & d.rep_orig]
print('max |log| change in fam_med among rows replaced in both:', float(np.abs(np.log(chg.fam_med / chg.fam_med_orig)).max()))
print(d[(d.rep != d.rep_orig) | (np.abs(np.log(d.fam_med / d.fam_med_orig)) > 0.01)][['vid', 'question', 'rep', 'rep_orig', 'fam_med', 'fam_med_orig', 'n_r']].to_string())
