import sys, re
sys.path.insert(0, '/home/user/quantiphy-challenge')
import numpy as np, pandas as pd
from qp.data import load_split
OUT = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/verify_lab3d/rerun/'
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500); pd.set_option('display.max_colwidth', 70)
T = pd.read_pickle(OUT + 'test_gated.pkl')
R = T[T['rep']].copy()
R['checktype'] = R.fam_check.str.split('=').str[0]
print(R.groupby(['fam', 'fam_check', 'cat']).size().unstack(fill_value=0))
print(R.groupby(['checktype', 'cat']).size().unstack(fill_value=0))
# is cur == direct on lab motion test rows?
T['cur_eq_dir'] = np.isclose(T.cur, pd.to_numeric(T.direct, errors='coerce'), rtol=1e-6)
print('test lab motion rows: cur==direct', T.cur_eq_dir.sum(), 'of', len(T))
print('replaced: cur==direct', R.qid.map(T.set_index('qid').cur_eq_dir).sum(), 'of', len(R))
# question-text time vs spec time
t = load_split('test').set_index('qid')
bad = []
for _, r in R.iterrows():
    q = t.loc[r.qid, 'question']
    ts = [float(x) for x in re.findall(r'(\d+(?:\.\d+)?)\s*s(?:econds?)?\b', q)]
    if r.kind in ('speed', 'acceleration'):
        if ts and (r.t is None or abs(ts[0] - r.t) > 1e-6):
            bad.append((r.qid, q, r.t))
    elif r.kind in ('displacement', 'path_length'):
        w = r.window
        if len(ts) >= 2 and (not w or abs(ts[0] - w[0]) > 1e-6 or abs(ts[1] - w[1]) > 1e-6):
            bad.append((r.qid, q, w))
print('time/window mismatches question text vs spec in replaced rows:', len(bad)); [print('  ', b) for b in bad[:20]]
# unit check
print(R.groupby(['kind', 'unit']).size())
# n frames per lab clip vs the [n>=60] term
lab = load_split('test'); lab = lab[lab.video_source == 'lab']
