"""Label-free check: is each replaced row's 3D reconstruction consistent with the object's own apparent size?
Under a correct reconstruction, |P(t)| * d_px(t) = f * D is constant in time. We compute, inside the query window
(t +- 0.25 s, or the displacement/path window +- 0.1 s), the ratio q(t) = |P(t)| * d(t) on good dense points and
report the max/min of a robust linear trend of log q across the window (trend-based, to ignore per-frame noise)."""
import sys, pickle
sys.path.insert(0, '/home/user/quantiphy-challenge'); sys.path.insert(0, 'rerun')
import numpy as np, pandas as pd
import fit as FT
recon = pickle.load(open('rerun/recon2.pkl', 'rb'))
T = pd.read_pickle('rerun/test_gated.pkl')
A = pd.read_pickle('rerun/gated.pkl')
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 400); pd.set_option('display.max_colwidth', 60)
def check(split, vid, obj, kind, t, window):
    o = recon.get((split, vid), {}).get(obj)
    if o is None or o.get('P') is None:
        return np.nan, 0
    ob = o['obs']
    if kind in ('speed', 'acceleration'):
        lo, hi = t - 0.25, t + 0.25
    else:
        lo, hi = (window[0] - 0.1, window[1] + 0.1) if window else (-1e9, 1e9)
    m = (ob['t'] >= lo) & (ob['t'] <= hi) & np.isfinite(ob['d']) & o['good'] & np.isfinite(o['P'][:, 0])
    if m.sum() < 4:
        return np.nan, int(m.sum())
    q = np.log(np.linalg.norm(o['P'][m], axis=1) * ob['d'][m])
    tt = ob['t'][m]
    c = np.polyfit(tt, q, 1)
    span = tt.max() - tt.min()
    return float(np.exp(abs(c[0]) * span)), int(m.sum())   # trend change of |P|*d across the window
rows = []
R = A[A.split == 'test'].merge(T[['qid', 'rep', 'cur', 'ratio']], on='qid')
for _, r in R[R.fit.notna()].iterrows():
    v, n = check(r.split, r.vid, r.obj, r.kind, r.t, r.window)
    rows.append(dict(qid=r.qid, vid=r.vid, fam=r.fam, cat=r['cat'], kind=r.kind, obj=r.obj, mode=r['mode'], rep=r.rep, ratio=r.ratio, size_incons=v, n=n))
D = pd.DataFrame(rows)
D.to_pickle('sizecheck.pkl')
print('rows with fit (test):', len(D), ' checkable:', D.size_incons.notna().sum())
for lab, g in (('replaced', D[D.rep]), ('not replaced', D[~D.rep])):
    s = g.size_incons.dropna()
    print(f'{lab:13s} n={len(s)} median trend change {s.median():.3f}  >1.15: {(s > 1.15).mean():.2f}  >1.25: {(s > 1.25).mean():.2f}')
print(D[D.rep].groupby('fam').size_incons.median().round(3).to_dict())
fam_bad = D[D.rep].groupby(['fam', 'obj']).size_incons.median().round(3)
print(fam_bad[fam_bad > 1.15])
