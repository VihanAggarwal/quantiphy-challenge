from vload import *
m = meta(); cats=m.category.to_numpy(); gt=m.answer.to_numpy(); vids=m.video_id.to_numpy()
def c(path, col_): return col(path, col_).reindex(m.index).abs().where(lambda s: s>0)
v1p=c('runs/val_hr_v1_high/val_hires.csv','parsed_value'); v1d=c('runs/val_hr_v1_high/val_hires.csv','direct_value')
v2d=c('runs/val_hr_v2_high/val_hires.csv','direct_value'); ohd=c('runs/val_opus_high/val.csv','direct_value')
ast=c('runs/val_astra_high/val_hires.csv','direct_value')
gem_=gem('/home/user/quantiphy-challenge/runs/val_gem31pro_video/val_hires/records').reindex(m.index)
def lmed(*cols):
    X=np.log(np.vstack([np.asarray(x,float) for x in cols]).T)
    return np.array([np.exp(np.median(r[np.isfinite(r)])) if np.isfinite(r).any() else np.nan for r in X])
nonlab3d = (m.category.str[1]=='3') & m.video_source.isin(['simulation','segmentation'])
s3 = (cats=='S3'); s3nl = s3 & nonlab3d.to_numpy()
c3 = lmed(v1d,v2d,ohd)
dep = np.where(nonlab3d, c3, v1p)
it = lambda p: items(p, gt)
D = it(dep)
rules = {
 'median(C3d) [deployed-like]': dep,
 'median(med(C3d), astra, gem)': np.where(s3nl, lmed(c3, ast, gem_), dep),
 'median(C3d+astra+gem) 5-way': np.where(s3nl, lmed(v1d,v2d,ohd,ast,gem_), dep),
 'median(v1.direct, astra, gem)': np.where(s3nl, lmed(v1d, ast, gem_), dep),
 'median(v1.parsed, astra, gem) all S3': np.where(s3, lmed(v1p, ast, gem_), dep),
 'median(med(C3d), astra)': np.where(s3nl, lmed(c3, ast), dep),
 'median(med(C3d), gem)': np.where(s3nl, lmed(c3, gem_), dep),
}
print('S3 nonlab videos', sorted(set(vids[s3nl])), s3nl.sum(), 'q; astra missing', ast[s3nl].isna().sum(), 'gem missing', gem_[s3nl].isna().sum())
for k,p in rules.items():
    I = it(p); ch = (np.abs(np.log(p/dep))>1e-9).sum()
    pv = {v: round(I[vids==v].mean()-D[vids==v].mean(),3) for v in sorted(set(vids[s3]))}
    print(f'{k:40s} changed {ch:2d}  S3 {I[s3].mean()-D[s3].mean():+.3f}  MRA {mra(I,cats)["MRA"]-mra(D,cats)["MRA"]:+.4f}  per-video {pv}')
# question-level detail for S3 non-lab
det = pd.DataFrame({'vid':vids,'tk':m.question.str[:60],'truth':gt,'v1d':v1d,'v2d':v2d,'ohd':ohd,'c3':c3,'astra':ast,'gem':gem_,'r3':lmed(c3,ast,gem_)})[s3nl]
det['it_dep']=items(det.c3.values, det.truth.values); det['it_r3']=items(det.r3.values, det.truth.values)
pd.set_option('display.width',250)
print(det.round(3).to_string())
