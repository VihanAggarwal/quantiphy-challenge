"""Independent loader for verification (does not import the oracles' common.py)."""
import sys, json, math
from pathlib import Path
import numpy as np, pandas as pd
REPO = Path("/home/user/quantiphy-challenge")
sys.path.insert(0, str(REPO))
from qp.data import load_split, load_validation
from qp.mra import item_scores as off_items, score as off_score, THRESHOLDS

def meta():
    m = load_split("val_hires").set_index("qid", drop=False)
    v = load_validation()
    v = v.set_index("qid") if "qid" in v.columns else v
    m["answer"] = v["answer"].reindex(m.index) if "answer" not in m.columns or m["answer"].isna().all() else m["answer"]
    return m

def col(path, c):
    t = pd.read_csv(REPO / path).set_index("id")
    return pd.to_numeric(t[c], errors="coerce")

def gem(recdir):
    vals = {}
    for p in sorted(Path(recdir).glob("*.json")):
        rec = json.loads(p.read_text())
        for a in rec.get("answers", []) or []:
            try:
                x = abs(float(a["value"])); vals[int(a["qid"])] = x if math.isfinite(x) and x > 0 else np.nan
            except Exception: pass
    return pd.Series(vals, dtype=float)

def items(pred, gt):
    p = np.asarray(pred, float)
    s = off_items(pd.Series(p), gt)
    s = np.where(np.isfinite(np.abs(p)), s, 0.0)
    return s

def mra(it, cats):
    per = {c: float(np.mean(it[cats == c])) for c in ("S2","D2","S3","D3")}
    per["MRA"] = float(np.mean(list(per.values())))
    return per
