from vload import *
import re
m = meta(); cats = m.category.to_numpy(); gt = m.answer.to_numpy()
v1 = col('runs/val_hr_v1_high/val_hires.csv','parsed_value').reindex(m.index).abs().to_numpy()
TH = np.array(THRESHOLDS)
def item(p, g):
    rel = np.abs(p-g)/g
    return (rel[...,None] < 1-TH).sum(-1)/len(TH)
def best_factor(p, g):
    # candidate c: breakpoints c = g*(1 +- (1-t))/p, nudged inward, plus 1
    cands=[1.0]
    for pi,gi in zip(p,g):
        for t in TH:
            for s in (+1,-1):
                b = gi*(1+s*(1-t))/pi
                if b>0:
                    cands += [b*(1-1e-9), b*(1+1e-9)]
    cands = np.array(cands)
    sc = item(cands[:,None]*p[None,:], g[None,:]).sum(1)
    best = sc.max()
    ok = cands[sc==best]
    return ok[np.argmin(np.abs(np.log(ok)))], best
vids = m.video_id.to_numpy()
def oracle(pred):
    out = pred.copy()
    for v in np.unique(vids):
        ix = vids==v
        c,_ = best_factor(pred[ix], gt[ix]); out[ix] = c*pred[ix]
    return out
base = mra(item(v1,gt), cats); orc = mra(item(oracle(v1),gt), cats)
print('base', {k:round(x,3) for k,x in base.items()}); print('A1', {k:round(x,3) for k,x in orc.items()})
# null: shuffle log residuals across videos within category
rng = np.random.default_rng(0)
lr = np.log(v1/gt)
gains=[]; percat=[]
for r in range(100):
    lr2 = lr.copy()
    for c in ("S2","D2","S3","D3"):
        ix = np.where(cats==c)[0]; lr2[ix] = rng.permutation(lr[ix])
    p2 = gt*np.exp(lr2)
    b = mra(item(p2,gt),cats); o = mra(item(oracle(p2),gt),cats)
    gains.append(o['MRA']-b['MRA']); percat.append({c:o[c]-b[c] for c in ("S2","D2","S3","D3")})
gains=np.array(gains)
print('real gain', round(orc['MRA']-base['MRA'],4), 'null mean', round(gains.mean(),4), 'sd', round(gains.std(),4), 'excess', round(orc['MRA']-base['MRA']-gains.mean(),4), 'p', (gains>=orc['MRA']-base['MRA']).mean())
pc = pd.DataFrame(percat).mean()
for c in ("S2","D2","S3","D3"): print(c, 'gain', round(orc[c]-base[c],3), 'null', round(pc[c],3), 'excess', round(orc[c]-base[c]-pc[c],3))
# per-video factors
rows=[]
for v in np.unique(vids):
    ix = vids==v; c,_ = best_factor(v1[ix],gt[ix])
    rows.append((v, cats[ix][0], ix.sum(), round(c,3), round(item(v1[ix],gt[ix]).mean(),3), round(item(c*v1[ix],gt[ix]).mean(),3)))
df = pd.DataFrame(rows, columns=['video','cat','n','c','base','oracle']).sort_values('c')
print(df.to_string(index=False))
# ICC / variance split
lrc = np.clip(lr, -np.log(3), np.log(3))
s = pd.Series(lrc, index=m.index); vm = s.groupby(vids).transform('mean')
print('total var', round(s.var(ddof=0),3), 'between', round(vm.var(ddof=0),3), 'within', round((s-vm).var(ddof=0),3))
