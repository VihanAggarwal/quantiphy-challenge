import sys
sys.path.insert(0, '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/oracles')
from common import item_scores, load_meta, load_runs
from oracle_a import best_factor
import numpy as np, pandas as pd
m = load_meta(); R = load_runs(m); y = m.answer; base = R["v1.parsed"]; r = np.log(base/y)
def gain(sub, resid):
    tb=to=0.0
    for vid,g in sub.groupby('video_id'):
        p = (y.loc[g.index]*np.exp(resid.loc[g.index])).values
        c,_,s = best_factor(p, y.loc[g.index].values)
        tb += item_scores(p, y.loc[g.index].values).sum(); to += s
    return (to-tb)/len(sub)
subsets = {
 'size prior, motion targets': (m.pkind=='size') & m.motion,
 'dynamic prior, static targets': m.pkind.isin(['speed','accel']) & ~m.motion,
 '2D (geometry answers)': ~m.is3d,
 'size prior, motion, non-lab': (m.pkind=='size') & m.motion & (m.src!='lab'),
}
for name, sel in subsets.items():
    sub = m[sel]; g_real = gain(sub, r)
    print(name, len(sub), sub.video_id.nunique(), 'real', round(g_real,3), sub.groupby(['category','src']).video_id.nunique().to_dict())
    for strat in (None, 'category', 'cat_src'):
        rng = np.random.default_rng(5); nulls=[]
        key = None if strat is None else (sub.category if strat=='category' else sub.category + sub.src.where(sub.src=='lab','nonlab'))
        for k in range(200):
            rr = r.copy()
            if key is None:
                rr.loc[sub.index] = rng.permutation(r.loc[sub.index].values)
            else:
                for kv in key.unique():
                    ix = sub.index[key==kv]; rr.loc[ix] = rng.permutation(r.loc[ix].values)
            nulls.append(gain(sub, rr))
        nulls=np.array(nulls)
        print('   null strat', strat, 'mean', round(nulls.mean(),3), 'excess', round(g_real-nulls.mean(),3), 'p', round((nulls>=g_real).mean(),3))
