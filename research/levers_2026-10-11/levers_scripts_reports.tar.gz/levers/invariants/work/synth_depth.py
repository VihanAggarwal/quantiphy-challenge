"""Noise-free truth recovery: depth knots (3 times vs every frame), sideways motion amplitude,
original solver vs Z-interpolation. Uses test_invariance's scene builder with patched scene params."""
import math, numpy as np
import test_invariance as ti
import zinterp

def scene(lam=1.0, W=1280, H=720, fov=83.1, x0=-0.3, v0=0.2, acc=0.8, z=1.2, knots=(0.0, 1.0, 2.0), vz=0.0):
    f = (W / 2) / math.tan(math.radians(fov) / 2)
    t = np.arange(ti.N) / ti.FPS
    xa = (x0 + v0 * t + 0.5 * acc * t ** 2) * lam
    za = (z + vz * t) * lam
    PA = np.c_[xa, np.full(ti.N, 0.05 * lam), za]
    PB = np.tile([0.35 * lam, -0.12 * lam, 1.6 * lam], (ti.N, 1))
    vel = np.array([v0 + acc * 1.0, 0, vz])
    truth = {'A_v_1.0': float(np.linalg.norm(vel)) * lam, 'A_a': acc * lam, 'B_w': 0.30 * lam,
             'AB_dist_1.0': float(np.linalg.norm(PA[24] - PB[24]))}
    ks = np.arange(ti.N) / ti.FPS if knots == 'all' else knots
    depth = [dict(object='ball', distance_m=float(np.linalg.norm(PA[int(round(k * ti.FPS))])), time=round(float(k), 4)) for k in ks]
    depth.append(dict(object='box', distance_m=float(np.linalg.norm(PB[0])), time=None))
    return f, {'A': (PA, 0.0335 * lam), 'B': (PB, 0.15 * lam)}, truth, depth

cases = [('sideways in view, knots 0/1/2', dict(x0=-0.5, v0=0.2, acc=0.4)),
         ('sideways in view, knots all frames', dict(x0=-0.5, v0=0.2, acc=0.4, knots='all')),
         ('sideways in view, knots 0/2', dict(x0=-0.5, v0=0.2, acc=0.4, knots=(0.0, 2.0))),
         ('sideways + receding, knots 0/1/2', dict(x0=-0.5, v0=0.2, acc=0.4, vz=0.3)),
         ('original scene (leaves view), knots 0/1/2', dict()),
         ('centred small motion, knots 0/1/2', dict(x0=-0.1, v0=0.05, acc=0.1))]
names = {1: 'box width', 2: 'speed@1', 3: 'accel', 4: 'dist@1'}
for label, kw in cases:
    ti.scene_3d = lambda lam=1.0, W=1280, H=720, fov=83.1, kw=kw: scene(lam, W, H, fov, **kw)
    for prior in ('size', 'speed'):
        line = []
        for z in (False, True):
            with zinterp.zinterp(z):
                p, m, truth = ti.build(1280, 720, 854, prior=prior)
                a = ti.answers(p, m, lab=True)
            line.append(' '.join(f'{names[q]} {a[q][0] / truth[q] - 1:+.3f}' if a[q][0] else f'{names[q]} nan' for q in sorted(a)))
        print(f'{label:42s} prior={prior:5s} | orig: {line[0]} | zinterp: {line[1]}')
