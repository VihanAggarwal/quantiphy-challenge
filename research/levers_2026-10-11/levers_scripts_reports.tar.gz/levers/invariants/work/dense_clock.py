"""Dense check of the lab clock against STATED motion priors (exact labels; test inputs only).
Every frame: moving blob by difference to the median background, the component nearest Claude's prior
track (interpolated in time); 3D with f = 722 px @1280 and the prior object's depth_info (qp.geometry's
depth matching, range convention). Then the stated quantity at its time with local polynomial fits on
the video clock n/24 vs the capture clock. Also per-frame step ratios at the drop transitions."""
import sys
import cv2
import numpy as np
import pandas as pd
import inv
from qp import geometry as geo

VIDS = sys.argv[1:] or ['captured_0054a', 'captured_0054as', 'captured_0054ax', 'captured_0054b', 'captured_0054bs',
                        'captured_0054bx', 'captured_0053', 'captured_0053s', 'captured_0053x', 'captured_0001',
                        'captured_0002', 'captured_0013', 'captured_0013x', 'captured_0062', 'captured_0061',
                        'captured_0047', 'captured_0052', 'captured_0023', 'captured_0024', 'captured_0041']
df, rec, anns = inv.load('test', '/home/user/quantiphy-challenge/runs/test_v1_high_854/test/records')


def frames(path):
    c = cv2.VideoCapture(path); out = []
    while True:
        ok, f = c.read()
        if not ok:
            break
        out.append(f)
    return out


def track(fr, seed_t, seed_uv, thr=28, min_area=60, radius=90):
    bg = np.median(np.stack(fr).astype(np.float32), axis=0)
    out = {}
    for n, f in enumerate(fr):
        t = n / 24.0
        if t < seed_t[0] - 0.1 or t > seed_t[-1] + 0.1:
            continue
        pred = np.array([np.interp(t, seed_t, seed_uv[:, 0]), np.interp(t, seed_t, seed_uv[:, 1])])
        d = np.abs(f.astype(np.float32) - bg).max(axis=2)
        m = (d > thr).astype(np.uint8)
        m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
        k, lab, st, cen = cv2.connectedComponentsWithStats(m)
        best = None
        for j in range(1, k):
            if st[j][4] < min_area:
                continue
            dd = np.hypot(*(cen[j] - pred))
            if dd < radius and (best is None or dd < best[0]):
                best = (dd, j)
        if best is not None:
            out[n] = cen[best[1]]
    return out


def local(t, P, t0, half, deg=2):
    sel = np.abs(t - t0) <= half + 1e-9
    if sel.sum() < deg + 2:
        return None
    c = np.polyfit(t[sel] - t0, P[sel], deg)
    return c  # highest power first


rows = []
for vid in VIDS:
    q = df[df.video_id == vid]
    if q.empty:
        continue
    a = anns.get(int(q.qid.iloc[0]))
    prior = a.spec.prior
    if prior.kind not in ('speed', 'acceleration'):
        continue
    pr = [tr for tr in a.tracks if tr.role == 'prior' and tr.obs]
    if not pr:
        print(vid, 'no prior track'); continue
    tr = max(pr, key=lambda x: len(x.obs))
    pts = [(o.t, o.point if o.point is not None else ([(o.box[0] + o.box[2]) / 2, (o.box[1] + o.box[3]) / 2] if o.box else None)) for o in tr.obs]
    pts = [(t, p) for t, p in pts if p is not None]
    st = np.array([p[0] for p in pts]); su = np.array([p[1] for p in pts], float)
    fr = frames(q.video_path.iloc[0])
    H, W = fr[0].shape[:2]
    trk = track(fr, st, su)
    n = np.array(sorted(trk)); uv = np.array([trk[i] for i in n])
    if len(n) < 10:
        print(vid, 'too few dense points', len(n)); continue
    f = inv.lab_f((W, H)); c = (W / 2, H / 2)
    groups = geo._depth_groups(a.spec.depth)
    fn = geo.match_depth([tr.depth_name, tr.object, *prior.objects[:1]], groups) if groups else None
    if fn is None:
        print(vid, 'no depth for prior'); continue
    tv, tc = n / 24.0, inv.capture_time(n)
    res = dict(video=vid, prior=q.prior.iloc[0], kind=prior.kind, stated=prior.value_si, t0=prior.time, n_dense=len(n),
               depth=fn.names)
    # per-frame 2D step ratios at the drop transitions (11->12, 35->36) vs neighbours
    step = {int(i): np.linalg.norm(uv[k + 1] - uv[k]) for k, i in enumerate(n[:-1]) if n[k + 1] == i + 1}
    for d in (11, 35):
        nb = [step.get(j) for j in (d - 2, d - 1, d + 1, d + 2) if step.get(j)]
        if step.get(d) and nb and np.median(nb) > 2:
            res[f'step{d}'] = round(step[d] / np.median(nb), 2)
    for clock, tt in (('video', tv), ('capture', tc)):
        P = geo._View(f, c, fn).pos(tt, uv)
        cols = geo._axis_cols(prior.axis, 3)
        t0 = prior.time if prior.time is not None else (tt[0] + tt[-1]) / 2
        for half in (0.13, 0.21, 0.3, 0.5):
            cc = local(tt, P, t0, half, 2)
            if cc is None:
                continue
            val = np.linalg.norm(cc[-2][cols]) if prior.kind == 'speed' else np.linalg.norm(2 * cc[0][cols])
            res[f'{clock}_{half}'] = round(val / prior.value_si, 3)  # measured / stated
        # smoothness: rms residual of a cubic over the whole dense track
        c3 = np.polyfit(tt, P, 3)
        res[f'rms3_{clock}_mm'] = round(1000 * float(np.sqrt(((P - np.vander(tt, 4) @ c3) ** 2).sum(1).mean())), 1)
    rows.append(res)
    print(res, flush=True)
pd.DataFrame(rows).to_csv('dense_clock.csv', index=False)
