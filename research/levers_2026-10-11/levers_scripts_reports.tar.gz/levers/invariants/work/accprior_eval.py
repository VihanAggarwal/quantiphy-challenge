import sys; sys.path.insert(0, "/home/user/quantiphy-challenge")
import numpy as np, pandas as pd
from qp.mra import item_scores
R = pd.read_pickle('accprior_test.pkl')
x = R[R.prior_kind == 'acceleration'].copy()
x['grav'] = np.isclose(x.prior_si, 9.8)
x['assumed'] = x['flags'].str.contains('prior_depth_assumed')
for sub, s in (('all', x), ('depth known', x[~x.assumed]), ('gravity', x[x.grav]), ('slope/other', x[~x.grav])):
    print(f'== {sub}')
    for (clock, var), g in s.groupby(['clock', 'var']):
        g = g.dropna(subset=['prior_meas'])
        lr = np.log(g.prior_si / g.prior_meas)
        print(f'  {clock:8s} {var:13s} n={len(g):2d} median stated/meas {np.exp(lr.median()):.3f} '
              f'median|log| {lr.abs().median():.3f} MRA {np.nanmean(item_scores(g.prior_meas, g.prior_si)):.3f}')
