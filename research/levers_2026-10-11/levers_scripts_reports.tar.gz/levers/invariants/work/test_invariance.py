"""(a) Synthetic invariance tests of the annotation -> geometry path (qp.claude_annotate.to_annotations +
qp.geometry.solve), no API, no video files.

Scenes are rendered analytically at the ORIGINAL resolution; the "annotator" reports coordinates in the
downscaled frame exactly as read_frames produces it (scale = min(1, max_side / max(w, h)), frame size
round(w * scale) x round(h * scale)). Checks:
  R  resolution invariance: answers from 854-px annotations == answers from original-px annotations
  D  dimensional invariance: lengths (prior value, depths, object sizes) x lambda -> answers x lambda
  T  truth recovery (pinhole + Euclidean range, known lab camera, f solved from the prior)
Run: .venv/bin/python test_invariance.py"""
import math
import sys

import numpy as np

sys.path.insert(0, '/home/user/quantiphy-challenge')
from qp import claude_annotate as ca  # noqa: E402
from qp import geometry as geo  # noqa: E402

FPS = 24.0
N = 49


def seen_scale(W, H, max_side=854):
    s = min(1.0, max_side / max(W, H))
    return s, round(W * s), round(H * s)


def project(P, f, W, H):
    """Pinhole, principal point at the image centre (x right, y down, z forward)."""
    P = np.atleast_2d(P)
    return np.c_[f * P[:, 0] / P[:, 2] + W / 2, f * P[:, 1] / P[:, 2] + H / 2]


def scene_3d(lam=1.0, W=1280, H=720, fov=83.1):
    """Ball A (diameter 0.067 lam, prior) rolling sideways with acceleration; box B (width 0.30 lam) static,
    off-axis; ball C falling (gravity check). Returns frames -> obs per object, depth entries, truths."""
    f = (W / 2) / math.tan(math.radians(fov) / 2)
    t = np.arange(N) / FPS
    out = {}
    # A: starts at x=-0.3, z=1.2, moves +x with v0=0.2, a=0.8 (lam scaled), y = +0.05
    xa = (-0.3 + 0.2 * t + 0.5 * 0.8 * t ** 2) * lam
    PA = np.c_[xa, np.full(N, 0.05 * lam), np.full(N, 1.2 * lam)]
    rA = 0.0335 * lam
    out['A'] = (PA, rA)
    # B: static box centre at (0.35, -0.12, 1.6) lam, width 0.30 lam along x (fronto-parallel)
    PB = np.tile([0.35 * lam, -0.12 * lam, 1.6 * lam], (N, 1))
    out['B'] = (PB, 0.15 * lam)
    truth = {'A_v_1.0': (0.2 + 0.8 * 1.0) * lam, 'A_a': 0.8 * lam, 'B_w': 0.30 * lam,
             'AB_dist_1.0': float(np.linalg.norm(PA[24] - PB[24]))}
    depth = []
    for tt in (0.0, 1.0, 2.0):  # Euclidean ranges at three times for A, constant for B
        i = int(round(tt * FPS))
        depth.append(dict(object='ball', distance_m=float(np.linalg.norm(PA[i])), time=tt))
    depth.append(dict(object='box', distance_m=float(np.linalg.norm(PB[0])), time=None))
    return f, out, truth, depth


def obs_for(P, r, f, W, H, s, frames, kind):
    """Obs dicts (seen-frame coords) of a sphere/segment of half-size r at centres P."""
    obs = []
    for i in frames:
        c = project(P[i], f, W, H)[0]
        ex = project(P[i] + [r, 0, 0], f, W, H)[0] - project(P[i] - [r, 0, 0], f, W, H)[0]
        half = abs(ex[0]) / 2
        e0, e1 = c - [half, 0], c + [half, 0]
        o = {'frame': int(i), 'point': list(c * s)}
        if kind == 'size':
            o['extent'] = [list(e0 * s), list(e1 * s)]
            o['box'] = [*(c - half) * s, *(c + half) * s]
        obs.append(o)
    return obs


def build(W, H, max_side, lam=1.0, prior='size', fov=83.1, lab=True):
    s, sw, sh = seen_scale(W, H, max_side)
    s_eff = s  # the code maps back with 1 / meta scale
    f, objs, truth, depth = scene_3d(lam, W, H, fov)
    frames = sorted(set(np.linspace(0, N - 1, 16).round().astype(int)) | {24})
    PA, rA = objs['A']; PB, rB = objs['B']
    # the annotator reports coordinates in the seen frame: orig * (sw / W) for x, (sh / H) for y
    sx, sy = sw / W, sh / H
    def to_seen(obs):
        for o in obs:
            o['point'] = [o['point'][0] / s_eff * sx, o['point'][1] / s_eff * sy]
            if 'extent' in o:
                o['extent'] = [[p[0] / s_eff * sx, p[1] / s_eff * sy] for p in o['extent']]
                b = o['box']; o['box'] = [b[0] / s_eff * sx, b[1] / s_eff * sy, b[2] / s_eff * sx, b[3] / s_eff * sy]
        return obs
    tA_size = to_seen(obs_for(PA, rA, f, W, H, s_eff, frames, 'size'))
    tA_pt = to_seen(obs_for(PA, rA, f, W, H, s_eff, frames, 'point'))
    tB = to_seen(obs_for(PB, rB, f, W, H, s_eff, frames, 'size'))
    depth_txt = '\n'.join((f"t={d['time']}s, " if d['time'] is not None else '') +
                          f"distance_{d['object']}_camera = {d['distance_m']:.6f}m" for d in depth)
    if prior == 'size':
        ptxt, pq = f"diameter of the ball = {2 * rA * 100:.6f}cm", dict(kind='size', objects=['ball'], dimension='diameter')
        ptrack = tA_size
    else:
        ptxt, pq = f"velocity of the ball at 1.0s = {truth['A_v_1.0']:.6f}m/s", dict(kind='speed', objects=['ball'], time=1.0)
        ptrack = tA_pt
    qs = []
    targets = [(1, dict(kind='size', objects=['box'], dimension='width'), 'cm', truth['B_w'] * 100, [('target', 'box', tB)]),
               (2, dict(kind='speed', objects=['ball'], time=1.0), 'm/s', truth['A_v_1.0'], [('target', 'ball', tA_pt)]),
               (3, dict(kind='acceleration', objects=['ball']), 'm/s^2', truth['A_a'], [('target', 'ball', tA_pt)]),
               (4, dict(kind='distance', objects=['ball', 'box'], time=1.0), 'm', truth['AB_dist_1.0'],
                [('target', 'ball', tA_pt), ('target2', 'box', tB)])]
    meta_q, parsed_q, truths = [], [], {}
    for qid, tq, unit, tv, ttracks in targets:
        tracks = [dict(role='prior', object='ball', obs=ptrack)] + [dict(role=r, object=o, obs=ob) for r, o, ob in ttracks]
        parsed_q.append(dict(qid=qid, spec=dict(target=tq, prior=pq, depth=[]), tracks=tracks, direct_answer=1.0))
        meta_q.append(dict(qid=qid, target_unit=unit, prior=ptxt, depth_info=depth_txt))
        truths[qid] = tv
    meta = dict(video_id='syn', fps=FPS, fps_from_container=False, video_type='D3MS' if prior != 'size' else 'S3MS',
                n_frames_total=N, scale=s, image_size=[round(sw / s), round(sh / s)], frames=frames,
                questions=meta_q, prompt_version='v1')
    return dict(questions=parsed_q), meta, truths


def answers(parsed, meta, lab=True):
    anns = ca.to_annotations(parsed, meta)
    out = {}
    for qid, a in anns.items():
        kw = {'camera_fov_deg': ca.LAB_FOV_DEG} if lab else {}
        ans = geo.solve(a.spec, a.tracks, tuple(meta['image_size']), meta['fps'], seen_scale=meta['scale'], **kw)
        out[qid] = (ans.value, ans.debug.get('f_px'), ans.flags)
    return out


def main():
    ok = True
    print('R: resolution invariance (same scene, annotator at full res vs 854 px)')
    for W, H in ((1280, 720), (1920, 1080), (3840, 2160), (1080, 1920), (2560, 1440)):
        for prior in ('size', 'speed'):
            for lab in (True, False):
                full = answers(*build(W, H, 100000, prior=prior)[:2], lab=lab)
                p854, m854, truth = build(W, H, 854, prior=prior)
                small = answers(p854, m854, lab=lab)
                devs = {q: small[q][0] / full[q][0] - 1 for q in full if full[q][0] and small[q][0]}
                err = {q: full[q][0] / truth[q] - 1 for q in full if full[q][0]}
                mx = max(abs(v) for v in devs.values())
                ok &= mx < 5e-3
                print(f'  {W}x{H} prior={prior:5s} cam={"lab" if lab else "free"}: max |854/full - 1| = {mx:.2e}; '
                      f'full-res error vs truth ' + ' '.join(f'q{q}:{e:+.3f}' for q, e in err.items()))
    print('D: dimensional invariance (all lengths x lambda)')
    for lam in (0.01, 10.0):
        for prior in ('size', 'speed'):
            a1 = answers(*build(1920, 1080, 854, 1.0, prior)[:2], lab=False)
            p, m, _ = build(1920, 1080, 854, lam, prior)
            a2 = answers(p, m, lab=False)
            r = {q: a2[q][0] / (a1[q][0] * lam) - 1 for q in a1 if a1[q][0] and a2[q][0]}
            mx = max(abs(v) for v in r.values())
            ok &= mx < 1e-3
            print(f'  lambda={lam:g} prior={prior}: max |ans(lam)/(lam ans) - 1| = {mx:.2e}')
    print('PASS' if ok else 'FAIL')


if __name__ == '__main__':
    main()
