"""Harness for the invariants audit: cached Claude records -> annotations -> qp.geometry answers,
with switchable (a) lab time base (video n/24 vs capture time round_half_up(25 n/24)/25),
(b) depth convention (range r vs optical-axis Z), (c) fixed lab focal length.
Nothing in the repo is modified: module constants are patched in-process only."""
from __future__ import annotations

import contextlib
import copy
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path('/home/user/quantiphy-challenge')
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'scripts'))

from qp import claude_annotate as ca  # noqa: E402
from qp import geometry as geo  # noqa: E402
from qp.data import load_split  # noqa: E402
import run_claude as rc  # noqa: E402

LAB_F_1280 = 722.0   # px at 1280 px width (research: f ~722 px)


def load(split: str, rec_dir: str | Path):
    df = load_split(split)
    records = rc.load_records(Path(rec_dir))
    records = {k: v for k, v in records.items() if v.get('status') in rc.USABLE}
    records = rc.prepare_records(df, records)
    anns = ca.load_annotations(records)
    return df, records, anns


def capture_time(frame: np.ndarray | float, fps_video: float = 24.0, fps_cap: float = 25.0):
    """Capture time of a video frame produced by ffmpeg's fps filter (round half up)."""
    n = np.asarray(frame, float)
    return np.floor(n * fps_cap / fps_video + 0.5) / fps_cap


def video_to_capture(t: float, fps_video: float = 24.0) -> float:
    """A query time stated on the video clock (n/24) mapped to the capture clock (interpolated)."""
    if t is None or not math.isfinite(t):
        return t
    n = t * fps_video
    lo = math.floor(n)
    a, b = capture_time(lo), capture_time(lo + 1)
    return float(a + (b - a) * (n - lo))


def remap_times(anns: dict, df: pd.DataFrame, records: dict, query: str = 'keep', sources=('lab',)) -> dict:
    """Copy of anns with Obs.t of videos from `sources` (24 fps) mapped to capture time.
    query: 'keep' (question / prior times are capture times) or 'map' (they are video times n/24)."""
    out = copy.deepcopy(anns)
    src = dict(zip(df.qid.astype(int), df.video_source))
    vid = dict(zip(df.qid.astype(int), df.video_id))
    for qid, a in out.items():
        if src.get(qid) not in sources:
            continue
        fps = float(records[vid[qid]]['meta']['fps'])
        if abs(fps - 24) > 1e-6:
            continue
        for tr in a.tracks:
            for o in tr.obs:
                o.t = float(capture_time(round(o.t * fps)))
        if query == 'map':
            for q in (a.spec.target, a.spec.prior):
                if q.time is not None:
                    q.time = video_to_capture(q.time)
                if q.window:
                    q.window = [video_to_capture(x) for x in q.window]
    return out


@contextlib.contextmanager
def patched(depth_is_range: bool | None = None, fixed_f: float | None = None):
    """Temporarily set geo.DEPTH_IS_RANGE and/or force the solved focal length."""
    old_r, old_map, old_solve = geo.DEPTH_IS_RANGE, geo._map_f, geo._solve_f
    try:
        if depth_is_range is not None:
            geo.DEPTH_IS_RANGE = depth_is_range
        if fixed_f is not None:
            geo._map_f = lambda fn, value, width, f_cam: fixed_f
            geo._solve_f = lambda fn, value, width, f_def: fixed_f
        yield
    finally:
        geo.DEPTH_IS_RANGE, geo._map_f, geo._solve_f = old_r, old_map, old_solve


def lab_f(image_size) -> float:
    return LAB_F_1280 * float(image_size[0]) / 1280.0


def solve_one(a, rec, source: str, fixed_lab_f: bool = False, depth_is_range: bool = True,
              camera_fov: bool = True):
    """geo.solve with the run_claude settings (lab 3D: camera prior) or with the lab f fixed."""
    meta = rec['meta']
    size, fps = tuple(meta['image_size']), float(meta['fps'])
    kw = {}
    if source in ('lab',) and a.spec.is_3d and camera_fov:
        kw['camera_fov_deg'] = ca.LAB_FOV_DEG
    ff = lab_f(size) if (fixed_lab_f and source == 'lab' and a.spec.is_3d) else None
    with patched(depth_is_range=depth_is_range, fixed_f=ff):
        return geo.solve(a.spec, a.tracks, size, fps, seen_scale=float(meta.get('scale') or 1.0), **kw)


def solve_all(df, records, anns, **kw) -> pd.DataFrame:
    rows = []
    for r in df.itertuples():
        a = anns.get(int(r.qid))
        if a is None:
            continue
        ans = solve_one(a, records[r.video_id], r.video_source, **kw)
        d = ans.debug
        rows.append(dict(qid=int(r.qid), video_id=r.video_id, src=r.video_source, cat=r.category,
                         geo=ans.value, method=ans.method, flags=';'.join(ans.flags),
                         prior_meas=d.get('prior_measured_si'), prior_si=a.spec.prior.value_si,
                         prior_kind=a.spec.prior.kind, target_kind=a.spec.target.kind,
                         f_px=d.get('f_px'), direct=a.direct_answer))
    return pd.DataFrame(rows)
