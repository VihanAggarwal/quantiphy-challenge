import numpy as np, pandas as pd, inv, sys
from qp.mra import item_scores
from depthconv import offaxis
W = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/invariants/work/'
runs = {'val_hr_v1_high': ('val_hires', '/home/user/quantiphy-challenge/runs/val_hr_v1_high/val_hires/records'),
        'val_hr_v2_high': ('val_hires', '/home/user/quantiphy-challenge/runs/val_hr_v2_high/val_hires/records'),
        'val_opus_high': ('val', '/home/user/quantiphy-challenge/runs/val_opus_high/val/records'),
        'val_opus_med': ('val', '/home/user/quantiphy-challenge/runs/val_opus_med/val/records'),
        'val_opus_med2': ('val', '/home/user/quantiphy-challenge/runs/val_opus_med2/val/records')}
allr = []
for name, (split, d) in runs.items():
    df, rec, anns = inv.load(split, d)
    d3 = df[(df.video_type.str[1] == '3') & (df.video_source != 'lab')]
    for conv, is_r in (('r', True), ('Z', False)):
        res = inv.solve_all(d3, rec, anns, depth_is_range=is_r)
        res['conv'] = conv; res['run'] = name
        m = res.merge(df[['qid', 'answer']], on='qid')
        allr.append(m)
        sc = np.nan_to_num(item_scores(m.geo, m.answer))
        print(f'{name:15s} conv {conv}: n={len(m)} 3D non-lab geo MRA {sc.mean():.3f}; f-from-prior rows {(m.method=="3d_focal_from_prior").sum()}')
A = pd.concat(allr)
A.to_pickle(W + 'depthconv_sim_val.pkl')
w = A.pivot_table(index=['run', 'qid'], columns='conv', values='geo').reset_index().merge(A[A.conv=='r'][['run','qid','answer','video_id','method']], on=['run','qid'])
w['lr_r'] = np.log(w.answer / w.r); w['lr_Z'] = np.log(w.answer / w.Z)
print('per video (all runs pooled): median |log err| r vs Z, and mean item score')
for v, g in w.groupby('video_id'):
    print(f'  {v:28s} n={len(g):3d} |lr| r {g.lr_r.abs().median():.3f} Z {g.lr_Z.abs().median():.3f}  MRA r {np.nan_to_num(item_scores(g.r, g.answer)).mean():.3f} Z {np.nan_to_num(item_scores(g.Z, g.answer)).mean():.3f}  max|Z/r-1| {np.nanmax(np.abs(g.Z/g.r-1)):.3f}')
