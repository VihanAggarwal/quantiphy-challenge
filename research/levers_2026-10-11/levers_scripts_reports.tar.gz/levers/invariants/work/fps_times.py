import sys, re
import numpy as np, pandas as pd
sys.path.insert(0, '/home/user/quantiphy-challenge')
from qp.data import load_split
from qp.claude_annotate import mentioned_times
W = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/invariants/work/'
r = pd.read_csv(W + 'pts_scan.csv')
df = load_split('test')
rows = []
for v in r.itertuples():
    q = df[df.video_id == v.video_id]
    texts = list(q.question) + list(q.prior) + list(q.depth_info)
    ts = mentioned_times(texts)
    tq = mentioned_times(list(q.question))
    rows.append(dict(video_id=v.video_id, src=v.src, fps_ds=v.fps_ds, fps_c=v.fps_pts, n=v.n,
                     dur_ds=(v.n - 1) / v.fps_ds, dur_c=(v.n - 1) / v.fps_pts, tmax=max(ts) if ts else np.nan,
                     tq=max(tq) if tq else np.nan, nq=len(q), cats=''.join(sorted(set(q.category))),
                     inf=''.join(sorted(set(q.inference_type)))))
t = pd.DataFrame(rows)
t['mismatch'] = abs(t.fps_ds - t.fps_c) > 0.05
t['beyond_ds'] = t.tmax > t.dur_ds + 0.05
t['beyond_c'] = t.tmax > t.dur_c + 0.05
print(t.groupby(['mismatch', 'src']).agg(n=('video_id', 'size'), beyond_ds=('beyond_ds', 'sum'), beyond_c=('beyond_c', 'sum'), nq=('nq', 'sum')))
pd.set_option('display.width', 250)
print(t[t.mismatch].sort_values('src').to_string())
t.to_csv(W + 'fps_times.csv', index=False)
