import sys; sys.path.insert(0, "/home/user/quantiphy-challenge")
import numpy as np, pandas as pd, inv
from qp.mra import item_scores
out = {}
for split, d in (('test', '/home/user/quantiphy-challenge/runs/test_v1_high_854/test/records'),
                 ('val_hires', '/home/user/quantiphy-challenge/runs/val_hr_v1_high/val_hires/records'),
                 ('val', '/home/user/quantiphy-challenge/runs/val_opus_high/val/records')):
    df, rec, anns = inv.load(split, d)
    lab = df[(df.video_source == 'lab')]
    rv = inv.solve_all(lab, rec, anns)
    rc_ = inv.solve_all(lab, rec, inv.remap_times(anns, df, rec))
    m = rv.merge(rc_[['qid', 'geo']], on='qid', suffixes=('_v', '_c'))
    if 'answer' in df.columns:
        m = m.merge(df[['qid', 'answer']], on='qid')
        for col in ('geo_v', 'geo_c'):
            sc = np.nan_to_num(item_scores(m[col], m.answer))
            mot = m.target_kind.isin(['speed', 'acceleration', 'displacement', 'path_length']).to_numpy()
            print(f'{split:9s} {col}: lab geo MRA all {sc.mean():.3f} static {sc[~mot].mean():.3f} (n={(~mot).sum()}) motion {sc[mot].mean():.3f} (n={mot.sum()})')
    m['ch'] = np.abs(m.geo_c / m.geo_v - 1)
    m.to_pickle(f'clock_effect_{split}.pkl')
    print(split, 'changed >1%:', (m.ch > 0.01).sum(), 'of', len(m), '; static changed >1%:',
          ((m.ch > 0.01) & ~m.target_kind.isin(['speed', 'acceleration', 'displacement', 'path_length'])).sum())
S = pd.read_pickle('sub_vs_run.pkl')
m = pd.read_pickle('clock_effect_test.pkl').merge(S[['qid', 'is_geo', 'parsed_value']], on='qid')
g = m[m.is_geo]
print('submission rows taken from geometry (lab):', len(g), 'changed >1%:', (g.ch > 0.01).sum(), 'median change', g.ch.median(), 'max', g.ch.max())
print(g[g.ch > 0.01].groupby('cat').ch.describe())
