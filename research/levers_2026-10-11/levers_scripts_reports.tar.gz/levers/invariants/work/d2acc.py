import sys; sys.path.insert(0, "/home/user/quantiphy-challenge")
import numpy as np, pandas as pd, inv
from qp.mra import item_scores
runs = {'val_hr_v1_high': ('val_hires', '/home/user/quantiphy-challenge/runs/val_hr_v1_high/val_hires/records'),
        'val_hr_v2_high': ('val_hires', '/home/user/quantiphy-challenge/runs/val_hr_v2_high/val_hires/records'),
        'val_opus_high': ('val', '/home/user/quantiphy-challenge/runs/val_opus_high/val/records'),
        'val_opus_med2': ('val', '/home/user/quantiphy-challenge/runs/val_opus_med2/val/records')}
rows = []
for name, (split, d) in runs.items():
    df, rec, anns = inv.load(split, d)
    d2 = df[(df.video_type.str[1] == '2')]
    r = inv.solve_all(d2, rec, anns).merge(df[['qid', 'answer', 'prior', 'inference_type']], on='qid')
    r['run'] = name
    rows.append(r)
R = pd.concat(rows)
R['lr'] = np.log(R.answer / R.geo)
R['static'] = ~R.target_kind.isin(['speed', 'acceleration', 'displacement', 'path_length'])
R = R.reset_index(drop=True)
R.to_pickle('d2acc.pkl')
g = R.groupby(['video_id', 'prior_kind', 'static']).agg(prior=('prior', 'first'), n=('qid', 'size'), med_gt_over_geo=('lr', lambda s: float(np.exp(np.nanmedian(s))))).reset_index()
pd.set_option('display.width', 200); pd.set_option('display.max_colwidth', 60)
print(g[g.prior_kind != 'size'].round(3).to_string())
print('median gt/geo on static targets by prior kind (all runs pooled):')
print(R[R.static].groupby('prior_kind').lr.agg(['size', lambda s: float(np.exp(np.nanmedian(s)))]))
