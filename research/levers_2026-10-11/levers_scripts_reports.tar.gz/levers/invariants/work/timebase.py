"""(b) Lab time base: video time n/24 vs capture time round_half_up(25n/24)/25.
1. label-free: residuals of smooth fits to Claude's lab motion tracks (pixel points), both clocks.
2. stated lab motion priors measured at fixed f (722 px @1280) + depth_info, both clocks (test + val).
3. validation lab geometry answers vs GT, both clocks."""
import sys
import numpy as np
import pandas as pd
import inv
from qp import geometry as geo
from qp.mra import item_scores

W = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/invariants/work/'
RUNS = {'test': '/home/user/quantiphy-challenge/runs/test_v1_high_854/test/records',
        'val_hires': '/home/user/quantiphy-challenge/runs/val_hr_v1_high/val_hires/records'}


def track_resid(anns, df, records):
    """Per lab motion track (>= 9 obs with points): rms residual of a cubic in t, video vs capture clock."""
    src = dict(zip(df.qid.astype(int), df.video_source))
    vid = dict(zip(df.qid.astype(int), df.video_id))
    seen, rows = set(), []
    for qid, a in anns.items():
        if src.get(qid) != 'lab':
            continue
        for tr in a.tracks:
            pts = [(o.t, o.point) for o in tr.obs if o.point is not None]
            if len(pts) < 9:
                continue
            key = (vid[qid], tr.object, len(pts), round(pts[0][1][0], 1))
            if key in seen:
                continue
            seen.add(key)
            t = np.array([p[0] for p in pts]); P = np.array([p[1] for p in pts])
            if np.ptp(P, axis=0).max() < 40:
                continue
            n = np.round(t * 24)
            tc = inv.capture_time(n)
            out = dict(video=vid[qid], obj=tr.object, n=len(t), span=float(np.ptp(P, axis=0).max()))
            for name, tt in (('video', t), ('capture', tc)):
                for deg in (2, 3):
                    c = np.polyfit(tt, P, deg)
                    r = P - np.vander(tt, deg + 1) @ c
                    out[f'rms{deg}_{name}'] = float(np.sqrt((r ** 2).sum(1).mean()))
            rows.append(out)
    return pd.DataFrame(rows)


def prior_check(split):
    df, rec, anns = inv.load(split, RUNS[split])
    lab_q = set(df.qid[(df.video_source == 'lab') & (df.video_type.str[1] == '3')].astype(int))
    anns = {q: a for q, a in anns.items() if q in lab_q}
    tr = track_resid(anns, df, rec)
    out = {}
    for clock, A in (('video', anns), ('capture', inv.remap_times(anns, df, rec, query='keep')),
                     ('capture_qmap', inv.remap_times(anns, df, rec, query='map'))):
        out[clock] = inv.solve_all(df[df.qid.isin(lab_q)], rec, A, fixed_lab_f=True)
    return df, tr, out


if __name__ == '__main__':
    for split in ('test', 'val_hires'):
        df, tr, out = prior_check(split)
        print(f'===== {split}: {len(tr)} lab motion tracks (>=9 pts, >=40 px travel)')
        if len(tr):
            for deg in (2, 3):
                v, c = tr[f'rms{deg}_video'], tr[f'rms{deg}_capture']
                print(f'  deg {deg}: median rms video {v.median():.2f} px, capture {c.median():.2f} px; '
                      f'capture lower in {(c < v).mean():.0%} of tracks; median ratio {np.median(c / v):.3f}')
        tr.to_csv(W + f'track_resid_{split}.csv', index=False)
        # one row per video (one distinct prior per video): stated / measured at fixed f
        rows = []
        for clock, r in out.items():
            r = r.copy(); r['clock'] = clock
            rows.append(r)
        R = pd.concat(rows)
        R.to_pickle(W + f'timebase_{split}.pkl')
        P = R[R.prior_kind.isin(['speed', 'acceleration'])].dropna(subset=['prior_meas'])
        P = P.groupby(['clock', 'video_id']).agg(kind=('prior_kind', 'first'), stated=('prior_si', 'first'),
                                                  meas=('prior_meas', 'median')).reset_index()
        P['lr'] = np.log(P.stated / P.meas)
        for kind in ('speed', 'acceleration'):
            for clock in out:
                x = P[(P.kind == kind) & (P.clock == clock)]
                if len(x):
                    sc = item_scores(x.meas, x.stated)
                    print(f'  prior {kind:12s} {clock:13s} n={len(x):3d} median stated/meas {np.exp(x.lr.median()):.3f} '
                          f'rms log {np.sqrt((x.lr ** 2).mean()):.3f} median|log| {x.lr.abs().median():.3f} MRA(meas vs stated) {np.nanmean(sc):.3f}')
        if 'answer' in df.columns:
            lab = df[(df.video_source == 'lab')][['qid', 'answer', 'category', 'question']]
            for clock, r in out.items():
                m = lab.merge(r, on='qid')
                m = m[m.target_kind.isin(['speed', 'acceleration', 'displacement', 'path_length'])]
                sc = item_scores(m.geo, m.answer)
                print(f'  val lab motion targets {clock:13s} n={len(m)} geo MRA {np.nanmean(np.nan_to_num(sc)):.3f}')
                m = lab.merge(r, on='qid')
                sc = item_scores(m.geo, m.answer)
                print(f'  val lab all targets    {clock:13s} n={len(m)} geo MRA {np.nanmean(np.nan_to_num(sc)):.3f}')
