"""Audit parsed prior specs against the prior text: time stated in text vs spec time/window, kind, axis."""
import re, numpy as np, pandas as pd, inv
from qp import claude_annotate as ca
W = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/invariants/work/'
TIME_RE = re.compile(r'(?:\bt\s*=\s*(\d+(?:\.\d+)?)\s*s?\b|\bat\s+(?:t\s*=\s*)?(\d+(?:\.\d+)?)\s*s(?:ec(?:ond)?s?)?\b|\bat\s+time\s+(\d+(?:\.\d+)?))', re.I)
for split, d in (('test', '/home/user/quantiphy-challenge/runs/test_v1_high_854/test/records'),
                 ('val_hires', '/home/user/quantiphy-challenge/runs/val_hr_v1_high/val_hires/records')):
    df, rec, anns = inv.load(split, d)
    rows = []
    for r in df.itertuples():
        a = anns.get(int(r.qid))
        if a is None: continue
        p = a.spec.prior
        m = TIME_RE.search(r.prior)
        tt = float(next(g for g in m.groups() if g)) if m else None
        span = ca.prior_time_span(r.prior, 10.0)
        rows.append(dict(qid=r.qid, vid=r.video_id, cat=r.category, src=r.video_source, prior=r.prior, kind=p.kind,
                         time=p.time, window=p.window, axis=p.axis, text_time=tt, span=span is not None,
                         grav=bool(re.search('grav', r.prior, re.I))))
    P = pd.DataFrame(rows)
    mot = P[P.kind.isin(['speed', 'acceleration'])]
    print(f'== {split}: {len(P)} questions, motion priors {len(mot)}')
    t = mot[mot.text_time.notna() & ~mot.span]
    bad = t[(t.time.isna()) | (np.abs(t.time.fillna(-99) - t.text_time) > 1e-6)]
    print(f'  priors stating a time: {len(t)} questions; spec time missing or different: {len(bad)}')
    print(bad[['qid', 'vid', 'prior', 'kind', 'time', 'window']].drop_duplicates('vid').head(20).to_string())
    u = mot[mot.text_time.isna() & ~mot.span & mot.time.notna() & ~mot.grav]
    print(f'  priors WITHOUT a stated time but spec has a time: {len(u)} questions')
    print(u[['qid', 'vid', 'prior', 'kind', 'time', 'window']].drop_duplicates('vid').head(25).to_string())
    g = mot[mot.grav]
    print(f'  gravity priors: {len(g)}; axis counts {g.axis.value_counts().to_dict()}; with time {g.time.notna().sum()}, window {g.window.notna().sum()}')
    w = mot[mot.span]
    print(f'  before/after/from-to priors: {len(w)} questions, {w.vid.nunique()} videos')
    print(w[['vid', 'prior', 'kind', 'time', 'window']].drop_duplicates('vid').head(30).to_string())
    P.to_pickle(W + f'priorspec_{split}.pkl')
