"""(c) depth_info convention: Euclidean range r vs optical-axis depth Z.
Lab (fixed camera f=722 px @1280): stated priors measured at fixed f under both conventions, vs the
off-axis factor |ray| = sqrt(1 + ((u-cx)^2 + (v-cy)^2) / f^2) at the prior object's track.
If r is right, log(stated / meas_Z) = -log|ray| (slope -1) and log(stated / meas_r) has slope 0.
If Z is right, log(stated / meas_r) = +log|ray| (slope +1) and log(stated / meas_Z) slope 0."""
import numpy as np
import pandas as pd
import inv
from qp import geometry as geo
from qp.mra import item_scores

W = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/invariants/work/'
RUNS = {'test': '/home/user/quantiphy-challenge/runs/test_v1_high_854/test/records',
        'val_hires': '/home/user/quantiphy-challenge/runs/val_hr_v1_high/val_hires/records'}


def offaxis(a, size, role='prior', f=None):
    """Median |ray| of the role's track points / extent midpoints / box centres."""
    W_, H_ = size
    c = np.array([W_ / 2, H_ / 2])
    f = f or inv.lab_f(size)
    pts = []
    for tr in a.tracks:
        if tr.role != role:
            continue
        for o in tr.obs:
            if o.extent is not None:
                pts.append((np.array(o.extent[0]) + np.array(o.extent[1])) / 2)
            elif o.point is not None:
                pts.append(np.array(o.point))
            elif o.box is not None:
                pts.append(np.array([(o.box[0] + o.box[2]) / 2, (o.box[1] + o.box[3]) / 2]))
    if not pts:
        return np.nan
    P = np.array(pts)
    return float(np.median(np.sqrt(1 + ((P - c) ** 2).sum(1) / f ** 2)))


def run(split):
    df, rec, anns = inv.load(split, RUNS[split])
    lab3 = df[(df.video_source == 'lab') & (df.video_type.str[1] == '3')]
    rows = []
    for conv, is_r in (('r', True), ('Z', False)):
        res = inv.solve_all(lab3, rec, anns, fixed_lab_f=True, depth_is_range=is_r)
        res['conv'] = conv
        rows.append(res)
    R = pd.concat(rows)
    vid = dict(zip(df.qid.astype(int), df.video_id))
    R['ray_prior'] = [offaxis(anns[q], rec[vid[q]]['meta']['image_size']) for q in R.qid]
    R['ray_target'] = [offaxis(anns[q], rec[vid[q]]['meta']['image_size'], 'target') for q in R.qid]
    R.to_pickle(W + f'depthconv_{split}.pkl')
    return df, R


def slope(x, y):
    ok = np.isfinite(x) & np.isfinite(y)
    x, y = x[ok], y[ok]
    if len(x) < 3:
        return np.nan, np.nan, len(x)
    A = np.c_[np.ones(len(x)), x]
    coef, res, *_ = np.linalg.lstsq(A, y, rcond=None)
    s2 = ((y - A @ coef) ** 2).sum() / max(len(x) - 2, 1)
    se = np.sqrt(s2 * np.linalg.inv(A.T @ A)[1, 1])
    return coef[1], se, len(x)


if __name__ == '__main__':
    for split in ('test', 'val_hires'):
        df, R = run(split)
        print(f'===== {split}')
        for kinds, label in ((['size'], 'size priors'), (['speed', 'acceleration'], 'motion priors')):
            P = R[R.prior_kind.isin(kinds)].dropna(subset=['prior_meas'])
            P = P.groupby(['conv', 'video_id']).agg(stated=('prior_si', 'first'), meas=('prior_meas', 'median'),
                                                    ray=('ray_prior', 'median'), fl=('flags', 'first')).reset_index()
            P = P[~P.fl.str.contains('prior_depth_assumed')]
            P['lr'] = np.log(P.stated / P.meas)
            for conv in ('r', 'Z'):
                x = P[P.conv == conv]
                b, se, n = slope(np.log(x.ray.to_numpy()), x.lr.to_numpy())
                sc = np.nanmean(item_scores(x.meas, x.stated))
                print(f'  {label:14s} conv {conv}: n={n:3d} median stated/meas {np.exp(x.lr.median()):.3f} '
                      f'rms log {np.sqrt((x.lr ** 2).mean()):.3f} slope vs log|ray| {b:+.2f} +- {se:.2f} '
                      f'MRA {sc:.3f}  (|ray| median {x.ray.median():.3f}, max {x.ray.max():.3f})')
        if 'answer' in df.columns:
            lab = df[['qid', 'answer']]
            for conv in ('r', 'Z'):
                m = lab.merge(R[R.conv == conv], on='qid')
                for kinds, label in ((['size', 'distance', 'other'], 'static'), (['speed', 'acceleration', 'displacement', 'path_length'], 'motion')):
                    mm = m[m.target_kind.isin(kinds)]
                    sc = np.nan_to_num(item_scores(mm.geo, mm.answer))
                    lr = np.log(mm.answer / mm.geo)
                    print(f'  val lab {label} targets conv {conv}: n={len(mm)} geo MRA {sc.mean():.3f} median gt/geo {np.exp(np.nanmedian(lr)):.3f}')
