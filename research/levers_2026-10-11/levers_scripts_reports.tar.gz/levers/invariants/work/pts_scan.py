"""For every test video: dataset fps vs container fps; PTS uniformity (VFR check); frame count."""
import subprocess, json, sys, collections
import numpy as np, pandas as pd
sys.path.insert(0, '/home/user/quantiphy-challenge')
from qp.data import load_split
from concurrent.futures import ThreadPoolExecutor
df = load_split('test')
vids = df.drop_duplicates('video_id')[['video_id', 'video_path', 'fps', 'video_source', 'video_type']]
def probe(row):
    p = row.video_path
    try:
        out = subprocess.run(['ffprobe', '-v', 'error', '-select_streams', 'v:0', '-show_entries',
                              'packet=pts_time', '-of', 'csv=p=0', p], capture_output=True, text=True, timeout=120).stdout
        pts = np.sort(np.array([float(x) for x in out.split() if x and x != 'N/A']))
        st = json.loads(subprocess.run(['ffprobe', '-v', 'error', '-select_streams', 'v:0', '-show_entries',
                              'stream=r_frame_rate,avg_frame_rate,nb_frames', '-of', 'json', p], capture_output=True, text=True).stdout)['streams'][0]
        d = np.diff(pts)
        med = float(np.median(d)) if len(d) else float('nan')
        return dict(video_id=row.video_id, src=row.video_source, vt=row.video_type, fps_ds=row.fps,
                    r=st.get('r_frame_rate'), avg=st.get('avg_frame_rate'), n=len(pts),
                    fps_pts=1/med if med > 0 else float('nan'),
                    dmax_rel=float(d.max()/med) if len(d) else float('nan'), dmin_rel=float(d.min()/med) if len(d) else float('nan'),
                    max_dev_s=float(np.max(np.abs(pts - pts[0] - np.arange(len(pts)) / row.fps))) if len(pts) else float('nan'))
    except Exception as e:
        return dict(video_id=row.video_id, err=str(e))
with ThreadPoolExecutor(4) as ex:
    res = list(ex.map(probe, vids.itertuples()))
r = pd.DataFrame(res)
r.to_csv('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/invariants/work/pts_scan.csv', index=False)
print(len(r))
r['fps_match'] = (abs(r.fps_pts - r.fps_ds) < 0.05)
print(r.groupby('src').agg(n=('video_id', 'size'), fps_match=('fps_match', 'mean'), maxdev=('max_dev_s', 'max'), dmax=('dmax_rel', 'max'), dmin=('dmin_rel', 'min')))
print(r[~r.fps_match | (r.max_dev_s > 0.01)].to_string())
