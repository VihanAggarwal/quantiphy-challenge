"""Patched depth handling for qp.geometry (in-process monkeypatch, repo untouched).

Problem: geometry linearly interpolates the Euclidean RANGE r between depth_info times and divides by
|ray(u,v)| per point. For any object that moves sideways, r(t) is not linear in t even when the
optical-axis depth Z(t) is (constant-Z sideways motion: r = Z |ray(t)|), so positions between and beyond
the knots are distorted and speeds / accelerations are biased (noise-free synthetic: +11% speed, +24%
acceleration).
Fix ("zinterp"): convert each timed depth entry to optical-axis depth Z_k = r_k / |ray(track at t_k)|
using the object's own track (interpolated in time), then interpolate / extrapolate Z linearly.
Untimed entries keep the current per-point conversion (static objects). Only objects with >= 2 timed
entries and a track change."""
from __future__ import annotations

import contextlib
import math

import numpy as np

from qp import geometry as geo

_orig_solve_3d = geo._solve_3d
_orig_depth = geo._View._depth


class ZFn:
    """Optical-axis depth vs time (piecewise linear, linear extrapolation), flagged is_Z."""
    is_Z = True

    def __init__(self, base, ts, zs):
        self.names, self.values, self.pairs = base.names, base.values, base.pairs
        self.ts, self.zs = np.asarray(ts, float), np.asarray(zs, float)

    def __call__(self, t):
        t = np.atleast_1d(np.asarray(t, float))
        ts, zs = self.ts, self.zs
        out = np.interp(t, ts, zs)
        s0, s1 = (zs[1] - zs[0]) / (ts[1] - ts[0]), (zs[-1] - zs[-2]) / (ts[-1] - ts[-2])
        out = np.where(t < ts[0], zs[0] + s0 * (t - ts[0]), out)
        out = np.where(t > ts[-1], zs[-1] + s1 * (t - ts[-1]), out)
        return np.maximum(out, 0.2 * zs.min())


def _depth_patched(self, t, uv):
    ray, n = self._ray_norm(uv)
    if getattr(self.rng, 'is_Z', False):
        return ray, self.rng(t)
    return ray, self.rng(t) / (n if geo.DEPTH_IS_RANGE else 1.0)


def _to_z(fn, obj, c, f):
    """DepthFn with >= 2 timed knots + a track -> ZFn; else fn unchanged."""
    if fn is None or obj is None or not getattr(fn, 'pairs', None) or getattr(fn, 'is_Z', False):
        return fn
    if not isinstance(fn, geo.DepthFn) or len(fn._parts) != 1:
        return fn
    timed = {}
    for tt, d in fn.pairs:
        if tt is not None:
            timed.setdefault(tt, []).append(d)
    if len(timed) < 2:
        return fn
    t, uv = obj.points()
    if len(t) < 2:
        return fn
    ts = np.array(sorted(timed))
    rs = np.array([np.mean(timed[x]) for x in ts])
    u = np.interp(ts, t, uv[:, 0]); v = np.interp(ts, t, uv[:, 1])
    nrm = np.sqrt(1 + ((u - c[0]) ** 2 + (v - c[1]) ** 2) / f ** 2)
    return ZFn(fn, ts, rs / nrm)


def make_solve_3d():
    """_solve_3d wrapper: depth functions of timed objects become Z functions. The focal length is not
    known when depth() runs, so the conversion happens inside _View via a lazy wrapper keyed on f."""
    def _solve_3d(target, prior, pa, pb, ta, tb, groups, image_size, flags, debug, tol, flight=False,
                  camera_fov_deg=None, objs=None):
        W, H = (float(x) for x in image_size)
        c = (W / 2, H / 2)
        orig_view = geo._View

        class LazyView(orig_view):
            def __init__(self, f=None, c=(0.0, 0.0), rng=None):
                super().__init__(f, c, rng)
                obj = getattr(rng, '_zobj', None)
                if obj is not None and f is not None:
                    self.rng = _to_z(rng, obj, self.c, f)

        orig_match = geo.match_depth

        def match_tag(names, entries):
            fn = orig_match(names, entries)
            return fn

        # tag depth fns with their object: wrap _loom (called with (fn, obj, ...)) to attach obj
        orig_loom = geo._loom

        def loom_tag(fn, obj, anchors, same_name, W_, H_, debug_, label):
            out = orig_loom(fn, obj, anchors, same_name, W_, H_, debug_, label)
            if out is fn and isinstance(fn, geo.DepthFn) and obj is not None:
                fn._zobj = obj
            return out

        geo._View, geo._loom = LazyView, loom_tag
        try:
            return _orig_solve_3d(target, prior, pa, pb, ta, tb, groups, image_size, flags, debug, tol, flight,
                                  camera_fov_deg, objs)
        finally:
            geo._View, geo._loom = orig_view, orig_loom
    return _solve_3d


@contextlib.contextmanager
def zinterp(on: bool = True):
    if not on:
        yield
        return
    old_s, old_d = geo._solve_3d, geo._View._depth
    geo._View._depth = _depth_patched
    geo._solve_3d = make_solve_3d()
    try:
        yield
    finally:
        geo._solve_3d, geo._View._depth = old_s, old_d
