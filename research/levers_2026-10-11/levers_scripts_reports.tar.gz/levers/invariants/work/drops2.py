"""Per-transition frame-difference energy ratio, median over all lab clips (global drop pattern)."""
import cv2, numpy as np, glob, os
from concurrent.futures import ProcessPoolExecutor
def scan(p):
    c = cv2.VideoCapture(p); prev = None; e = []
    while True:
        ok, f = c.read()
        if not ok: break
        g = cv2.cvtColor(cv2.resize(f, (320, 180), interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2GRAY).astype(np.float32)
        if prev is not None: e.append(np.mean(np.abs(g - prev)))
        prev = g
    e = np.array(e)
    rat = np.full(len(e), np.nan)
    for i in range(len(e)):
        nb = [e[j] for j in (i - 2, i - 1, i + 1, i + 2) if 0 <= j < len(e)]
        rat[i] = e[i] / (np.median(nb) + 1e-6)
    return os.path.basename(p)[:-4].strip(), rat
ps = sorted(glob.glob('/home/user/quantiphy-challenge/data/QuantiPhy/captured_*.mp4'))
with ProcessPoolExecutor(4) as ex:
    res = list(ex.map(scan, ps))
for L in (48, 72):
    R = np.array([r for _, r in res if len(r) == L])
    if not len(R): continue
    med = np.nanmedian(np.log(R), axis=0)
    frac = np.mean(R > 1.3, axis=0)
    print(f'clips with {L+1} frames: {len(R)}')
    order = np.argsort(-med)[:8]
    print('  top transitions (i -> i+1): ', [(int(i), round(float(np.exp(med[i])), 2), round(float(frac[i]), 2)) for i in order])
    print('  median ratio all others:', round(float(np.exp(np.median(np.delete(med, order[:3])))), 3))
np.save('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/invariants/work/drops2.npy', np.array([(n, r) for n, r in res], dtype=object), allow_pickle=True)
