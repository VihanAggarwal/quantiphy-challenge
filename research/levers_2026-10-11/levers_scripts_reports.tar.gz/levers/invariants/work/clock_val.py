import sys; sys.path.insert(0, "/home/user/quantiphy-challenge")
import numpy as np, pandas as pd, inv
from qp.mra import item_scores
R = '/home/user/quantiphy-challenge/runs/'
runs = {'val_hr_v1_high': ('val_hires', R + 'val_hr_v1_high/val_hires/records'),
        'val_hr_v2_high': ('val_hires', R + 'val_hr_v2_high/val_hires/records'),
        'val_hr_v2_med': ('val_hires', R + 'val_hr_v2_med/val_hires/records'),
        'val_opus_low': ('val', R + 'val_opus_low/val/records'), 'val_opus_med': ('val', R + 'val_opus_med/val/records'),
        'val_opus_med2': ('val', R + 'val_opus_med2/val/records'), 'val_opus_high': ('val', R + 'val_opus_high/val/records'),
        'val_opus_xhigh': ('val', R + 'val_opus_xhigh/val/records')}
mot = ['speed', 'acceleration', 'displacement', 'path_length']
rows = []
for name, (split, d) in runs.items():
    try:
        df, rec, anns = inv.load(split, d)
    except Exception as e:
        print(name, 'skip', e); continue
    lab = df[df.video_source == 'lab']
    a = inv.solve_all(lab, rec, anns); b = inv.solve_all(lab, rec, inv.remap_times(anns, df, rec))
    m = a.merge(b[['qid', 'geo']], on='qid', suffixes=('_v', '_c')).merge(df[['qid', 'answer', 'question']], on='qid')
    m['run'] = name
    rows.append(m)
M = pd.concat(rows); M.to_pickle('clock_val.pkl')
M['sv'] = np.nan_to_num(item_scores(M.geo_v, M.answer)); M['sc'] = np.nan_to_num(item_scores(M.geo_c, M.answer))
M['ismot'] = M.target_kind.isin(mot)
print(M.groupby(['run', 'ismot']).agg(n=('qid', 'size'), video=('sv', 'mean'), capture=('sc', 'mean')).round(3).unstack())
print('pooled over runs, by video (motion targets):')
print(M[M.ismot].groupby('video_id').agg(n=('qid', 'size'), video=('sv', 'mean'), capture=('sc', 'mean')).round(3))
print('pooled over runs, by video (static targets):')
print(M[~M.ismot].groupby('video_id').agg(n=('qid', 'size'), video=('sv', 'mean'), capture=('sc', 'mean')).round(3))
