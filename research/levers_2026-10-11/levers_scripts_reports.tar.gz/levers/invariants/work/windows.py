import numpy as np, pandas as pd, inv
from qp import geometry as geo
df, rec, anns = inv.load('test', '/home/user/quantiphy-challenge/runs/test_v1_high_854/test/records')
P = pd.read_pickle('priorspec_test.pkl')
w = P[P.span].drop_duplicates('vid')
for r in w.itertuples():
    a = anns[r.qid]
    pr = [t for t in a.tracks if t.role == 'prior']
    if not pr: print(r.vid, 'no prior track'); continue
    tr = max(pr, key=lambda t: len(t.obs))
    t = np.array([o.t for o in tr.obs if o.point is not None or o.box is not None])
    w0, w1 = r.window
    inside = ((t >= w0 - 1e-6) & (t <= w1 + 1e-6)).sum()
    flags = set()
    o = geo._Obj(tr, flags)
    tt, uv = o.points()
    def acc(q):
        try:
            return geo._motion(q, tt, uv, set(), 0.1, None, False)
        except Exception as e:
            return np.nan
    q_win = geo.Quantity(kind='acceleration', objects=['x'], window=list(r.window), axis=a.spec.prior.axis)
    q_all = geo.Quantity(kind='acceleration', objects=['x'], axis=a.spec.prior.axis)
    aw, aa = acc(q_win), acc(q_all)
    # parabolic fit restricted strictly to obs inside the window (>=3)
    sel = (tt >= w0 - 1e-6) & (tt <= w1 + 1e-6)
    ain = np.nan
    if sel.sum() >= 4:
        c = np.polyfit(tt[sel], uv[sel], 2); ain = float(np.linalg.norm(2 * c[0]))
    print(f'{r.vid:28s} {r.prior[:55]:55s} win {w0:.2f}-{w1:.2f} n_obs {len(t):2d} inside {inside:2d} | a_px window {aw:8.1f} strict-in {ain:8.1f} whole {aa:8.1f} axis {a.spec.prior.axis}')
