"""Noise-free: object with constant acceleration (or constant speed) recorded at 25 fps, delivered as a
24 fps clip by frame drops. Estimate speed / acceleration with qp.geometry's estimators using the video
clock n/24 vs the capture clock. Dense (every frame) vs sparse (16 uniform + asked-time frames)."""
import sys; sys.path.insert(0, '/home/user/quantiphy-challenge')
import numpy as np, inv
from qp import geometry as geo
from qp.spec import Quantity
N = 49
n = np.arange(N)
tc = inv.capture_time(n); tv = n / 24
def est(kind, t_obs, P, time=None, window=None):
    q = Quantity(kind=kind, objects=['x'], time=time, window=window)
    return geo._motion(q, t_obs, P, set(), 0.1, None, False)
print('motion  sampling  quantity            truth   video-clock  capture-clock')
for label, a, v0, rel in (('accel a=3, from rest at 0.3 s', 3.0, 0.0, 0.3), ('const v=1', 0.0, 1.0, 0.0)):
    x = np.where(tc > rel, v0 * (tc - rel) + 0.5 * a * np.clip(tc - rel, 0, None) ** 2, v0 * (tc - rel))
    P = np.c_[x * 500, np.zeros(N)]  # 500 px per metre
    for samp, idx in (('dense', n), ('sparse', np.unique(np.r_[np.linspace(0, 48, 16).round().astype(int), [24, 38]]))):
        for kind, time, truth in (('speed', 1.0, (v0 + a * (1.0 - rel)) * 500), ('speed', 1.5, (v0 + a * (1.5 - rel)) * 500),
                                  ('acceleration', 1.0, a * 500), ('acceleration', None, a * 500)):
            if kind == 'acceleration' and a == 0:
                continue
            ev, ec = est(kind, tv[idx], P[idx], time), est(kind, tc[idx], P[idx], time)
            print(f'{label:30s} {samp:7s} {kind:12s} t={time!s:5s} {truth:8.1f}  {ev / truth - 1:+.3f}       {ec / truth - 1:+.3f}')
