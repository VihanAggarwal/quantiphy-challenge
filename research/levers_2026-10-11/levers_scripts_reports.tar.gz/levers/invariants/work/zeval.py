import sys; sys.path.insert(0, "/home/user/quantiphy-challenge")
import numpy as np, pandas as pd
from qp.mra import item_scores
A = pd.read_pickle('zreal.pkl')
mot = ['speed', 'acceleration', 'displacement', 'path_length']
print('== validation 3D geometry: orig (r-interp) vs zinterp')
for run, g in A[A.run != 'test'].groupby('run'):
    for z in (False, True):
        x = g[g.z == z]
        sc = np.nan_to_num(item_scores(x.geo, x.answer))
        lab = (x.src == 'lab').to_numpy(); m = x.target_kind.isin(mot).to_numpy()
        print(f'  {run:15s} z={z!s:5s} all {sc.mean():.3f} (n={len(x)}) lab {sc[lab].mean():.3f} nonlab {sc[~lab].mean():.3f} '
              f'| motion {sc[m].mean():.3f} (n={m.sum()}) static {sc[~m].mean():.3f}')
    w = g.pivot_table(index='qid', columns='z', values='geo')
    ch = (np.abs(w[True] / w[False] - 1) > 0.01).sum()
    print(f'  {run:15s} answers changed > 1%: {ch} of {len(w)}')
T = A[A.run == 'test']
print('== test lab motion priors at fixed f (stated / measured)')
for z in (False, True):
    x = T[(T.z == z) & T.fixed & (T.src == 'lab') & T.prior_kind.isin(['speed', 'acceleration'])].dropna(subset=['prior_meas'])
    x = x.groupby('video_id').agg(kind=('prior_kind', 'first'), stated=('prior_si', 'first'), meas=('prior_meas', 'median'), fl=('flags', 'first'))
    x = x[~x.fl.str.contains('prior_depth_assumed')]
    for k in ('speed', 'acceleration'):
        y = x[x.kind == k]; lr = np.log(y.stated / y.meas)
        print(f'  z={z!s:5s} {k:12s} n={len(y)} median ratio {np.exp(lr.median()):.3f} rms log {np.sqrt((lr**2).mean()):.3f} MRA {np.nanmean(item_scores(y.meas, y.stated)):.3f}')
print('== test answers (run_claude settings, camera prior): change > 1% by category/source/kind')
w = T[~T.fixed].pivot_table(index='qid', columns='z', values='geo')
meta = T[(~T.fixed) & (T.z == False)].set_index('qid')[['cat', 'src', 'target_kind', 'video_id']]
w = w.join(meta)
w['ch'] = np.abs(w[True] / w[False] - 1)
w['ismot'] = w.target_kind.isin(mot)
print(w[w.ch > 0.01].groupby(['cat', 'src', 'ismot']).agg(n=('ch', 'size'), med=('ch', 'median'), mx=('ch', 'max')))
w.to_pickle('zreal_test_changes.pkl')
