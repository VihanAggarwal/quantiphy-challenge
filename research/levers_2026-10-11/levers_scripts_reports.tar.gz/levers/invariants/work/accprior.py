"""Acceleration-prior estimators, judged on stated lab acceleration priors (exact labels) at fixed f=722.
Variants patch qp.geometry._motion's acceleration branch in-process:
  cur      current code
  span     'at t' acceleration -> longest parabolic run (as for untimed priors) when it contains t,
           else current
  anyaxis  gravity in 3D: full vector (x, y, z) instead of camera y only
  capture  capture-time clock for lab clips
"""
import math
import sys
import numpy as np
import pandas as pd
import inv
from qp import geometry as geo
from qp.mra import item_scores

W = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/invariants/work/'
_orig_motion = geo._motion


def motion_span(q, t, P, flags, tol, floor=None, flight=False):
    time = geo._num(q.time, inf_ok=True)
    if q.kind == 'acceleration' and time is not None and math.isfinite(time) and not geo._window(q):
        cols = geo._axis_cols(q.axis, P.shape[1])
        span = geo._parabolic_span(t, P[:, cols])
        ts = t[span]
        if span.stop - span.start >= 5 and ts[0] - tol <= time <= ts[-1] + tol:
            q2 = geo.replace(q, time=None)
            sub_t, sub_P = t[span], P[span]
            return _orig_motion(q2, sub_t, sub_P, flags, tol, floor, flight)
    return _orig_motion(q, t, P, flags, tol, floor, flight)


_orig_axis = geo._axis_cols


def axis_any(axis, d):
    return list(range(d)) if d == 3 else _orig_axis(axis, d)


def run(split, rec_dir):
    df, rec, anns = inv.load(split, rec_dir)
    lab = df[(df.video_source == 'lab') & (df.video_type.str[1] == '3')]
    lab = lab.drop_duplicates('video_id')  # one prior per video
    rows = []
    for clock in ('video', 'capture'):
        A = anns if clock == 'video' else inv.remap_times(anns, df, rec)
        for var in ('cur', 'span', 'anyaxis', 'span+anyaxis'):
            geo._motion = motion_span if 'span' in var else _orig_motion
            geo._axis_cols = axis_any if 'anyaxis' in var else _orig_axis
            try:
                r = inv.solve_all(lab, rec, A, fixed_lab_f=True)
            finally:
                geo._motion, geo._axis_cols = _orig_motion, _orig_axis
            r['var'] = var; r['clock'] = clock
            rows.append(r)
    return pd.concat(rows)


if __name__ == '__main__':
    R = run('test', '/home/user/quantiphy-challenge/runs/test_v1_high_854/test/records')
    R.to_pickle(W + 'accprior_test.pkl')
    sys.exit(0)
    x = R[R.prior_kind == 'acceleration'].copy()
    x['grav'] = np.isclose(x.prior_si, 9.8)
    x['assumed'] = x.flags.str.contains('prior_depth_assumed')
    for sub, s in (('all', x), ('depth known', x[~x.assumed]), ('gravity', x[x.grav]), ('slope/other', x[~x.grav])):
        print(f'== {sub}')
        for (clock, var), g in s.groupby(['clock', 'var']):
            g = g.dropna(subset=['prior_meas'])
            lr = np.log(g.prior_si / g.prior_meas)
            print(f'  {clock:8s} {var:13s} n={len(g):2d} median stated/meas {np.exp(lr.median()):.3f} '
                  f'median|log| {lr.abs().median():.3f} MRA {np.nanmean(item_scores(g.prior_meas, g.prior_si)):.3f}')
