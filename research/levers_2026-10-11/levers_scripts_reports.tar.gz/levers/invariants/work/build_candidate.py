"""Candidate: lab capture clock on the rows the current submission takes from lab geometry.
new = submission x geo(capture clock) / geo(video clock), both from the same cached tracks (harness, no
refine/dense), only where the submission value equals runs/test_v1_high_854/test.csv geo_value (rtol 1e-4),
and only for ratios within [0.75, 1.33] (fixed guard against near-zero speeds; not tuned)."""
import numpy as np, pandas as pd
C = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/invariants/candidates/'
sub = pd.read_csv('/home/user/quantiphy-challenge/submissions/trackA_probe7b_p5_ens_famext.csv')
S = pd.read_pickle('sub_vs_run.pkl')
E = pd.read_pickle('clock_effect_test.pkl')[['qid', 'geo_v', 'geo_c', 'target_kind', 'cat', 'video_id']]
m = S[['qid', 'is_geo', 'parsed_value', 'category']].merge(E, on='qid')
m['ratio'] = m.geo_c / m.geo_v
ok = m.is_geo & np.isfinite(m.ratio) & (np.abs(m.ratio - 1) > 1e-3) & m.ratio.between(0.75, 1.33)
ch = m[ok]
new = sub[['id', 'parsed_value']].copy()
rat = dict(zip(ch.qid, ch.ratio))
new['parsed_value'] = [v * rat.get(i, 1.0) for i, v in zip(new.id, new.parsed_value)]
assert len(new) == 3289 and new.parsed_value.notna().all() and (new.parsed_value > 0).all()
new.to_csv(C + 'trackA_inv_labclock_on_p7b.csv', index=False)
d = (new.parsed_value / sub.parsed_value)
print('rows changed:', int((np.abs(d - 1) > 1e-9).sum()), '| skipped by guard:', int((m.is_geo & ~m.ratio.between(0.75, 1.33)).sum()))
print(ch.groupby(['category', 'target_kind']).agg(n=('qid', 'size'), median_ratio=('ratio', 'median'), min=('ratio', 'min'), max=('ratio', 'max')).round(3))
ch[['qid', 'video_id', 'category', 'target_kind', 'parsed_value', 'ratio']].to_csv(C + 'trackA_inv_labclock_changed_rows.csv', index=False)
