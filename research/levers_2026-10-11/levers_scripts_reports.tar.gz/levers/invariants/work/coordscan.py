"""Raw Claude coordinates vs the size of the frames it saw: out-of-frame or normalized coordinates?"""
import json, glob, sys
import numpy as np, pandas as pd
rows = []
for run in sys.argv[1:]:
    for f in sorted(glob.glob(run + '/*.json')):
        r = json.load(open(f))
        m, p = r.get('meta'), r.get('parsed')
        if not m or not p:
            continue
        sw, sh = round(m['image_size'][0] * m['scale']), round(m['image_size'][1] * m['scale'])
        xs, ys = [], []
        for q in p.get('questions', []):
            for tr in q.get('tracks') or []:
                for o in tr.get('obs') or []:
                    for k in ('point',):
                        v = o.get(k)
                        if isinstance(v, list) and len(v) == 2 and all(isinstance(x, (int, float)) for x in v):
                            xs.append(v[0]); ys.append(v[1])
                    b = o.get('box')
                    if isinstance(b, list) and len(b) == 4 and all(isinstance(x, (int, float)) for x in b):
                        xs += [b[0], b[2]]; ys += [b[1], b[3]]
                    e = o.get('extent')
                    if isinstance(e, list) and len(e) == 2:
                        for pt in e:
                            if isinstance(pt, list) and len(pt) == 2 and all(isinstance(x, (int, float)) for x in pt):
                                xs.append(pt[0]); ys.append(pt[1])
        if not xs:
            continue
        xs, ys = np.array(xs), np.array(ys)
        rows.append(dict(run=run.split('/runs/')[1].split('/')[0], vid=m['video_id'], sw=sw, sh=sh, n=len(xs),
                         xmax=xs.max(), ymax=ys.max(), xmin=xs.min(), ymin=ys.min(),
                         out=float(np.mean((xs > sw * 1.02) | (ys > sh * 1.02) | (xs < -0.02 * sw) | (ys < -0.02 * sh))),
                         xmax_rel=xs.max() / sw, ymax_rel=ys.max() / sh))
d = pd.DataFrame(rows)
print(d.groupby('run').agg(videos=('vid', 'size'), frac_out=('out', 'mean'), vids_any_out=('out', lambda s: (s > 0).sum()),
                           xmax_rel_max=('xmax_rel', 'max'), ymax_rel_max=('ymax_rel', 'max'), xmax_rel_med=('xmax_rel', 'median')))
print(d[d.out > 0.01].sort_values('out', ascending=False).head(15).to_string())
