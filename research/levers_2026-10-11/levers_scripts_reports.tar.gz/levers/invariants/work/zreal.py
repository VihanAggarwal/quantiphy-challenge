import numpy as np, pandas as pd, inv, zinterp
from qp.mra import item_scores
W = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/invariants/work/'
RUNS = {'test': '/home/user/quantiphy-challenge/runs/test_v1_high_854/test/records',
        'val_hires': '/home/user/quantiphy-challenge/runs/val_hr_v1_high/val_hires/records',
        'val_hr_v2_high': '/home/user/quantiphy-challenge/runs/val_hr_v2_high/val_hires/records',
        'val_opus_high': '/home/user/quantiphy-challenge/runs/val_opus_high/val/records',
        'val_opus_med2': '/home/user/quantiphy-challenge/runs/val_opus_med2/val/records'}
SPLIT = {'test': 'test', 'val_hires': 'val_hires', 'val_hr_v2_high': 'val_hires', 'val_opus_high': 'val', 'val_opus_med2': 'val'}
out = []
for name, d in RUNS.items():
    df, rec, anns = inv.load(SPLIT[name], d)
    d3 = df[df.video_type.str[1] == '3']
    for z in (False, True):
        for fixed in ((False, True) if name == 'test' else (False,)):
            with zinterp.zinterp(z):
                r = inv.solve_all(d3, rec, anns, fixed_lab_f=fixed)
            r['z'] = z; r['fixed'] = fixed; r['run'] = name
            if 'answer' in df.columns:
                r = r.merge(df[['qid', 'answer']], on='qid')
            out.append(r)
    print('done', name, flush=True)
A = pd.concat(out); A.to_pickle(W + 'zreal.pkl')
