| best-of-N per question (ceiling) | S2 | D2 | S3 | D3 | MRA | gain | static | motion |
|---|---|---|---|---|---|---|---|---|
| v1 geo|direct (oracle B) | 0.756 | 0.927 | 0.819 | 0.764 | 0.816 | 0.031 | 0.812 | 0.820 |
| v1 geo|direct + v2 parsed|direct | 0.788 | 0.959 | 0.842 | 0.794 | 0.846 | 0.060 | 0.842 | 0.847 |
| all Claude runs (5 x geo|direct) | 0.794 | 0.978 | 0.872 | 0.862 | 0.876 | 0.091 | 0.880 | 0.875 |
| v1 geo|direct + astra | 0.766 | 0.946 | 0.863 | 0.789 | 0.841 | 0.055 | 0.838 | 0.846 |
| all Claude + astra | 0.803 | 0.984 | 0.898 | 0.870 | 0.889 | 0.103 | 0.892 | 0.888 |
