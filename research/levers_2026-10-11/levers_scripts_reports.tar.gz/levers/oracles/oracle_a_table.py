"""Oracle A summary with the shuffled-residual null (reads oracle_a outputs + oracle_a_null.csv)."""
import numpy as np
import pandas as pd

from common import CATS, item_scores, load_meta, load_runs, macro, md_table
from oracle_a import oracle_preds

m = load_meta(); R = load_runs(m); y = m.answer
base = R["v1.parsed"]
null = pd.read_csv("oracle_a_null.csv")
b = item_scores(base.values, y.values)
rows = []
for mode, label in (("one", "A1 one factor / video"), ("split", "A2 static + motion factors / video"),
                    ("order", "A3 c * beta^(target order - prior order) / video")):
    o, _ = oracle_preds(m, base, mode)
    it = item_scores(o.values, y.values)
    subsets = {"MRA": None, "static": ~m.motion.values, "motion": m.motion.values,
               "prior size": (m.pkind == "size").values, "prior speed": (m.pkind == "speed").values,
               "prior accel": (m.pkind == "accel").values}
    subsets.update({c: (m.category == c).values for c in CATS})
    for sname, sel in subsets.items():
        if sname == "MRA":
            real = macro(it, m.category.values)["MRA"] - macro(b, m.category.values)["MRA"]
            nk = mode
        else:
            real = it[sel].mean() - b[sel].mean()
            key = {"static": "_static", "motion": "_motion", "prior size": "_prior_size", "prior speed": "_prior_speed",
                   "prior accel": "_prior_accel"}.get(sname, "_" + sname)
            nk = mode + key
        base_v = macro(b, m.category.values)["MRA"] if sname == "MRA" else b[sel].mean()
        rows.append(dict(oracle=label, subset=sname, n=int(len(m) if sel is None else sel.sum()), base=base_v,
                         oracle_score=base_v + real, gain=real, null_gain=null[nk].mean(), null_sd=null[nk].std(),
                         excess=real - null[nk].mean(),
                         share_of_loss_recovered=real / (1 - base_v), excess_share_of_loss=(real - null[nk].mean()) / (1 - base_v)))
T = pd.DataFrame(rows)
T.index = T.oracle + " | " + T.subset
T = T.drop(columns=["oracle", "subset"]); T.index.name = "oracle | subset"
open("oracle_a_table.md", "w").write(md_table(T) + "\n")
print(md_table(T))
