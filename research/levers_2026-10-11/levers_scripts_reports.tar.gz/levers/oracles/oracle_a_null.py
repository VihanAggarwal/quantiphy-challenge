"""Null distribution for oracles A1/A2/A3: log residuals shuffled within category (no shared per-video structure)."""
import sys, time
import numpy as np, pandas as pd
from common import CATS, item_scores, load_meta, load_runs, macro
from oracle_a import oracle_preds
reps = int(sys.argv[1]) if len(sys.argv) > 1 else 40
rng = np.random.default_rng(1)
m = load_meta(); R = load_runs(m); y = m.answer; base = R["v1.parsed"]
r = np.log(base / y)
rows = []
t0 = time.time()
for k in range(reps):
    rr = r.copy()
    for c in CATS:
        ix = m.index[m.category == c]
        rr.loc[ix] = rng.permutation(r.loc[ix].values)
    pb = y * np.exp(rr)
    b = item_scores(pb.values, y.values)
    d = dict(base=macro(b, m.category.values)["MRA"])
    for mode in ("one", "split", "order"):
        o, _ = oracle_preds(m, pb, mode)
        it = item_scores(o.values, y.values)
        d[mode] = macro(it, m.category.values)["MRA"] - d["base"]
        d[mode + "_static"] = it[~m.motion.values].mean() - b[~m.motion.values].mean()
        d[mode + "_motion"] = it[m.motion.values].mean() - b[m.motion.values].mean()
        for pk in ("size", "speed", "accel"):
            sel = (m.pkind == pk).values
            d[mode + "_prior_" + pk] = it[sel].mean() - b[sel].mean()
        for c in CATS:
            sel = (m.category == c).values
            d[mode + "_" + c] = it[sel].mean() - b[sel].mean()
    rows.append(d)
    print(k, round(time.time() - t0), flush=True)
df = pd.DataFrame(rows); df.to_csv("oracle_a_null.csv", index=False)
print(df.describe().T[["mean", "std", "min", "max"]])
