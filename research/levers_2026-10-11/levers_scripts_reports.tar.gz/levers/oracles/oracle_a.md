### Oracle A summary (v1.parsed, 159 q / 24 videos)

| variant | S2 | D2 | S3 | D3 | MRA | static | motion | prior=size | prior=speed | prior=accel |
|---|---|---|---|---|---|---|---|---|---|---|
| baseline v1.parsed | 0.709 | 0.924 | 0.800 | 0.709 | 0.786 | 0.784 | 0.783 | 0.761 | 0.767 | 0.861 |
| A1: one factor / video | 0.803 | 0.941 | 0.823 | 0.747 | 0.828 | 0.822 | 0.827 | 0.815 | 0.802 | 0.879 |
| A2: static & motion factors / video | 0.828 | 0.943 | 0.860 | 0.757 | 0.847 | 0.829 | 0.866 | 0.847 | 0.808 | 0.888 |
| A3: c*beta^(dorder) / video | 0.837 | 0.943 | 0.867 | 0.757 | 0.851 | 0.829 | 0.876 | 0.855 | 0.808 | 0.888 |

Null (residuals shuffled within category, 200 reps): one-factor oracle gain on MRA mean 0.026 (5-95% 0.020..0.032); static 0.024, motion 0.028.

### Excluding suspect labels

| variant (excl. 12 suspect GT) | S2 | D2 | S3 | D3 | MRA |
|---|---|---|---|---|---|
| baseline v1.parsed | 0.769 | 0.924 | 0.805 | 0.756 | 0.814 |
| A1: one factor / video | 0.852 | 0.941 | 0.825 | 0.800 | 0.854 |
| A2: static & motion factors / video | 0.890 | 0.943 | 0.857 | 0.807 | 0.874 |
| A3: c*beta^(dorder) / video | 0.897 | 0.943 | 0.865 | 0.807 | 0.878 |

### Per video

| video | cat | src | prior | n | n_motion | base | oracleA1 | c | med_logres | mad_within | med_abs_logres |
|---|---|---|---|---|---|---|---|---|---|---|---|
| internet_0005 | D2 | internet | speed | 4 | 0 | 0.900 | 0.900 | 1.000 | 0.010 | 0.031 | 0.031 |
| internet_0013 | D2 | internet | speed | 6 | 2 | 1.000 | 1.000 | 1.000 | -0.006 | 0.020 | 0.015 |
| internet_0019 | D2 | internet | accel | 7 | 2 | 0.929 | 0.957 | 1.028 | -0.057 | 0.022 | 0.057 |
| simulation_0098_segmented | D2 | segmentation | speed | 4 | 1 | 0.975 | 1.000 | 0.953 | 0.019 | 0.012 | 0.019 |
| simulation_0193 | D2 | simulation | speed | 12 | 3 | 0.900 | 0.908 | 1.030 | 0.012 | 0.002 | 0.014 |
| simulation_0196 | D2 | simulation | speed | 4 | 0 | 0.850 | 0.900 | 0.955 | 0.061 | 0.086 | 0.121 |
| captured_0013 | D3 | lab | accel | 8 | 1 | 0.762 | 0.762 | 1.000 | -0.086 | 0.144 | 0.114 |
| captured_0041x | D3 | lab | speed | 3 | 0 | 0.600 | 0.600 | 1.000 | 0.022 | 0.202 | 0.180 |
| captured_0061 | D3 | lab | speed | 9 | 4 | 0.567 | 0.600 | 1.146 | -0.375 | 0.416 | 0.375 |
| simulation_0009 | D3 | simulation | speed | 9 | 0 | 0.500 | 0.622 | 1.823 | -0.564 | 0.128 | 0.567 |
| simulation_0060 | D3 | simulation | accel | 13 | 3 | 0.854 | 0.877 | 1.038 | -0.044 | 0.052 | 0.080 |
| simulation_0300 | D3 | simulation | accel | 5 | 2 | 0.940 | 0.960 | 1.006 | 0.020 | 0.034 | 0.041 |
| internet_0001 | S2 | internet | size | 3 | 1 | 0.833 | 0.933 | 1.103 | -0.107 | 0.023 | 0.107 |
| internet_0004 | S2 | internet | size | 4 | 2 | 0.875 | 0.875 | 1.000 | -0.048 | 0.079 | 0.079 |
| internet_0027 | S2 | internet | size | 5 | 3 | 0.880 | 0.880 | 1.000 | 0.009 | 0.017 | 0.026 |
| simulation_0089 | S2 | simulation | size | 6 | 2 | 0.483 | 0.817 | 0.653 | 0.362 | 0.108 | 0.362 |
| simulation_0163 | S2 | simulation | size | 6 | 4 | 0.833 | 0.833 | 1.000 | -0.013 | 0.010 | 0.022 |
| simulation_0171 | S2 | simulation | size | 8 | 8 | 0.550 | 0.637 | 0.812 | 0.203 | 0.141 | 0.248 |
| captured_0021x | S3 | lab | size | 5 | 2 | 0.900 | 0.900 | 1.000 | 0.000 | 0.031 | 0.031 |
| captured_0027s | S3 | lab | size | 4 | 3 | 0.475 | 0.625 | 1.234 | -0.542 | 0.303 | 0.542 |
| captured_0034as | S3 | lab | size | 9 | 4 | 0.778 | 0.789 | 1.033 | -0.218 | 0.224 | 0.218 |
| simulation_0015 | S3 | simulation | size | 11 | 1 | 0.736 | 0.745 | 1.012 | -0.171 | 0.161 | 0.250 |
| simulation_0034_segmented | S3 | segmentation | size | 6 | 3 | 0.967 | 0.983 | 0.986 | -0.020 | 0.018 | 0.023 |
| simulation_0170_segmented | S3 | segmentation | size | 8 | 8 | 0.887 | 0.900 | 1.036 | -0.023 | 0.074 | 0.087 |

### Residual structure

Variance of clipped log residual: total 0.1195, between-video (of means) 0.0370, within 0.0825; ANOVA ICC 0.20.

Within-video slope of log residual on (target order - prior order): 0.010 (bootstrap over videos 90% CI -0.076..0.096); videos with mixed orders: 20. By prior kind: accel 0.050 (4 videos), size -0.022 (12 videos), speed 0.083 (4 videos)

|  | n | videos | median_r | median_abs_r | median_abs_r_centered |
|---|---|---|---|---|---|
| ('accel', 'distance') | 1.000 | 1.000 | -0.035 | 0.035 | 0.022 |
| ('accel', 'size') | 24.000 | 4.000 | -0.061 | 0.079 | 0.081 |
| ('accel', 'speed') | 8.000 | 4.000 | -0.031 | 0.042 | 0.023 |
| ('size', 'accel') | 12.000 | 5.000 | -0.027 | 0.226 | 0.191 |
| ('size', 'distance') | 6.000 | 4.000 | 0.008 | 0.066 | 0.125 |
| ('size', 'size') | 28.000 | 9.000 | -0.009 | 0.102 | 0.137 |
| ('size', 'speed') | 29.000 | 12.000 | -0.009 | 0.106 | 0.055 |
| ('speed', 'distance') | 8.000 | 5.000 | -0.080 | 0.234 | 0.483 |
| ('speed', 'size') | 33.000 | 8.000 | 0.003 | 0.087 | 0.060 |
| ('speed', 'speed') | 10.000 | 4.000 | 0.006 | 0.024 | 0.019 |

### Mixed videos: median log residual of static vs motion targets

| video | prior | cat | static_med_r | motion_med_r | motion_minus_static |
|---|---|---|---|---|---|
| captured_0013 | accel | D3 | -0.019 | -0.154 | -0.135 |
| captured_0021x | size | S3 | -0.023 | 0.175 | 0.198 |
| captured_0027s | size | S3 | -0.170 | -0.776 | -0.606 |
| captured_0034as | size | S3 | 0.006 | -0.346 | -0.352 |
| captured_0061 | speed | D3 | -0.145 | -0.432 | -0.287 |
| internet_0001 | size | S2 | -0.118 | 0.065 | 0.184 |
| internet_0004 | size | S2 | 0.031 | -0.220 | -0.251 |
| internet_0013 | speed | D2 | -0.006 | -0.010 | -0.004 |
| internet_0019 | accel | D2 | -0.073 | -0.015 | 0.058 |
| internet_0027 | size | S2 | 0.008 | 0.026 | 0.018 |
| simulation_0015 | size | S3 | -0.091 | -0.262 | -0.172 |
| simulation_0034_segmented | size | S3 | -0.024 | -0.017 | 0.007 |
| simulation_0060 | accel | D3 | -0.036 | -0.044 | -0.008 |
| simulation_0089 | size | S2 | 0.254 | 0.443 | 0.189 |
| simulation_0098_segmented | speed | D2 | 0.024 | 0.001 | -0.024 |
| simulation_0163 | size | S2 | -1.798 | -0.013 | 1.785 |
| simulation_0193 | speed | D2 | -0.025 | 0.013 | 0.037 |
| simulation_0300 | accel | D3 | -0.026 | 0.031 | 0.057 |

### One-factor oracle on other answer columns (gaps filled with v1.parsed)

| answers | base | oracleA1 | gain_static | gain_motion |
|---|---|---|---|---|
| v1.direct | 0.766 | 0.830 | 0.064 | 0.058 |
| v1.geo | 0.739 | 0.785 | 0.037 | 0.056 |
| v2.parsed | 0.783 | 0.829 | 0.029 | 0.063 |
| oh.parsed | 0.782 | 0.827 | 0.031 | 0.061 |
| astra.direct | 0.759 | 0.838 | 0.072 | 0.081 |
