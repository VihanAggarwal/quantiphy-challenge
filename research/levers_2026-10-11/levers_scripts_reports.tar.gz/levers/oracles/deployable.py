"""Increments over the deployed-like structure (v1.parsed with 3D non-lab -> median of 3 Claude direct answers),
for the combinations that could actually be bought on test (extra vendors on a subset). Validation only."""
import numpy as np, pandas as pd
src = open("combo.py").read().split("# ------------------------------------------------------------------ LOVO selection")[0].replace("args = ap.parse_args()", "args = ap.parse_args(['--reps','2000'])")
exec(src)
def per_cat_ci(a, b):
    out = {}
    for c in vids:
        diffs = [a[np.concatenate([pos[v] for v in bs[c]])].mean() - b[np.concatenate([pos[v] for v in bs[c]])].mean() for bs in BOOT]
        out[c] = (a[cats == c].mean() - b[cats == c].mean(), np.quantile(diffs, .025), np.quantile(diffs, .975))
    return out


D = rules[DEPLOYED]; Dit = items[DEPLOYED]
s3 = (cats == "S3"); d3 = (cats == "D3")
cand = {
    "3D non-lab median + astra": rules["base; 3D non-lab -> median(C3 direct + astra)"],
    "3D non-lab median + astra + gem": rules["base; 3D non-lab -> median(C3 direct + astra + gem)"],
    "3D non-lab median + gem": pd.Series(np.where(nonlab3d, comb(C3d + G), R[BASE]), index=R.index),
    "S3 non-lab only: median + astra + gem": pd.Series(np.where(nonlab3d & s3, comb(C3d + A + G), D), index=R.index),
    "S3 non-lab only: median + astra": pd.Series(np.where(nonlab3d & s3, comb(C3d + A), D), index=R.index),
    "S3 all rows: median(v1.parsed, astra, gem)": pd.Series(np.where(s3, comb(["v1.parsed"] + A + G), D), index=R.index),
    "S3 lab rows: median(v1.parsed, astra, gem)": pd.Series(np.where(s3 & (m.src.values == "lab"), comb(["v1.parsed"] + A + G), D), index=R.index),
    "lab rows (S3+D3): median(v1.parsed, astra, gem)": pd.Series(np.where(m.src.values == "lab", comb(["v1.parsed"] + A + G), D), index=R.index),
}
rows = []
for k, v in cand.items():
    it = item_scores(v.values, y)
    mu, lo, hi, lo90, hi90, p = boot(it, Dit)
    pc = per_cat_ci(it, Dit)
    d = {"rule (vs deployed-like)": k, "changed q": int((np.abs(np.log(v / D)) > 1e-9).sum()), "dMRA": macro_any(it) - macro_any(Dit),
         "95% CI": f"{lo:+.3f}..{hi:+.3f}", "P(>0)": p}
    d.update({c: f"{pc[c][0]:+.3f} ({pc[c][1]:+.3f}..{pc[c][2]:+.3f})" for c in ("S3", "D3")})
    rows.append(d)
T = pd.DataFrame(rows).set_index("rule (vs deployed-like)")
open("deployable.md", "w").write(md_table(T) + "\n")
print(md_table(T))
