| oracle | subset | n | base | oracle_score | gain | null_gain | null_sd | excess | share_of_loss_recovered | excess_share_of_loss |
|---|---|---|---|---|---|---|---|---|---|
| A1 one factor / video | MRA | 159.000 | 0.786 | 0.828 | 0.043 | 0.027 | 0.005 | 0.016 | 0.200 | 0.073 |
| A1 one factor / video | static | 100.000 | 0.784 | 0.822 | 0.038 | 0.025 | 0.006 | 0.013 | 0.176 | 0.062 |
| A1 one factor / video | motion | 59.000 | 0.783 | 0.827 | 0.044 | 0.030 | 0.012 | 0.014 | 0.203 | 0.065 |
| A1 one factor / video | prior size | 75.000 | 0.761 | 0.815 | 0.053 | 0.034 | 0.009 | 0.020 | 0.223 | 0.083 |
| A1 one factor / video | prior speed | 51.000 | 0.767 | 0.802 | 0.035 | 0.019 | 0.007 | 0.017 | 0.151 | 0.071 |
| A1 one factor / video | prior accel | 33.000 | 0.861 | 0.879 | 0.018 | 0.023 | 0.011 | -0.005 | 0.130 | -0.033 |
| A1 one factor / video | S2 | 32.000 | 0.709 | 0.803 | 0.094 | 0.046 | 0.014 | 0.047 | 0.323 | 0.163 |
| A1 one factor / video | D2 | 37.000 | 0.924 | 0.941 | 0.016 | 0.010 | 0.004 | 0.007 | 0.214 | 0.088 |
| A1 one factor / video | S3 | 43.000 | 0.800 | 0.823 | 0.023 | 0.024 | 0.009 | -0.001 | 0.116 | -0.004 |
| A1 one factor / video | D3 | 47.000 | 0.709 | 0.747 | 0.038 | 0.029 | 0.009 | 0.010 | 0.131 | 0.033 |
| A2 static + motion factors / video | MRA | 159.000 | 0.786 | 0.847 | 0.062 | 0.048 | 0.007 | 0.014 | 0.288 | 0.065 |
| A2 static + motion factors / video | static | 100.000 | 0.784 | 0.829 | 0.045 | 0.037 | 0.007 | 0.008 | 0.208 | 0.035 |
| A2 static + motion factors / video | motion | 59.000 | 0.783 | 0.866 | 0.083 | 0.062 | 0.016 | 0.021 | 0.383 | 0.098 |
| A2 static + motion factors / video | prior size | 75.000 | 0.761 | 0.847 | 0.085 | 0.061 | 0.011 | 0.024 | 0.358 | 0.101 |
| A2 static + motion factors / video | prior speed | 51.000 | 0.767 | 0.808 | 0.041 | 0.026 | 0.009 | 0.015 | 0.176 | 0.064 |
| A2 static + motion factors / video | prior accel | 33.000 | 0.861 | 0.888 | 0.027 | 0.044 | 0.016 | -0.017 | 0.196 | -0.121 |
| A2 static + motion factors / video | S2 | 32.000 | 0.709 | 0.828 | 0.119 | 0.084 | 0.020 | 0.035 | 0.409 | 0.121 |
| A2 static + motion factors / video | D2 | 37.000 | 0.924 | 0.943 | 0.019 | 0.017 | 0.005 | 0.002 | 0.250 | 0.032 |
| A2 static + motion factors / video | S3 | 43.000 | 0.800 | 0.860 | 0.060 | 0.044 | 0.011 | 0.016 | 0.302 | 0.080 |
| A2 static + motion factors / video | D3 | 47.000 | 0.709 | 0.757 | 0.049 | 0.047 | 0.012 | 0.002 | 0.168 | 0.008 |
| A3 c * beta^(target order - prior order) / video | MRA | 159.000 | 0.786 | 0.851 | 0.066 | 0.049 | 0.007 | 0.017 | 0.307 | 0.080 |
| A3 c * beta^(target order - prior order) / video | static | 100.000 | 0.784 | 0.829 | 0.045 | 0.035 | 0.007 | 0.010 | 0.208 | 0.044 |
| A3 c * beta^(target order - prior order) / video | motion | 59.000 | 0.783 | 0.876 | 0.093 | 0.067 | 0.016 | 0.026 | 0.430 | 0.121 |
| A3 c * beta^(target order - prior order) / video | prior size | 75.000 | 0.761 | 0.855 | 0.093 | 0.063 | 0.011 | 0.030 | 0.391 | 0.126 |
| A3 c * beta^(target order - prior order) / video | prior speed | 51.000 | 0.767 | 0.808 | 0.041 | 0.026 | 0.009 | 0.015 | 0.176 | 0.064 |
| A3 c * beta^(target order - prior order) / video | prior accel | 33.000 | 0.861 | 0.888 | 0.027 | 0.043 | 0.015 | -0.016 | 0.196 | -0.114 |
| A3 c * beta^(target order - prior order) / video | S2 | 32.000 | 0.709 | 0.837 | 0.128 | 0.086 | 0.020 | 0.042 | 0.441 | 0.143 |
| A3 c * beta^(target order - prior order) / video | D2 | 37.000 | 0.924 | 0.943 | 0.019 | 0.016 | 0.006 | 0.002 | 0.250 | 0.033 |
| A3 c * beta^(target order - prior order) / video | S3 | 43.000 | 0.800 | 0.867 | 0.067 | 0.046 | 0.011 | 0.022 | 0.337 | 0.108 |
| A3 c * beta^(target order - prior order) / video | D3 | 47.000 | 0.709 | 0.757 | 0.049 | 0.046 | 0.011 | 0.003 | 0.168 | 0.010 |
