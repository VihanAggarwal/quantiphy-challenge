"""Oracle A: best per-video multiplicative factor on the final answers (val_hr_v1_high parsed_value),
plus the within-video log-residual structure. Validation labels used for DIAGNOSIS only."""
from __future__ import annotations

import json
import sys

import numpy as np
import pandas as pd

from common import CATS, item_scores, load_meta, load_runs, macro, md_table

OUT = sys.argv[1] if len(sys.argv) > 1 else "oracle_a"
rng = np.random.default_rng(0)


def best_factor(p, y, extra_exp=None):
    """Factor c maximizing sum item(c*p, y) (ties: c closest to 1 in log).
    If extra_exp is given (array of exponents e_i), search c*beta**e_i over a 2D grid."""
    p = np.asarray(p, float); y = np.asarray(y, float)
    ok = np.isfinite(p) & (p > 0)
    if not ok.any():
        return 1.0, 1.0, item_scores(p, y).sum()
    if extra_exp is None:
        bps = []
        for t in (0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95):
            bps += list(y[ok] * t / p[ok]) + list(y[ok] * (2 - t) / p[ok])
        bps = np.sort(np.log(np.array(bps)))
        cand = np.concatenate([(bps[:-1] + bps[1:]) / 2, [0.0]])
        best, bc = -1, 0.0
        for lc in cand:
            s = item_scores(p * np.exp(lc), y).sum()
            if s > best + 1e-12 or (abs(s - best) < 1e-12 and abs(lc) < abs(bc)):
                best, bc = s, lc
        return float(np.exp(bc)), 1.0, best
    e = np.asarray(extra_exp, float)
    grid = np.linspace(-1.5, 1.5, 601)  # log factor grid, step 0.005
    best, bc, bb = -1, 0.0, 0.0
    for lb in grid[::4]:
        q = p * np.exp(lb * e)
        c, _, s = best_factor(q, y)
        lc = np.log(c)
        if s > best + 1e-12 or (abs(s - best) < 1e-12 and abs(lc) + abs(lb) < abs(bc) + abs(bb)):
            best, bc, bb = s, lc, lb
    return float(np.exp(bc)), float(np.exp(bb)), best


def oracle_preds(m, pred, mode="one"):
    """Return oracle-adjusted predictions and per-video factor table."""
    out = pred.copy()
    rows = []
    for vid, g in m.groupby("video_id"):
        idx = g.index
        p, y = pred.loc[idx].values, g.answer.values
        if mode == "one":
            c, b, _ = best_factor(p, y)
            out.loc[idx] = p * c
        elif mode == "order":  # c * beta^(tord - pord): timing / kinematics hypothesis
            e = (g.tord - g.pord).values
            c, b, _ = best_factor(p, y, e)
            out.loc[idx] = p * c * b ** e
        elif mode == "split":  # separate factor for static and motion targets
            c = b = np.nan
            for mot, gg in g.groupby("motion"):
                cc, _, _ = best_factor(pred.loc[gg.index].values, gg.answer.values)
                out.loc[gg.index] = pred.loc[gg.index].values * cc
                if mot: b = cc
                else: c = cc
        rows.append(dict(video_id=vid, c=c, beta=b))
    return out, pd.DataFrame(rows).set_index("video_id")


def summarize(m, items_by_name):
    cats = m.category.values
    rows = {}
    for name, it in items_by_name.items():
        d = macro(it, cats)
        d["static"] = it[~m.motion.values].mean()
        d["motion"] = it[m.motion.values].mean()
        for pk in ("size", "speed", "accel"):
            d[f"prior={pk}"] = it[(m.pkind == pk).values].mean()
        rows[name] = d
    t = pd.DataFrame(rows).T
    t.index.name = "variant"
    return t


def main():
    m = load_meta(); R = load_runs(m)
    y = m.answer
    base = R["v1.parsed"].copy()
    res = {}
    items = {"baseline v1.parsed": item_scores(base.values, y.values)}
    o1, f1 = oracle_preds(m, base, "one")
    items["A1: one factor / video"] = item_scores(o1.values, y.values)
    o2, f2 = oracle_preds(m, base, "split")
    items["A2: static & motion factors / video"] = item_scores(o2.values, y.values)
    o3, f3 = oracle_preds(m, base, "order")
    items["A3: c*beta^(dorder) / video"] = item_scores(o3.values, y.values)
    # per-question perfect (upper bound): 1.0 everywhere
    T = summarize(m, items)

    # Null: shuffle log-residuals within category (destroys within-video sharing), same oracle
    r = np.log(base / y)
    null = []
    for k in range(200):
        rr = r.copy()
        for c in CATS:
            ix = m.index[m.category == c]
            rr.loc[ix] = rng.permutation(r.loc[ix].values)
        pb = y * np.exp(rr)
        o, _ = oracle_preds(m, pb, "one")
        b_it = item_scores(pb.values, y.values); o_it = item_scores(o.values, y.values)
        null.append(dict(base=macro(b_it, m.category.values)["MRA"], orc=macro(o_it, m.category.values)["MRA"],
                         static=o_it[~m.motion.values].mean() - b_it[~m.motion.values].mean(),
                         motion=o_it[m.motion.values].mean() - b_it[m.motion.values].mean()))
    null = pd.DataFrame(null)
    null_gain = (null.orc - null.base)

    # Per-video table
    vt = []
    for vid, g in m.groupby("video_id"):
        it_b = items["baseline v1.parsed"][m.index.get_indexer(g.index)]
        it_o = items["A1: one factor / video"][m.index.get_indexer(g.index)]
        rv = r.loc[g.index]
        vt.append(dict(video=vid, cat=g.category.iloc[0], src=g.src.iloc[0], prior=g.pkind.iloc[0], n=len(g),
                       n_motion=int(g.motion.sum()), base=it_b.mean(), oracleA1=it_o.mean(), c=f1.loc[vid, "c"],
                       med_logres=float(np.median(rv)), mad_within=float(np.median(np.abs(rv - np.median(rv)))),
                       med_abs_logres=float(np.median(np.abs(rv)))))
    vt = pd.DataFrame(vt).set_index("video").sort_values(["cat", "video"])

    # Residual structure
    m2 = m.copy(); m2["r"] = r
    m2["rc"] = m2.r - m2.groupby("video_id").r.transform("median")
    # variance decomposition (robust: clip residuals to +-log(3))
    rcl = m2.r.clip(-np.log(3), np.log(3))
    vm = rcl.groupby(m2.video_id).transform("mean")
    between = float(np.var(vm)); within = float(np.var(rcl - vm)); total = float(np.var(rcl))
    # one-way ANOVA ICC
    g = m2.assign(rcl=rcl).groupby("video_id").rcl
    k = g.size(); n = len(m2); a = len(k)
    msb = float((k * (g.mean() - rcl.mean()) ** 2).sum() / (a - 1))
    msw = float(((rcl - vm) ** 2).sum() / (n - a))
    k0 = (n - (k ** 2).sum() / n) / (a - 1)
    icc = (msb - msw) / (msb + (k0 - 1) * msw)
    # fixed-effects regression of r on dorder within video
    m2["dord"] = m2.tord - m2.pord
    m2["dord_c"] = m2.dord - m2.groupby("video_id").dord.transform("mean")
    m2["rcl"] = rcl
    m2["rcl_c"] = rcl - vm
    w = m2.dord_c ** 2
    slope = float((m2.dord_c * m2.rcl_c).sum() / w.sum()) if w.sum() > 0 else np.nan
    # bootstrap over videos for the slope
    vids = m2.video_id.unique(); sl = []
    for b in range(2000):
        pick = rng.choice(vids, len(vids), replace=True)
        sub = pd.concat([m2[m2.video_id == v] for v in pick])
        ww = (sub.dord_c ** 2).sum()
        if ww > 0:
            sl.append(float((sub.dord_c * sub.rcl_c).sum() / ww))
    sl = np.array(sl)
    n_mixed = int((m2.groupby("video_id").dord.nunique() > 1).sum())
    # slope by prior kind
    slope_pk = {}
    for pk, sub in m2.groupby("pkind"):
        ww = (sub.dord_c ** 2).sum()
        slope_pk[pk] = (float((sub.dord_c * sub.rcl_c).sum() / ww) if ww > 0 else np.nan,
                        int((sub.groupby("video_id").dord.nunique() > 1).sum()))
    # residual table by prior kind x target kind
    rt = m2.groupby(["pkind", "tkind"]).agg(n=("r", "size"), videos=("video_id", "nunique"),
                                             median_r=("r", "median"),
                                             median_abs_r=("r", lambda s: float(np.median(np.abs(s)))),
                                             median_abs_r_centered=("rc", lambda s: float(np.median(np.abs(s)))))
    # within-video: static vs motion offsets in mixed videos
    mix = []
    for vid, gg in m2.groupby("video_id"):
        if gg.motion.any() and (~gg.motion).any():
            mix.append(dict(video=vid, prior=gg.pkind.iloc[0], cat=gg.category.iloc[0],
                            static_med_r=float(gg.r[~gg.motion].median()), motion_med_r=float(gg.r[gg.motion].median())))
    mix = pd.DataFrame(mix).set_index("video")
    mix["motion_minus_static"] = mix.motion_med_r - mix.static_med_r

    # Same oracle applied to other answer columns (does a shared scale exist in direct answers?)
    other = {}
    for col in ["v1.direct", "v1.geo", "v2.parsed", "oh.parsed", "astra.direct"]:
        p = R[col].copy()
        miss = p.isna()
        p[miss] = base[miss]  # fill gaps with base so the oracle is comparable
        o, _ = oracle_preds(m, p, "one")
        bi, oi = item_scores(p.values, y.values), item_scores(o.values, y.values)
        other[col] = dict(base=macro(bi, m.category.values)["MRA"], oracleA1=macro(oi, m.category.values)["MRA"],
                          gain_static=oi[~m.motion.values].mean() - bi[~m.motion.values].mean(),
                          gain_motion=oi[m.motion.values].mean() - bi[m.motion.values].mean())
    other = pd.DataFrame(other).T; other.index.name = "answers"

    # Excluding suspect labels
    ns = ~m.suspect.values
    sus = {}
    for name, it in items.items():
        d = macro(it, m.category.values, ns); sus[name] = d
    sus = pd.DataFrame(sus).T; sus.index.name = "variant (excl. 12 suspect GT)"

    with open(f"{OUT}.md", "w") as fh:
        fh.write("### Oracle A summary (v1.parsed, 159 q / 24 videos)\n\n" + md_table(T) + "\n\n")
        fh.write(f"Null (residuals shuffled within category, 200 reps): one-factor oracle gain on MRA "
                 f"mean {null_gain.mean():.3f} (5-95% {null_gain.quantile(.05):.3f}..{null_gain.quantile(.95):.3f}); "
                 f"static {null.static.mean():.3f}, motion {null.motion.mean():.3f}.\n\n")
        fh.write("### Excluding suspect labels\n\n" + md_table(sus) + "\n\n")
        fh.write("### Per video\n\n" + md_table(vt) + "\n\n")
        fh.write(f"### Residual structure\n\nVariance of clipped log residual: total {total:.4f}, between-video "
                 f"(of means) {between:.4f}, within {within:.4f}; ANOVA ICC {icc:.2f}.\n\n"
                 f"Within-video slope of log residual on (target order - prior order): {slope:.3f} "
                 f"(bootstrap over videos 90% CI {np.quantile(sl, .05):.3f}..{np.quantile(sl, .95):.3f}); "
                 f"videos with mixed orders: {n_mixed}. By prior kind: "
                 + ", ".join(f"{k} {v[0]:.3f} ({v[1]} videos)" for k, v in slope_pk.items()) + "\n\n")
        fh.write(md_table(rt) + "\n\n")
        fh.write("### Mixed videos: median log residual of static vs motion targets\n\n" + md_table(mix) + "\n\n")
        fh.write("### One-factor oracle on other answer columns (gaps filled with v1.parsed)\n\n" + md_table(other) + "\n")
    json.dump(dict(null_gain_mean=float(null_gain.mean()), slope=slope, slope_ci=[float(np.quantile(sl, .05)), float(np.quantile(sl, .95))],
                   icc=float(icc), between=between, within=within), open(f"{OUT}.json", "w"), indent=1)
    vt.to_csv(f"{OUT}_per_video.csv")
    print(open(f"{OUT}.md").read())


if __name__ == "__main__":
    main()
