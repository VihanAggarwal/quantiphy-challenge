# Oracles and multi-model combination on validation (QuantiPhy Track A)

Scope: validation only (159 questions, 24 videos, 6 per category). Labels are used only to evaluate. Every
selection is judged leave-one-video-out (LOVO), and uncertainty comes from a bootstrap over videos stratified by
category (2000 resamples, 6 videos per category). No paid API calls were made. The Gemini numbers come from the
team's own background runs (see section 3.4). Code and raw outputs are in this folder (`*.py`, `*.md`, `*.csv`).

## Summary

1. **Oracle A (one factor per video).** It lifts v1.parsed from .786 to .828 (+.043). A free factor on about 6.6
   questions per video also fits noise, and a shuffled-residual null predicts +.027 ± .005 from that alone. So
   **a truly shared per-video scale explains only about +.016 MRA (7% of the loss).** That share is concentrated in
   S2 (+.047 above the null, mainly simulation_0089 and simulation_0171) and in motion targets under size priors
   (+.053 above the null on those 41 questions). Dynamic-prior static targets show little: +.008 above the null,
   p = .08. There is no sign that the error depends on the derivative order of the prior and target (slope +.010,
   90% CI -.076..+.096). A second factor per video (static/motion, or c·β^Δorder) gains no more than the null
   predicts. **The large per-video offsets are shared by all models** (per-video offsets correlate .84-.95 across
   Claude runs and .48-.75 with Astra). An ensemble therefore cannot remove them; only a better measurement of the
   prior and of motion can, or the offsets are label issues.
2. **Oracle B (best of geometry vs direct per question).** +.031 (90% CI +.016..+.049) is the ceiling. Every LOVO
   router (per category, category × motion, category × source × kind) **loses** .017-.047. In every cell both answers
   win some questions, and the current hand routing is already the best rule at cell level. Routing is not a lever.
3. **Model combination.** No fixed combination rule beats v1.parsed with confidence. The best fixed rule is
   "v1.parsed, with the direct-routed rows replaced by the median of 3 Claude direct + Astra + Gemini": +.009
   (95% CI -.003..+.025). Relative to the structure already deployed on test (a 3-run Claude median on 3D non-lab),
   adding Astra and Gemini gives +.003 (-.003..+.007). **Gemini 3.1 Pro (native video, thinking high) is far weaker
   than Claude:** MRA .584 with its gaps filled by v1.parsed, and .575 vs .783 on the same 156 questions. Its errors
   are almost uncorrelated with the other models (r ≈ .22), but they are too large to help on average. Astra is
   .747 vs .777 on its 146 answered questions, with error correlation .5-.7 against Claude; blending it into all
   answers loses -.009.
4. **One honest positive.** A nested LOVO, which picks both the scheme and the rule inside each fold, chooses
   "best rule per category from the full pool" in all 24 folds and scores **+.025 (95% CI +.005..+.043)**. Per
   category: S2 +.009, D2 +.030, S3 +.033, D3 +.028. Only the S3 part is consistent and plausible: in all 6 folds
   it picks the cross-vendor median **median(v1, Astra, Gemini)**, which helps 4 of 6 S3 videos and hurts none.
   The D2 and D3 parts pick a single medium-effort Claude run, which is almost certainly luck and in any case
   cannot be deployed. The same 3-vendor median **loses -.092 in D3**, where Gemini is poor (.472). Against the
   deployed-like structure, using it on S3 only gives S3 +.049 (+.010..+.081), MRA +.012. It is a post-hoc,
   6-video finding.
5. **Recommendation.** Do not spend uploads or money on general ensembling or routing. The one combination worth
   a cheap test is the 3-vendor median on S3 3D non-lab test rows: 244 questions, 46 videos, about $16 of Astra
   plus about $13 of Gemini at the measured validation cost per question. Treat its expected test gain as
   +0.000..+0.008 MRA. The bigger lesson from the oracles is that the remaining loss is mostly per-question error
   rather than shared scale. The shared part that does exist (S2 prior measurement, motion under size priors) is
   common to every model, so it needs measurement work (prior extent over frames, segmented-twin masks, motion
   fits), not more votes.
