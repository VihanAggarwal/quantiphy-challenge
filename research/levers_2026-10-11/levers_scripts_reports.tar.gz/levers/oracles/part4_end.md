## 4. What this means for the next steps

- **Calibration lever (expert idea 3, the dynamic-prior calibrator).** On validation a shared per-video scale is
  worth about +.016 MRA beyond chance, even with perfect knowledge. It is largest in S2 (2D size priors: the
  pixel extent of the prior object, e.g. a flapping bird's length) and in motion targets under size priors. It is
  small for dynamic-prior static targets (+.008, p = .08; 12 videos). The test diagnostics put D2 static at .791,
  so the test may hold more than validation shows. Validation alone does not support ranking the dynamic-prior
  calibrator first; S2 prior extents and S2/S3 motion look at least as promising.
- **Kinematics/timing.** There is no derivative-order structure in the residuals, so a global time-base error is
  unlikely. The lab size-prior videos show motion answers below static answers within the same video (log
  -.35..-.61). That fits either inflated lab velocity labels (noted earlier) or real lab motion under-measurement.
  With 4 videos the two cannot be told apart.
- **Routing.** Leave it as it is: the oracle ceiling is +.031, and every learnable router loses.
- **Ensembling.** General ensembling is not worth money. The one exception is a targeted, cheap probe of the
  3-vendor median on S3 3D non-lab test rows (section 3.3), with a planning gain of +0.000..+0.008. If it is tried,
  keep stated-fact and family-pooled rows fixed. Re-sync twins afterwards, as the probe-7a ensemble did.
- **Gemini key.** Gemini 3.1 Pro alone is much weaker than Claude on this task (.575 vs .783 on the same
  questions). It has no value as a voter in D2/D3 and only as a tie-breaker in S3. If its $19 is spent, the S3
  non-lab subset (about $13 for 244 questions with native video) is the only use these data support.

## 5. Caveats and what I could not do

- 24 validation videos, 6 per category, 1-13 questions per video. Every per-category number rests on 6 videos,
  and the accel-prior rows on 4. The bootstrap CIs hold the LOVO predictions fixed, so they understate the
  variance of the selection itself.
- The rule pool was designed by me after looking at the per-model results; the gate and video-scale families were
  added after the first combination pass. Nested LOVO covers the choice among schemes, not my design choices. The
  S3 finding is post hoc.
- The oh/om/om2 runs use the 480p validation videos and older code paths, while v1/v2 use full-resolution
  frames. Their parsed answers are taken as written in their CSVs (not replayed with the current code).
- Validation has no family/twin post-rules applied, so "deployed-like" is only the 3-run-median part of the test
  pipeline. The test baseline (probe 5/7b) includes scene-family rules that may already capture part of any gain.
- The Gemini frames run stopped after 3 videos (not my job). The Gemini numbers come from the native-video run,
  which finished during this study. No API calls were made by me, and no test answers were set from labels.
- The A2/A3 null uses 60 repetitions and the subset null 100. The null shuffles residuals within category (or
  within subset), which also keeps the category's outliers; a different null, e.g. a parametric noise model,
  would shift the "excess" numbers by about ±.005.

## Files

`common.py` (loaders, MRA), `oracle_a.py` (+ `oracle_a.md`, `oracle_a_per_video.csv`), `oracle_a_null.py`
(+ `oracle_a_null.csv`), `oracle_a_table.py` (+ `oracle_a_table.md`), `oracle_a_subsets.py` (+ `.md`),
`oracle_b.py` (+ `oracle_b.md`), `oracle_bestofn.md`, `combo.py` (+ `combo_final.md`, `combo_final_rules.csv`,
`combo_final_models.csv`, `combo_final_val_predictions.csv` = validation predictions of every fixed rule;
`combo_nogem.md` = same study without Gemini; `combo_gem_checkpoint45.md`, `combo_gemsubset_checkpoint45.md` = the
45-minute checkpoint), `nested_lovo.py` (+ `nested_lovo_final.txt`), `deployable.py` (+ `deployable.md`),
`video_offsets.md`.
