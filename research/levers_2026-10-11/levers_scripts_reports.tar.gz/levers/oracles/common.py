"""Shared loaders for the oracle / combination study (validation only)."""
from __future__ import annotations

import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd

REPO = Path("/home/user/quantiphy-challenge")
sys.path.insert(0, str(REPO))
from qp.data import load_split  # noqa: E402
from qp.mra import THRESHOLDS  # noqa: E402

CATS = ("S2", "D2", "S3", "D3")
SUSPECT = {403, 2349, 2607, 3049, 3051, 1123, 1130, 1354, 1355, 3054, 139, 2276}
ORDER = {"size": 0, "distance": 0, "speed": 1, "accel": 2}


def target_kind(q: str) -> str:
    s = q.lower()
    if "acceleration" in s or "m/s^2" in s or "m/s²" in s:
        return "accel"
    if re.search(r"\b(speed|velocity)\b", s):
        return "speed"
    if "wingspan" in s:
        return "size"
    if re.search(r"\bdistance\b|how far|displacement|travel|apart|between", s):
        return "distance"
    return "size"


def prior_kind(p: str) -> str:
    s = p.lower()
    if "acc" in s or "m/s^2" in s or "m/s²" in s:
        return "accel"
    if re.search(r"speed|velocity|m/s", s):
        return "speed"
    return "size"


def load_meta() -> pd.DataFrame:
    df = load_split("val_hires")
    df["tkind"] = df["question"].map(target_kind)
    df["pkind"] = df["prior"].map(prior_kind)
    df["tord"] = df["tkind"].map(ORDER)
    df["pord"] = df["pkind"].map(ORDER)
    df["motion"] = df["tkind"].isin(["speed", "accel"])
    df["is3d"] = df["category"].str[1] == "3"
    df["src"] = df["video_source"]
    df["suspect"] = df["qid"].isin(SUSPECT)
    return df.set_index("qid", drop=False)


RUNS = {
    # name: (csv, columns)
    "v1": ("runs/val_hr_v1_high/val_hires.csv", ("parsed", "geo", "direct")),
    "v2": ("runs/val_hr_v2_high/val_hires.csv", ("parsed", "geo", "direct")),
    "oh": ("runs/val_opus_high/val.csv", ("parsed", "geo", "direct")),
    "om": ("runs/val_opus_med/val.csv", ("parsed", "geo", "direct")),
    "om2": ("runs/val_opus_med2/val.csv", ("parsed", "geo", "direct")),
    # extras (reported, not in the main combination sets unless noted)
    "ol": ("runs/val_opus_low/val.csv", ("parsed", "geo", "direct")),
    "ox": ("runs/val_opus_xhigh/val.csv", ("parsed", "geo", "direct")),
    "v2m": ("runs/val_hr_v2_med/val_hires.csv", ("parsed", "geo", "direct")),
    "fab": ("runs/val_fable_high/val.csv", ("parsed", "geo", "direct")),
    "astra": ("runs/val_astra_high/val_hires.csv", ("direct",)),
}


def gem_from_records(rec_dir=REPO / "runs/val_gem31pro_frames/val_hires/records") -> pd.Series:
    """Same parsing as scripts/run_gemini_direct.py::_write, but usable while the run is in progress."""
    import json, math
    vals = {}
    for p in sorted(Path(rec_dir).glob("*.json")):
        try:
            rec = json.loads(p.read_text())
        except Exception:
            continue
        for a in rec.get("answers", []) or []:
            try:
                x = abs(float(a["value"]))
                vals[int(a["qid"])] = x if math.isfinite(x) and x > 0 else math.nan
            except (KeyError, TypeError, ValueError):
                continue
    return pd.Series(vals, dtype=float)


def load_runs(meta: pd.DataFrame) -> pd.DataFrame:
    """Wide table indexed by qid: columns '<run>.<parsed|geo|direct>' (NaN where missing/invalid)."""
    out = pd.DataFrame(index=meta.index)
    for name, (path, cols) in RUNS.items():
        p = REPO / path
        if not p.exists():
            continue
        t = pd.read_csv(p).set_index("id")
        for c in cols:
            col = {"parsed": "parsed_value", "geo": "geo_value", "direct": "direct_value"}[c]
            v = pd.to_numeric(t[col], errors="coerce").abs() if col in t.columns else pd.Series(dtype=float)
            v = v.where(v > 0)
            out[f"{name}.{c}"] = v.reindex(meta.index)
    # Gemini 3.1 Pro: read the records directly (the runner writes its CSV only at the end).
    # gem  = native-video input run (runs/val_gem31pro_video, the run that is covering all 24 videos)
    # gemf = 16-32 frame input run (runs/val_gem31pro_frames; stopped after 3 videos)
    out["gem.direct"] = gem_from_records(REPO / "runs/val_gem31pro_video/val_hires/records").reindex(meta.index)
    out["gemf.direct"] = gem_from_records(REPO / "runs/val_gem31pro_frames/val_hires/records").reindex(meta.index)
    return out


def item_scores(pred, gt) -> np.ndarray:
    p = np.abs(np.asarray(pred, dtype=float))
    g = np.asarray(gt, dtype=float)
    with np.errstate(divide="ignore", invalid="ignore"):
        rel = np.abs(p - g) / g
    hits = np.zeros(len(g))
    for t in THRESHOLDS:
        hits += (rel < 1 - t)
    s = hits / len(THRESHOLDS)
    s[~np.isfinite(p)] = 0.0  # missing prediction scores 0, like the evaluator
    return s


def macro(items: np.ndarray, cats: np.ndarray, mask=None) -> dict:
    if mask is None:
        mask = np.ones(len(items), bool)
    per = {c: float(np.mean(items[(cats == c) & mask])) for c in CATS if ((cats == c) & mask).any()}
    per["MRA"] = float(np.mean([per[c] for c in CATS if c in per]))
    return per


def fmt(x, nd=3):
    if x is None or (isinstance(x, float) and not np.isfinite(x)):
        return ""
    return f"{x:.{nd}f}"


def md_table(df: pd.DataFrame, nd=3) -> str:
    cols = list(df.columns)
    lines = ["| " + " | ".join([str(df.index.name or "")] + [str(c) for c in cols]) + " |",
             "|" + "---|" * (len(cols) + 1)]
    for idx, row in df.iterrows():
        cells = []
        for c in cols:
            v = row[c]
            if isinstance(v, (float, np.floating)):
                cells.append(fmt(float(v), nd))
            else:
                cells.append(str(v))
        lines.append("| " + " | ".join([str(idx)] + cells) + " |")
    return "\n".join(lines)
