"""Nested LOVO: also select the LOVO *scheme* (pool x granularity) inside each outer fold, so that choosing the
best-looking scheme after the fact is accounted for. Reuses combo.py's rule definitions (validation only)."""
import sys

import numpy as np
import pandas as pd

src = open("combo.py").read().split("# ------------------------------------------------------------------ LOVO selection")[0]
src = src.replace("args = ap.parse_args()", f"args = ap.parse_args({sys.argv[1:]!r})")
exec(src)

vid = m.video_id.values
pool_rules = [r for r in rules if not r.startswith(("fab.", "v2m.", "ol.", "ox."))]
pool_models = ["v1.parsed", "v1.direct", "v1.geo", "v2.parsed", "v2.direct", "oh.parsed", "oh.direct", "astra.direct"] + G
pools = {"all rules": pool_rules, "single models": pool_models,
         "small set": [BASE, "median(C5 parsed)", "median(C3 direct)", "base; 3D non-lab -> median(C3 direct)",
                       "base; 3D non-lab -> median(C3 direct + astra)"] + (["base; 3D non-lab -> median(C3 direct + astra + gem)", "median(C5 parsed + astra + gem)"] if G else []),
         "video-scale": [BASE] + [r for r in rules if r.startswith("video scale")],
         "wgmean": [BASE] + [r for r in rules if r.startswith("wgmean")],
         "gate": [BASE] + [r for r in rules if r.startswith("gate")]}
keys = {"global": np.array(["all"] * len(m)), "cat": cats,
        "cat x motion": np.array([f"{c}|{x}" for c, x in zip(cats, m.motion.values)])}
IT = {r: items[r] for r in pool_rules}


def macro_mask(a, mask):
    cs = [c for c in CATS if ((cats == c) & mask).any()]
    return float(np.mean([a[(cats == c) & mask].mean() for c in cs]))


def lovo_pred(pool, kname, allowed):
    """LOVO predictions (item scores) for videos in `allowed`, training only on other allowed videos."""
    key = keys[kname]; pred = np.full(len(m), np.nan)
    for v in np.unique(vid[allowed]):
        te = vid == v; tr = allowed & ~te
        for k in np.unique(key[te]):
            s_te = te & (key == k); s_tr = tr & (key == k)
            if kname == "global":
                sc = {r: macro_mask(IT[r], tr) for r in pool}
            else:
                if s_tr.sum() < 5:
                    pred[s_te] = base_it[s_te]; continue
                sc = {r: IT[r][s_tr].mean() for r in pool}
            best = max(sc.values())
            pick = BASE if sc[BASE] >= best - 1e-12 else max(sc, key=sc.get)
            pred[s_te] = IT[pick][s_te]
    return pred


schemes = [(p, k) for p in pools for k in keys]
allv = np.ones(len(m), bool)
outer = {s: lovo_pred(pools[s[0]], s[1], allv) for s in schemes}
final = np.full(len(m), np.nan); chosen = []
for v in np.unique(vid):
    inner_allowed = vid != v
    sc = {}
    for s in schemes:
        p = lovo_pred(pools[s[0]], s[1], inner_allowed)
        sc[s] = macro_mask(p, inner_allowed)
    best = max(sc, key=sc.get)
    chosen.append(best)
    final[vid == v] = outer[best][vid == v]
res = {"nested LOVO (scheme chosen inside each fold)": macro_mask(final, allv)}
for s in schemes:
    res[f"LOVO {s[0]} / {s[1]}"] = macro_mask(outer[s], allv)
base_m = macro_mask(base_it, allv)
print(f"base {base_m:.4f}")
for k, v in sorted(res.items(), key=lambda x: -x[1]):
    print(f"{v - base_m:+.4f}  {k}")
print(pd.Series([f"{a}/{b}" for a, b in chosen]).value_counts())
# bootstrap of the nested result
diffs = []
for bs in BOOT:
    diffs.append(np.mean([final[np.concatenate([pos[v] for v in bs[c]])].mean() - base_it[np.concatenate([pos[v] for v in bs[c]])].mean() for c in bs]))
print("nested 95% CI", np.quantile(diffs, [.025, .975]).round(4), "P>0", np.mean(np.array(diffs) > 0))
for c in CATS:
    print(c, round(final[cats == c].mean() - base_it[cats == c].mean(), 3))
