"""Oracle A restricted to subsets: per video, one factor fitted on the subset's questions only; gain vs a
null where the subset's log residuals are shuffled across videos (same per-video counts)."""
import numpy as np
import pandas as pd

from common import item_scores, load_meta, load_runs, md_table
from oracle_a import best_factor

rng = np.random.default_rng(2)
m = load_meta(); R = load_runs(m); y = m.answer
base = R["v1.parsed"]
r = np.log(base / y)


def gain(sub, resid):
    tot_b = tot_o = 0.0
    for vid, g in sub.groupby("video_id"):
        p = (y.loc[g.index] * np.exp(resid.loc[g.index])).values
        c, _, s = best_factor(p, y.loc[g.index].values)
        tot_b += item_scores(p, y.loc[g.index].values).sum(); tot_o += s
    return (tot_o - tot_b) / len(sub)


rows = []
subsets = {}
for pk in ("size", "speed", "accel"):
    for mot in (False, True):
        subsets[f"prior={pk}, {'motion' if mot else 'static'} targets"] = (m.pkind == pk) & (m.motion == mot)
subsets["dynamic prior (D2+D3), static targets"] = m.pkind.isin(["speed", "accel"]) & ~m.motion
subsets["all static targets"] = ~m.motion
subsets["all motion targets"] = m.motion
for c in ("S2", "D2", "S3", "D3"):
    subsets[f"category {c}"] = m.category == c
subsets["3D non-lab (direct answers)"] = m.is3d & m.src.isin(["simulation", "segmentation"])
subsets["2D (geometry answers)"] = ~m.is3d
subsets["lab"] = m.src == "lab"
for name, sel in subsets.items():
    sub = m[sel]
    # only videos with >= 2 questions in the subset can share a factor; singletons are perfect-fit noise
    nq = sub.groupby("video_id").size()
    g_real = gain(sub, r)
    nulls = []
    for k in range(100):
        rr = r.copy()
        rr.loc[sub.index] = rng.permutation(r.loc[sub.index].values)
        nulls.append(gain(sub, rr))
    nulls = np.array(nulls)
    b = item_scores(base.loc[sub.index].values, y.loc[sub.index].values).mean()
    rows.append(dict(subset=name, n=len(sub), videos=sub.video_id.nunique(), singletons=int((nq == 1).sum()),
                     base=b, oracle_gain=g_real, null_gain=nulls.mean(), excess=g_real - nulls.mean(),
                     p_null_ge_real=float((nulls >= g_real).mean())))
T = pd.DataFrame(rows).set_index("subset")
open("oracle_a_subsets.md", "w").write(md_table(T) + "\n")
print(md_table(T))
