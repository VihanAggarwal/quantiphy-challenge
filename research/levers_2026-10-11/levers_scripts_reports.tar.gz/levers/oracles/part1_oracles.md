## 1. Oracle A: one multiplicative factor per video

**Setup.** Final answers of the best single configuration (`runs/val_hr_v1_high/val_hires.csv`, `parsed_value`,
MRA 0.786). For each of the 24 videos, the factor c that maximises the summed item score of c x answer over the
video's questions (exact search over the MRA breakpoints; ties go to the factor nearest 1). A1 = one factor per
video; A2 = one factor for static targets and one for motion targets; A3 = c x beta^(target order - prior order)
(order: size/distance 0, speed 1, acceleration 2), i.e. a free time-base error per video.

**A fitted factor always gains something, even when errors share nothing.** With 6.6 questions per video, a free
factor fits noise. The null below shuffles the log residuals log(pred/truth) across videos within each category (60
repetitions), which keeps every error but destroys any per-video sharing; "excess" = real gain - mean null gain is
the part that a genuinely shared per-video scale explains. Measured, 159 questions / 24 videos.

| oracle | subset | n | base | oracle | gain | null gain (sd) | **excess** | share of loss recovered (raw / excess) |
|---|---|---|---|---|---|---|---|---|
| A1 one factor | **MRA** | 159 | .786 | .828 | +.043 | +.027 (.005) | **+.016** | 20% / 7% |
| A1 | static targets | 100 | .784 | .822 | +.038 | +.025 (.006) | +.013 | 18% / 6% |
| A1 | motion targets | 59 | .783 | .827 | +.044 | +.030 (.012) | +.014 | 20% / 7% |
| A1 | size-prior videos (12) | 75 | .761 | .815 | +.053 | +.034 (.009) | +.020 | 22% / 8% |
| A1 | speed-prior videos (8) | 51 | .767 | .802 | +.035 | +.019 (.007) | +.017 | 15% / 7% |
| A1 | accel-prior videos (4) | 33 | .861 | .879 | +.018 | +.023 (.011) | -.005 | 13% / 0% |
| A1 | S2 | 32 | .709 | .803 | +.094 | +.046 (.014) | **+.047** | 32% / 16% |
| A1 | D2 | 37 | .924 | .941 | +.016 | +.010 (.004) | +.007 | 21% / 9% |
| A1 | S3 | 43 | .800 | .823 | +.023 | +.024 (.009) | -.001 | 12% / 0% |
| A1 | D3 | 47 | .709 | .747 | +.038 | +.029 (.009) | +.010 | 13% / 3% |
| A2 static + motion factors | MRA | 159 | .786 | .847 | +.062 | +.048 (.007) | +.014 | 29% / 7% |
| A3 c x beta^(order diff) | MRA | 159 | .786 | .851 | +.066 | +.049 (.007) | +.017 | 31% / 8% |

(Full table with every subset for A2/A3: `oracle_a_table.md`. Excluding the 12 suspect labels: base .814, A1 .854, A2 .874, A3 .878; same picture.)

**Subset oracles** (factor fitted on the subset's questions only, null = the subset's residuals shuffled across
videos, 100 repetitions; `oracle_a_subsets.md`):

| subset | n | videos | base | oracle gain | null gain | excess | p(null >= real) |
|---|---|---|---|---|---|---|---|
| size prior, static targets | 34 | 10 | .788 | +.065 | +.056 | +.008 | .23 |
| **size prior, motion targets** | 41 | 12 | .739 | +.102 | +.050 | **+.053** | **.00** |
| speed prior, static targets | 41 | 8 | .754 | +.041 | +.024 | +.017 | .07 |
| speed prior, motion targets | 10 | 4 | .820 | +.040 | +.041 | -.001 | .50 |
| accel prior, static targets | 25 | 4 | .828 | +.024 | +.030 | -.006 | .83 |
| accel prior, motion targets | 8 | 4 | .962 | +.038 | +.018 | +.020 | .03 |
| dynamic prior (D2+D3), static targets | 66 | 12 | .782 | +.035 | +.026 | +.008 | .08 |
| 2D (geometry answers) | 69 | 12 | .825 | +.052 | +.018 | +.035 | .00 |
| 3D non-lab (direct answers) | 52 | 6 | .794 | +.035 | +.023 | +.011 | .00 |
| lab | 38 | 6 | .695 | +.026 | +.033 | -.007 | .71 |

**Where the shared offsets are (per video, `oracle_a_per_video.csv`).** Six of 24 videos need |log c| > 0.1:
simulation_0089 (S2, prior = small bird length; c = 0.65, all six answers 1.25-1.55x too high, video score .48 -> .82),
simulation_0009 (D3 sim, speed prior, direct answers ~0.57x too low on 8 of 9, c = 1.82, .50 -> .62),
captured_0027s (S3 lab, c = 1.23), simulation_0171 (S2, c = 0.81, astronaut speeds/accelerations too high),
captured_0061 (D3 lab, c = 1.15) and internet_0001 (S2, c = 1.10). The rest sit at c ~ 1.

**These offsets are shared by every model, so no ensemble can remove them.** Per-video median log residuals
(`video_offsets.md`) correlate 0.84-0.95 across the five Claude runs and 0.48-0.75 between Claude and GPT-6 Astra;
simulation_0089 is +0.31..+0.56 in every Claude run, Astra and Gemini; captured_0027s is -0.34..-0.71 in every Claude
run (Astra -1.46); simulation_0009 is -0.21..-0.56 in all of them. They are either a shared misreading of the prior
(simulation_0089: a flapping bird's "length"), shared 3D-scale misjudgement (simulation_0009) or label issues
(the lab velocities flagged earlier as inflated), not run-to-run noise.

**Residual structure.** Log residuals (clipped at 3x) have total variance 0.120: 0.037 between video means and
0.083 within videos (one-way ICC 0.20). So most error is question-specific; the common per-video offset is a minority
component. Within-video dependence on derivative order: slope of the log residual on (target order - prior order),
with video fixed effects, is +0.010 (90% video-bootstrap CI -0.076..+0.096; 20 videos mix orders); by prior kind
accel +0.05 (4 videos), size -0.02 (12), speed +0.08 (4). No evidence of a time-base (beta^order) error, and A3's extra
parameter gains no more than the null predicts (excess +.017 vs A1 +.016). The one structured pattern is in lab
size-prior videos: motion answers sit well below static answers within the same video (captured_0027s -0.61,
captured_0034as -0.35 in log; also simulation_0015 -0.17 and captured_0061 -0.29 with a speed prior), i.e. lab motion
under-prediction relative to the labels (consistent with the earlier finding that a few lab scenes have inflated
speed labels; it cannot be separated from a real motion-measurement error with 4 videos).

**Reading for the expert's hypothesis A.** On validation, a shared scale error from dynamic priors hitting static
targets is weak: dynamic-prior static targets give +.008 excess (p = .08), D2 +.007. The real shared-offset signal
is in **2D size-prior videos (S2: +.047 excess, 16% of the S2 loss) and motion targets under size priors (+.053
excess on those 41 questions)**, i.e. prior-object pixel measurement (S2 scale) and motion measurement in S2/S3. Even
a perfect per-video scale would only recover ~7% of the total loss beyond chance (+.016 MRA); the remaining ~93% is
per-question error (object/dimension/time/measurement), which matches the test diagnostics ("losses are spread").
Caveat: 24 videos; the accel-prior rows rest on 4 videos.

## 2. Oracle B: geometry vs direct, per question

Same run (`v1.geo`, `v1.direct`; geometry is missing on 3 questions and falls back to direct). Oracle B takes the
better of the two per question. The LOVO routers choose geometry or direct per cell on the other 23 videos (cells
need >= 3 training questions from >= 2 videos, else the current routing is kept). Measured.

| answer | S2 | D2 | S3 | D3 | MRA | static | motion | dMRA vs current | 90% CI (video bootstrap) |
|---|---|---|---|---|---|---|---|---|---|
| geometry everywhere | .709 | .924 | .670 | .653 | .739 | .741 | .717 | -.046 | -.080..-.012 |
| direct everywhere | .678 | .911 | .788 | .687 | .766 | .756 | .780 | -.019 | -.037..-.004 |
| **current routing (parsed)** | .709 | .924 | .800 | .709 | **.786** | .784 | .783 | 0 | |
| **Oracle B** | .756 | .927 | .819 | .764 | **.816** | .812 | .820 | **+.031** | +.016..+.049 |
| LOVO router per category | .709 | .924 | .788 | .640 | .766 | .746 | .785 | -.020 | -.035..-.002 |
| LOVO router per cat x motion | .666 | .916 | .726 | .647 | .739 | .733 | .737 | -.047 | -.077..-.019 |
| LOVO router per cat x source x motion | .709 | .924 | .758 | .670 | .766 | .752 | .776 | -.020 | -.041..+.000 |
| LOVO router per cat x source x kind | .713 | .924 | .767 | .670 | .769 | .752 | .785 | -.017 | -.036..+.001 |

Where the oracle headroom is (mean item score, current -> oracle B; `oracle_b.md` has all cells):

| cell | n | current | oracle B | gain | geo better / direct better |
|---|---|---|---|---|---|
| S2 accel | 7 | .500 | .614 | +.114 | 5 / 1 |
| S2 size | 9 | .644 | .689 | +.044 | 1 / 2 |
| S2 speed | 13 | .815 | .838 | +.023 | 2 / 3 |
| D2 (all kinds) | 37 | .924 | .927 | +.003 | 5 / 1 |
| S3 size | 19 | .832 | .837 | +.005 | 2 / 8 |
| S3 speed | 16 | .781 | .825 | +.044 | 2 / 4 |
| D3 size | 31 | .739 | .790 | +.052 | 14 / 8 |
| D3 speed | 10 | .790 | .830 | +.040 | 0 / 6 |
| D3 distance | 6 | .417 | .517 | +.100 | 2 / 1 |
| by source: D3 simulation (direct-routed) | 27 | .752 | .822 | +.070 | 7 / 11 |

**Routing is not a lever.** The ceiling is +.031 MRA, but in every cell both answers win on some questions (e.g. D3
size 14 vs 8), so the winner is not predictable from category/source/kind: every LOVO router loses (-.017 to -.047).
The current hand routing (2D geometry, 3D non-lab direct, lab sizes geometry / motion direct) is already the best
available cell-level rule on these data. A per-question router would need a question-level reliability signal; the
disagreement-gated rules in section 3 are the label-free version of that and give at most +.004 LOVO.

Best-of-N per question (`oracle_bestofn.md`, a hindsight ceiling for any per-question selector, not achievable):
v1 geo|direct .816; + v2 parsed|direct .846; 5 Claude runs x geo|direct .876; all Claude + Astra .889.
