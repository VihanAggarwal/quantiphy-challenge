## 3. Multi-model combination

### 3.1 Inputs

| key | run | input | notes |
|---|---|---|---|
| v1 | val_hr_v1_high | Claude Opus 5.5, prompt v1, high, full-res frames | the baseline (`parsed` = routed pipeline answer) |
| v2 | val_hr_v2_high | Claude, prompt v2, high, 1280 px, up to 44 frames | |
| oh / om / om2 | val_opus_high / med / med2 | Claude, prompt v1, 480p validation videos | om, om2 = medium effort |
| fab, ol, ox, v2m | extras (claude-fable-5-1 high, opus low, opus xhigh, v2 medium) | | reported only, not in the combination pools |
| astra | val_astra_high | GPT-6 Astra, direct answers on the same frames | 146/159 answered |
| gem | val_gem31pro_video | Gemini 3.1 Pro, native video (12 fps), thinking high | 156/159 answered (read from its records) |
| gemf | val_gem31pro_frames | Gemini 3.1 Pro, 16-32 frames | **stopped after 3 videos (23 answers)**; see 3.4 |

`parsed` = the pipeline's routed answer, `direct` = the model's own number, `geo` = geometry solver. C5p = parsed
answers of {v1, v2, oh, om, om2}, C3d = direct answers of {v1, v2, oh} (the validation analogue of the three test
runs median-ed on 3D non-lab), "deployed-like" = v1.parsed with 3D non-lab rows replaced by median(C3d), the
structure of the current test submission before the family rules.

### Per-model scores

Category columns and the gap-filled MRA fill a model's missing answers with v1.parsed; source and kind columns are means over the questions the model answered.

| model | coverage | MRA (missing=0) | MRA (gaps=v1.parsed) | S2 | D2 | S3 | D3 | internet | lab | simulation | segmentation | size | distance | speed | accel | base on same q | model on same q |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| v1.parsed | 159/159 | 0.786 | 0.786 | 0.709 | 0.924 | 0.800 | 0.709 | 0.914 | 0.695 | 0.742 | 0.933 | 0.796 | 0.713 | 0.830 | 0.600 | 0.784 | 0.784 |
| v1.direct | 159/159 | 0.766 | 0.766 | 0.678 | 0.911 | 0.788 | 0.687 | 0.914 | 0.655 | 0.722 | 0.933 | 0.776 | 0.640 | 0.836 | 0.558 | 0.784 | 0.765 |
| v1.geo | 156/159 | 0.730 | 0.739 | 0.709 | 0.924 | 0.670 | 0.653 | 0.914 | 0.681 | 0.681 | 0.789 | 0.740 | 0.793 | 0.789 | 0.442 | 0.789 | 0.737 |
| v2.parsed | 159/159 | 0.783 | 0.783 | 0.706 | 0.916 | 0.779 | 0.730 | 0.907 | 0.692 | 0.747 | 0.911 | 0.808 | 0.707 | 0.802 | 0.608 | 0.784 | 0.782 |
| v2.direct | 159/159 | 0.770 | 0.770 | 0.637 | 0.922 | 0.793 | 0.730 | 0.910 | 0.708 | 0.719 | 0.911 | 0.806 | 0.687 | 0.811 | 0.500 | 0.784 | 0.773 |
| oh.parsed | 159/159 | 0.782 | 0.782 | 0.725 | 0.916 | 0.758 | 0.730 | 0.903 | 0.663 | 0.761 | 0.906 | 0.811 | 0.693 | 0.800 | 0.592 | 0.784 | 0.780 |
| oh.direct | 159/159 | 0.728 | 0.728 | 0.644 | 0.824 | 0.735 | 0.709 | 0.886 | 0.611 | 0.686 | 0.906 | 0.746 | 0.647 | 0.791 | 0.475 | 0.784 | 0.730 |
| om.parsed | 159/159 | 0.769 | 0.769 | 0.716 | 0.954 | 0.709 | 0.698 | 0.914 | 0.666 | 0.749 | 0.794 | 0.805 | 0.667 | 0.804 | 0.442 | 0.784 | 0.764 |
| om.direct | 159/159 | 0.708 | 0.708 | 0.641 | 0.859 | 0.681 | 0.649 | 0.914 | 0.574 | 0.669 | 0.794 | 0.715 | 0.653 | 0.796 | 0.342 | 0.784 | 0.705 |
| om2.parsed | 159/159 | 0.775 | 0.775 | 0.725 | 0.884 | 0.753 | 0.738 | 0.879 | 0.682 | 0.758 | 0.861 | 0.800 | 0.687 | 0.809 | 0.558 | 0.784 | 0.774 |
| om2.direct | 159/159 | 0.734 | 0.734 | 0.634 | 0.819 | 0.726 | 0.755 | 0.879 | 0.671 | 0.686 | 0.861 | 0.760 | 0.667 | 0.789 | 0.467 | 0.784 | 0.738 |
| fab.parsed | 159/159 | 0.749 | 0.749 | 0.694 | 0.876 | 0.702 | 0.726 | 0.859 | 0.663 | 0.726 | 0.839 | 0.779 | 0.707 | 0.787 | 0.425 | 0.784 | 0.748 |
| fab.direct | 159/159 | 0.719 | 0.719 | 0.669 | 0.832 | 0.691 | 0.683 | 0.890 | 0.597 | 0.680 | 0.844 | 0.718 | 0.700 | 0.789 | 0.450 | 0.784 | 0.717 |
| astra.direct | 146/159 | 0.700 | 0.759 | 0.675 | 0.916 | 0.795 | 0.649 | 0.897 | 0.605 | 0.698 | 0.972 | 0.757 | 0.647 | 0.789 | 0.658 | 0.777 | 0.747 |
| gem.direct | 156/159 | 0.565 | 0.584 | 0.625 | 0.565 | 0.674 | 0.472 | 0.636 | 0.568 | 0.533 | 0.661 | 0.565 | 0.567 | 0.660 | 0.244 | 0.783 | 0.575 |

### Pairwise: median |log ratio| of answers

| median |log a/b| | v1.p | v1.d | v1.geo | v2.p | v2.d | oh.p | oh.d | om.d | om2.d | astra | gem |
|---|---|---|---|---|---|---|---|---|---|---|---|
| v1.p | 0.000 | 0.006 | 0.000 | 0.027 | 0.032 | 0.019 | 0.043 | 0.076 | 0.054 | 0.055 | 0.307 |
| v1.d | 0.006 | 0.000 | 0.048 | 0.043 | 0.033 | 0.032 | 0.028 | 0.051 | 0.037 | 0.045 | 0.343 |
| v1.geo | 0.000 | 0.048 | 0.000 | 0.041 | 0.059 | 0.035 | 0.097 | 0.100 | 0.072 | 0.072 | 0.316 |
| v2.p | 0.027 | 0.043 | 0.041 | 0.000 | 0.004 | 0.027 | 0.049 | 0.078 | 0.047 | 0.062 | 0.286 |
| v2.d | 0.032 | 0.033 | 0.059 | 0.004 | 0.000 | 0.036 | 0.044 | 0.076 | 0.043 | 0.070 | 0.285 |
| oh.p | 0.019 | 0.032 | 0.035 | 0.027 | 0.036 | 0.000 | 0.008 | 0.067 | 0.051 | 0.065 | 0.318 |
| oh.d | 0.043 | 0.028 | 0.097 | 0.049 | 0.044 | 0.008 | 0.000 | 0.031 | 0.031 | 0.109 | 0.381 |
| om.d | 0.076 | 0.051 | 0.100 | 0.078 | 0.076 | 0.067 | 0.031 | 0.000 | 0.047 | 0.108 | 0.349 |
| om2.d | 0.054 | 0.037 | 0.072 | 0.047 | 0.043 | 0.051 | 0.031 | 0.047 | 0.000 | 0.082 | 0.328 |
| astra | 0.055 | 0.045 | 0.072 | 0.062 | 0.070 | 0.065 | 0.109 | 0.108 | 0.082 | 0.000 | 0.277 |
| gem | 0.307 | 0.343 | 0.316 | 0.286 | 0.285 | 0.318 | 0.381 | 0.349 | 0.328 | 0.277 | 0.000 |

### Pairwise: Spearman correlation of log residuals (clipped at 3x)

| Spearman r of log residuals | v1.p | v1.d | v1.geo | v2.p | v2.d | oh.p | oh.d | om.d | om2.d | astra | gem |
|---|---|---|---|---|---|---|---|---|---|---|---|
| v1.p | 1.00 | 0.92 | 0.79 | 0.80 | 0.82 | 0.83 | 0.77 | 0.73 | 0.80 | 0.63 | 0.22 |
| v1.d | 0.92 | 1.00 | 0.72 | 0.75 | 0.84 | 0.82 | 0.84 | 0.81 | 0.83 | 0.69 | 0.24 |
| v1.geo | 0.79 | 0.72 | 1.00 | 0.73 | 0.75 | 0.73 | 0.68 | 0.57 | 0.66 | 0.53 | 0.30 |
| v2.p | 0.80 | 0.75 | 0.73 | 1.00 | 0.92 | 0.77 | 0.70 | 0.56 | 0.65 | 0.51 | 0.23 |
| v2.d | 0.82 | 0.84 | 0.75 | 0.92 | 1.00 | 0.80 | 0.76 | 0.63 | 0.72 | 0.63 | 0.24 |
| oh.p | 0.83 | 0.82 | 0.73 | 0.77 | 0.80 | 1.00 | 0.92 | 0.69 | 0.76 | 0.60 | 0.20 |
| oh.d | 0.77 | 0.84 | 0.68 | 0.70 | 0.76 | 0.92 | 1.00 | 0.79 | 0.78 | 0.63 | 0.21 |
| om.d | 0.73 | 0.81 | 0.57 | 0.56 | 0.63 | 0.69 | 0.79 | 1.00 | 0.81 | 0.70 | 0.24 |
| om2.d | 0.80 | 0.83 | 0.66 | 0.65 | 0.72 | 0.76 | 0.78 | 0.81 | 1.00 | 0.62 | 0.23 |
| astra | 0.63 | 0.69 | 0.53 | 0.51 | 0.63 | 0.60 | 0.63 | 0.70 | 0.62 | 1.00 | 0.24 |
| gem | 0.22 | 0.24 | 0.30 | 0.23 | 0.24 | 0.20 | 0.21 | 0.24 | 0.23 | 0.24 | 1.00 |

v1.direct is nearly identical to v1.parsed (median |log ratio| .006): in 2D, Claude's own number comes from its own
annotations, so it is not an independent second opinion. Claude runs disagree by 2-8% per question and their errors
correlate .7-.9. Astra disagrees by about 6% with error correlation .5-.7. Gemini disagrees by about 30% with
error correlation about .2.

### 3.2 Combination rules (all 159 questions, Gemini included)

Fixed rules need no selection. "LOVO pick [pool] per cell" chooses, for each held-out video, the rule with the best
mean item score in that cell on the other 23 videos. dMRA is measured against v1.parsed. The 95% CI comes from the
category-stratified video bootstrap of the paired difference. "d vs deployed-like" compares with the structure
already used on test. Families: median / gmean / trim = median, geometric mean or trimmed log-mean over the listed
answers; gate = keep v1.parsed unless |log(v1 / consensus of the others)| > T, then take the median of all; wgmean
= v1^(1-w) · consensus^w per question; video scale = v1 × exp(w · median over the video of log(consensus / v1)),
a label-free version of oracle A. The full table with about 100 rules is in `combo_final.md`.

| rule (159 q / 24 videos) | S2 | D2 | S3 | D3 | MRA | dMRA | 95% CI | P(>0) | d vs deployed-like | dMRA excl. suspect |
|---|---|---|---|---|---|---|---|---|---|---|
| v1.parsed | 0.709 | 0.924 | 0.800 | 0.709 | 0.786 | 0.000 | +0.000..+0.000 | 0.000 | -0.004 | 0.000 |
| v2.parsed | 0.706 | 0.916 | 0.779 | 0.730 | 0.783 | -0.003 | -0.032..+0.028 | 0.438 | -0.007 | -0.004 |
| oh.parsed | 0.725 | 0.916 | 0.758 | 0.730 | 0.782 | -0.003 | -0.028..+0.026 | 0.401 | -0.007 | -0.002 |
| v1.direct | 0.678 | 0.911 | 0.788 | 0.687 | 0.766 | -0.019 | -0.039..-0.001 | 0.018 | -0.023 | -0.022 |
| astra.direct | 0.675 | 0.916 | 0.795 | 0.649 | 0.759 | -0.027 | -0.064..+0.005 | 0.051 | -0.031 | -0.027 |
| gem.direct | 0.625 | 0.565 | 0.674 | 0.472 | 0.584 | -0.201 | -0.267..-0.131 | 0.000 | -0.205 | -0.212 |
| median(C5 parsed) | 0.722 | 0.941 | 0.770 | 0.723 | 0.789 | 0.003 | -0.013..+0.023 | 0.614 | -0.001 | 0.003 |
| trim(C5 parsed) | 0.731 | 0.930 | 0.774 | 0.719 | 0.789 | 0.003 | -0.015..+0.022 | 0.621 | -0.001 | 0.002 |
| median(C3 direct) | 0.662 | 0.905 | 0.770 | 0.711 | 0.762 | -0.023 | -0.053..+0.005 | 0.052 | -0.027 | -0.026 |
| median(C5 parsed + astra) | 0.719 | 0.938 | 0.774 | 0.719 | 0.788 | 0.002 | -0.012..+0.018 | 0.590 | -0.002 | 0.001 |
| median(C5 parsed + astra + gem) | 0.722 | 0.938 | 0.774 | 0.719 | 0.788 | 0.003 | -0.011..+0.019 | 0.630 | -0.001 | 0.002 |
| trim(C5 parsed + astra + gem) | 0.713 | 0.932 | 0.798 | 0.723 | 0.792 | 0.006 | -0.012..+0.025 | 0.742 | 0.002 | 0.004 |
| gmean(C5 parsed + astra + gem) | 0.731 | 0.903 | 0.779 | 0.715 | 0.782 | -0.004 | -0.029..+0.024 | 0.416 | -0.007 | -0.004 |
| gmean(v1.parsed, astra) | 0.681 | 0.932 | 0.791 | 0.700 | 0.776 | -0.009 | -0.025..+0.004 | 0.087 | -0.013 | -0.009 |
| median(v1.parsed, astra, gem) | 0.684 | 0.924 | 0.833 | 0.617 | 0.765 | -0.021 | -0.048..+0.007 | 0.098 | -0.025 | -0.027 |
| median(C3 direct + astra + gem) | 0.672 | 0.908 | 0.793 | 0.719 | 0.773 | -0.013 | -0.038..+0.012 | 0.148 | -0.016 | -0.015 |
| base; 3D non-lab -> median(C3 direct) | 0.709 | 0.924 | 0.784 | 0.740 | 0.789 | 0.004 | -0.008..+0.022 | 0.644 | 0.000 | 0.005 |
| base; 3D non-lab -> median(C3 direct + astra) | 0.709 | 0.924 | 0.798 | 0.728 | 0.790 | 0.004 | -0.003..+0.016 | 0.738 | 0.000 | 0.005 |
| base; 3D non-lab -> median(C3 direct + astra + gem) | 0.709 | 0.924 | 0.802 | 0.732 | 0.792 | 0.006 | -0.004..+0.023 | 0.760 | 0.003 | 0.008 |
| base; direct-routed rows -> median(C3 direct + astra + gem) | 0.709 | 0.924 | 0.805 | 0.738 | 0.794 | 0.009 | -0.003..+0.025 | 0.891 | 0.005 | 0.010 |
| gate |log base/cons|>0.2 -> median [C5p + astra] | 0.713 | 0.938 | 0.795 | 0.723 | 0.792 | 0.007 | -0.002..+0.017 | 0.917 | 0.003 | 0.006 |
| gate |log base/cons|>0.2 -> median [C5p + astra + gem] | 0.713 | 0.930 | 0.791 | 0.726 | 0.790 | 0.004 | -0.005..+0.014 | 0.802 | 0.000 | 0.004 |
| wgmean base^0.75 x cons^0.25 [v2.p, oh.p, astra, gem] | 0.709 | 0.922 | 0.807 | 0.728 | 0.791 | 0.006 | -0.001..+0.013 | 0.949 | 0.002 | 0.005 |
| video scale w=0.50 [v2.p, oh.p, astra, gem] | 0.706 | 0.916 | 0.800 | 0.709 | 0.783 | -0.003 | -0.010..+0.003 | 0.167 | -0.007 | -0.003 |
| video scale w=1.00 [other Claude (v2.p, oh.p)] | 0.722 | 0.908 | 0.802 | 0.715 | 0.787 | 0.001 | -0.007..+0.010 | 0.627 | -0.003 | 0.001 |
| LOVO pick [single models] per cat | 0.703 | 0.878 | 0.747 | 0.677 | 0.751 | -0.034 | -0.055..-0.018 | 0.000 | -0.038 | -0.032 |
| LOVO pick [single models] per cat x src x kind | 0.666 | 0.903 | 0.765 | 0.700 | 0.758 | -0.027 | -0.051..-0.007 | 0.002 | -0.031 | -0.023 |
| LOVO pick [small set] per cat | 0.722 | 0.924 | 0.800 | 0.706 | 0.788 | 0.003 | -0.003..+0.009 | 0.817 | -0.001 | 0.003 |
| LOVO pick [gated-median family] per global | 0.713 | 0.927 | 0.795 | 0.723 | 0.790 | 0.004 | -0.008..+0.016 | 0.747 | 0.000 | 0.004 |
| LOVO pick [video-scale family] per global | 0.713 | 0.905 | 0.800 | 0.711 | 0.782 | -0.003 | -0.011..+0.002 | 0.107 | -0.007 | -0.003 |
| LOVO pick [weighted-gmean family] per global | 0.706 | 0.908 | 0.784 | 0.702 | 0.775 | -0.011 | -0.027..+0.005 | 0.113 | -0.014 | -0.015 |
| LOVO pick [all rules] per global | 0.703 | 0.900 | 0.786 | 0.721 | 0.778 | -0.008 | -0.023..+0.006 | 0.145 | -0.012 | -0.007 |
| LOVO pick [all rules] per cat x motion | 0.628 | 0.932 | 0.779 | 0.719 | 0.765 | -0.021 | -0.050..+0.004 | 0.052 | -0.025 | -0.018 |
| LOVO pick [all rules] per cat x src x kind | 0.631 | 0.930 | 0.786 | 0.719 | 0.767 | -0.019 | -0.046..+0.007 | 0.074 | -0.023 | -0.015 |
| LOVO pick [all rules] per cat | 0.719 | 0.954 | 0.833 | 0.736 | 0.810 | 0.025 | +0.005..+0.043 | 0.993 | 0.021 | 0.025 |


### Per-category change vs v1.parsed (95% video-bootstrap CI)

| rule | S2 | D2 | S3 | D3 |
|---|---|---|---|---|
| LOVO pick [all rules] per cat | +0.009 (-0.014..+0.038) | +0.030 (-0.027..+0.069) | +0.033 (+0.010..+0.051) | +0.028 (-0.016..+0.076) |
| base; direct-routed rows -> median(C3 direct + astra + gem) | +0.000 (+0.000..+0.000) | +0.000 (+0.000..+0.000) | +0.005 (+0.000..+0.011) | +0.030 (-0.015..+0.094) |
| wgmean base^0.00 x cons^1.00 [v2.p, oh.p, astra, gem] | +0.003 (-0.018..+0.029) | +0.005 (-0.055..+0.037) | +0.007 (-0.016..+0.031) | +0.013 (-0.037..+0.080) |
| gate |log base/cons|>0.2 -> median [C5p + astra] | +0.003 (+0.000..+0.010) | +0.014 (+0.000..+0.026) | -0.005 (-0.019..+0.008) | +0.015 (-0.011..+0.050) |
| base; 3D non-lab -> median(C3 direct + astra + gem) | +0.000 (+0.000..+0.000) | +0.000 (+0.000..+0.000) | +0.002 (-0.000..+0.006) | +0.023 (-0.018..+0.089) |
| gate |log base/cons|>0.2 -> median [v2.p, oh.p, astra] | +0.003 (+0.000..+0.010) | +0.000 (-0.033..+0.023) | +0.005 (-0.005..+0.018) | +0.017 (-0.005..+0.050) |
| trim(C5 parsed + astra + gem) | +0.003 (-0.011..+0.025) | +0.008 (-0.042..+0.037) | -0.002 (-0.032..+0.027) | +0.015 (-0.019..+0.067) |
| base; direct-routed rows -> median(C3 direct + astra) | +0.000 (+0.000..+0.000) | +0.000 (+0.000..+0.000) | +0.002 (-0.004..+0.013) | +0.021 (-0.007..+0.066) |
| base; 3D non-lab -> median(C3 direct) | +0.000 (+0.000..+0.000) | +0.000 (+0.000..+0.000) | -0.016 (-0.030..+0.000) | +0.032 (-0.008..+0.102) |
| base; 3D non-lab -> median(C3 direct + astra) | +0.000 (+0.000..+0.000) | +0.000 (+0.000..+0.000) | -0.002 (-0.006..+0.000) | +0.019 (-0.008..+0.065) |
| median(C5 parsed) | +0.012 (-0.003..+0.034) | +0.016 (-0.014..+0.039) | -0.030 (-0.056..+0.000) | +0.015 (-0.024..+0.081) |

Nested LOVO, which picks the LOVO scheme (pool × granularity) inside each outer fold as well
(`nested_lovo_final.txt`):

```
base 0.7856
+0.0248  nested LOVO (scheme chosen inside each fold)
+0.0248  LOVO all rules / cat
+0.0040  LOVO gate / global
+0.0036  LOVO gate / cat x motion
+0.0031  LOVO gate / cat
+0.0026  LOVO small set / cat
-0.0010  LOVO small set / global
-0.0034  LOVO video-scale / global
-0.0079  LOVO all rules / global
-0.0083  LOVO small set / cat x motion
-0.0105  LOVO wgmean / global
-0.0145  LOVO video-scale / cat
-0.0188  LOVO wgmean / cat x motion
-0.0209  LOVO all rules / cat x motion
-0.0218  LOVO single models / global
-0.0301  LOVO video-scale / cat x motion
-0.0304  LOVO wgmean / cat
-0.0344  LOVO single models / cat
-0.0345  LOVO single models / cat x motion
all rules/cat    24
Name: count, dtype: int64
nested 95% CI [0.0049 0.0434] P>0 0.993
S2 0.009
D2 0.03
S3 0.033
D3 0.028
```

### LOVO choices (most frequent picks across held-out videos x cells)

- LOVO pick [all rules] per global: {'base; direct-routed rows -> median(C3 direct + astra + gem)': 19, 'wgmean base^0.00 x cons^1.00 [v2.p, oh.p, astra, gem]': 2, 'wgmean base^0.00 x cons^1.00 [other Claude (v2.p, oh.p)]': 2, 'wgmean base^0.75 x cons^0.25 [v2.p, oh.p, astra, gem]': 1}
- LOVO pick [all rules] per cat: {'median(v1.parsed, astra, gem)': 6, 'om.parsed': 6, 'om2.direct': 5, 'gmean(C5 parsed + astra + gem)': 5, 'om2.parsed': 1, 'trim(C5 parsed)': 1}
- LOVO pick [all rules] per cat x motion: {'median(v1.parsed, astra, gem)': 7, 'om.parsed': 5, 'om2.direct': 4, 'om2.parsed': 4, 'v1.parsed': 4, 'gmean(v1.parsed, astra)': 3}
- LOVO pick [all rules] per cat x src x kind: {'median(v1.parsed, astra, gem)': 9, 'om.parsed': 6, 'om2.parsed': 6, 'v2.direct': 5, 'wgmean base^0.00 x cons^1.00 [astra, gem]': 4, 'v1.parsed': 4}
- LOVO pick [single models] per global: {'v1.parsed': 19, 'v2.parsed': 4, 'oh.parsed': 1}
- LOVO pick [single models] per cat: {'oh.parsed': 8, 'v1.parsed': 6, 'v2.direct': 6, 'astra.direct': 2, 'v2.parsed': 2}
- LOVO pick [single models] per cat x motion: {'v1.parsed': 11, 'v2.direct': 9, 'oh.parsed': 7, 'v2.parsed': 6, 'astra.direct': 5, 'v1.direct': 4}
- LOVO pick [single models] per cat x src x kind: {'v1.parsed': 15, 'oh.parsed': 10, 'v2.direct': 9, 'v2.parsed': 9, 'v1.direct': 6, 'astra.direct': 6}
- LOVO pick [small set] per global: {'base; 3D non-lab -> median(C3 direct + astra + gem)': 23, 'v1.parsed': 1}
- LOVO pick [small set] per cat: {'median(C5 parsed)': 11, 'base; 3D non-lab -> median(C3 direct)': 5, 'base; 3D non-lab -> median(C3 direct + astra + gem)': 5, 'v1.parsed': 3}
- LOVO pick [small set] per cat x motion: {'v1.parsed': 21, 'median(C5 parsed)': 11, 'base; 3D non-lab -> median(C3 direct)': 5, 'base; 3D non-lab -> median(C3 direct + astra + gem)': 4, 'median(C3 direct)': 1}
- LOVO pick [small set] per cat x src x kind: {'v1.parsed': 29, 'median(C5 parsed)': 16, 'base; 3D non-lab -> median(C3 direct + astra + gem)': 5, 'base; 3D non-lab -> median(C3 direct)': 3, 'median(C3 direct)': 2, 'median(C5 parsed + astra + gem)': 1}
- LOVO pick [video-scale family] per global: {'video scale w=1.00 [other Claude (v2.p, oh.p)]': 19, 'video scale w=0.50 [other Claude (v2.p, oh.p)]': 2, 'v1.parsed': 2, 'video scale w=0.25 [v2.p, oh.p, astra, gem]': 1}
- LOVO pick [video-scale family] per cat: {'video scale w=1.00 [other Claude (v2.p, oh.p)]': 9, 'v1.parsed': 7, 'video scale w=0.50 [other Claude (v2.p, oh.p)]': 3, 'video scale w=0.50 [astra, gem]': 2, 'video scale w=0.25 [v2.p, oh.p, astra, gem]': 2, 'video scale w=1.00 [astra, gem]': 1}
- LOVO pick [video-scale family] per cat x motion: {'v1.parsed': 16, 'video scale w=1.00 [other Claude (v2.p, oh.p)]': 7, 'video scale w=1.00 [astra, gem]': 6, 'video scale w=0.50 [astra, gem]': 5, 'video scale w=0.25 [v2.p, oh.p, astra, gem]': 3, 'video scale w=0.50 [astra]': 2}
- LOVO pick [video-scale family] per cat x src x kind: {'v1.parsed': 19, 'video scale w=1.00 [astra, gem]': 11, 'video scale w=1.00 [other Claude (v2.p, oh.p)]': 10, 'video scale w=0.50 [astra, gem]': 7, 'video scale w=0.25 [astra, gem]': 4, 'video scale w=0.25 [v2.p, oh.p, astra, gem]': 2}
- LOVO pick [weighted-gmean family] per global: {'wgmean base^0.00 x cons^1.00 [v2.p, oh.p, astra, gem]': 16, 'wgmean base^0.75 x cons^0.25 [v2.p, oh.p, astra, gem]': 6, 'wgmean base^0.00 x cons^1.00 [other Claude (v2.p, oh.p)]': 2}
- LOVO pick [weighted-gmean family] per cat: {'wgmean base^0.00 x cons^1.00 [other Claude (v2.p, oh.p)]': 6, 'wgmean base^0.50 x cons^0.50 [astra]': 5, 'wgmean base^0.75 x cons^0.25 [v2.p, oh.p, astra, gem]': 3, 'wgmean base^0.75 x cons^0.25 [astra, gem]': 2, 'wgmean base^0.00 x cons^1.00 [astra, gem]': 2, 'wgmean base^0.00 x cons^1.00 [astra]': 1}
- LOVO pick [weighted-gmean family] per cat x motion: {'wgmean base^0.00 x cons^1.00 [other Claude (v2.p, oh.p)]': 15, 'v1.parsed': 5, 'wgmean base^0.00 x cons^1.00 [astra]': 5, 'wgmean base^0.00 x cons^1.00 [astra, gem]': 4, 'wgmean base^0.50 x cons^0.50 [astra]': 3, 'wgmean base^0.50 x cons^0.50 [astra, gem]': 2}
- LOVO pick [weighted-gmean family] per cat x src x kind: {'wgmean base^0.00 x cons^1.00 [other Claude (v2.p, oh.p)]': 16, 'wgmean base^0.00 x cons^1.00 [astra, gem]': 8, 'v1.parsed': 7, 'wgmean base^0.00 x cons^1.00 [astra]': 5, 'wgmean base^0.50 x cons^0.50 [astra]': 4, 'wgmean base^0.50 x cons^0.50 [astra, gem]': 4}
- LOVO pick [gated-median family] per global: {'gate |log base/cons|>0.2 -> median [C5p + astra]': 22, 'gate |log base/cons|>0.2 -> median [v2.p, oh.p, astra]': 2}
- LOVO pick [gated-median family] per cat: {'gate |log base/cons|>0.1 -> median [C5p + astra]': 6, 'gate |log base/cons|>0.1 -> median [C5p + astra + gem]': 6, 'gate |log base/cons|>0.1 -> median [v2.p, oh.p, astra]': 5, 'gate |log base/cons|>0.2 -> median [v2.p, oh.p, astra]': 5, 'gate |log base/cons|>0.2 -> median [C5p + astra + gem]': 1, 'v1.parsed': 1}
- LOVO pick [gated-median family] per cat x motion: {'v1.parsed': 14, 'gate |log base/cons|>0.2 -> median [v2.p, oh.p, astra]': 12, 'gate |log base/cons|>0.1 -> median [v2.p, oh.p, astra]': 7, 'gate |log base/cons|>0.1 -> median [C5p + astra + gem]': 7, 'gate |log base/cons|>0.1 -> median [C5p + astra]': 1, 'gate |log base/cons|>0.2 -> median [C5p + astra + gem]': 1}
- LOVO pick [gated-median family] per cat x src x kind: {'v1.parsed': 22, 'gate |log base/cons|>0.2 -> median [v2.p, oh.p, astra]': 13, 'gate |log base/cons|>0.1 -> median [v2.p, oh.p, astra]': 10, 'gate |log base/cons|>0.1 -> median [C5p + astra + gem]': 7, 'gate |log base/cons|>0.1 -> median [C5p + astra]': 3, 'gate |log base/cons|>0.2 -> median [C5p + astra + gem]': 1}

**Reading.** Out of about 100 fixed rules, the best gains +.009 (CI -.003..+.025). Medians of Claude runs are
+.003 with S3 consistently negative (-.030). Adding Astra or Gemini to a median of correlated Claude answers barely
moves it, and geometric means or blends with Astra or Gemini lose. The label-free video-scale and weighted rules do
not recover oracle A, because the per-video offsets are common to all models (table below). The per-category
selection from the full pool wins under nested LOVO (+.025), but look at what it picks:

- **S2** (+.009): gmean(C5p + Astra + Gemini) in 5 folds and trim(C5p) in 1. Small and within noise.
- **D2** (+.030): om.parsed, a single medium-effort 480p Claude run, in all 6 folds. Per video it gives
  +.075, -.083, +.014, 0, +.067, +.100. A lucky run, not a method, and not deployable.
- **S3** (+.033): median(v1.parsed, Astra, Gemini) in all 6 folds. Per video it gives 0, +.025, +.022, +.064,
  0, +.050. It changes 10 questions, mostly by taking Astra's value when Claude and Astra disagree.
- **D3** (+.028): om2.direct, another single medium run, in 5 of 6 folds. Same objection as D2.

So the only transferable piece is the S3 cross-vendor median. It is post hoc (one rule out of about 100, in one
category out of four), the same rule loses -.092 in D3, and S3 has 6 videos.

### 3.3 Combinations that could actually be bought for test (relative to the deployed-like structure)

Test coverage today: v1 high on all 568 videos, plus two more Claude runs on the 123 3D non-lab videos. There are
no Astra or Gemini test runs. Validation cost per question, measured from the run records: Astra $0.067,
Gemini video $0.053 (frames about $0.038), Claude v1 high $0.023. The test has 3289 questions, of which 756 are 3D
non-lab: 244 in S3 (46 videos) and 512 in D3 (77 videos).

| rule (vs deployed-like) | changed q | dMRA | 95% CI | P(>0) | S3 | D3 |
|---|---|---|---|---|---|---|
| 3D non-lab median + astra | 25 | 0.000 | -0.007..+0.006 | 0.539 | +0.014 (+0.000..+0.027) | -0.013 (-0.037..+0.000) |
| 3D non-lab median + astra + gem | 24 | 0.003 | -0.003..+0.007 | 0.833 | +0.019 (+0.000..+0.035) | -0.009 (-0.016..+0.000) |
| 3D non-lab median + gem | 36 | -0.000 | -0.006..+0.005 | 0.475 | +0.014 (+0.000..+0.027) | -0.015 (-0.033..+0.000) |
| S3 non-lab only: median + astra + gem | 10 | 0.005 | +0.000..+0.009 | 0.923 | +0.019 (+0.000..+0.035) | +0.000 (+0.000..+0.000) |
| S3 non-lab only: median + astra | 15 | 0.003 | +0.000..+0.007 | 0.923 | +0.014 (+0.000..+0.027) | +0.000 (+0.000..+0.000) |
| S3 all rows: median(v1.parsed, astra, gem) | 25 | 0.012 | +0.002..+0.020 | 1.000 | +0.049 (+0.010..+0.081) | +0.000 (+0.000..+0.000) |
| S3 lab rows: median(v1.parsed, astra, gem) | 8 | 0.002 | +0.000..+0.004 | 0.906 | +0.007 (+0.000..+0.017) | +0.000 (+0.000..+0.000) |
| lab rows (S3+D3): median(v1.parsed, astra, gem) | 23 | -0.003 | -0.014..+0.005 | 0.310 | +0.007 (+0.000..+0.017) | -0.019 (-0.062..+0.009) |


- Adding Astra and/or Gemini to the 3D non-lab median: about 0 overall (S3 +.014..+.019, D3 -.009..-.015).
- S3 only, 3-vendor median on every S3 row: S3 +.049 (+.010..+.081), MRA +.012. Most of that comes from the 3
  non-lab S3 videos; the lab rows add +.007. On test this would need Astra and Gemini on all 578 S3 questions
  (about $39 + $31, above the remaining OpenAI $33 and Gemini $19). The non-lab part alone (244 questions) is
  about $16 + $13.
- Expected test gain if run on S3 non-lab: validation measures about +.07 per changed S3 non-lab question over 3
  videos. Shrunk for post-hoc selection, and because the test S3 non-lab rows already carry the 3-run median plus
  family corrections (K scaling, pooling, stated facts), I would plan for **+0.000..+0.008 MRA**. Treat it as a
  probe, not a sure gain.

### 3.4 Gemini 3.1 Pro: coverage and behaviour

- The frames run (`runs/val_gem31pro_frames`) stopped after 3 videos at 18:06 and never wrote more than 15 rows to
  its CSV; its process is gone. At the 45-minute checkpoint (18:51) the native-video run that replaced it had
  answered 119/159 (`combo_gem_checkpoint45.md`, `combo_gemsubset_checkpoint45.md`). It finished at 19:01 with
  156/159 answered, so the tables above use the full run, read from its records with the runner's own parsing.
- On those 156 questions Gemini scores .575 against .783 for v1. By category (gaps filled with v1): S2 .625, D2
  .565, S3 .674, D3 .472. By kind (answered only): size .565, speed .660, acceleration .244. It is poor with motion
  priors: internet_0019 people are 1.65x too tall; simulation_0060 sizes are 0.3-0.5x. There are no unit mismatches:
  the unit it reports always matches the asked unit.
- On the 23 questions both Gemini runs answered (3 videos: captured_0013, captured_0034as, simulation_0089): video
  .674, frames .522, v1 .696, Astra .600. That is too small to rank the input modes.

### 3.5 Per-video offsets across models (why combination cannot fix oracle A)

Median log residual per video and model; correlations across videos: Claude-Claude .84-.95, Claude-Astra .48-.75.

| video: median log residual | cat | src | v1.p | v1.d | v2.p | oh.p | om.p | om2.p | astra.d | gem.d |
|---|---|---|---|---|---|---|---|---|---|---|
| internet_0005 | D2 | internet | 0.01 | 0.02 | 0.02 | 0.01 | 0.01 | 0.01 | -0.01 |  |
| internet_0013 | D2 | internet | -0.01 | 0.00 | 0.06 | 0.04 | 0.03 | 0.10 | -0.02 |  |
| internet_0019 | D2 | internet | -0.06 | -0.06 | -0.06 | -0.05 | -0.04 | -0.04 | -0.04 |  |
| simulation_0098_segmented | D2 | segmentation | 0.02 | 0.01 | 0.02 | 0.02 | 0.01 | 0.02 | -0.00 |  |
| simulation_0193 | D2 | simulation | 0.01 | 0.00 | 0.01 | 0.02 | 0.02 | 0.02 | -0.00 |  |
| simulation_0196 | D2 | simulation | 0.06 | 0.15 | 0.02 | 0.13 | 0.05 | 0.28 | 0.19 |  |
| captured_0013 | D3 | lab | -0.09 | -0.22 | -0.00 | -0.07 | -0.19 | -0.00 | -0.14 | 0.36 |
| captured_0041x | D3 | lab | 0.02 | 0.18 | 0.05 | 0.00 | 0.00 | 0.00 | 0.17 |  |
| captured_0061 | D3 | lab | -0.37 | -0.30 | -0.48 | -0.37 | -0.39 | -0.46 | 0.41 |  |
| simulation_0009 | D3 | simulation | -0.56 | -0.56 | -0.25 | -0.29 | -0.21 | -0.35 | -0.43 |  |
| simulation_0060 | D3 | simulation | -0.04 | -0.04 | -0.07 | -0.08 | 0.03 | -0.04 |  |  |
| simulation_0300 | D3 | simulation | 0.02 | 0.02 | -0.03 | 0.02 | 0.01 | 0.02 | -0.13 |  |
| internet_0001 | S2 | internet | -0.11 | -0.00 | 0.02 | -0.05 | -0.05 | -0.03 | 0.04 |  |
| internet_0004 | S2 | internet | -0.05 | -0.04 | -0.05 | -0.04 | 0.03 | -0.05 | 0.22 |  |
| internet_0027 | S2 | internet | 0.01 | -0.01 | 0.00 | 0.00 | -0.01 | -0.01 | -0.03 |  |
| simulation_0089 | S2 | simulation | 0.36 | 0.41 | 0.47 | 0.33 | 0.34 | 0.31 | 0.56 | 0.55 |
| simulation_0163 | S2 | simulation | -0.01 | -0.00 | 0.00 | -0.01 | -0.01 | -0.01 | 0.02 |  |
| simulation_0171 | S2 | simulation | 0.20 | 0.10 | 0.18 | 0.20 | 0.20 | 0.22 | 0.10 |  |
| captured_0021x | S3 | lab | 0.00 | 0.00 | -0.02 | 0.00 | 0.02 | 0.03 | -0.03 |  |
| captured_0027s | S3 | lab | -0.54 | -0.54 | -0.34 | -0.55 | -0.71 | -0.49 | -1.46 |  |
| captured_0034as | S3 | lab | -0.22 | -0.34 | -0.11 | -0.42 | -0.35 | -0.33 | -0.38 | -0.14 |
| simulation_0015 | S3 | simulation | -0.17 | -0.17 | -0.19 | -0.25 | -0.14 | -0.04 | -0.01 |  |
| simulation_0034_segmented | S3 | segmentation | -0.02 | -0.02 | -0.03 | -0.03 | -0.00 | -0.05 | -0.00 |  |
| simulation_0170_segmented | S3 | segmentation | -0.02 | -0.02 | -0.07 | -0.01 | -0.14 | 0.01 | 0.01 |  |

