"""Oracle B: per question, the better of geometry and direct (val_hr_v1_high), plus an honest
leave-one-video-out (LOVO) router between the two. Labels used for evaluation only."""
from __future__ import annotations

import sys

import numpy as np
import pandas as pd

from common import CATS, item_scores, load_meta, load_runs, macro, md_table

OUT = sys.argv[1] if len(sys.argv) > 1 else "oracle_b"
rng = np.random.default_rng(0)


def boot_diff(m, a, b, reps=2000):
    """Stratified (by category) video bootstrap of macro MRA(a) - MRA(b); a, b per-question item arrays."""
    vids = {c: m[m.category == c].video_id.unique() for c in CATS}
    pos = {v: np.where(m.video_id.values == v)[0] for v in m.video_id.unique()}
    out = []
    for _ in range(reps):
        cm = []
        for c in CATS:
            pick = rng.choice(vids[c], len(vids[c]), replace=True)
            ix = np.concatenate([pos[v] for v in pick])
            cm.append(a[ix].mean() - b[ix].mean())
        out.append(np.mean(cm))
    out = np.array(out)
    return out.mean(), np.quantile(out, 0.05), np.quantile(out, 0.95), (out > 0).mean()


def main():
    m = load_meta(); R = load_runs(m); y = m.answer.values
    geo = R["v1.geo"].copy(); direct = R["v1.direct"].copy(); parsed = R["v1.parsed"].copy()
    geo_f = geo.fillna(direct)
    it = {"geo": item_scores(geo_f.values, y), "direct": item_scores(direct.values, y),
          "parsed (current routing)": item_scores(parsed.values, y)}
    it["oracle B"] = np.maximum(it["geo"], it["direct"])
    routed_direct = (parsed.round(9) != geo.round(9)) | geo.isna()

    # ---- LOVO router: per cell choose geo or direct by training mean item score
    def cellkey(df, kind):
        if kind == "cat":
            return df.category
        if kind == "cat x motion":
            return df.category + "|" + df.motion.map({True: "motion", False: "static"})
        if kind == "cat x src x motion":
            return df.category + "|" + df.src + "|" + df.motion.map({True: "motion", False: "static"})
        if kind == "cat x src x kind":
            return df.category + "|" + df.src + "|" + df.tkind
    lovo = {}
    for kind in ("cat", "cat x motion", "cat x src x motion", "cat x src x kind"):
        key = cellkey(m, kind).values
        pred = np.zeros(len(m))
        choice_log = []
        for v in m.video_id.unique():
            te = m.video_id.values == v
            tr = ~te
            for k in np.unique(key[te]):
                sel_tr = tr & (key == k)
                sel_te = te & (key == k)
                ntr_v = m.video_id.values[sel_tr]
                if sel_tr.sum() >= 3 and len(np.unique(ntr_v)) >= 2:
                    g, d = it["geo"][sel_tr].mean(), it["direct"][sel_tr].mean()
                    use_geo = g > d
                    pred[sel_te] = np.where(use_geo, it["geo"][sel_te], it["direct"][sel_te])
                    choice_log.append((v, k, "geo" if use_geo else "direct"))
                else:  # too little training evidence: keep current routing
                    pred[sel_te] = it["parsed (current routing)"][sel_te]
                    choice_log.append((v, k, "current"))
        lovo[f"LOVO router ({kind})"] = pred
    it.update(lovo)

    cats = m.category.values
    rows = {}
    base = it["parsed (current routing)"]
    for name, a in it.items():
        d = macro(a, cats)
        d["static"] = a[~m.motion.values].mean(); d["motion"] = a[m.motion.values].mean()
        mu, lo, hi, p = boot_diff(m, a, base)
        d["dMRA vs current"] = d["MRA"] - macro(base, cats)["MRA"]
        d["90% CI"] = f"{lo:+.3f}..{hi:+.3f}"
        rows[name] = d
    T = pd.DataFrame(rows).T; T.index.name = "answer"

    # breakdown per category x kind and per source
    def breakdown(group):
        rws = []
        for k, g in m.groupby(group):
            ix = m.index.get_indexer(g.index)
            rws.append(dict(cell=k if isinstance(k, str) else " | ".join(k), n=len(g), videos=g.video_id.nunique(),
                            routed_direct=int(routed_direct.iloc[ix].sum()),
                            geo=it["geo"][ix].mean(), direct=it["direct"][ix].mean(),
                            current=base[ix].mean(), oracleB=it["oracle B"][ix].mean(),
                            gain=it["oracle B"][ix].mean() - base[ix].mean(),
                            geo_better=int((it["geo"][ix] > it["direct"][ix] + 1e-9).sum()),
                            direct_better=int((it["direct"][ix] > it["geo"][ix] + 1e-9).sum())))
        return pd.DataFrame(rws).set_index("cell")
    B1 = breakdown(["category", "tkind"]); B2 = breakdown(["category", "src"]); B3 = breakdown(["tkind"])

    # Category-weighted gain: oracle gain in each cell x its weight in the macro
    with open(f"{OUT}.md", "w") as fh:
        fh.write("### Oracle B and LOVO routers (v1: geometry vs direct)\n\n" + md_table(T) + "\n\n")
        fh.write("### Per category x target kind (mean item score)\n\n" + md_table(B1) + "\n\n")
        fh.write("### Per category x source\n\n" + md_table(B2) + "\n\n")
        fh.write("### Per target kind\n\n" + md_table(B3) + "\n")
    print(open(f"{OUT}.md").read())


if __name__ == "__main__":
    main()
