"""Multi-model combination study on validation (159 q / 24 videos).

Models: Claude runs (val_hr_v1_high, val_hr_v2_high, val_opus_high/med/med2; parsed = routed pipeline answer,
direct = Claude's own number, geo = geometry), GPT-6 Astra (direct), Gemini 3.1 Pro (direct, partial coverage).
Every selection among rules/models is judged leave-one-video-out (LOVO); uncertainty by a category-stratified
bootstrap over videos. Labels are used for evaluation only.
"""
from __future__ import annotations

import argparse
import itertools
import json

import numpy as np
import pandas as pd

from common import CATS, item_scores, load_meta, load_runs, macro, md_table

ap = argparse.ArgumentParser()
ap.add_argument("--out", default="combo")
ap.add_argument("--subset", default="all", help="all | gem (videos fully answered by Gemini)")
ap.add_argument("--reps", type=int, default=2000)
ap.add_argument("--nogem", action="store_true")
args = ap.parse_args()
rng = np.random.default_rng(0)

m = load_meta(); R = load_runs(m)
if args.nogem and "gem.direct" in R:
    R = R.drop(columns=["gem.direct"])
if args.subset == "gem":
    cov = R["gem.direct"].notna().groupby(m.video_id).all()
    keep = cov[cov].index
    m = m[m.video_id.isin(keep)]
    R = R.loc[m.index]
y = m.answer.values
cats = m.category.values
BASE = "v1.parsed"
has_gem = "gem.direct" in R and R["gem.direct"].notna().any()
nonlab3d = (m.is3d & m.src.isin(["simulation", "segmentation"])).values
geo_routed = (R["v1.parsed"].round(9) == R["v1.geo"].round(9)).values & R["v1.geo"].notna().values


# ------------------------------------------------------------------ combination rules
def comb(cols, how="median"):
    X = np.log(R[list(cols)].values.astype(float))
    out = np.full(len(X), np.nan)
    for i, row in enumerate(X):
        v = np.sort(row[np.isfinite(row)])
        if len(v) == 0:
            continue
        if how == "median":
            out[i] = np.median(v)
        elif how == "gmean":
            out[i] = v.mean()
        elif how == "trim":
            out[i] = v[1:-1].mean() if len(v) >= 4 else np.median(v)
    s = pd.Series(np.exp(out), index=R.index)
    return s.fillna(R[BASE])


C5p = ["v1.parsed", "v2.parsed", "oh.parsed", "om.parsed", "om2.parsed"]
C3p = ["v1.parsed", "v2.parsed", "oh.parsed"]
C5d = ["v1.direct", "v2.direct", "oh.direct", "om.direct", "om2.direct"]
C3d = ["v1.direct", "v2.direct", "oh.direct"]
A = ["astra.direct"]; G = ["gem.direct"] if has_gem else []

rules: dict[str, pd.Series] = {}
singles = ["v1.parsed", "v1.direct", "v1.geo", "v2.parsed", "v2.direct", "oh.parsed", "oh.direct", "om.parsed",
           "om.direct", "om2.parsed", "om2.direct", "astra.direct"] + G + ["fab.parsed", "fab.direct", "v2m.parsed", "ol.parsed", "ox.parsed"]
for s in singles:
    rules[s] = R[s].fillna(R[BASE]) if s != BASE else R[s]
for how in ("median", "gmean", "trim"):
    rules[f"{how}(C5 parsed)"] = comb(C5p, how)
    rules[f"{how}(C5 direct)"] = comb(C5d, how)
    rules[f"{how}(C5 parsed + astra)"] = comb(C5p + A, how)
    if G:
        rules[f"{how}(C5 parsed + astra + gem)"] = comb(C5p + A + G, how)
        rules[f"{how}(C3 direct + astra + gem)"] = comb(C3d + A + G, how)
rules["median(C3 parsed)"] = comb(C3p); rules["gmean(C3 parsed)"] = comb(C3p, "gmean")
rules["median(C3 direct)"] = comb(C3d); rules["gmean(C3 direct)"] = comb(C3d, "gmean")
rules["median(v1.parsed, v2.parsed, astra)"] = comb(["v1.parsed", "v2.parsed"] + A)
rules["gmean(v1.parsed, astra)"] = comb(["v1.parsed"] + A, "gmean")
rules["median(C3 direct + astra)"] = comb(C3d + A)
if G:
    rules["median(v1.parsed, astra, gem)"] = comb(["v1.parsed"] + A + G)
    rules["gmean(v1.parsed, astra, gem)"] = comb(["v1.parsed"] + A + G, "gmean")
    rules["median(v1.direct, astra, gem)"] = comb(["v1.direct"] + A + G)
    rules["gmean(v1.parsed, gem)"] = comb(["v1.parsed"] + G, "gmean")
# pipeline-structured: keep geometry-routed rows; replace direct-routed rows by an ensemble of direct answers
for label, cols in [("C3 direct", C3d), ("C5 direct", C5d), ("C3 direct + astra", C3d + A)] + (
        [("C3 direct + astra + gem", C3d + A + G), ("v1.direct + astra + gem", ["v1.direct"] + A + G),
         ("v1.direct + gem", ["v1.direct"] + G)] if G else []):
    e = comb(cols)
    rules[f"base; direct-routed rows -> median({label})"] = pd.Series(np.where(geo_routed, R[BASE], e), index=R.index)
    rules[f"base; 3D non-lab -> median({label})"] = pd.Series(np.where(nonlab3d, e, R[BASE]), index=R.index)

# Shrink toward a consensus of OTHER models: per question (weighted geometric mean) or per video (one shared
# factor = median over the video's questions of log(consensus / base)), i.e. a label-free version of oracle A.
CONS_SETS = {"other Claude (v2.p, oh.p)": ["v2.parsed", "oh.parsed"], "astra": A,
             "v2.p, oh.p, astra": ["v2.parsed", "oh.parsed"] + A}
if G:
    CONS_SETS.update({"astra, gem": A + G, "v2.p, oh.p, astra, gem": ["v2.parsed", "oh.parsed"] + A + G})
lb = np.log(R[BASE])
for cname, cols in CONS_SETS.items():
    cons = np.log(comb(cols).where(R[cols].notna().any(axis=1)))
    d = (cons - lb)
    sv = d.groupby(m.video_id).transform("median").fillna(0.0)
    for w in (0.25, 0.5, 1.0):
        rules[f"wgmean base^{1 - w:.2f} x cons^{w:.2f} [{cname}]"] = np.exp(lb + w * d.fillna(0.0))
        rules[f"video scale w={w:.2f} [{cname}]"] = np.exp(lb + w * sv)

# Disagreement-gated: keep base unless it is far from the others' consensus, then take the median of all.
GATE_SETS = {"v2.p, oh.p, astra": ["v2.parsed", "oh.parsed"] + A, "C5p + astra": C5p + A}
if G:
    GATE_SETS["C5p + astra + gem"] = C5p + A + G
for gname, cols in GATE_SETS.items():
    others = [c for c in cols if c != BASE]
    cons = comb(others).where(R[others].notna().any(axis=1))
    dis = np.abs(np.log(cons / R[BASE])).fillna(0.0)
    allm = comb(list(dict.fromkeys([BASE] + cols)))
    for T in (0.1, 0.2, 0.3, 0.5):
        rules[f"gate |log base/cons|>{T} -> median [{gname}]"] = pd.Series(np.where(dis > T, allm, R[BASE]), index=R.index)

items = {k: item_scores(v.values, y) for k, v in rules.items()}
DEPLOYED = "base; 3D non-lab -> median(C3 direct)"
base_it = items[BASE]

# ------------------------------------------------------------------ bootstrap
vids = {c: m[m.category == c].video_id.unique() for c in CATS if (m.category == c).any()}
pos = {v: np.where(m.video_id.values == v)[0] for v in m.video_id.unique()}
BOOT = []
for _ in range(args.reps):
    BOOT.append({c: rng.choice(vids[c], len(vids[c]), replace=True) for c in vids})


def boot(a, b=base_it):
    out = []
    for bs in BOOT:
        out.append(np.mean([a[np.concatenate([pos[v] for v in bs[c]])].mean() - b[np.concatenate([pos[v] for v in bs[c]])].mean() for c in bs]))
    out = np.array(out)
    return out.mean(), np.quantile(out, .025), np.quantile(out, .975), np.quantile(out, .05), np.quantile(out, .95), (out > 0).mean()


def macro_any(a, mask=None):
    mask = np.ones(len(a), bool) if mask is None else mask
    cs = [c for c in CATS if ((cats == c) & mask).any()]
    return float(np.mean([a[(cats == c) & mask].mean() for c in cs]))


# ------------------------------------------------------------------ LOVO selection / routing
def cell_keys(kind):
    if kind == "global":
        return np.array(["all"] * len(m))
    if kind == "cat":
        return cats
    if kind == "cat x motion":
        return np.array([f"{c}|{'mot' if x else 'sta'}" for c, x in zip(cats, m.motion.values)])
    if kind == "cat x src x kind":
        return np.array([f"{c}|{s}|{k}" for c, s, k in zip(cats, m.src.values, m.tkind.values)])


def lovo_select(pool, kind, fallback_kind="cat x motion", min_q=5, min_v=2):
    """For each held-out video, per cell choose the rule in `pool` with the best training mean item score
    (training = other videos; global uses macro MRA). Ties keep base. Returns items and choice counts."""
    key = cell_keys(kind); fkey = cell_keys(fallback_kind) if kind == "cat x src x kind" else None
    pred = np.zeros(len(m)); choices = []
    vid = m.video_id.values
    for v in np.unique(vid):
        te = vid == v; tr = ~te
        for k in np.unique(key[te]):
            sel_te = te & (key == k)
            sel_tr = tr & (key == k)
            if kind == "global":
                scores = {r: macro_any(items[r], tr) for r in pool}
            else:
                if sel_tr.sum() < min_q or len(np.unique(vid[sel_tr])) < min_v:
                    if fkey is None:
                        pred[sel_te] = base_it[sel_te]; choices.append(BASE); continue
                    fk = fkey[sel_te][0]
                    sel_tr = tr & (fkey == fk)
                    if sel_tr.sum() < min_q:
                        pred[sel_te] = base_it[sel_te]; choices.append(BASE); continue
                scores = {r: items[r][sel_tr].mean() for r in pool}
            best = max(scores.values())
            pick = BASE if scores.get(BASE, -1) >= best - 1e-12 else max(scores, key=scores.get)
            pred[sel_te] = items[pick][sel_te]; choices.append(pick)
    return pred, pd.Series(choices).value_counts()


pool_rules = [r for r in rules if not r.startswith(("fab.", "v2m.", "ol.", "ox."))]
pool_models = ["v1.parsed", "v1.direct", "v1.geo", "v2.parsed", "v2.direct", "oh.parsed", "oh.direct", "astra.direct"] + G
pool_small = [BASE, "median(C5 parsed)", "median(C3 direct)", "base; 3D non-lab -> median(C3 direct)",
              "base; 3D non-lab -> median(C3 direct + astra)"] + (["base; 3D non-lab -> median(C3 direct + astra + gem)",
                                                                   "median(C5 parsed + astra + gem)"] if G else [])
pool_vscale = [BASE] + [r for r in rules if r.startswith("video scale")]
pool_wg = [BASE] + [r for r in rules if r.startswith("wgmean")]
pool_gate = [BASE] + [r for r in rules if r.startswith("gate")]
lovo = {}
lovo_choices = {}
for pname, pool in [("all rules", pool_rules), ("single models", pool_models), ("small set", pool_small),
                    ("video-scale family", pool_vscale), ("weighted-gmean family", pool_wg), ("gated-median family", pool_gate)]:
    for kind in ("global", "cat", "cat x motion", "cat x src x kind"):
        it, ch = lovo_select(pool, kind)
        lovo[f"LOVO pick [{pname}] per {kind}"] = it
        lovo_choices[f"LOVO pick [{pname}] per {kind}"] = ch.head(6).to_dict()

# ------------------------------------------------------------------ tables
res = []
for name, it in list(items.items()) + list(lovo.items()):
    d = {"rule": name}
    for c in CATS:
        d[c] = it[cats == c].mean() if (cats == c).any() else np.nan
    d["MRA"] = macro_any(it)
    d["static"] = it[~m.motion.values].mean(); d["motion"] = it[m.motion.values].mean()
    mu, lo95, hi95, lo90, hi90, p = boot(it)
    d["dMRA"] = d["MRA"] - macro_any(base_it)
    d["95% CI"] = f"{lo95:+.3f}..{hi95:+.3f}"
    d["P(>0)"] = p
    d["d vs deployed-like"] = d["MRA"] - macro_any(items[DEPLOYED])
    ns = ~m.suspect.values
    d["dMRA excl. suspect"] = macro_any(it, ns) - macro_any(base_it, ns)
    res.append(d)
res = pd.DataFrame(res).set_index("rule")


def per_cat_ci(a, b=base_it):
    out = {}
    for c in vids:
        diffs = []
        for bs in BOOT:
            ix = np.concatenate([pos[v] for v in bs[c]])
            diffs.append(a[ix].mean() - b[ix].mean())
        diffs = np.array(diffs)
        out[c] = (a[cats == c].mean() - b[cats == c].mean(), np.quantile(diffs, .025), np.quantile(diffs, .975))
    return out


# per-model breakdowns (answered questions only, with coverage)
bk_models = ["v1.parsed", "v1.direct", "v1.geo", "v2.parsed", "v2.direct", "oh.parsed", "oh.direct", "om.parsed",
             "om.direct", "om2.parsed", "om2.direct", "fab.parsed", "fab.direct", "astra.direct"] + G
bk = []
for c in bk_models:
    v = R[c]; ans = v.notna().values
    it_raw = item_scores(v.values, y)  # missing -> 0
    it_fill = items[c] if c in items else it_raw
    d = {"model": c, "coverage": f"{ans.sum()}/{len(ans)}", "MRA (missing=0)": macro_any(it_raw),
         "MRA (gaps=v1.parsed)": macro_any(it_fill)}
    for cc in CATS:
        d[cc] = it_fill[cats == cc].mean() if (cats == cc).any() else np.nan
    for s in ("internet", "lab", "simulation", "segmentation"):
        sel = (m.src.values == s) & ans
        d[s] = it_raw[sel].mean() if sel.any() else np.nan
    for k in ("size", "distance", "speed", "accel"):
        sel = (m.tkind.values == k) & ans
        d[k] = it_raw[sel].mean() if sel.any() else np.nan
    # same-questions comparison against base on its answered set
    d["base on same q"] = base_it[ans].mean(); d["model on same q"] = it_raw[ans].mean()
    bk.append(d)
bk = pd.DataFrame(bk).set_index("model")

# pairwise
pw_models = ["v1.parsed", "v1.direct", "v1.geo", "v2.parsed", "v2.direct", "oh.parsed", "oh.direct", "om.direct", "om2.direct", "astra.direct"] + G
mlr = pd.DataFrame(index=pw_models, columns=pw_models, dtype=float)
cor = pd.DataFrame(index=pw_models, columns=pw_models, dtype=float)
for a, b in itertools.product(pw_models, pw_models):
    ok = R[a].notna() & R[b].notna()
    la, lb = np.log(R[a][ok]), np.log(R[b][ok])
    mlr.loc[a, b] = float(np.median(np.abs(la - lb)))
    ra = (la - np.log(m.answer[ok])).clip(-np.log(3), np.log(3)); rb = (lb - np.log(m.answer[ok])).clip(-np.log(3), np.log(3))
    cor.loc[a, b] = float(np.corrcoef(pd.Series(ra.values).rank(), pd.Series(rb.values).rank())[0, 1])
short = {c: c.replace(".parsed", ".p").replace(".direct", ".d").replace("astra.d", "astra").replace("gem.d", "gem") for c in pw_models}
mlr = mlr.rename(index=short, columns=short); cor = cor.rename(index=short, columns=short)
mlr.index.name = "median |log a/b|"; cor.index.name = "Spearman r of log residuals"

with open(f"{args.out}.md", "w") as fh:
    fh.write(f"Subset: {args.subset}; {len(m)} questions, {m.video_id.nunique()} videos; Gemini present: {has_gem} "
             f"(answered {int(R['gem.direct'].notna().sum()) if 'gem.direct' in R else 0}).\n\n")
    fh.write("### Per-model scores\n\nCategory columns and the gap-filled MRA fill a model's missing answers with v1.parsed; "
             "source and kind columns are means over the questions the model answered.\n\n" + md_table(bk) + "\n\n")
    fh.write("### Pairwise: median |log ratio| of answers\n\n" + md_table(mlr) + "\n\n")
    fh.write("### Pairwise: Spearman correlation of log residuals (clipped at 3x)\n\n" + md_table(cor, 2) + "\n\n")
    fh.write("### Combination rules and LOVO selections (dMRA vs v1.parsed; video bootstrap stratified by category)\n\n"
             + md_table(res.sort_values("MRA", ascending=False)) + "\n\n")
    top = res.drop(index=[BASE]).sort_values("MRA", ascending=False).index[:8].tolist()
    extra = [r for r in ("base; 3D non-lab -> median(C3 direct)", "base; 3D non-lab -> median(C3 direct + astra)",
                         "base; 3D non-lab -> median(C3 direct + astra + gem)", "median(C5 parsed)") if r in res.index and r not in top]
    rows = []
    for r in top + extra:
        a = lovo[r] if r in lovo else items[r]
        pc = per_cat_ci(a)
        rows.append({"rule": r, **{c: f"{pc[c][0]:+.3f} ({pc[c][1]:+.3f}..{pc[c][2]:+.3f})" for c in pc}})
    fh.write("### Per-category change vs v1.parsed (95% video-bootstrap CI)\n\n" + md_table(pd.DataFrame(rows).set_index("rule")) + "\n\n")
    fh.write("### LOVO choices (most frequent picks across held-out videos x cells)\n\n")
    for k, v in lovo_choices.items():
        fh.write(f"- {k}: {v}\n")
res.to_csv(f"{args.out}_rules.csv"); bk.to_csv(f"{args.out}_models.csv")
print(open(f"{args.out}.md").read())

# validation predictions of the fixed rules (id, value per rule) for re-checking; LOVO picks are item-level only
pd.DataFrame({k: v for k, v in rules.items()}, index=R.index).rename_axis("id").to_csv(f"{args.out}_val_predictions.csv")
