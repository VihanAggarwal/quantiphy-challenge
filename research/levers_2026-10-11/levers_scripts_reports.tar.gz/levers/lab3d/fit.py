"""3D trajectory reconstruction of lab objects + segment-wise constrained fits.
Camera: fixed, f = 722 px at 1280 width, principal point at the image centre.
Time: real capture time t = (n + [n>=12] + [n>=36] + [n>=60]) / 25 (25->24 fps drops).
Depth: range r = f * D / d_px (D from timed depth_info anchors of the object, else a size prior);
anchors enter as strong radial constraints."""
import sys, pickle, re, math
sys.path.insert(0, '/home/user/quantiphy-challenge')
import numpy as np
from qp.geometry import name_score
OUT = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/lab3d/'
F1280 = 722.0
MOTION = {'speed', 'acceleration', 'displacement', 'path_length'}
CFG = dict(depth_conv='range', sig_px_dense=1.5, sig_px_claude=4.0, sig_d_dense=0.06, seg_pen=40.0,
           min_seg=5, gravity_tol_deg=35.0)

def t_real(n):
    n = np.asarray(n, float)
    return (n + (n >= 12) + (n >= 36) + (n >= 60)) / 25.0

def ray(u, v, W, H, f):
    r = np.stack([(np.asarray(u) - W / 2) / f, (np.asarray(v) - H / 2) / f, np.ones(np.shape(u))], -1)
    if CFG['depth_conv'] == 'range':
        return r / np.linalg.norm(r, axis=-1, keepdims=True)
    return r  # 'z': depth value multiplies the (x/f, y/f, 1) ray

def good_dense(m):
    return (not m['touch']) and m['claude_dev'] < 0.35 and 0.7 < m['size_ratio'] < 1.4

def observations(obj, N):
    """Per frame: u, v, d (px or nan), sigma_px, source."""
    rows = {}
    for n, m in obj['dense'].items():
        if good_dense(m):
            rows[n] = (m['cx'], m['cy'], min(m['d_minor'], m['bw'], m['bh']) if m['d_minor'] > 0 else np.nan,
                       CFG['sig_px_dense'], 'dense')
    for fr, x, y, wh in obj['claude']:
        if fr not in rows:
            rows[fr] = (x, y, np.nan, CFG['sig_px_claude'], 'claude')
    ns = np.array(sorted(rows))
    a = [rows[n] for n in ns]
    return dict(n=ns, t=t_real(ns), u=np.array([x[0] for x in a]), v=np.array([x[1] for x in a]),
                d=np.array([x[2] for x in a], float), sig=np.array([x[3] for x in a]),
                src=np.array([x[4] for x in a]))

def size_at(obs, t, half=0.09):
    m = (np.abs(obs['t'] - t) <= half) & np.isfinite(obs['d'])
    if m.sum() == 0:
        return None
    return float(np.median(obs['d'][m]))

# ---------------------------------------------------------------- segmentation (2D + size)
def _quad_sse(t, Y, w):
    if len(t) < 3:
        return 0.0
    tc = t - t.mean()
    A = np.column_stack([np.ones_like(tc), tc, tc ** 2]) * w[:, None]
    sse = 0.0
    for k in range(Y.shape[1]):
        y = Y[:, k] * w
        coef, *_ = np.linalg.lstsq(A, y, rcond=None)
        r = y - A @ coef
        sse += float(np.sum(np.minimum(r ** 2, 16.0)))  # robust cap at 4 sigma
    return sse

def segment(obs):
    t, u, v, sig = obs['t'], obs['u'], obs['v'], obs['sig']
    n = len(t)
    Y = np.column_stack([u, v]); w = 1.0 / sig
    ms = CFG['min_seg']
    if n < 2 * ms:
        return [(0, n)]
    best = np.full(n + 1, np.inf); best[0] = 0.0; prev = np.zeros(n + 1, int)
    for j in range(ms, n + 1):
        for i in range(0, j - ms + 1):
            if not np.isfinite(best[i]):
                continue
            c = best[i] + _quad_sse(t[i:j], Y[i:j], w[i:j]) + CFG['seg_pen']
            if c < best[j]:
                best[j], prev[j] = c, i
    segs = []; j = n
    while j > 0:
        i = prev[j]; segs.append((i, j)); j = i
    return segs[::-1]

# ---------------------------------------------------------------- 3D weighted least squares
def wls(ts, P, Wm, model, t0, gvec=None):
    """Fit P(t) = P0 + V (t-t0) + 0.5 A (t-t0)^2 with per-point 3x3 weight matrices.
    model: 'cv' (A=0), 'ca' (A free), 'g' (A = gvec fixed)."""
    k = {'cv': 6, 'ca': 9, 'g': 6}[model]
    M = np.zeros((k, k)); b = np.zeros(k)
    for ti, Pi, Wi in zip(ts, P, Wm):
        tau = ti - t0
        cols = [np.eye(3), tau * np.eye(3)] + ([0.5 * tau ** 2 * np.eye(3)] if model == 'ca' else [])
        J = np.hstack(cols)
        y = Pi - (0.5 * tau ** 2 * gvec if model == 'g' else 0)
        M += J.T @ Wi @ J; b += J.T @ Wi @ y
    try:
        x = np.linalg.solve(M + 1e-9 * np.eye(k), b)
    except np.linalg.LinAlgError:
        return None
    P0, V = x[:3], x[3:6]
    A = x[6:9] if model == 'ca' else (gvec if model == 'g' else np.zeros(3))
    chi2 = 0.0
    for ti, Pi, Wi in zip(ts, P, Wm):
        tau = ti - t0
        e = Pi - (P0 + V * tau + 0.5 * A * tau ** 2)
        chi2 += float(e @ Wi @ e)
    return dict(P0=P0, V=V, A=A, chi2=chi2, k=k, t0=t0, model=model)

def build_points(obs, idx, D, f, W, H, anchors):
    ts, P, Wm = [], [], []
    for i in idx:
        rr = ray(obs['u'][i], obs['v'][i], W, H, f)
        rn = np.linalg.norm(rr); e = rr / rn
        d = obs['d'][i]
        lat_sig = obs['sig'][i] / f  # radians-ish; scaled by range below
        if np.isfinite(d) and d > 3:
            r = f * D / d
            rad_sig = r * max(CFG['sig_d_dense'], 1.0 / d)
            Pi = r * rr
        else:
            r = None
            Pi = None
        if Pi is None:
            # lateral-only constraint: placeholder range from the nearest sized observation, radial weight 0
            ds = obs['d'][np.isfinite(obs['d'])]
            rguess = f * D / np.median(ds) if len(ds) else 1.5
            Pi = rguess * rr / (rn if CFG['depth_conv'] == 'range' else 1.0)
            rad_w = 0.0; r = rguess
        else:
            rad_w = 1.0 / rad_sig ** 2
        lat = r * lat_sig
        Wi = rad_w * np.outer(e, e) + (np.eye(3) - np.outer(e, e)) / lat ** 2
        ts.append(obs['t'][i]); P.append(Pi); Wm.append(Wi)
    for (ta, ra, ua, va) in anchors:
        rr = ray(ua, va, W, H, f); rn = np.linalg.norm(rr); e = rr / rn
        Pi = ra * rr
        Wi = np.outer(e, e) / (0.01 * ra) ** 2 + (np.eye(3) - np.outer(e, e)) / (ra * 2.0 / f) ** 2
        ts.append(ta); P.append(Pi); Wm.append(Wi)
    return np.array(ts), np.array(P), Wm

def fit_segment(obs, i0, i1, D, f, W, H, anchors):
    idx = list(range(i0, i1))
    tmin, tmax = obs['t'][i0], obs['t'][i1 - 1]
    anc = [a for a in anchors if tmin - 0.02 <= a[0] <= tmax + 0.02]
    ts, P, Wm = build_points(obs, idx, D, f, W, H, anc)
    t0 = float(np.mean(ts))
    fits = {}
    for model in ('cv', 'ca'):
        r = wls(ts, P, Wm, model, t0)
        if r:
            fits[model] = r
    out = dict(i0=i0, i1=i1, tmin=tmin, tmax=tmax, n=len(idx), n_anchor=len(anc), fits=fits)
    ca = fits.get('ca')
    if ca is not None:
        a = np.linalg.norm(ca['A'])
        down = np.array([0.0, 1.0, 0.0])
        ang = math.degrees(math.acos(np.clip(ca['A'] @ down / max(a, 1e-9), -1, 1)))
        out['a_ca'] = a; out['ang_down'] = ang
        if 5.0 <= a <= 15.0 and ang <= CFG['gravity_tol_deg'] and len(idx) >= 6:
            g = 9.8 * ca['A'] / a
            r = wls(ts, P, Wm, 'g', t0, gvec=g)
            if r:
                fits['g'] = r
    # model choice by AIC with noise scale from the CA fit
    if 'ca' in fits:
        dof = max(3 * len(ts) - 9, 1)
        s2 = max(fits['ca']['chi2'] / dof, 1.0)
        aic = {m: fr['chi2'] / s2 + 2 * fr['k'] for m, fr in fits.items()}
        out['aic'] = aic; out['s2'] = s2
        out['best'] = min(aic, key=aic.get)
    elif 'cv' in fits:
        out['best'] = 'cv'
    return out

def pos(fr, t):
    tau = t - fr['t0']
    return fr['P0'] + fr['V'] * tau + 0.5 * fr['A'] * tau ** 2

def vel(fr, t):
    return fr['V'] + fr['A'] * (t - fr['t0'])

# ---------------------------------------------------------------- per-object reconstruction
def depth_entries(info):
    ents = {}
    for q in info['qs']:
        for e in q['depth']:
            try:
                d = float(e.get('distance_m'))
            except (TypeError, ValueError):
                continue
            tt = e.get('time')
            tt = None if tt is None else float(tt)
            ents[(str(e.get('object')), tt, round(d, 4))] = (str(e.get('object')), tt, d)
    return list(ents.values())

def match_anchor_names(objname, ents, all_objs):
    best, picks = 0.0, []
    for nm in {e[0] for e in ents}:
        s = name_score(objname, nm)
        if s > best + 1e-9:
            best, picks = s, [nm]
        elif s > 0 and abs(s - best) < 1e-9:
            picks.append(nm)
    if best >= 0.34:
        # ensure this depth name is not a better match for another tracked object
        ok = []
        for nm in picks:
            others = max((name_score(o, nm) for o in all_objs if o != objname), default=0)
            if others <= best + 1e-9:
                ok.append(nm)
        return ok, best
    return [], best

PRIOR_SIZE_RE = re.compile(r'(diameter|length|width|height)\s+of\s+(?:the\s+|one\s+)?(.+?)\s*=\s*([\d.]+)\s*(mm|cm|m)\b', re.I)

def prior_size(prior_text):
    m = PRIOR_SIZE_RE.search(prior_text or '')
    if not m:
        return None
    v = float(m.group(3)) * {'mm': 1e-3, 'cm': 1e-2, 'm': 1.0}[m.group(4).lower()]
    return m.group(2).strip().lower(), m.group(1).lower(), v

def reconstruct(info, dense_v):
    W, H = info['image_size']; f = F1280 * W / 1280.0
    ents = depth_entries(info)
    prior_text = next(iter(info['qinfo'].values()))['prior_text']
    ps = prior_size(prior_text)
    objs = {}
    names = list(dense_v['objs'].keys())
    for nm, o in dense_v['objs'].items():
        obs = observations(o, dense_v['N'])
        if len(obs['n']) < 4:
            continue
        dnames, sc = match_anchor_names(nm, ents, names)
        timed = [(e[1], e[2]) for e in ents if e[0] in dnames and e[1] is not None]
        Ds, anchors = [], []
        for ta, ra in timed:
            dpx = size_at(obs, ta)
            # image position at anchor time (interpolated)
            ua, va = np.interp(ta, obs['t'], obs['u']), np.interp(ta, obs['t'], obs['v'])
            if obs['t'].min() - 0.05 <= ta <= obs['t'].max() + 0.05:
                anchors.append((ta, ra, ua, va))
            if dpx:
                rr = ray(ua, va, W, H, f)
                rscale = np.linalg.norm(rr) if CFG['depth_conv'] == 'z' else 1.0
                Ds.append(ra * rscale * dpx / f)
        D_src = None; D = None; D_prior = None
        if ps and name_score(nm, ps[0]) >= 0.5 and ps[1] == 'diameter':
            D_prior = ps[2]
        if Ds:
            D, D_src = float(np.median(Ds)), 'anchor'
        elif D_prior:
            D, D_src = D_prior, 'prior'
        if D is None:
            objs[nm] = dict(obs=obs, D=None, D_src=None, anchors=anchors, segs=[], dnames=dnames)
            continue
        segs = []
        for (i0, i1) in segment(obs):
            segs.append(fit_segment(obs, i0, i1, D, f, W, H, anchors))
        objs[nm] = dict(obs=obs, D=D, D_src=D_src, D_anchor_list=Ds, D_prior=D_prior, anchors=anchors,
                        segs=segs, dnames=dnames)
    return objs

# ---------------------------------------------------------------- answering
def find_obj(objs, names):
    best, pick = 0.0, None
    for nm in objs:
        s = max((name_score(nm, x) for x in names), default=0)
        if s > best:
            best, pick = s, nm
    return pick if best >= 0.5 else None

def seg_at(o, t, tol=0.045):
    cands = [s for s in o['segs'] if s.get('best') and s['tmin'] - tol <= t <= s['tmax'] + tol]
    if not cands:
        return None
    # prefer the segment whose interior contains t, then the one with more observations
    cands.sort(key=lambda s: (-int(bool(s['tmin'] <= t <= s['tmax'])), -s['n']))
    return cands[0]

UNIT = {'m': 1, 'cm': 100, 'mm': 1000, 'm/s': 1, 'cm/s': 100, 'mm/s': 1000, 'km/h': 3.6,
        'm/s^2': 1, 'cm/s^2': 100, 'mm/s^2': 1000}

def answer(objs, kind, names, time=None, window=None, unit='m'):
    nm = find_obj(objs, names)
    if nm is None:
        return None, 'no_obj'
    o = objs[nm]
    if o['D'] is None or not o['segs']:
        return None, 'no_scale'
    info = dict(obj=nm, D_src=o['D_src'])
    if kind == 'speed':
        if time is None:
            return None, 'no_time'
        s = seg_at(o, time)
        if s is None:
            return None, 'time_outside'
        fr = s['fits'][s['best']]
        val = float(np.linalg.norm(vel(fr, time)))
        info.update(seg=s, model=s['best'])
    elif kind == 'acceleration':
        if time is None:
            return None, 'no_time'
        s = seg_at(o, time)
        if s is None:
            return None, 'time_outside'
        m = 'g' if 'g' in s['fits'] else 'ca'
        if m not in s['fits']:
            return None, 'no_ca'
        val = float(np.linalg.norm(s['fits'][m]['A']))
        info.update(seg=s, model=m)
    elif kind == 'displacement':
        if not window:
            return None, 'no_window'
        t0, t1 = window
        s0, s1 = seg_at(o, t0), seg_at(o, t1)
        if s0 is None or s1 is None:
            return None, 'time_outside'
        p0 = pos(s0['fits'][s0['best']], t0); p1 = pos(s1['fits'][s1['best']], t1)
        val = float(np.linalg.norm(p1 - p0))
        info.update(seg=s0, model=s0['best'])
    elif kind == 'path_length':
        tot = 0.0
        w0, w1 = (window if window else (-1e9, 1e9))
        for s in o['segs']:
            if not s.get('best'):
                continue
            a, b = max(s['tmin'], w0), min(s['tmax'], w1)
            if b <= a:
                continue
            fr = s['fits'][s['best']]
            tt = np.linspace(a, b, 60)
            pts = np.array([pos(fr, x) for x in tt])
            tot += float(np.sum(np.linalg.norm(np.diff(pts, axis=0), axis=1)))
        val = tot
        info.update(seg=None, model='path')
    else:
        return None, 'kind'
    return val * UNIT.get(unit, 1), info
