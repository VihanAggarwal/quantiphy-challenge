import sys, pickle
sys.path.insert(0, '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/lab3d')
import numpy as np, fit as FT
tag = sys.argv[2] if len(sys.argv) > 2 else ''
recon = pickle.load(open(FT.OUT + f'recon{tag}.pkl', 'rb'))
for key, objs in recon.items():
    if key[1] not in sys.argv[1].split(','):
        continue
    for nm, o in objs.items():
        print(key, nm, 'D', o['D'], o['D_src'], 'Dlist', np.round(o.get('D_anchor_list', []), 4), 'prior', o.get('D_prior'), 'anchors', [(a[0], a[1]) for a in o['anchors']])
        ob = o['obs']
        print('   n  ', list(ob['n']))
        print('   src', ''.join('d' if s == 'dense' else 'c' for s in ob['src']))
        print('   d  ', list(np.round(ob['d'], 0)))
        for s in o['segs']:
            print('   seg %.3f-%.3f n=%d anc=%d best=%s a_ca=%s ang=%s' % (s['tmin'], s['tmax'], s['n'], s['n_anchor'], s.get('best'),
                  np.round(s.get('a_ca', np.nan), 2), np.round(s.get('ang_down', np.nan), 0)),
                  {m: (np.round(fr['V'], 2).tolist(), np.round(fr['A'], 2).tolist(), round(fr['chi2'], 1)) for m, fr in s['fits'].items()})
