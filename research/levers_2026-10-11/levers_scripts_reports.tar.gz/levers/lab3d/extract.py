"""Per lab video: Claude objects (merged tracks, full-res px), questions, depth anchors, prior.
Test records: runs/test_v1_high_854; validation: runs/val_hr_v1_high (val_hires)."""
import sys, json, pickle, re
sys.path.insert(0, '/home/user/quantiphy-challenge')
import numpy as np, pandas as pd
from qp.data import load_split
from qp.geometry import name_score
R = '/home/user/quantiphy-challenge/'
OUT = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/lab3d/'
MOTION = {'speed', 'acceleration', 'displacement', 'path_length'}

def canon(name):
    return re.sub(r'\s+', ' ', str(name or '').strip().lower())

def video_info(run, split, vid, qrows):
    d = json.load(open(f'{R}runs/{run}/{split}/records/{vid}.json'))
    meta = d['meta']; sc = float(meta.get('scale') or 1.0)
    objs = {}
    qs = []
    for q in (d.get('parsed') or {}).get('questions', []):
        qs.append(dict(qid=q['qid'], target=q['spec']['target'], prior=q['spec']['prior'],
                       depth=q['spec'].get('depth') or [], direct=q.get('direct_answer')))
        for tr in q.get('tracks') or []:
            nm = canon(tr.get('object'))
            for o in tr.get('obs') or []:
                fr = o.get('frame')
                if fr is None:
                    continue
                box = o.get('box'); pt = o.get('point'); ext = o.get('extent')
                if box:
                    x0, y0, x1, y1 = [v / sc for v in box]
                    c = ((x0 + x1) / 2, (y0 + y1) / 2); wh = (abs(x1 - x0), abs(y1 - y0))
                    if pt:
                        c = (pt[0] / sc, pt[1] / sc)
                elif pt:
                    c = (pt[0] / sc, pt[1] / sc); wh = None
                elif ext:
                    (a, b), (cc, dd) = ext
                    c = ((a + cc) / 2 / sc, (b + dd) / 2 / sc); wh = None
                else:
                    continue
                objs.setdefault(nm, {}).setdefault(int(fr), []).append((c, wh, tr.get('role')))
    # merge duplicates per frame
    merged = {}
    for nm, frs in objs.items():
        rows = []
        for fr, lst in sorted(frs.items()):
            cs = np.array([x[0] for x in lst]); whs = [x[1] for x in lst if x[1]]
            wh = tuple(np.median(np.array(whs), axis=0)) if whs else None
            rows.append((fr, float(np.median(cs[:, 0])), float(np.median(cs[:, 1])), wh))
        merged[nm] = rows
    qinfo = {}
    for _, x in qrows.iterrows():
        qinfo[int(x.qid)] = dict(question=x.question, prior_text=x.prior, depth_info=x.depth_info,
                                 category=x.category, answer=x.get('answer', np.nan))
    return dict(vid=vid, meta=meta, objs=merged, qs=qs, qinfo=qinfo, n_frames=meta['n_frames_total'],
                image_size=meta['image_size'], scale=sc)

def main():
    out = {}
    for split, run in (('test', 'test_v1_high_854'), ('val_hires', 'val_hr_v1_high')):
        df = load_split(split)
        lab = df[df.video_source == 'lab']
        for vid, g in lab.groupby('video_id'):
            try:
                out[(split, vid)] = video_info(run, split, vid, g)
            except FileNotFoundError:
                print('missing', split, vid)
    pickle.dump(out, open(OUT + 'videos.pkl', 'wb'))
    print(len(out))

if __name__ == '__main__':
    main()
