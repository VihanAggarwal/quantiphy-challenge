"""Gate (fixed before looking at validation scores) + candidate CSV + validation comparison."""
import sys, re, pickle
sys.path.insert(0, '/home/user/quantiphy-challenge')
import numpy as np, pandas as pd
from qp.mra import item_scores
OUT = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/lab3d/'
R = '/home/user/quantiphy-challenge/'
GATE = dict(modes=('plane2', 'plane1', 'radial'), fam_spread=1.25, min_renders=2, prior_lo=0.8, prior_hi=1.25,
            grav_lo=7.5, grav_hi=12.5, sanity=3.0, acc_min_seg=8)

def norm_q(q):
    return re.sub(r'\s+', ' ', str(q).strip().lower())

def build(tag='2'):
    A = pd.read_pickle(OUT + f'answers{tag}.pkl'); P = pd.read_pickle(OUT + f'priors{tag}.pkl')
    A['qn'] = A.question.map(norm_q)
    ok = A.fit.notna() & A['mode'].isin(GATE['modes']) & (A.fit > 0)
    ok &= ~((A.kind == 'acceleration') & ~((A.model == 'g') | (A.n_seg >= GATE['acc_min_seg'])))
    A['row_ok'] = ok
    # family prior check
    fam_prior = {}
    for fam, g in P[P.kind != 'seg_accel'].groupby('fam'):
        dyn = g[~g.gravity.astype(bool)]
        if len(dyn):
            r = (dyn.fit / dyn.stated).dropna()
            fam_prior[fam] = ('dyn', float(np.median(r)) if len(r) else np.nan)
    fam_grav = {}
    seg = P[(P.kind == 'seg_accel') & (P.ang <= 30) & (P.n_seg >= 7) & (P.fit >= 4.0)]
    for fam, g in seg.groupby('fam'):
        fam_grav[fam] = float(np.median(g.fit))
    def fam_pass(fam):
        if fam in fam_prior:
            r = fam_prior[fam][1]
            return bool(np.isfinite(r) and GATE['prior_lo'] <= r <= GATE['prior_hi']), f'prior_ratio={r:.3f}'
        if fam in fam_grav:
            a = fam_grav[fam]
            return bool(GATE['grav_lo'] <= a <= GATE['grav_hi']), f'freefall_a={a:.2f}'
        return True, 'no_check'
    fp = {fam: fam_pass(fam) for fam in A.fam.unique()}
    A['fam_pass'] = A.fam.map(lambda f: fp[f][0]); A['fam_check'] = A.fam.map(lambda f: fp[f][1])
    # family agreement per (fam, question)
    agg = {}
    for (fam, qn), g in A[A.row_ok].groupby(['fam', 'qn']):
        v = g.fit.values
        agg[(fam, qn)] = dict(n_r=len(v), med=float(np.median(v)), spread=float(v.max() / v.min()))
    A['n_r'] = [agg.get((f, q), {}).get('n_r', 0) for f, q in zip(A.fam, A.qn)]
    A['fam_med'] = [agg.get((f, q), {}).get('med', np.nan) for f, q in zip(A.fam, A.qn)]
    A['spread'] = [agg.get((f, q), {}).get('spread', np.nan) for f, q in zip(A.fam, A.qn)]
    A['gate'] = A.fam_pass & (A.n_r >= GATE['min_renders']) & (A.spread <= GATE['fam_spread'])
    return A, fp, fam_prior, fam_grav

if __name__ == '__main__':
    A, fp, fam_prior, fam_grav = build()
    pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500); pd.set_option('display.max_colwidth', 70)
    print('family checks:'); [print('  ', k, v) for k, v in sorted(fp.items())]
    A.to_pickle(OUT + 'gated.pkl')
    print(A.groupby('split')[['row_ok', 'gate']].sum())
