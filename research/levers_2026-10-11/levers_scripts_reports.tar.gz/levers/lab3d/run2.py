import sys, pickle, re
sys.path.insert(0, '/home/user/quantiphy-challenge')
sys.path.insert(0, '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/lab3d')
import numpy as np, pandas as pd
import fit as FT, fit2 as F2
from run import family
from qp.data import load_split
OUT = FT.OUT

def run(tag='2'):
    vids = pickle.load(open(OUT + 'videos.pkl', 'rb'))
    dense = pickle.load(open(OUT + 'dense.pkl', 'rb'))
    units = {}
    for sp in ('test', 'val_hires'):
        df = load_split(sp)
        units.update(dict(zip(df.qid, df.target_unit)))
    rows, prow, recon = [], [], {}
    for key, info in vids.items():
        dv = dense.get(key)
        if not dv or 'objs' not in dv:
            continue
        objs = F2.reconstruct(info, dv)
        recon[key] = objs
        for q in info['qs']:
            tg = q['target']; kind = tg.get('kind')
            if kind not in FT.MOTION:
                continue
            qi = info['qinfo'].get(q['qid'], {})
            unit = units.get(q['qid']) or tg.get('unit') or 'm'
            val, inf = F2.answer(objs, kind, tg.get('objects') or [], tg.get('time'), tg.get('window'), unit)
            row = dict(split=key[0], vid=key[1], fam=family(key[1]), qid=q['qid'], kind=kind, question=qi.get('question'),
                       unit=unit, fit=val, direct=q['direct'], gt=qi.get('answer', np.nan), cat=qi.get('category'),
                       t=tg.get('time'), window=tg.get('window'))
            if isinstance(inf, dict):
                row.update(obj=inf['obj'], mode=inf['mode'], model=inf.get('model'), n_seg=inf.get('n_seg'), seg_a=inf.get('seg_a'))
            else:
                row.update(reason=inf)
            rows.append(row)
        q0 = info['qs'][0] if info['qs'] else None
        if q0:
            pr = q0['prior']
            ptxt = next(iter(info['qinfo'].values()))['prior_text']
            if pr.get('kind') in ('speed', 'acceleration') and pr.get('value_si'):
                names = pr.get('objects') or list(objs.keys())
                grav = bool(re.search(r'grav|^\s*acceleration\s*=', ptxt, re.I))
                val, inf = F2.answer(objs, pr['kind'], names, pr.get('time'), None, 'm/s' if pr['kind'] == 'speed' else 'm/s^2', use_g=False)
                prow.append(dict(split=key[0], vid=key[1], fam=family(key[1]), prior=ptxt, kind=pr['kind'], t=pr.get('time'),
                                 stated=pr['value_si'], fit=val, gravity=grav,
                                 obj=inf['obj'] if isinstance(inf, dict) else inf,
                                 mode=inf.get('mode') if isinstance(inf, dict) else None,
                                 model=inf.get('model') if isinstance(inf, dict) else None,
                                 n_seg=inf.get('n_seg') if isinstance(inf, dict) else None))
            # free-flight gravity check: every object's segments with >=7 good points
            for nm, o in objs.items():
                if not o.get('mode'):
                    continue
                obs = o['obs']
                for (i0, i1) in o['segs']:
                    idx = np.arange(i0, i1); idx = idx[o['good'][idx]]
                    if len(idx) >= 7:
                        tt = obs['t'][idx]
                        fr = F2._fit(tt, o['P'][idx], 1 / obs['sig'][idx] ** 2, float(tt.mean()), 'ca')
                        a = np.linalg.norm(fr['A'])
                        prow.append(dict(split=key[0], vid=key[1], fam=family(key[1]), prior='[segment accel] ' + ptxt[:30],
                                         kind='seg_accel', t=(round(tt.min(), 2), round(tt.max(), 2)), stated=np.nan, fit=a,
                                         gravity=None, obj=nm, mode=o['mode'], model='ca', n_seg=len(idx),
                                         ang=float(np.degrees(np.arccos(np.clip(fr['A'] @ F2.DOWN / max(a, 1e-9), -1, 1))))))
    A = pd.DataFrame(rows); Pp = pd.DataFrame(prow)
    A.to_pickle(OUT + f'answers{tag}.pkl'); Pp.to_pickle(OUT + f'priors{tag}.pkl')
    pickle.dump(recon, open(OUT + f'recon{tag}.pkl', 'wb'))
    return A, Pp

if __name__ == '__main__':
    A, Pp = run()
    pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500); pd.set_option('display.max_colwidth', 50)
    print(A.groupby('split').fit.apply(lambda s: s.notna().mean()), len(A))
    print(A.reason.value_counts()); print(A['mode'].value_counts())
    Pp['ratio'] = Pp.fit / Pp.stated
    print(Pp[Pp.kind != 'seg_accel'][['vid', 'prior', 't', 'stated', 'fit', 'ratio', 'obj', 'mode', 'model', 'n_seg']].to_string())
    print(Pp[Pp.kind == 'seg_accel'][['vid', 't', 'fit', 'ang', 'obj', 'mode', 'n_seg']].to_string())
