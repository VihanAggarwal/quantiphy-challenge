import sys
sys.path.insert(0, '/home/user/quantiphy-challenge')
import numpy as np, pandas as pd
from qp.mra import item_scores
OUT = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/lab3d/'
R = '/home/user/quantiphy-challenge/'
P = pd.read_pickle(OUT + 'priors2.pkl')
P = P[P.split == 'test']
dyn = P[(P.kind != 'seg_accel') & (~P.gravity.astype(bool))].copy()
dyn['ratio'] = dyn.fit / dyn.stated
dyn['mra'] = item_scores(dyn.fit.where(dyn.fit.notna(), np.nan), dyn.stated)
print('dynamic-prior harness (test renders): n renders', len(dyn), 'fitted', dyn.fit.notna().sum())
print('  MRA of fit predicting the stated prior (unfitted=0):', round(np.nanmean(dyn.mra.fillna(0)), 3), ' on fitted only:', round(np.nanmean(dyn.mra), 3))
print('  per family median ratio:', dyn.groupby('fam').ratio.median().round(3).to_dict())
print('  |log ratio|<0.1 share (fitted):', round((np.abs(np.log(dyn.ratio.dropna())) < 0.1).mean(), 3))
ff = P[(P.kind == 'seg_accel') & (P.ang <= 30) & (P.n_seg >= 7) & (P.fit >= 4)]
print('free-flight segments (test):', len(ff), 'median |a|', round(ff.fit.median(), 2), 'IQR', ff.fit.quantile([.25, .75]).round(2).tolist())
T = pd.read_pickle(OUT + 'test_gated.pkl')
# cross-render agreement for all row_ok questions with >=2 renders
A = pd.read_pickle(OUT + 'gated.pkl')
g = A[A.row_ok & (A.n_r >= 2)].drop_duplicates(['fam', 'qn'])
print('cross-render agreement (fam-questions with >=2 fitted renders):', len(g), 'spread<=1.10:', round((g.spread <= 1.10).mean(), 3),
      'spread<=1.25:', round((g.spread <= 1.25).mean(), 3), 'median spread', round(g.spread.median(), 3))
# strict variant: families whose label-free check actually ran and passed
base = pd.read_csv(R + 'submissions/trackA_probe7b_p5_ens_famext.csv')
strict = T[T['rep'] & ~T.fam_check.str.startswith('no_check')]
print('strict variant rows', len(strict), 'by cat', strict.cat.value_counts().to_dict(), 'families', sorted(strict.fam.unique()))
rep = strict.set_index('qid').fam_med
out = base[['id', 'parsed_value']].copy()
out['parsed_value'] = [rep.get(i, v) for i, v in zip(out.id, out.parsed_value)]
out.to_csv(OUT + 'trackA_lab3d_strict.csv', index=False)
r = strict.fam_med / strict.cur
print('  strict ratio median', round(r.median(), 3), 'p10/p90', r.quantile([.1, .9]).round(3).tolist())
for f in ('trackA_lab3d_replace.csv', 'trackA_lab3d_blend.csv', 'trackA_lab3d_strict.csv'):
    d = pd.read_csv(OUT + f)
    ch = (np.abs(d.parsed_value.values - base.parsed_value.values) > 1e-9 * np.abs(base.parsed_value.values))
    print(f, len(d), 'changed', int(ch.sum()), 'ids match', bool((d.id.values == base.id.values).all()), 'finite>0', bool((d.parsed_value > 0).all()))
