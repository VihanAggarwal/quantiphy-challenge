import sys
sys.path.insert(0, '/home/user/quantiphy-challenge')
import numpy as np, pandas as pd
from qp.mra import item_scores
OUT = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/lab3d/'
R = '/home/user/quantiphy-challenge/'
A = pd.read_pickle(OUT + 'gated.pkl')
cur = pd.read_csv(R + 'runs/val_hr_v1_high/val_hires.csv').set_index('id')
V = A[A.split == 'val_hires'].copy()
V['cur'] = V.qid.map(cur.parsed_value)
for c in ('cur', 'direct', 'fit', 'fam_med'):
    V['s_' + c] = item_scores(V[c].fillna(-1e9).abs().where(V[c].notna(), np.nan), V['gt'].astype(float))
pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 60)
print(V[['vid', 'qid', 'question', 'gt', 'cur', 'direct', 'fit', 'fam_med', 'n_r', 'spread', 'mode', 'model', 'fam_check', 'gate', 'reason']].round(3).to_string())
print()
for name, m in (('all motion', V.index == V.index), ('fit exists', V.fit.notna()), ('row_ok', V.row_ok), ('gate', V.gate)):
    s = V[m]
    print(f'{name:12s} n={len(s):2d}  cur={np.nanmean(s.s_cur) if len(s) else np.nan:.3f}  direct={np.nanmean(s.s_direct) if len(s) else np.nan:.3f}  '
          f'fit={np.nanmean(s.s_fit.fillna(0)) if len(s) else np.nan:.3f}  fam_med={np.nanmean(s.s_fam_med.fillna(0)) if len(s) else np.nan:.3f}')
V.to_pickle(OUT + 'val_eval.pkl')
