import sys, json
sys.path.insert(0, '/home/user/quantiphy-challenge')
import pandas as pd, numpy as np
from qp.data import load_split
R = '/home/user/quantiphy-challenge/'
OUT = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/lab3d/'
def recs(run, split, vids):
    out = {}
    for v in vids:
        try:
            d = json.load(open(f'{R}runs/{run}/{split}/records/{v}.json'))
        except FileNotFoundError:
            continue
        for q in (d.get('parsed') or {}).get('questions', []):
            out[q['qid']] = (q, d['meta'])
    return out
if __name__ == '__main__':
    t = load_split('test')
    lab = t[t.video_source == 'lab'].copy()
    sub = pd.read_csv(R + 'submissions/trackA_probe7b_p5_ens_famext.csv').set_index('id')
    geo = pd.read_csv(R + 'runs/test_v1_high_854/test.csv').set_index('id')
    rc = recs('test_v1_high_854', 'test', lab.video_id.unique())
    rows = []
    for _, x in lab.iterrows():
        q, meta = rc.get(x.qid, (None, None))
        tk = q['spec']['target']['kind'] if q else None
        rows.append(dict(qid=x.qid, vid=x.video_id, cat=x.category, q=x.question, kind=tk,
                         cur=sub.loc[x.qid, 'parsed_value'], direct=q.get('direct_answer') if q else None,
                         geo=geo.loc[x.qid, 'geo_value'], method=geo.loc[x.qid, 'method']))
    df = pd.DataFrame(rows)
    df.to_pickle(OUT + 'lab_table.pkl')
    pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 80); pd.set_option('display.max_rows', 1000)
    print(df.kind.value_counts())
    print(pd.crosstab(df.kind, df.cat))
    df['cur_dir'] = df.cur / df.direct
    print(df.groupby('kind').cur_dir.describe())
