import sys, pickle, re
sys.path.insert(0, '/home/user/quantiphy-challenge')
sys.path.insert(0, '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/lab3d')
import numpy as np, pandas as pd
import fit as FT
from qp.data import load_split
OUT = FT.OUT

def family(vid):
    m = re.match(r'captured_(\d+[ab]?)', vid)
    return m.group(1) if m else vid

def run(conv='range', tag=''):
    FT.CFG['depth_conv'] = conv
    vids = pickle.load(open(OUT + 'videos.pkl', 'rb'))
    dense = pickle.load(open(OUT + 'dense.pkl', 'rb'))
    units = {}
    for sp in ('test', 'val_hires'):
        df = load_split(sp)
        units.update(dict(zip(df.qid, df.target_unit)))
    rows, prow, recon = [], [], {}
    for key, info in vids.items():
        dv = dense.get(key)
        if not dv or 'objs' not in dv:
            continue
        objs = FT.reconstruct(info, dv)
        recon[key] = objs
        for q in info['qs']:
            tg = q['target']; kind = tg.get('kind')
            if kind not in FT.MOTION:
                continue
            qi = info['qinfo'].get(q['qid'], {})
            unit = units.get(q['qid']) or tg.get('unit') or 'm'
            val, inf = FT.answer(objs, kind, tg.get('objects') or [], tg.get('time'), tg.get('window'), unit)
            row = dict(split=key[0], vid=key[1], fam=family(key[1]), qid=q['qid'], kind=kind, question=qi.get('question'),
                       unit=unit, fit=val, direct=q['direct'], gt=qi.get('answer', np.nan), cat=qi.get('category'))
            if isinstance(inf, dict):
                s = inf.get('seg')
                row.update(obj=inf['obj'], D_src=inf['D_src'], model=inf['model'],
                           seg_n=s['n'] if s else None, seg_span=(s['tmax'] - s['tmin']) if s else None,
                           n_anchor=s['n_anchor'] if s else None)
            else:
                row.update(reason=inf)
            rows.append(row)
        # prior check (dynamic priors)
        q0 = info['qs'][0] if info['qs'] else None
        if q0:
            pr = q0['prior']
            if pr.get('kind') in ('speed', 'acceleration') and pr.get('value_si'):
                names = pr.get('objects') or []
                if not names:
                    names = list(objs.keys())
                ptxt = next(iter(info['qinfo'].values()))['prior_text']
                grav = bool(re.search(r'grav|^\s*acceleration\s*=', ptxt, re.I))
                val, inf = FT.answer(objs, pr['kind'], names, pr.get('time'), None, 'm/s' if pr['kind'] == 'speed' else 'm/s^2')
                prow.append(dict(split=key[0], vid=key[1], fam=family(key[1]), prior=ptxt, kind=pr['kind'], t=pr.get('time'),
                                 stated=pr['value_si'], fit=val, gravity=grav,
                                 obj=inf['obj'] if isinstance(inf, dict) else inf,
                                 model=inf.get('model') if isinstance(inf, dict) else None,
                                 D_src=inf.get('D_src') if isinstance(inf, dict) else None))
    A = pd.DataFrame(rows); Pp = pd.DataFrame(prow)
    A.to_pickle(OUT + f'answers{tag}.pkl'); Pp.to_pickle(OUT + f'priors{tag}.pkl')
    pickle.dump(recon, open(OUT + f'recon{tag}.pkl', 'wb'))
    return A, Pp, recon

if __name__ == '__main__':
    conv = sys.argv[1] if len(sys.argv) > 1 else 'range'
    A, Pp, recon = run(conv, '' if conv == 'range' else '_' + conv)
    pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500); pd.set_option('display.max_colwidth', 60)
    print(A.groupby('split').fit.apply(lambda s: s.notna().mean()), len(A))
    print(A.reason.value_counts())
    Pp['ratio'] = Pp.fit / Pp.stated
    print(Pp[['vid', 'prior', 't', 'stated', 'fit', 'ratio', 'obj', 'model', 'D_src']].to_string())
