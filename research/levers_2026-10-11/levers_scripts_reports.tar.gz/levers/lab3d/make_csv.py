import sys
sys.path.insert(0, '/home/user/quantiphy-challenge')
sys.path.insert(0, '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/lab3d')
import numpy as np, pandas as pd
from gate import GATE
OUT = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/lab3d/'
R = '/home/user/quantiphy-challenge/'
A = pd.read_pickle(OUT + 'gated.pkl')
base = pd.read_csv(R + 'submissions/trackA_probe7b_p5_ens_famext.csv')
T = A[A.split == 'test'].copy()
cur = base.set_index('id').parsed_value
T['cur'] = T.qid.map(cur)
T['ratio'] = T.fam_med / T.cur
T['sane'] = (T.ratio <= GATE['sanity']) & (T.ratio >= 1 / GATE['sanity'])
T['rep'] = T.gate & T.sane & T.fam_med.notna()
rep = T[T['rep']].set_index('qid').fam_med
out = base[['id', 'parsed_value']].copy()
out['parsed_value'] = [rep.get(i, v) for i, v in zip(out.id, out.parsed_value)]
assert len(out) == 3289 and out.parsed_value.notna().all() and (out.parsed_value > 0).all()
out.to_csv(OUT + 'trackA_lab3d_replace.csv', index=False)
# blend variant: geometric mean of fit and current on the same rows
blend = base[['id', 'parsed_value']].copy()
bl = (T[T['rep']].set_index('qid').fam_med * T[T['rep']].set_index('qid').cur) ** 0.5
blend['parsed_value'] = [bl.get(i, v) for i, v in zip(blend.id, blend.parsed_value)]
blend.to_csv(OUT + 'trackA_lab3d_blend.csv', index=False)
T.to_pickle(OUT + 'test_gated.pkl')
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 300); pd.set_option('display.max_colwidth', 70)
print('lab motion test rows', len(T), 'fit exists', T.fit.notna().sum(), 'row_ok', T.row_ok.sum(), 'gate', T.gate.sum(), 'replaced', T['rep'].sum())
print('changed rows (|ratio-1|>1e-6):', int((T['rep'] & (np.abs(T.ratio - 1) > 1e-6)).sum()))
def q(s):
    return pd.Series({'n': len(s), 'median': s.median(), 'p10': s.quantile(.1), 'p90': s.quantile(.9),
                      'within5%': (np.abs(np.log(s)) < np.log(1.05)).mean(), 'within10%': (np.abs(np.log(s)) < np.log(1.10)).mean(),
                      'gt25%off': (np.abs(np.log(s)) > np.log(1.25)).mean()})
X = T[T['rep']]
print(X.groupby('cat').ratio.apply(q).unstack().round(3))
print(X.groupby('kind').ratio.apply(q).unstack().round(3))
print('all-rows ratio fit/current (row_ok, any gate):')
print(T[T.row_ok].assign(r=T.fit / T.cur).groupby('cat').r.apply(q).unstack().round(3))
print(X[['vid', 'qid', 'cat', 'kind', 'question', 'cur', 'direct', 'fam_med', 'ratio', 'n_r', 'spread', 'mode', 'fam_check']].sort_values(['vid', 'qid']).round(3).to_string())
