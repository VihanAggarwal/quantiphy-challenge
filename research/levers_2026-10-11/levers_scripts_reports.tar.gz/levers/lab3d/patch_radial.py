p = 'fit2.py'
s = open(p).read()
old = """    good = cosv >= CFG2['min_cos']
    return dict(obs=obs, mode=mode, D=D, anchors=anchors, plane=plane, P=P, cos=cosv, good=good, check=check,
                segs=segment(obs), rs=rs)"""
new = """    good = cosv >= CFG2['min_cos']
    segs = segment(obs)
    if good.mean() < 0.5 and D and anchors:
        # near-radial motion: the plane is ill-conditioned. Range from apparent size (smoothed per segment,
        # log-quadratic in time), rescaled so the timed depth anchors are met exactly.
        rr = np.full(len(obs['t']), np.nan)
        for (i0, i1) in segs:
            idx = np.arange(i0, i1); ok = np.isfinite(rs[idx]) & (rs[idx] > 0)
            if ok.sum() < 4:
                continue
            tt, y = obs['t'][idx][ok], np.log(rs[idx][ok])
            keep = np.ones(len(tt), bool)
            for _ in range(2):
                deg = 2 if keep.sum() >= 6 else 1
                c = np.polyfit(tt[keep], y[keep], deg)
                res = y - np.polyval(c, tt)
                sd = max(1.4826 * np.median(np.abs(res[keep])), 0.01)
                keep = np.abs(res) <= 2.5 * sd
            rr[idx] = np.exp(np.polyval(c, obs['t'][idx]))
        fin = np.isfinite(rr)
        if fin.sum() >= 4:
            at = sorted((ta, ra / np.interp(ta, obs['t'][fin], rr[fin])) for ta, ra, _ in anchors)
            corr = np.interp(obs['t'], [a for a, _ in at], [b for _, b in at])
            rr = rr * corr
            P = rr[:, None] * E
            good = fin
            mode = 'radial'
            check['radial_corr'] = [round(b, 3) for _, b in at]
    return dict(obs=obs, mode=mode, D=D, anchors=anchors, plane=plane, P=P, cos=cosv, good=good, check=check,
                segs=segs, rs=rs)"""
assert old in s
s = s.replace(old, new)
open(p, 'w').write(s)
print('patched')
