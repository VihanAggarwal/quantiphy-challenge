"""Dense per-frame measurements of moving objects: background difference (median background,
fixed camera) inside a window around Claude's interpolated track. Output per object per frame:
cx, cy, bw, bh, area, d_minor (4*sqrt(min eigen of second moments)), d_eq, d_major, ok."""
import sys, pickle, time, os
import numpy as np, cv2
from multiprocessing import Pool
cv2.setNumThreads(1)
OUT = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/lab3d/'
VID = '/home/user/quantiphy-challenge/data/QuantiPhy/%s.mp4'

def frames(vid):
    c = cv2.VideoCapture(VID % vid)
    out = []
    while True:
        ok, f = c.read()
        if not ok:
            break
        out.append(f)
    return np.stack(out)

def moving(rows, min_move=6.0):
    if len(rows) < 3:
        return False
    xy = np.array([(r[1], r[2]) for r in rows])
    return np.ptp(xy[:, 0]) > min_move or np.ptp(xy[:, 1]) > min_move

def interp_track(rows, N):
    fr = np.array([r[0] for r in rows], float)
    x = np.array([r[1] for r in rows]); y = np.array([r[2] for r in rows])
    whs = [(r[0], max(r[3])) for r in rows if r[3]]
    n = np.arange(N)
    cx, cy = np.interp(n, fr, x), np.interp(n, fr, y)
    if whs:
        s = np.interp(n, [a for a, _ in whs], [b for _, b in whs])
    else:
        s = np.full(N, 40.0)
    return cx, cy, np.maximum(s, 8.0), int(fr.min()), int(fr.max())

def measure(mask):
    ys, xs = np.nonzero(mask)
    if len(xs) < 5:
        return None
    cx, cy = xs.mean(), ys.mean()
    cov = np.cov(np.vstack([xs, ys]))
    ev = np.linalg.eigvalsh(cov)
    return dict(cx=float(cx), cy=float(cy), bw=float(np.ptp(xs) + 1), bh=float(np.ptp(ys) + 1), area=float(len(xs)),
                d_minor=float(4 * np.sqrt(max(ev[0], 0))), d_major=float(4 * np.sqrt(max(ev[1], 0))),
                d_eq=float(2 * np.sqrt(len(xs) / np.pi)))

def track_video(item):
    key, info = item
    split, vid = key
    t0 = time.time()
    try:
        F = frames(vid)
    except Exception as e:
        return key, {'error': str(e)}
    N = len(F)
    bg = np.median(F, axis=0).astype(np.int16)
    res = {}
    for nm, rows in info['objs'].items():
        if not moving(rows):
            continue
        cx, cy, s, f0, f1 = interp_track(rows, N)
        recs = {}
        for n in range(max(0, f0 - 3), min(N, f1 + 4)):
            half = 1.2 * s[n] + 25
            x0, x1 = int(max(0, cx[n] - half)), int(min(F.shape[2], cx[n] + half))
            y0, y1 = int(max(0, cy[n] - half)), int(min(F.shape[1], cy[n] + half))
            if x1 - x0 < 8 or y1 - y0 < 8:
                continue
            d = np.abs(F[n, y0:y1, x0:x1].astype(np.int16) - bg[y0:y1, x0:x1]).max(axis=2)
            m = (d > 30).astype(np.uint8)
            m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
            m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
            k, lab, st, cen = cv2.connectedComponentsWithStats(m)
            exp_area = np.pi / 4 * s[n] ** 2
            best = None
            px, py = cx[n] - x0, cy[n] - y0
            for j in range(1, k):
                area = st[j][4]
                if area < 0.12 * exp_area:
                    continue
                dd = np.hypot(cen[j][0] - px, cen[j][1] - py)
                if dd > 0.8 * s[n] + 15:
                    continue
                sc = area / (1 + dd / max(s[n], 1))
                if best is None or sc > best[0]:
                    best = (sc, j)
            if best is None:
                continue
            j = best[1]
            r = measure(lab == j)
            if r is None:
                continue
            r['cx'] += x0; r['cy'] += y0
            r['touch'] = bool(st[j][0] == 0 or st[j][1] == 0 or st[j][0] + st[j][2] >= x1 - x0 or st[j][1] + st[j][3] >= y1 - y0)
            r['size_ratio'] = float(np.sqrt(r['area'] / exp_area))
            r['claude_dev'] = float(np.hypot(r['cx'] - cx[n], r['cy'] - cy[n]) / s[n])
            recs[n] = r
        res[nm] = dict(dense=recs, claude=rows, f0=f0, f1=f1)
    return key, dict(objs=res, N=N, secs=time.time() - t0)

if __name__ == '__main__':
    vids = pickle.load(open(OUT + 'videos.pkl', 'rb'))
    items = sorted(vids.items(), key=lambda kv: (kv[0][0] != 'val_hires', kv[0][1]))
    out = {}
    t0 = time.time()
    with Pool(4) as p:
        for i, (key, r) in enumerate(p.imap_unordered(track_video, items)):
            out[key] = r
            print(i, key, r.get('secs'), len(r.get('objs', {})), 'elapsed %.0f' % (time.time() - t0), flush=True)
            if i % 10 == 0:
                pickle.dump(out, open(OUT + 'dense.pkl', 'wb'))
    pickle.dump(out, open(OUT + 'dense.pkl', 'wb'))
    print('done')
