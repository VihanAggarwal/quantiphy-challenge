"""Version 2: plane back-projection. With >= 2 timed depth anchors of the moving object, its 3D path is
taken to lie in the vertical plane through the two anchor points (straight lines, slopes, projectiles);
every image observation is back-projected onto that plane. With 1 anchor (or a size prior), the plane's
horizontal direction comes from the apparent-size range trend (fallback: plane facing the camera).
Segment-wise fits in 3D: CV, CA, and gravity (|a| = 9.8, direction fitted) for free flight."""
import sys, math
import numpy as np
sys.path.insert(0, '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/lab3d')
import fit as FT
from fit import t_real, observations, size_at, segment, match_anchor_names, depth_entries, prior_size, find_obj, UNIT
from qp.geometry import name_score
DOWN = np.array([0.0, 1.0, 0.0])
CFG2 = dict(min_cos=0.12, win_v=0.25, win_a=0.4, min_pts=5)

def unit_ray(u, v, W, H, f):
    r = np.stack([(np.asarray(u, float) - W / 2) / f, (np.asarray(v, float) - H / 2) / f, np.ones(np.shape(u))], -1)
    return r / np.linalg.norm(r, axis=-1, keepdims=True)

def plane_from(A1, horiz_dir):
    h = horiz_dir - (horiz_dir @ DOWN) * DOWN
    if np.linalg.norm(h) < 1e-6:
        return None
    h /= np.linalg.norm(h)
    n = np.cross(h, DOWN); n /= np.linalg.norm(n)
    return A1, n

def backproject(e, plane):
    A1, n = plane
    c = e @ n
    if abs(c) < 1e-9:
        return None, 0.0
    lam = (A1 @ n) / c
    return lam * e, abs(c)

def reconstruct_obj(nm, o, info, ents, names, W, H, f, ps):
    obs = observations(o, None)
    if len(obs['n']) < 4:
        return None
    E = unit_ray(obs['u'], obs['v'], W, H, f)
    dnames, sc = match_anchor_names(nm, ents, names)
    timed = sorted({(e[1], e[2]) for e in ents if e[0] in dnames and e[1] is not None})
    anchors = []
    for ta, ra in timed:
        if obs['t'].min() - 0.05 <= ta <= obs['t'].max() + 0.05:
            ua, va = np.interp(ta, obs['t'], obs['u']), np.interp(ta, obs['t'], obs['v'])
            anchors.append((ta, ra, unit_ray(ua, va, W, H, f) * ra))
    # apparent-size ranges (balls): D from anchors, else size prior
    Ds = []
    for ta, ra, Pa in anchors:
        dpx = size_at(obs, ta)
        if dpx:
            Ds.append(ra * dpx / f)
    D_prior = ps[2] if (ps and ps[1] == 'diameter' and name_score(nm, ps[0]) >= 0.5) else None
    D = float(np.median(Ds)) if Ds else D_prior
    rs = f * D / obs['d'] if D else np.full(len(obs['t']), np.nan)
    mode, plane, check = None, None, {}
    if len(anchors) >= 2:
        # the two anchors farthest apart in 3D
        best = None
        for i in range(len(anchors)):
            for j in range(i + 1, len(anchors)):
                dd = np.linalg.norm(anchors[i][2] - anchors[j][2])
                if best is None or dd > best[0]:
                    best = (dd, i, j)
        dd, i, j = best
        A1, A2 = anchors[i][2], anchors[j][2]
        d12 = A2 - A1
        hz = d12 - (d12 @ DOWN) * DOWN
        if np.linalg.norm(hz) > 0.25 * np.linalg.norm(d12) and dd > 0.03:
            plane = plane_from(A1, hz); mode = 'plane2'
        elif dd > 0.03:  # near-vertical motion: vertical plane facing the camera through A1
            facing = A1 - (A1 @ DOWN) * DOWN
            plane = plane_from(A1, np.cross(DOWN, facing / np.linalg.norm(facing))); mode = 'plane2v'
        others = [a for k, a in enumerate(anchors) if k not in (i, j)]
        if plane is not None and others:
            errs = []
            for ta, ra, Pa in others:
                ua, va = np.interp(ta, obs['t'], obs['u']), np.interp(ta, obs['t'], obs['v'])
                P, c = backproject(unit_ray(ua, va, W, H, f), plane)
                if P is not None:
                    errs.append(np.linalg.norm(P) / ra)
            check['anchor3_ratio'] = errs
    if plane is None and (anchors or D):
        # one anchor (or size prior): horizontal direction from size-based 3D trend
        A1 = anchors[0][2] if anchors else None
        ok = np.isfinite(rs)
        if A1 is None and ok.sum() >= 3:
            k = np.argmin(np.abs(obs['t'] - np.median(obs['t'][ok])) + 1e3 * (~ok))
            A1 = rs[k] * E[k]
        if A1 is None:
            return dict(obs=obs, mode=None, D=D, anchors=anchors)
        hdir = None
        if ok.sum() >= 4:
            P = rs[ok, None] * E[ok]
            tt = obs['t'][ok]
            X = np.column_stack([np.ones_like(tt), tt - tt.mean()])
            coef, *_ = np.linalg.lstsq(X, P, rcond=None)
            vdir = coef[1]
            vh = vdir - (vdir @ DOWN) * DOWN
            lat = np.linalg.norm(vh - (vh @ (A1 / np.linalg.norm(A1))) * A1 / np.linalg.norm(A1))
            if np.linalg.norm(vh) > 1e-6:
                hdir = vh
                check['size_dir_radial_frac'] = float(abs(vh @ A1 / np.linalg.norm(A1)) / np.linalg.norm(vh))
        if hdir is None:
            a1h = A1 - (A1 @ DOWN) * DOWN
            hdir = np.cross(DOWN, a1h / np.linalg.norm(a1h))
        plane = plane_from(A1, hdir); mode = 'plane1' if anchors else 'plane0'
    if plane is None:
        return dict(obs=obs, mode=None, D=D, anchors=anchors)
    P = np.full((len(obs['t']), 3), np.nan); cosv = np.zeros(len(obs['t']))
    for k in range(len(obs['t'])):
        p, c = backproject(E[k], plane)
        if p is not None and p[2] > 0.1:
            P[k], cosv[k] = p, c
    good = cosv >= CFG2['min_cos']
    segs = segment(obs)
    if good.mean() < 0.5 and D and anchors:
        # near-radial motion: the plane is ill-conditioned. Range from apparent size (smoothed per segment,
        # log-quadratic in time), rescaled so the timed depth anchors are met exactly.
        rr = np.full(len(obs['t']), np.nan)
        for (i0, i1) in segs:
            idx = np.arange(i0, i1); ok = np.isfinite(rs[idx]) & (rs[idx] > 0)
            if ok.sum() < 4:
                continue
            tt, y = obs['t'][idx][ok], np.log(rs[idx][ok])
            keep = np.ones(len(tt), bool)
            for _ in range(2):
                deg = 2 if keep.sum() >= 6 else 1
                c = np.polyfit(tt[keep], y[keep], deg)
                res = y - np.polyval(c, tt)
                sd = max(1.4826 * np.median(np.abs(res[keep])), 0.01)
                keep = np.abs(res) <= 2.5 * sd
            rr[idx] = np.exp(np.polyval(c, obs['t'][idx]))
        fin = np.isfinite(rr)
        if fin.sum() >= 4:
            at = sorted((ta, ra / np.interp(ta, obs['t'][fin], rr[fin])) for ta, ra, _ in anchors)
            corr = np.interp(obs['t'], [a for a, _ in at], [b for _, b in at])
            rr = rr * corr
            P = rr[:, None] * E
            good = fin
            mode = 'radial'
            check['radial_corr'] = [round(b, 3) for _, b in at]
    return dict(obs=obs, mode=mode, D=D, anchors=anchors, plane=plane, P=P, cos=cosv, good=good, check=check,
                segs=segs, rs=rs)

def reconstruct(info, dense_v):
    W, H = info['image_size']; f = FT.F1280 * W / 1280.0
    ents = depth_entries(info)
    ps = prior_size(next(iter(info['qinfo'].values()))['prior_text'])
    names = list(dense_v['objs'].keys())
    out = {}
    for nm, o in dense_v['objs'].items():
        r = reconstruct_obj(nm, o, info, ents, names, W, H, f, ps)
        if r is not None:
            out[nm] = r
    return out

def _fit(tt, PP, ww, t0, model, g=None):
    tau = tt - t0
    cols = [np.ones_like(tau), tau] + ([0.5 * tau ** 2] if model == 'ca' else [])
    X = np.column_stack(cols) * np.sqrt(ww)[:, None]
    Y = (PP - (0.5 * tau[:, None] ** 2 * g[None, :] if model == 'g' else 0)) * np.sqrt(ww)[:, None]
    coef, *_ = np.linalg.lstsq(X, Y, rcond=None)
    res = Y - X @ coef
    A = coef[2] if model == 'ca' else (g if model == 'g' else np.zeros(3))
    return dict(P0=coef[0], V=coef[1], A=A, sse=float(np.sum(res ** 2)), t0=t0, n=len(tt), model=model)

def seg_points(o, t, tol=0.045):
    obs = o['obs']
    for (i0, i1) in o['segs']:
        if obs['t'][i0] - tol <= t <= obs['t'][i1 - 1] + tol:
            idx = np.arange(i0, i1)
            idx = idx[o['good'][idx]]
            return idx, (obs['t'][i0], obs['t'][i1 - 1])
    return None, None

def local(o, t, half, model='ca'):
    idx, span = seg_points(o, t)
    if idx is None or len(idx) < CFG2['min_pts']:
        return None
    obs = o['obs']
    tt = obs['t'][idx]
    sel = np.abs(tt - t) <= half
    if sel.sum() < CFG2['min_pts']:
        order = np.argsort(np.abs(tt - t))[:CFG2['min_pts']]
        sel = np.zeros(len(tt), bool); sel[order] = True
    w = 1.0 / obs['sig'][idx][sel] ** 2
    fr = _fit(tt[sel], o['P'][idx][sel], w, t, model if sel.sum() >= 4 else 'cv')
    fr['span'] = (tt[sel].min(), tt[sel].max()); fr['seg_span'] = span; fr['n_seg'] = len(idx)
    # free-flight check on the whole segment
    if len(idx) >= 7:
        full = _fit(tt, o['P'][idx], 1.0 / obs['sig'][idx] ** 2, float(np.mean(tt)), 'ca')
        a = np.linalg.norm(full['A'])
        ang = math.degrees(math.acos(np.clip(full['A'] @ DOWN / max(a, 1e-9), -1, 1)))
        fr['seg_a'] = a; fr['seg_ang'] = ang
        if 6.5 <= a <= 13.0 and ang <= 30:
            gf = _fit(tt, o['P'][idx], 1.0 / obs['sig'][idx] ** 2, t, 'g', g=9.8 * DOWN)
            fr['g'] = gf
    return fr

def answer(objs, kind, names, time=None, window=None, unit='m', use_g=True):
    nm = find_obj(objs, names)
    if nm is None:
        return None, 'no_obj'
    o = objs[nm]
    if not o.get('mode'):
        return None, 'no_scale'
    info = dict(obj=nm, mode=o['mode'])
    if kind in ('speed', 'acceleration'):
        if time is None:
            return None, 'no_time'
        fr = local(o, time, CFG2['win_v'] if kind == 'speed' else CFG2['win_a'])
        if fr is None:
            return None, 'time_outside'
        src = fr.get('g') if (use_g and fr.get('g') is not None) else fr
        val = float(np.linalg.norm(src['V'] if kind == 'speed' else src['A']))
        info.update(model=src['model'], n_seg=fr['n_seg'], seg_a=fr.get('seg_a'))
    elif kind == 'displacement':
        if not window:
            return None, 'no_window'
        ps = []
        for tt in window:
            fr = local(o, tt, CFG2['win_v'])
            if fr is None:
                return None, 'time_outside'
            ps.append(fr['P0'])
        val = float(np.linalg.norm(ps[1] - ps[0]))
        info.update(model='disp', n_seg=None)
    elif kind == 'path_length':
        obs = o['obs']; tot = 0.0
        w0, w1 = window if window else (-1e9, 1e9)
        g = o['good'] & (obs['t'] >= w0 - 0.02) & (obs['t'] <= w1 + 0.02)
        if g.sum() < 5:
            return None, 'few'
        idx = np.where(g)[0]
        # smoothed path: local CV/CA through each point, then summed distance
        tt = obs['t'][idx]; PP = o['P'][idx]
        sm = []
        for k in range(len(idx)):
            sel = np.abs(tt - tt[k]) <= 0.1
            if sel.sum() >= 3:
                sm.append(_fit(tt[sel], PP[sel], np.ones(sel.sum()), tt[k], 'cv')['P0'])
            else:
                sm.append(PP[k])
        sm = np.array(sm)
        val = float(np.sum(np.linalg.norm(np.diff(sm, axis=0), axis=1)))
        info.update(model='path', n_seg=len(idx))
    else:
        return None, 'kind'
    return val * UNIT.get(unit, 1), info
