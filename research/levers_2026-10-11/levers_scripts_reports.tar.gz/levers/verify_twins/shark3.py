import sys, cv2, numpy as np
sys.path.insert(0, '/home/user/quantiphy-challenge')
from qp.data import load_split
t = load_split('test'); P = dict(zip(t.video_id, t.video_path))
fps = 24.0
for vid in ('simulation_0100_segmented', 'simulation_0101_segmented', 'simulation_0102_segmented', 'simulation_0103_segmented'):
    cap = cv2.VideoCapture(P[vid]); S = []; B = []; k = 0
    while cap.grab():
        ok, im = cap.retrieve(); H, W = im.shape[:2]
        fg = ((255 - im.min(axis=2)) > 20).astype(np.uint8)
        n, lab, st, cen = cv2.connectedComponentsWithStats(fg, connectivity=8)
        sh = [i for i in range(1, n) if cen[i][1] > 0.62 * H and st[i, 4] > 500]
        bo = [i for i in range(1, n) if cen[i][1] < 0.62 * H and st[i, 4] > 20000]
        if sh:
            i = max(sh, key=lambda j: st[j, 4]); S.append((k, cen[i][0], st[i, 0], st[i, 0] + st[i, 2], st[i, 0] <= 0 or st[i, 0] + st[i, 2] >= W))
        if bo:
            i = max(bo, key=lambda j: st[j, 4]); B.append((k, st[i, 0], st[i, 0] + st[i, 2], st[i, 0] <= 0 or st[i, 0] + st[i, 2] >= W))
        k += 1
    S = np.array(S, float); B = np.array(B, float)
    s = S[(S[:, 0] >= 1) & (S[:, 4] == 0)]
    c = np.polyfit(s[:, 0] / fps, s[:, 1], 2); a = 2 * c[0]; v0 = c[1]
    # boat speed: a boat edge that is never at the border
    bl = B[(B[:, 0] >= 1) & (B[:, 1] > 0)]; br = B[(B[:, 0] >= 1) & (B[:, 2] < W)]
    vb = []
    for arr, col in ((bl, 1), (br, 2)):
        if len(arr) > 5:
            cc = np.polyfit(arr[:, 0] / fps, arr[:, col], 2); vb.append((cc[1], 2 * cc[0], len(arr)))
    full = B[(B[:, 1] > 0) & (B[:, 2] < W)]
    Lb = np.median(full[:, 2] - full[:, 1]) if len(full) else np.nan
    T = (k - 1) / fps
    # average speed over the clip from the fit (t in [0, T]) and from end-to-end displacement
    tt = np.linspace(0, T, 1000); vv = np.abs(np.polyval(np.polyder(c), tt)); avg_fit = vv.mean()
    disp = abs(S[-1, 1] - S[0, 1]) / T
    print(f'{vid}: frames {k} T={T:.3f}s shark v0 {v0:.1f}px/s a {a:.2f}px/s2 v0/a {v0 / a:.3f}s | boat edge v,a {[(round(x[0], 1), round(x[1], 2), x[2]) for x in vb]} '
          f'| boat len px (fully visible frames n={len(full)}) {Lb}')
    if np.isfinite(Lb):
        sc = 10.0 / Lb
        print(f'   boat=10m scale: shark v0 {abs(v0) * sc:.3f} m/s a {abs(a) * sc:.3f} m/s2 v(1.0) {abs(v0 + a * 1.0) * sc:.3f} '
              f'avg speed (fit, 0..T) {avg_fit * sc:.3f} avg (endpoint disp/T) {disp * sc:.3f} boat v {abs(vb[0][0]) * sc:.3f}')
    sc2 = 1.0 / abs(a)
    print(f'   a=1 scale: shark v0 {abs(v0) * sc2:.3f} avg(fit) {avg_fit * sc2:.3f} boat v {abs(vb[0][0]) * sc2 if vb else np.nan:.3f} boat len {Lb * sc2:.3f} m')
