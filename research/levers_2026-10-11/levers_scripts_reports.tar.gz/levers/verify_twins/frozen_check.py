import sys, json, cv2, numpy as np
sys.path.insert(0, '/home/user/quantiphy-challenge')
from qp.data import load_split
from qp.claude_annotate import frozen_first_frame
t = load_split('test'); P = dict(zip(t.video_id, t.video_path))
def rel(p):
    cap = cv2.VideoCapture(p); fr = []
    while len(fr) < 3 and cap.grab():
        ok, im = cap.retrieve(); fr.append(cv2.cvtColor(im, cv2.COLOR_BGR2GRAY).astype(np.float32))
    return float(np.abs(fr[1] - fr[0]).mean()), float(np.abs(fr[2] - fr[1]).mean())
segs = sorted(v for v in P if v.startswith('simulation') and v.endswith('_segmented'))
out = {}
for s in segs:
    o = s[:-10]
    r = {}
    for v in (s, o):
        if v in P:
            d01, d12 = rel(P[v]); r[v] = dict(d01=d01, d12=d12, rel=d01 / max(d12, 1e-9), ca=frozen_first_frame(P[v]))
    out[s] = r
json.dump(out, open('frozen_check.json', 'w'), indent=1)
ns = sum(1 for s, r in out.items() if r[s]['rel'] < 0.25); no = sum(1 for s, r in out.items() if s[:-10] in r and r[s[:-10]]['rel'] < 0.25)
print('segmented rel<0.25 (grey mean):', ns, '| originals rel<0.25:', no)
print('ca frozen segmented:', sum(r[s]['ca'] for s, r in out.items()), '| ca frozen originals:', sum(r[s[:-10]]['ca'] for s, r in out.items() if s[:-10] in r))
for s, r in out.items():
    if r[s]['rel'] < 0.5 or (s[:-10] in r and r[s[:-10]]['rel'] < 0.5):
        o = r.get(s[:-10], {})
        print(f"{s:28s} seg rel {r[s]['rel']:.3f} d01 {r[s]['d01']:.3f} ca {r[s]['ca']} | orig rel {o.get('rel', np.nan):.3f} d01 {o.get('d01', np.nan):.3f} ca {o.get('ca')}")
