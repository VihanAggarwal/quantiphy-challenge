import sys, pickle, json
import numpy as np, pandas as pd
sys.path.insert(0, '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/twins')
import solve_families as S
F = pickle.load(open('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/twins/test_feats.pkl', 'rb'))
fams = sys.argv[1].split(',')
pickle.dump({k: F[k] for k in fams}, open('sub_feats.pkl', 'wb'))
for tag, fz in (('keep0', False), ('drop0', True)):
    for k in fams:
        S.FROZEN[k] = {'frozen': fz}
    sys.argv = ['x', 'test', 'sub_feats.pkl', f'sub_{tag}.csv']
    S.main()
a = pd.read_csv('sub_keep0.csv'); b = pd.read_csv('sub_drop0.csv')
m = a.merge(b, on=['rec_video', 'qid'], suffixes=('_k', '_d'))
m = m[~m.is_3d_k]
m['f_keep0'] = np.where(m.prior_kind_k.isin(['speed', 'acceleration']), m.prior_px_claude_k / m.prior_px_mask_k, 1.0)
m['f_drop0'] = np.where(m.prior_kind_k.isin(['speed', 'acceleration']), m.prior_px_claude_d / m.prior_px_mask_d, 1.0)
m['hyb_keep0'] = m.claude_geo_k * m.f_keep0; m['hyb_drop0'] = m.claude_geo_k * m.f_drop0
pd.set_option('display.width', 250)
print(m[['rec_video', 'qid', 'kind_k', 'prior_kind_k', 'claude_geo_k', 'prior_px_claude_k', 'prior_px_mask_k', 'prior_px_mask_d', 'hyb_keep0', 'hyb_drop0']].round(3).to_string())
