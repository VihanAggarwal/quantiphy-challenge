"""Independent re-measurement of the shark initial speed (0101/0102/0103): own mask centroids + Claude points."""
import json, sys
import cv2, numpy as np
sys.path.insert(0, '/home/user/quantiphy-challenge')
from qp.data import load_split
t = load_split('test'); P = dict(zip(t.video_id, t.video_path))
R = '/home/user/quantiphy-challenge/runs/test_v1_high_854/test/records/'

def fit(ts, xs, deg=2):
    c = np.polyfit(ts, xs, deg)          # x = c0 t^2 + c1 t + c2
    a, v0 = 2 * c[0], c[1]
    res = xs - np.polyval(c, ts)
    return v0, a, float(np.sqrt(np.mean(res ** 2)))

for cam in ('0101', '0102', '0103'):
    vid = f'simulation_{cam}_segmented'
    cap = cv2.VideoCapture(P[vid]); cs = []; areas = []
    k = 0
    while cap.grab():
        ok, im = cap.retrieve()
        dev = 255 - im.min(axis=2)
        fg = (dev > 20).astype(np.uint8)
        n, lab, st, cen = cv2.connectedComponentsWithStats(fg, connectivity=8)
        i = 1 + int(np.argmax(st[1:, cv2.CC_STAT_AREA]))
        m = lab == i
        ys, xs = np.nonzero(m)
        x0, x1 = xs.min(), xs.max()
        cs.append((k, xs.mean(), ys.mean(), x0, x1)); areas.append(m.sum()); k += 1
    fps = 24.0
    C = np.array(cs)
    print(vid, 'frames', len(C), 'n comps last', n - 1, 'area med', int(np.median(areas)), 'area p10/p90',
          int(np.percentile(areas, 10)), int(np.percentile(areas, 90)))
    print('  centroid x frames 0..4:', np.round(C[:5, 1], 2), ' left edge:', C[:5, 3], ' right edge:', C[:5, 4])
    for name, col in (('centroid', 1), ('left_edge', 3), ('right_edge', 4)):
        x = C[:, col]
        for lab_, sel, toff in (('all t=k/fps', slice(0, None), 0), ('drop0 t=k/fps', slice(1, None), 0),
                                ('drop0 t=(k-1)/fps', slice(1, None), 1)):
            ts = (C[sel, 0] - toff) / fps
            v0, a, rms = fit(ts, x[sel])
            print(f'  {name:10s} {lab_:18s} v0/a = {v0 / a:7.4f} s  (v0 {v0:8.2f} px/s, a {a:7.2f} px/s2, rms {rms:.2f} px)')
    # cubic check: is the acceleration constant?
    ts = C[1:, 0] / fps
    c3 = np.polyfit(ts, C[1:, 1], 3)
    print('  cubic coeff (jerk term) / quad coeff:', round(c3[0] / c3[1], 4), ' a(t0)/a(tend) cubic:',
          round((2 * c3[1] + 6 * c3[0] * ts[0]) / (2 * c3[1] + 6 * c3[0] * ts[-1]), 3))
    # Claude points (seen px; scale cancels in v0/a)
    for v in (f'simulation_{cam}', vid):
        r = json.load(open(R + v + '.json'))
        for q in r['parsed']['questions']:
            for tr in q['tracks']:
                if tr['role'] == 'prior' and 'shark' in tr['object'].lower() and len(tr['obs']) > 5:
                    ks = np.array([o['frame'] for o in tr['obs']], float); xs = np.array([o['point'][0] for o in tr['obs']], float)
                    v0a, aa, rms = fit(ks / fps, xs); v0b, ab, rmsb = fit(ks[ks > 0] / fps, xs[ks > 0])
                    print(f'  Claude {v:28s} q{q["qid"]}: v0/a all {v0a / aa:6.3f} | drop0 {v0b / ab:6.3f}  (n={len(ks)})')
                    break
            else:
                continue
            break
