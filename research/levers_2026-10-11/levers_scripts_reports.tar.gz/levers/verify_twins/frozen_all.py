import sys, json, cv2, numpy as np
sys.path.insert(0, '/home/user/quantiphy-challenge')
from qp.data import load_split
t = load_split('test'); P = dict(zip(t.video_id, t.video_path)); nq = t.video_id.value_counts().to_dict()
out = {}
for v, p in sorted(P.items()):
    if not v.startswith('simulation'):
        continue
    cap = cv2.VideoCapture(p); fr = []
    while len(fr) < 3 and cap.grab():
        ok, im = cap.retrieve(); fr.append(cv2.cvtColor(im, cv2.COLOR_BGR2GRAY).astype(np.int16))
    if len(fr) < 3:
        continue
    c01 = int((np.abs(fr[1] - fr[0]) > 25).sum()); c12 = int((np.abs(fr[2] - fr[1]) > 25).sum())
    out[v] = dict(c01=c01, c12=c12, frozen=bool(c12 >= 200 and c01 <= 0.02 * c12))
json.dump(out, open('frozen_all.json', 'w'), indent=0)
orig = {k: o for k, o in out.items() if not k.endswith('_segmented')}
seg = {k: o for k, o in out.items() if k.endswith('_segmented')}
fo = [k for k, o in orig.items() if o['frozen']]
print('original sim clips', len(orig), 'frozen (c01 <= 2% of c12, c12>=200):', len(fo), '| questions', sum(nq[k] for k in fo))
print('  of which have a segmented twin:', sum(1 for k in fo if k + '_segmented' in P), '| questions incl. twins',
      sum(nq[k] + nq.get(k + '_segmented', 0) for k in fo))
print('segmented frozen by same test:', sum(o['frozen'] for o in seg.values()), 'of', len(seg))
amb = [(k, o['c01'], o['c12']) for k, o in orig.items() if not o['frozen'] and o['c01'] < 0.2 * max(o['c12'], 1)]
print('ambiguous originals (2-20%):', amb[:20])
print('static-ish originals (c12<200):', sum(1 for o in orig.values() if o['c12'] < 200))
print(sorted(fo))
