import sys, cv2, numpy as np
sys.path.insert(0, '/home/user/quantiphy-challenge')
from qp.data import load_split
t = load_split('test'); P = dict(zip(t.video_id, t.video_path))
print(t.columns.tolist())
fps = 24.0
def fit(ts, xs, deg=2):
    c = np.polyfit(ts, xs, deg); return c[-2], 2 * c[-3], float(np.sqrt(np.mean((xs - np.polyval(c, ts)) ** 2)))
for cam in ('0101', '0102', '0103'):
  for vid in (f'simulation_{cam}_segmented',):
    cap = cv2.VideoCapture(P[vid]); C = []; k = 0
    while cap.grab():
        ok, im = cap.retrieve(); H, W = im.shape[:2]
        fg = ((255 - im.min(axis=2)) > 20).astype(np.uint8)
        n, lab, st, cen = cv2.connectedComponentsWithStats(fg, connectivity=8)
        cand = [i for i in range(1, n) if cen[i][1] > 0.62 * H and st[i, 4] > 500]
        if cand:
            i = max(cand, key=lambda j: st[j, 4])
            x0, y0, w, h, a = st[i]
            edge = x0 <= 0 or x0 + w >= W
            C.append((k, cen[i][0], cen[i][1], x0, x0 + w, a, edge))
        k += 1
    C = np.array(C, float); ok = C[:, 6] == 0
    print(vid, 'frames', k, 'shark found', len(C), 'non-edge', int(ok.sum()), 'area med', int(np.median(C[ok, 5])),
          'area p10/p90 %.0f/%.0f' % tuple(np.percentile(C[ok, 5], [10, 90])))
    print('  cx frames 0..3', np.round(C[:4, 1], 2), ' x0', C[:4, 3], ' x1', C[:4, 4])
    D = C[ok]
    for name, col in (('centroid', 1), ('left', 3), ('right', 4)):
        for lab_, sel, toff in (('all', D[:, 0] >= 0, 0), ('drop0', D[:, 0] >= 1, 0), ('drop0 shift', D[:, 0] >= 1, 1)):
            v0, a, rms = fit((D[sel, 0] - toff) / fps, D[sel, col])
            print(f'  {name:8s} {lab_:12s} v0/a = {v0 / a:6.3f} s  rms {rms:.2f}px  a {a:.1f}px/s2')
    sel = D[:, 0] >= 1
    c3 = np.polyfit(D[sel, 0] / fps, D[sel, 1], 3); ts = D[sel, 0] / fps
    acc = lambda tt: 2 * c3[1] + 6 * c3[0] * tt
    print('  cubic fit on centroid: a(start)/a(end) = %.3f ; v0/a(t0) from cubic = %.3f' % (acc(ts[0]) / acc(ts[-1]), c3[2] / acc(0)))
