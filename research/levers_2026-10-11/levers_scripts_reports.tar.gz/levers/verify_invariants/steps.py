"""Per-transition step ratios of a moving blob (background difference) on lab clips: is transition 4->5 a drop
or motion onset? For each clip, track the largest moving blob near Claude's prior/target track and
report step(i)/median(step(i-2..i+2 excl i)) for all transitions where the blob moves > 2 px/frame."""
import sys, cv2, numpy as np, pandas as pd
sys.path.insert(0, '/home/user/quantiphy-challenge')
sys.path.insert(0, '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/invariants/work')
import inv
df, rec, anns = inv.load('test', '/home/user/quantiphy-challenge/runs/test_v1_high_854/test/records')

def frames(p):
    c = cv2.VideoCapture(p); out = []
    while True:
        ok, f = c.read()
        if not ok: break
        out.append(f)
    return out

def track(fr, seed_t, seed_uv, thr=28, min_area=60, radius=90):
    bg = np.median(np.stack(fr).astype(np.float32), axis=0); out = {}
    for n, f in enumerate(fr):
        t = n / 24.0
        pred = np.array([np.interp(t, seed_t, seed_uv[:, 0]), np.interp(t, seed_t, seed_uv[:, 1])])
        d = np.abs(f.astype(np.float32) - bg).max(axis=2)
        m = (d > thr).astype(np.uint8)
        m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        k, lab, st, cen = cv2.connectedComponentsWithStats(m)
        best = None
        for j in range(1, k):
            if st[j][4] < min_area: continue
            dd = np.hypot(*(cen[j] - pred))
            if dd < radius and (best is None or dd < best[0]): best = (dd, j)
        if best is not None: out[n] = cen[best[1]]
    return out

rows = []
for vid in sys.argv[1:]:
    q = df[df.video_id == vid]
    a = anns.get(int(q.qid.iloc[0]))
    best = None
    for tr in a.tracks:
        pts = [(o.t, o.point) for o in tr.obs if o.point is not None]
        if len(pts) >= 6 and (best is None or len(pts) > len(best)): best = pts
    if best is None: continue
    st = np.array([p[0] for p in best]); su = np.array([p[1] for p in best], float)
    fr = frames(q.video_path.iloc[0])
    trk = track(fr, st, su)
    step = {n: float(np.hypot(*(trk[n + 1] - trk[n]))) for n in trk if n + 1 in trk}
    r = {}
    for i in sorted(step):
        nb = [step[j] for j in (i - 2, i - 1, i + 1, i + 2) if j in step]
        if len(nb) >= 3 and np.median(nb) > 2:
            r[i] = round(step[i] / np.median(nb), 2)
    print(vid, {k: v for k, v in r.items() if v > 1.3 or k in (3, 4, 11, 35)}, flush=True)
    rows.append(dict(video=vid, **{f's{k}': v for k, v in r.items()}))
pd.DataFrame(rows).to_csv('/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/verify_invariants/steps.csv', index=False)
