"""Reproduce the actual test pipeline (refine + dense motion from cache) on lab videos, then apply the
capture clock to the post-stepped tracks (incl. dense tracks) and compare the resulting ratio with the
candidate's harness ratio (sparse tracks only)."""
import sys, copy, time
import numpy as np, pandas as pd
sys.path.insert(0, '/home/user/quantiphy-challenge'); sys.path.insert(0, '/home/user/quantiphy-challenge/scripts')
sys.path.insert(0, '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/invariants/work')
import run_claude as rc
from qp import claude_annotate as ca
from qp.data import load_split
import inv

V = '/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/levers/verify_invariants/'


def main():
    split = sys.argv[1] if len(sys.argv) > 1 else 'test'
    recdir = {'test': '/home/user/quantiphy-challenge/runs/test_v1_high_854/test/records',
              'val_hires': '/home/user/quantiphy-challenge/runs/val_hr_v1_high/val_hires/records',
              'val': '/home/user/quantiphy-challenge/runs/val_opus_high/val/records'}[split]
    tag = split
    if len(sys.argv) > 2:
        recdir = f'/home/user/quantiphy-challenge/runs/{sys.argv[2]}/{split}/records'; tag = sys.argv[2]
    t0 = time.time()
    df = load_split(split)
    df = df[df.video_source == 'lab'].copy()
    records = rc.load_records(__import__('pathlib').Path(recdir))
    records = {k: v for k, v in records.items() if v.get('status') in rc.USABLE and k in set(df.video_id)}
    prep = rc.prepare_records(df, records)
    anns = ca.load_annotations(prep)
    anns = rc.post_steps(anns, df, prep, refine_priors=True, dense='motion', dense_cache=V + 'dense_cache/' + split,
                         dense_workers=4)
    print('post-steps done', time.time() - t0, flush=True)
    res_v = rc.build_results(df, records, rule='assumed_src', anns=copy.deepcopy(anns))
    anns_c = inv.remap_times(anns, df, prep, query='keep')
    res_c = rc.build_results(df, records, rule='assumed_src', anns=anns_c)
    m = res_v.merge(res_c[['id', 'geo_value', 'parsed_value']], on='id', suffixes=('_v', '_c'))
    m.to_pickle(V + f'repro_full_{tag}.pkl')
    print('done', time.time() - t0)


if __name__ == '__main__':
    main()
