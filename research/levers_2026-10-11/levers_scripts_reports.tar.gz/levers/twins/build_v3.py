"""Candidate v3 ("motion channel"): only the MOTION pixel measurements come from the segmented-twin masks
(dense centroid tracks, frozen first frame dropped); extents stay Claude's (seg masks have boundary halos,
shadows in the moving layer and missing parts, e.g. forklift forks). For a 2D question:

    hybrid = claude_geo * (target_px_mask / target_px_claude if the target is a motion quantity)
                        * (prior_px_claude / prior_px_mask  if the prior is a motion quantity)

applied as a correction factor r = hybrid / claude_geo of the record whose own Claude geometry equals the
submitted base value (within 1%); rows whose base was changed by family rules (pooling, facts) are skipped.
Gate: the motion roles pass solve_families.role_ok, the solve has no bad flags, |log r| <= log 1.25, r != 1,
and when both twin records have the question their mask motion px agree within 3%.

usage: build_v3.py SOLVED_CSV OUT_CSV
"""
import json
import math
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, "/home/user/quantiphy-challenge")
sys.path.insert(0, str(Path(__file__).parent))
from qp.data import load_split  # noqa: E402
from solve_families import GATE  # noqa: E402

BASE = "/home/user/quantiphy-challenge/submissions/trackA_probe7b_p5_ens_famext.csv"
MOTION = {"speed", "acceleration", "displacement", "path_length"}
RMAX = 1.25
AREA_DISP_MAX = 0.15   # p90 |log(area / median area)| of a motion role's clean frames (merges, white objects)


def normq(q):
    q = re.sub(r"(\d+)\.0+(?!\d)", r"\1", str(q).lower())
    return re.sub(r"[^a-z0-9.]", "", q)


def main():
    solved, out_csv = sys.argv[1:3]
    s = pd.read_csv(solved)
    s = s[(s.tag == "test") & (~s.is_3d)].copy()
    test = load_split("test").set_index("qid")
    base = pd.read_csv(BASE)
    bval = dict(zip(base.id, base.parsed_value))
    s["nq"] = s.qid.map(test.question).map(normq)
    s["base"] = s.qid.map(bval)
    s["fam"] = s.seg_video
    import pickle
    from qp.open.cv_track import object_key
    FE = pickle.load(open(str(Path(__file__).parent / "test_feats.pkl"), "rb"))

    def area_disp(seg, rec, obj):
        fe = FE.get(seg, {}).get("feats", {}).get(f"test:{rec}|{object_key(obj)[0]}")
        if not fe:
            return None
        ks = sorted(k for k in fe if fe[k]["clean"] and not fe[k]["edge"])
        if len(ks) < 5:
            return None
        a = np.log([fe[k]["area"] for k in ks])
        return float(np.percentile(np.abs(a - np.median(a)), 90))

    rows = []
    for r in s.itertuples():
        roles = json.loads(r.roles)
        t_motion, p_motion = r.kind in MOTION, r.prior_kind in MOTION
        f, why = 1.0, ""
        if not (t_motion or p_motion):
            why = "no_motion_part"
        else:
            for ro in roles:
                if ro["kind"] in MOTION and not ro["ok"]:
                    why = why or f"{ro['role']}:{ro['why']}"
                if ro["kind"] in MOTION and not why:
                    ad = area_disp(r.seg_video, r.rec_video, ro["obj"])
                    if ad is None or ad > AREA_DISP_MAX:
                        why = f"{ro['role']}:area_unstable"
            flags = str(r.mask_flags)
            bad = [x for x in flags.split(";") if x and any(x.startswith(b) or b in x for b in GATE["bad_flags"])]
            if not why and (not np.isfinite(r.mask_value) or bad):
                why = "solve:" + (bad[0] if bad else "failed")
            if not why:
                if t_motion:
                    if not (r.target_px_mask > 0 and r.target_px_claude > 0):
                        why = "no_target_px"
                    else:
                        f *= r.target_px_mask / r.target_px_claude
                if p_motion:
                    if not (r.prior_px_mask > 0 and r.prior_px_claude > 0):
                        why = why or "no_prior_px"
                    else:
                        f *= r.prior_px_claude / r.prior_px_mask
        rows.append(dict(qid=r.qid, rec_video=r.rec_video, fam=r.fam, nq=r.nq, category=r.category, kind=r.kind,
                         prior_kind=r.prior_kind, claude_geo=r.claude_geo, factor=f if not why else np.nan,
                         hybrid=r.claude_geo * f if not why else np.nan, why=why,
                         tpx=r.target_px_mask if t_motion else np.nan, ppx=r.prior_px_mask if p_motion else np.nan))
    R = pd.DataFrame(rows)
    # twin agreement on mask motion px
    R["twin_ok"] = True
    for (fam, nq), g in R.groupby(["fam", "nq"]):
        if g.rec_video.nunique() == 2:
            ok = True
            for c in ("tpx", "ppx"):
                v = g[c].to_numpy(float)
                if np.isfinite(v).all() and abs(math.log(v[0] / v[1])) > 0.03:
                    ok = False
                if np.isfinite(v).sum() == 1:
                    ok = False
            R.loc[g.index, "twin_ok"] = ok
    # family facts: a base value equal to a stated prior of a clip of the same scene family is exact
    from qp.claude_annotate import prior_si
    from qp.parse import _UNITS, canonical_unit
    from qp.postprocess import base_id
    F = json.load(open(str(Path(__file__).parent / "ref/big_levers_scripts_2026-10-10/scenegraph/families.json")))
    fmap = {b: k for k, v in F["series_families"].items() for b in v["bases"]}
    smap = {vid: k for k, v in F["scenarios"].items() for vid in v}
    famkey = lambda v: smap.get(v) or fmap.get(base_id(v)) or base_id(v)  # noqa: E731
    tt = test.reset_index()
    tt["fk"] = tt.video_id.map(famkey)
    facts = {f: np.array([x[0] for p in set(g.prior) if (x := prior_si(p))]) for f, g in tt.groupby("fk")}
    allfacts = np.array(sorted({x[0] for p in set(tt.prior) if (x := prior_si(p))}))
    fk_of = dict(zip(tt.qid, tt.fk))
    unit_of = dict(zip(tt.qid, tt.target_unit))

    def to_si(v, u):
        cu = canonical_unit(str(u or ""))
        return v * _UNITS[cu][0] if cu in _UNITS else v

    def is_fact(qid, b, pool=None):
        x = to_si(b, unit_of[qid])
        arr = facts.get(fk_of[qid], np.array([])) if pool is None else pool
        return bool(len(arr) and x > 0 and np.min(np.abs(arr - x) / x) < 1e-6)

    # pick, per qid, the record whose own Claude geometry equals the submitted base
    out_rows = []
    for qid in sorted(set(R.qid)):
        b = bval[qid]
        own = R[R.qid == qid].iloc[0]
        cands = R[(R.fam == own.fam) & (R.nq == own.nq)]
        src = cands[np.isfinite(cands.claude_geo) & (np.abs(np.log(cands.claude_geo / b)) < 0.01)]
        if not len(src):
            out_rows.append(dict(qid=qid, category=own.category, kind=own.kind, prior_kind=own.prior_kind, base=b,
                                 new=np.nan, why="base_modified_by_family_rules"))
            continue
        x = src.iloc[0]
        fact = is_fact(qid, b) or is_fact(qid, b, allfacts)
        why = x.why or ("twin_disagree" if not x.twin_ok else "") or ("base_is_stated_fact" if fact else "")
        fac = x.factor
        if not why and abs(math.log(fac)) > math.log(RMAX):
            why = "ratio_gate"
        if not why and abs(math.log(fac)) < 1e-9:
            why = "unchanged"
        out_rows.append(dict(qid=qid, category=own.category, kind=own.kind, prior_kind=own.prior_kind, base=b,
                             new=b * fac if not why else np.nan, factor=fac, why=why, src=x.rec_video, fact=fact,
                             would_be=b * fac if np.isfinite(fac) else np.nan, claude_geo=x.claude_geo))
    O = pd.DataFrame(out_rows)
    # label-free check: all family-fact rows (any record whose Claude geometry matched within 1%... or not):
    FX = []
    for r in R.itertuples():
        b = bval[r.qid]
        fam_fact, glob_fact = is_fact(r.qid, b), is_fact(r.qid, b, allfacts)
        if (fam_fact or glob_fact) and np.isfinite(r.factor) and r.factor > 0:
            FX.append(dict(qid=r.qid, rec=r.rec_video, kind=r.kind, prior_kind=r.prior_kind, fact=b, fam_fact=fam_fact,
                           claude_geo=r.claude_geo, hybrid=r.hybrid, twin_ok=r.twin_ok))
    FX = pd.DataFrame(FX)
    if len(FX):
        from qp.mra import item_scores
        FX["sc_claude"] = item_scores(FX.claude_geo, FX.fact); FX["sc_hybrid"] = item_scores(FX.hybrid, FX.fact)
        FX["le_claude"] = np.abs(np.log(FX.claude_geo / FX.fact)); FX["le_hybrid"] = np.abs(np.log(FX.hybrid / FX.fact))
        print("FACT CHECK (2D rows whose submitted value is a family-stated fact; gate passed except fact/ratio):")
        print(FX.round(3).to_string())
        print("  mean score claude %.3f hybrid %.3f | median |log err| claude %.4f hybrid %.4f | n=%d" % (
            FX.sc_claude.mean(), FX.sc_hybrid.mean(), FX.le_claude.median(), FX.le_hybrid.median(), len(FX)))
    O.to_csv(out_csv.replace(".csv", "_rows.csv"), index=False)
    ch = O[O.new.notna()]
    print("2D family qids:", len(O), "with a motion part:", int((O.kind.isin(MOTION) | O.prior_kind.isin(MOTION)).sum()))
    print("why:", O.why.fillna("").value_counts().to_dict())
    print("changed:", len(ch), ch.category.value_counts().to_dict())
    for c, g in ch.groupby("category"):
        lr = np.log(g.new / g.base)
        print(f"  {c}: n={len(g)} kinds={g.kind.value_counts().to_dict()} priors={g.prior_kind.value_counts().to_dict()} "
              f"new/old median {np.exp(lr.median()):.3f} p10 {np.exp(lr.quantile(.1)):.3f} p90 {np.exp(lr.quantile(.9)):.3f} "
              f"|log|>5%: {(np.abs(lr) > .05).sum()} >10%: {(np.abs(lr) > .1).sum()}")
    new = dict(bval)
    for r in ch.itertuples():
        new[r.qid] = float(r.new)
    out = base.copy()
    out["parsed_value"] = out.id.map(new)
    assert len(out) == 3289 and out.parsed_value.notna().all()
    out.to_csv(out_csv, index=False)
    print(ch.assign(r=ch.new / ch.base).sort_values("r")[["qid", "src", "category", "prior_kind", "kind", "base", "new", "r"]]
          .round(3).to_string())


if __name__ == "__main__":
    main()
