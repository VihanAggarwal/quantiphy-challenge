"""Track every Claude-named object of each simulation twin family on its segmented clip.

usage: track_families.py SPLIT OUT_PKL [workers]
SPLIT: test (records: runs/test_v1_high_854/test/records) | val_hires (runs/val_hr_v1_high/val_hires/records,
plus the test records of the same videos' originals when present).
Output: {seg_video: {"fps", "size", "n", "moving", "stats", "feats": {rec_video: {obj_key: {k: features}}},
                     "hints": {rec_video: {obj_key: [anchor dicts]}}, "skip_first"}}
"""
import json
import pickle

import numpy as np
import sys
import time
from multiprocessing import Pool
from pathlib import Path

sys.path.insert(0, "/home/user/quantiphy-challenge")
sys.path.insert(0, "/home/user/quantiphy-challenge/scripts")
sys.path.insert(0, str(Path(__file__).parent))
import run_claude as rc  # noqa: E402
from qp import claude_annotate as ca  # noqa: E402
from qp.data import load_split  # noqa: E402
import twinlib as T  # noqa: E402

REC = {"test": ["/home/user/quantiphy-challenge/runs/test_v1_high_854/test/records"],
       "val_hires": ["/home/user/quantiphy-challenge/runs/val_hr_v1_high/val_hires/records",
                     "/home/user/quantiphy-challenge/runs/test_v1_high_854/test/records"]}


def families(split):
    df = load_split(split)
    test = load_split("test") if split != "test" else df
    paths = dict(zip(test.video_id, test.video_path))
    paths.update(dict(zip(df.video_id, df.video_path)))
    segs = sorted({v for v in df.video_id if v.endswith("_segmented") and v.startswith("simulation")})
    return df, test, segs, paths


def job(args):
    seg, rec_vids, paths, split = args
    t0 = time.time()
    dfs = [load_split(split)] + ([load_split("test")] if split != "test" else [])
    objs, anns_by = {}, {}
    fps = None
    for tag, rv, recdir in rec_vids:
        rec = json.load(open(Path(recdir, f"{rv}.json")))
        if not rec or not rec.get("meta"):
            continue
        df = dfs[0] if tag == split.split("_")[0] else dfs[-1]
        rows = df[df.video_id == rv]
        prec = rc.prepare_records(rows, {rv: rec})
        anns = ca.load_annotations(prec)
        fps = float(rec["meta"]["fps"])
        hints = T.collect_hints(anns, fps)
        for key, oh in hints.items():
            objs[f"{tag}:{rv}|{key}"] = oh
        anns_by[rv] = anns
    if not objs:
        return seg, None
    skip = ca.frozen_first_frame(paths[seg])
    res, stats, size, n, moving = T.track_clip(paths[seg], objs, fps, skip_first=skip)
    out = {"fps": fps, "size": size, "n": n, "moving": moving, "stats": stats, "skip_first": skip,
           "feats": res, "hints": {k: [vars(h) for h in oh.hints] for k, oh in objs.items()},
           "ext_angles": {k: {d: float(np.median(v)) for d, v in oh.ext_angles.items()} for k, oh in objs.items()},
           "secs": round(time.time() - t0, 1)}
    print(f"{seg}: {len(objs)} objects, {n} frames, {out['secs']} s", flush=True)
    return seg, out


def main():
    split, out_pkl = sys.argv[1], sys.argv[2]
    workers = int(sys.argv[3]) if len(sys.argv) > 3 else 3
    only = sys.argv[4].split(",") if len(sys.argv) > 4 else None
    df, test, segs, paths = families(split)
    jobs = []
    for s in segs:
        if only and s not in only:
            continue
        o = s[:-len("_segmented")]
        rv = []
        if split == "test":
            rv = [("test", v, REC["test"][0]) for v in (s, o) if Path(REC["test"][0], f"{v}.json").exists()]
        else:
            rv = [("val", s, REC[split][0])] + [("test", v, REC["test"][0]) for v in (s, o)
                                                 if Path(REC["test"][0], f"{v}.json").exists()]
        jobs.append((s, rv, paths, split))
    print(len(jobs), "families", flush=True)
    out = {}
    with Pool(workers) as p:
        for seg, r in p.imap_unordered(job, jobs):
            if r is not None:
                out[seg] = r
                pickle.dump(out, open(out_pkl, "wb"))
    print("done", len(out))


if __name__ == "__main__":
    main()
