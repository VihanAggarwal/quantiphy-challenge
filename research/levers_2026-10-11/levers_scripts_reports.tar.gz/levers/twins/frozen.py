"""Frozen first frame per segmented clip, relative test: |f1-f0| < 0.25 |f2-f1| on foreground pixels."""
import sys, json, cv2, numpy as np
sys.path.insert(0, '/home/user/quantiphy-challenge')
from qp.data import load_split
from qp.claude_annotate import frozen_first_frame
out = {}
for split in ('test', 'val_hires'):
    t = load_split(split)
    for v, p in dict(zip(t.video_id, t.video_path)).items():
        if not (v.startswith('simulation') and v.endswith('_segmented')) or v in out:
            continue
        cap = cv2.VideoCapture(p); fr = []
        while len(fr) < 3 and cap.grab():
            ok, im = cap.retrieve(); fr.append(im.astype(np.int16))
        d01 = float(np.abs(fr[1] - fr[0]).max(axis=2).sum()); d12 = float(np.abs(fr[2] - fr[1]).max(axis=2).sum())
        orig = v[:-10]
        po = dict(zip(load_split('test').video_id, load_split('test').video_path)).get(orig) if False else None
        out[v] = dict(d01=d01, d12=d12, rel=d01 / max(d12, 1), frozen=bool(d12 > 0 and d01 < 0.25 * d12),
                      ca_frozen=frozen_first_frame(p))
json.dump(out, open('frozen.json', 'w'), indent=1)
print(sum(o['frozen'] for o in out.values()), 'frozen of', len(out), '| ca says', sum(o['ca_frozen'] for o in out.values()))
print({k: round(o['rel'], 3) for k, o in out.items() if o['frozen']})
