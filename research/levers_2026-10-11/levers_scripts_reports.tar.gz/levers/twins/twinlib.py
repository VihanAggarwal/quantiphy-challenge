"""Segmented twins as a measurement channel (CPU only).

simulation_X_segmented is a pixel-aligned copy of simulation_X on a white background. For every object
named in Claude's tracks (either clip's record) we extract per-frame masks from the segmented clip,
associate them with Claude's hints (boxes / extents / points, original-frame pixels), measure extents
and centroids on every frame (qp.open.cv_track conventions) and rebuild RoleTracks for qp.geometry.solve.

Per frame:  dev = 255 - min_c(I_c)  (deviation from white);  fg = dev > FG_T;  8-connected components.
Static camera: B = per-pixel temporal median of the segmented clip; mov = max_c |I - B| > MOV_T (the
moving layer, used when an object's fg component is merged with another object).
Association at frame k: hint box (Claude box / extent bbox / point) interpolated in time between Claude's
anchor frames; components with >= SEL_IN of their area inside the hint box (expanded) are the object.
A frame is "clean" when no selected component pokes far out of the hint (merge) and the union bbox is
compatible with the hint box size. Extents use the half-contrast mask (dev > 0.5 * object contrast).
"""
from __future__ import annotations

import math
import re
import sys
from dataclasses import dataclass, field

import cv2
import numpy as np

sys.path.insert(0, "/home/user/quantiphy-challenge")
from qp.open.cv_track import (build_obs, dimension_mode, extent_from_features, mask_features,  # noqa: E402
                              object_key)
from qp.spec import Obs, RoleTrack  # noqa: E402

FG_T = 20          # deviation from white for foreground components
MOV_T = 30         # deviation from the temporal median for the moving layer
SEL_IN = 0.5       # a component belongs to the hint when this share of its area is inside the expanded hint box
MIN_AREA = 6       # px, components smaller than this are noise


# ----------------------------------------------------------------------------- video

def read_all(path: str, step: int = 1, max_frames: int = 100000):
    cap = cv2.VideoCapture(path)
    out, i = [], 0
    while cap.grab():
        if i % step == 0:
            ok, im = cap.retrieve()
            if ok:
                out.append((i, im))
        i += 1
        if len(out) >= max_frames:
            break
    cap.release()
    return out, i


def frame_count(path: str) -> int:
    cap = cv2.VideoCapture(path)
    n = 0
    while cap.grab():
        n += 1
    cap.release()
    return n


def temporal_median(path: str, n_samples: int = 31):
    n = frame_count(path)
    step = max(1, n // n_samples)
    frames, _ = read_all(path, step=step)
    stack = np.stack([f for _, f in frames])
    return np.median(stack, axis=0).astype(np.uint8), n


# ----------------------------------------------------------------------------- hints

@dataclass
class Hint:
    t: float
    k: int
    box: list | None = None     # [x0, y0, x1, y1] original px
    point: list | None = None   # [x, y]


@dataclass
class ObjHints:
    key: str
    names: set = field(default_factory=set)
    hints: list = field(default_factory=list)   # Hint per anchor frame (merged boxes/points)
    dims: set = field(default_factory=set)      # asked dimensions (size quantities) for this object
    ext_angles: dict = field(default_factory=dict)  # dimension -> [angles (deg, mod 180) of Claude's extents]

    def anchors(self):
        return sorted(self.hints, key=lambda h: h.k)


def obs_hint(o: Obs, fps: float) -> Hint | None:
    """Box hint (Claude box), else a point hint (Claude point, else the extent midpoint)."""
    k = int(round(o.t * fps))
    box = list(o.box) if o.box is not None else None
    pt = list(o.point) if o.point is not None else None
    if pt is None and o.extent is not None:
        (x0, y0), (x1, y1) = o.extent
        pt = [(x0 + x1) / 2, (y0 + y1) / 2]
    if box is None and pt is None:
        return None
    return Hint(o.t, k, box=box, point=pt)


def collect_hints(anns: dict, fps: float) -> dict[str, ObjHints]:
    """{object key: ObjHints} over all questions of one record (roles prior/prior2/target/target2)."""
    objs: dict[str, ObjHints] = {}
    for a in anns.values():
        for tr in a.tracks:
            key = object_key(tr.object)[0]
            if not key:
                continue
            oh = objs.setdefault(key, ObjHints(key))
            oh.names.add(tr.object)
            q = a.spec.prior if tr.role.startswith("prior") else a.spec.target
            if q.kind == "size":
                oh.dims.add(q.dimension)
                for o in tr.obs:
                    if o.extent is not None:
                        (x0, y0), (x1, y1) = o.extent
                        if math.hypot(x1 - x0, y1 - y0) >= 2:
                            ang = math.degrees(math.atan2(y1 - y0, x1 - x0)) % 180.0
                            oh.ext_angles.setdefault(q.dimension, []).append(ang)
            for o in tr.obs:
                h = obs_hint(o, fps)
                if h is not None:
                    oh.hints.append(h)
    # merge hints of the same frame (box wins over point)
    for oh in objs.values():
        byk: dict[int, Hint] = {}
        for h in oh.hints:
            cur = byk.get(h.k)
            if cur is None:
                byk[h.k] = h
                continue
            if cur.box is None and h.box is not None:
                cur.box = h.box
            if cur.point is None and h.point is not None:
                cur.point = h.point
        oh.hints = list(byk.values())
    return objs


def _lin(k, ks, V):
    """Piecewise-linear interpolation of rows V at frame k, extrapolated linearly from the two end anchors."""
    if len(ks) == 1:
        return V[0]
    if k < ks[0]:
        i0, i1 = 0, 1
    elif k > ks[-1]:
        i0, i1 = len(ks) - 2, len(ks) - 1
    else:
        return np.array([np.interp(k, ks, V[:, j]) for j in range(V.shape[1])])
    d = ks[i1] - ks[i0]
    return V[i0] + (V[i1] - V[i0]) * (k - ks[i0]) / d if d else V[i0]


def interp_hint(anchors: list[Hint], k: int, static: bool = False):
    """(centre xy, box w/h or None, frames to the nearest anchor used) at frame k. Box anchors drive the
    hint when there are >= 2 of them (or 1 on a static object); outside the box anchors' frame range the
    centre follows the point anchors (shifted by the median box-centre - point offset) when they reach
    further, else it is extrapolated linearly. Otherwise point anchors only (point mode)."""
    anchors = sorted(anchors, key=lambda h: h.k)
    boxes = [h for h in anchors if h.box is not None]
    pts = [h for h in anchors if h.point is not None]
    if len(boxes) >= 2 or (boxes and static):
        ks = np.array([h.k for h in boxes], float)
        C = np.array([[(h.box[0] + h.box[2]) / 2, (h.box[1] + h.box[3]) / 2] for h in boxes])
        S = np.array([[h.box[2] - h.box[0], h.box[3] - h.box[1]] for h in boxes])
        wh = tuple(float(x) for x in _lin(min(max(k, ks[0]), ks[-1]), ks, S))
        near = int(np.min(np.abs(ks - k)))
        if static or ks[0] <= k <= ks[-1] or len(pts) < 2:
            c = C[0] if static and len(boxes) == 1 else _lin(k, ks, C)
            return np.asarray(c, float), wh, near
        pk = np.array([h.k for h in pts], float)
        P = np.array([h.point for h in pts], float)
        off = np.median(np.array([C[i] - _lin(ks[i], pk, P) for i in range(len(ks))]), axis=0)
        c = _lin(k, pk, P) + off
        near = int(min(near, np.min(np.abs(pk - k))))
        return np.asarray(c, float), wh, near
    if not pts:
        pts = [Hint(h.t, h.k, point=[(h.box[0] + h.box[2]) / 2, (h.box[1] + h.box[3]) / 2]) for h in anchors]
    ks = np.array([h.k for h in pts], float)
    P = np.array([h.point for h in pts], float)
    return np.asarray(_lin(k, ks, P), float), None, int(np.min(np.abs(ks - k)))


def hint_moves(anchors: list[Hint], W: int) -> float:
    if len(anchors) < 2:
        return 0.0
    C = []
    for h in anchors:
        C.append([(h.box[0] + h.box[2]) / 2, (h.box[1] + h.box[3]) / 2] if h.box is not None else h.point)
    C = np.array(C, float)
    return float(np.ptp(C, axis=0).max())


# ----------------------------------------------------------------------------- per-frame selection

def components(mask: np.ndarray):
    n, lab, st, cen = cv2.connectedComponentsWithStats(mask.astype(np.uint8), connectivity=8)
    return n, lab, st, cen


def select(lab, st, n, c, wh, W, H, pad_frac=0.12, pad_px=4):
    """Components belonging to a hint (centre c, size wh or None). Returns (ids, info)."""
    if wh is None:   # point hint: component containing / nearest to the point, plus its satellites
        x, y = int(np.clip(round(c[0]), 0, W - 1)), int(np.clip(round(c[1]), 0, H - 1))
        cid = lab[y, x]
        if cid == 0:
            r = 12
            win = lab[max(0, y - r):y + r + 1, max(0, x - r):x + r + 1]
            ids, cnt = np.unique(win[win > 0], return_counts=True)
            if not len(ids):
                return [], {"why": "no_comp_near_point"}
            cid = int(ids[np.argmax(cnt)])
        x0, y0, w, h = st[cid, :4]
        return [int(cid)], {"mode": "point", "bbox": [x0, y0, x0 + w, y0 + h]}
    w, h = wh
    px, py = pad_frac * w + pad_px, pad_frac * h + pad_px
    bx0, by0, bx1, by1 = c[0] - w / 2 - px, c[1] - h / 2 - py, c[0] + w / 2 + px, c[1] + h / 2 + py
    xi0, yi0 = int(max(0, math.floor(bx0))), int(max(0, math.floor(by0)))
    xi1, yi1 = int(min(W, math.ceil(bx1))), int(min(H, math.ceil(by1)))
    if xi1 <= xi0 or yi1 <= yi0:
        return [], {"why": "hint_outside"}
    win = lab[yi0:yi1, xi0:xi1]
    ids, cnt = np.unique(win[win > 0], return_counts=True)
    keep, poke = [], []
    for i, ci in zip(ids, cnt):
        a = st[i, cv2.CC_STAT_AREA]
        if a < MIN_AREA:
            continue
        if ci >= SEL_IN * a:
            keep.append(int(i))
        elif ci >= 0.15 * w * h and ci >= 0.3 * (win.size):
            poke.append(int(i))     # a big component mostly outside the hint covers the hint: merged
        elif ci >= 0.25 * w * h:
            poke.append(int(i))
    info = {"mode": "box", "hint": [bx0, by0, bx1, by1]}
    if poke:
        info["merged"] = True
    return keep, info


def union_bbox(st, ids):
    x0 = min(st[i, 0] for i in ids); y0 = min(st[i, 1] for i in ids)
    x1 = max(st[i, 0] + st[i, 2] for i in ids); y1 = max(st[i, 1] + st[i, 3] for i in ids)
    return [int(x0), int(y0), int(x1), int(y1)]


def iou(a, b):
    ix = max(0.0, min(a[2], b[2]) - max(a[0], b[0])); iy = max(0.0, min(a[3], b[3]) - max(a[1], b[1]))
    inter = ix * iy
    u = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return inter / u if u > 0 else 0.0


def half_contrast_mask(dev, lab, ids, bbox):
    """Object mask inside its bbox (+2 px): pixels of the selected components, re-thresholded at half
    the object's median contrast (antialiased edges count when at least half covered)."""
    H, W = dev.shape
    x0, y0, x1, y1 = max(0, bbox[0] - 2), max(0, bbox[1] - 2), min(W, bbox[2] + 2), min(H, bbox[3] + 2)
    sub_lab = lab[y0:y1, x0:x1]
    sel = np.isin(sub_lab, ids)
    d = dev[y0:y1, x0:x1].astype(np.float32)
    er = cv2.erode(sel.astype(np.uint8), np.ones((3, 3), np.uint8), iterations=2).astype(bool)
    D = float(np.median(d[er])) if er.sum() >= 10 else float(np.median(d[sel])) if sel.any() else 0.0
    zone = cv2.dilate(sel.astype(np.uint8), np.ones((3, 3), np.uint8), iterations=1).astype(bool)
    thr = max(0.5 * D, FG_T * 0.75)
    m = (zone & (d > thr)) | er
    # fill holes inside the object
    m8 = m.astype(np.uint8)
    cnts, _ = cv2.findContours(m8, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    filled = np.zeros_like(m8)
    cv2.drawContours(filled, cnts, -1, 1, thickness=-1)
    return filled.astype(bool), (x0, y0), D


def projections(mask, off, angles, window):
    """{angle: [length in the window, full length, window-touch]} of the mask's pixel squares projected on
    direction `angle` (deg). Window = the expanded hint box (None: whole mask): pixels outside it are ignored
    (a mast above a boat's box), and 'cut' says the mask continues past the window along that direction."""
    ys, xs = np.nonzero(mask)
    if not len(xs):
        return {}
    X, Y = xs + off[0] + 0.5, ys + off[1] + 0.5
    inside = np.ones(len(X), bool)
    if window is not None:
        x0, y0, x1, y1 = window
        inside = (X >= x0) & (X <= x1) & (Y >= y0) & (Y <= y1)
        if inside.sum() < 3:
            return {}
    out = {}
    for a in angles:
        u = (math.cos(math.radians(a)), math.sin(math.radians(a)))
        foot = abs(u[0]) + abs(u[1])
        p = X * u[0] + Y * u[1]
        pin = p[inside]
        L_in = float(pin.max() - pin.min() + foot)
        L_full = float(p.max() - p.min() + foot)
        out[a] = [round(L_in, 2), round(L_full, 2), bool(L_full - L_in > 1.5)]
    return out


# ----------------------------------------------------------------------------- tracking one clip

def track_clip(seg_path: str, objs: dict[str, ObjHints], fps: float, use_moving: bool = True,
               skip_first: bool = False, verbose: bool = False):
    """Per object: {frame k: features (+ 'clean', 'layer', 'iou')} from the segmented clip."""
    B, n = temporal_median(seg_path) if use_moving else (None, frame_count(seg_path))
    cap = cv2.VideoCapture(seg_path)
    ok, im = cap.read()
    H, W = im.shape[:2]
    cap.release()
    obj_list = [(key, oh, oh.anchors()) for key, oh in objs.items() if oh.hints]
    moving = {key: hint_moves(an, W) > 0.02 * W for key, oh, an in obj_list}
    angles = {key: sorted({0.0, 90.0} | {round(float(np.median(v)), 1) for v in oh.ext_angles.values()})
              for key, oh, an in obj_list}
    res = {key: {} for key, _, _ in obj_list}
    stats = {key: {"frames": 0, "clean": 0, "merged": 0, "moving_layer": 0, "lost": 0} for key, _, _ in obj_list}
    cap = cv2.VideoCapture(seg_path)
    k = -1
    while True:
        ok = cap.grab()
        if not ok:
            break
        k += 1
        if skip_first and k == 0:
            continue
        ok, im = cap.retrieve()
        if not ok:
            continue
        dev = (255 - im.min(axis=2)).astype(np.uint8)
        fg = dev > FG_T
        n_c, lab, st, _ = components(fg)
        mov = None
        for key, oh, an in obj_list:
            c, wh, near = interp_hint(an, k, static=not moving[key])
            s = stats[key]
            s["frames"] += 1
            ids, info = select(lab, st, n_c, c, wh, W, H)
            layer = "fg"
            merged = info.get("merged", False)
            if (merged or not ids) and use_moving and moving[key] and B is not None:
                if mov is None:
                    dm = np.abs(im.astype(np.int16) - B.astype(np.int16)).max(axis=2)
                    movm = (dm > MOV_T) & fg
                    movm = cv2.morphologyEx(movm.astype(np.uint8), cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
                    mn, mlab, mst, _ = components(movm)
                    mov = (mn, mlab, mst)
                mn, mlab, mst = mov
                ids2, info2 = select(mlab, mst, mn, c, wh, W, H)
                if ids2 and not info2.get("merged"):
                    ids, info, layer, merged = ids2, info2, "moving", False
                    lab_use, st_use = mlab, mst
                    s["moving_layer"] += 1
                else:
                    lab_use, st_use = lab, st
            else:
                lab_use, st_use = lab, st
            if not ids:
                s["lost"] += 1
                continue
            bb = union_bbox(st_use, ids)
            if layer == "moving":
                mask = np.isin(lab_use[bb[1]:bb[3], bb[0]:bb[2]], ids)
                off = (bb[0], bb[1]); D = None
            else:
                mask, off, D = half_contrast_mask(dev, lab_use, ids, bb)
            full = np.zeros((H, W), bool)
            full[off[1]:off[1] + mask.shape[0], off[0]:off[0] + mask.shape[1]] = mask
            f = mask_features(full)
            if f is None:
                s["lost"] += 1
                continue
            f["proj"] = projections(mask, off, angles[key], info.get("hint") if wh is not None else None)
            # compatibility with the hint box
            clean = not merged
            hb = None
            if wh is not None:
                hb = [c[0] - wh[0] / 2, c[1] - wh[1] / 2, c[0] + wh[0] / 2, c[1] + wh[1] / 2]
                f["iou"] = round(iou(f["box"], hb), 3)
                fw, fh = f["box"][2] - f["box"][0], f["box"][3] - f["box"][1]
                f["wr"], f["hr"] = round(fw / max(wh[0], 1), 3), round(fh / max(wh[1], 1), 3)
                if near == 0 and (f["iou"] < 0.5 or not (0.7 <= f["wr"] <= 1.35 and 0.7 <= f["hr"] <= 1.35)):
                    clean = False
                if near > 0 and (f["iou"] < 0.3 or not (0.6 <= f["wr"] <= 1.6 and 0.6 <= f["hr"] <= 1.6)):
                    clean = False
            else:
                # point hint: point must be within the object's bbox (expanded 10%)
                x0, y0, x1, y1 = f["box"]
                ex, ey = 0.1 * (x1 - x0) + 3, 0.1 * (y1 - y0) + 3
                f["pin"] = bool(x0 - ex <= c[0] <= x1 + ex and y0 - ey <= c[1] <= y1 + ey)
                if near == 0 and not f["pin"]:
                    clean = False
                # a point hint gives no size check: very large components (> 40% of the frame) are merges
                if (x1 - x0) * (y1 - y0) > 0.4 * W * H:
                    clean = False
            f["clean"], f["layer"], f["near"] = bool(clean), layer, int(near)
            if D is not None:
                f["D"] = round(D, 1)
            if merged:
                s["merged"] += 1
            if clean:
                s["clean"] += 1
            res[key][k] = f
    cap.release()
    return res, stats, (W, H), n, moving


def anchor_agreement(feats: dict, an: list[Hint]):
    """Median IoU with Claude's boxes on the anchor frames (boxes only) and share of point hints inside."""
    ious, pins = [], []
    for h in an:
        f = feats.get(h.k)
        if f is None:
            if h.box is not None:
                ious.append(0.0)
            else:
                pins.append(False)
            continue
        if h.box is not None:
            ious.append(iou(f["box"], h.box))
        elif h.point is not None:
            x0, y0, x1, y1 = f["box"]
            ex, ey = 0.1 * (x1 - x0) + 3, 0.1 * (y1 - y0) + 3
            pins.append(x0 - ex <= h.point[0] <= x1 + ex and y0 - ey <= h.point[1] <= y1 + ey)
    return (float(np.median(ious)) if ious else None, float(np.mean(pins)) if pins else None, len(ious), len(pins))


def area_jumpiness(feats: dict):
    ks = sorted(k for k, f in feats.items() if f.get("clean"))
    if len(ks) < 3:
        return None
    a = np.log([max(feats[k]["area"], 1) for k in ks])
    return float(np.median(np.abs(np.diff(a))))


# ----------------------------------------------------------------------------- RoleTracks

def mask_obs(feats: dict, fps: float, dimension: str | None, name: str, clean_only=True,
             ext_angle: float | None = None, motion: bool = False) -> list[Obs]:
    """Obs from mask features. Motion roles: centroids, frames touching the image border dropped.
    Size roles with a Claude extent direction: the mask's length along that direction inside the hint window
    (frames where the mask continues past the window along it are dropped); else cv_track's convention."""
    frames = {k: f for k, f in feats.items() if (f.get("clean") or not clean_only)}
    if motion:
        frames = {k: f for k, f in frames.items() if not f["edge"]}
        return [Obs(t=round(k / fps, 4), point=[float(f["c"][0]), float(f["c"][1])], box=[float(x) for x in f["box"]])
                for k, f in sorted(frames.items())]
    if dimension is None:
        return build_obs(frames, fps, extent_mode=None, name=name)
    frames = {k: f for k, f in frames.items() if not f["edge"]}
    mode = dimension_mode(dimension, name)
    ang = None
    if ext_angle is not None:
        ang = ext_angle
    elif mode in ("vertical", "horizontal"):
        ang = 90.0 if mode == "vertical" else 0.0
    out = []
    for k, f in sorted(frames.items()):
        if ang is not None:
            pr = f.get("proj") or {}
            key = min(pr, key=lambda a: abs(a - ang)) if pr else None
            if key is None or abs(key - ang) > 0.6:
                continue
            L, Lf, cut = pr[key]
            if cut:
                continue
            u = (math.cos(math.radians(key)), math.sin(math.radians(key)))
            cx, cy = f["c"]
            ext = [[cx - u[0] * L / 2, cy - u[1] * L / 2], [cx + u[0] * L / 2, cy + u[1] * L / 2]]
        else:
            ext = extent_from_features(f, mode, name)
        out.append(Obs(t=round(k / fps, 4), point=[float(f["c"][0]), float(f["c"][1])],
                       extent=[[round(float(v), 2) for v in p] for p in ext], box=[float(x) for x in f["box"]]))
    return out
