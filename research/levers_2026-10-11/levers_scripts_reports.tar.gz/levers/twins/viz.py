"""viz.py FEATS_PKL SEG_VIDEO OBJKEY_SUBSTR OUT.jpg : mask boxes (green) vs Claude anchors (red) on 3 frames."""
import pickle, sys, cv2, numpy as np
sys.path.insert(0, '/home/user/quantiphy-challenge')
from qp.data import load_split
F = pickle.load(open(sys.argv[1], 'rb')); seg, sub, out = sys.argv[2:5]
d = F[seg]; P = dict(zip(*load_split('test')[['video_id', 'video_path']].T.values))
keys = [k for k in d['feats'] if sub in k]
cap = cv2.VideoCapture(P[seg.replace('_segmented', '')] if len(sys.argv) > 5 else P[seg])
frames = {}; i = 0
while cap.grab():
    ok, im = cap.retrieve(); frames[i] = im; i += 1
ks = sorted(frames); pick = [ks[0], ks[len(ks) // 2], ks[-1]]
tiles = []
for k in pick:
    im = frames[k].copy()
    for key in keys:
        f = d['feats'][key].get(k)
        if f:
            x0, y0, x1, y1 = f['box']; cv2.rectangle(im, (x0, y0), (x1, y1), (0, 200, 0) if f['clean'] else (0, 200, 255), 3)
        for h in d['hints'][key]:
            if abs(h['k'] - k) <= 1:
                if h['box']: cv2.rectangle(im, tuple(int(v) for v in h['box'][:2]), tuple(int(v) for v in h['box'][2:]), (0, 0, 255), 2)
                if h['point']: cv2.circle(im, tuple(int(v) for v in h['point']), 8, (0, 0, 255), -1)
    cv2.putText(im, f'{seg} {sub} k={k}', (20, 50), 0, 1.5, (255, 0, 0), 3)
    tiles.append(cv2.resize(im, (640, int(640 * im.shape[0] / im.shape[1]))))
cv2.imwrite(out, np.hstack(tiles))
print(keys)
