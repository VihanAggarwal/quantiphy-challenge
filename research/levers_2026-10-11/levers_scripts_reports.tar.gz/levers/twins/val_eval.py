"""Validation: mask answers (all records of the 3 val twin families) vs labels, matched by question text."""
import re, sys
import numpy as np, pandas as pd
sys.path.insert(0, '/home/user/quantiphy-challenge')
from qp.data import load_split
from qp.mra import item_scores
def normq(q):
    q = re.sub(r"(\d+)\.0+(?!\d)", r"\1", str(q).lower()); return re.sub(r"[^a-z0-9.]", "", q)
v = load_split('val_hires'); t = load_split('test')
s = pd.read_csv(sys.argv[1])
qtext = {**dict(zip(t.qid, t.question))}
s['question'] = [ (v.set_index('qid').question.get(q) if tag=='val' else qtext.get(q)) for tag,q in zip(s.tag,s.qid)]
s['nq'] = s.question.map(normq)
v['nq'] = v.question.map(normq); v['fam'] = v.video_id.str.replace('_segmented','',regex=False)
gt = dict(zip(zip(v.fam, v.nq), v.answer))
s['fam'] = s.seg_video.str.replace('_segmented','',regex=False)
s['answer'] = [gt.get((f,q)) for f,q in zip(s.fam,s.nq)]
b = pd.read_csv('/home/user/quantiphy-challenge/runs/val_hr_v1_high/val_hires.csv')
cur = dict(zip(zip(v.fam, v.nq), v.qid.map(dict(zip(b.id, b.parsed_value)))))
s['val_pipeline'] = [cur.get((f,q)) for f,q in zip(s.fam,s.nq)]
s = s[s.answer.notna()].copy()
for c in ('mask_value','claude_geo','direct','val_pipeline'):
    s['sc_'+c] = item_scores(s[c], s.answer)
pd.set_option('display.width', 250)
print(s[['tag','rec_video','is_3d','kind','answer','mask_value','claude_geo','direct','val_pipeline','pre_gate_ok','why','sc_mask_value','sc_claude_geo','sc_val_pipeline']].round(3).to_string())
print(s.groupby(['is_3d','pre_gate_ok'])[['sc_mask_value','sc_claude_geo','sc_direct','sc_val_pipeline']].agg(['mean','size']).round(3))
