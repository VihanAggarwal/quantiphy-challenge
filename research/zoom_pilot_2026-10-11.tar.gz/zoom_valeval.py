"""Ground-truth check: rescale the cached test run's answers of val-mapped 2D questions by the zoomed /
original object length (median over the object's annotated frames, zoomed frames replaced) and score
both against the validation answers (qp.mra.item_scores). Variants: zoom (all zoomed frames) and hybrid
(a zoomed frame only where its line is within 8 deg of the original's)."""
import json, math, sys
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parent))
import zoom
from qp.mra import item_scores

def ang(e):
    e = np.asarray(e, float); u = e[1] - e[0]; return math.degrees(math.atan2(u[1], u[0]))

def factors(items, resp_dir=zoom.RESP):
    out = {}
    for it in items:
        p = resp_dir / f"{it['key']}.json"
        if not p.exists():
            continue
        r = json.loads(p.read_text())
        L = {f: float(np.linalg.norm(np.subtract(*np.asarray(ob["ext"], float)))) for f, ob in it["frames"].items()}
        Lz, Lh = dict(L), dict(L)
        for f, z in r["zoom"].items():
            f = int(f); lz = float(np.linalg.norm(np.subtract(*np.asarray(z["ext"], float))))
            Lz[f] = lz
            d = abs((ang(z["ext"]) - ang(it["frames"][f]["ext"]) + 90) % 180 - 90)
            if d <= 8:
                Lh[f] = lz
        m = np.median(list(L.values()))
        out[it["key"]] = dict(zoom=np.median(list(Lz.values())) / m, hyb=np.median(list(Lh.values())) / m)
    return out

def main():
    items = zoom.load_items("items_val.json")
    fac = factors(items)
    vm = pd.read_csv("/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/val_test_map.csv")
    vm = vm.sort_values("sim").drop_duplicates("tqid", keep="last")  # one val question per test qid (best text match)
    run = pd.read_csv(zoom.REPO / "runs/test_v1_high_854/test.csv").set_index("id")
    rows = []
    for t in vm.itertuples():
        q = int(t.tqid)
        f = {"zoom": 1.0, "hyb": 1.0}; touched = []
        for it in items:
            if it["key"] not in fac:
                continue
            for role in it.get("qroles", {}).get(str(q), []):
                for v in f:
                    f[v] *= fac[it["key"]][v] if role == "target" else 1 / fac[it["key"]][v]
                touched.append(f"{role}:{it['obj']}")
        if not touched or q not in run.index:
            continue
        geo = str(run.loc[q, "method"]).startswith("geometry")
        old = float(run.loc[q, "parsed_value"])
        rows.append(dict(qid=q, vid=t.video_id, cat=t.tcat, touched=";".join(touched), geo=geo, gt=t.answer, old=old,
                         zoom=old * f["zoom"] if geo else old, hyb=old * f["hyb"] if geo else old,
                         f_zoom=f["zoom"], f_hyb=f["hyb"]))
    d = pd.DataFrame(rows)
    for c in ("old", "zoom", "hyb"):
        d["s_" + c] = item_scores(d[c], d["gt"])
    d.to_csv(zoom.OUT / "val_gt_check.csv", index=False)
    summ = {"n_questions": int(len(d)), "n_geometry": int(d.geo.sum()), "n_clips": int(d.vid.nunique()),
            "mean_item_score": {c: round(float(d["s_" + c].mean()), 4) for c in ("old", "zoom", "hyb")},
            "by_category": {k: {c: round(float(g["s_" + c].mean()), 4) for c in ("old", "zoom", "hyb")} | {"n": int(len(g))}
                            for k, g in d.groupby("cat")},
            "by_source": {k: {c: round(float(g["s_" + c].mean()), 4) for c in ("old", "zoom", "hyb")} | {"n": int(len(g))}
                          for k, g in d.groupby(d.vid.str.split("_").str[0])},
            "median_abs_log_err": {c: round(float(np.median(np.abs(np.log(d[c] / d["gt"])))), 4) for c in ("old", "zoom", "hyb")},
            "answers_changed_gt1pct": {c: int((np.abs(np.log(d["f_" + c])) > 0.01).sum()) for c in ("zoom", "hyb")}}
    print(d[["qid", "vid", "cat", "touched", "gt", "old", "zoom", "hyb", "s_old", "s_zoom", "s_hyb"]].round(3).to_string())
    print(json.dumps(summ, indent=1))
    (zoom.OUT / "val_gt_check.json").write_text(json.dumps(summ, indent=1))
    return summ

if __name__ == "__main__":
    main()
