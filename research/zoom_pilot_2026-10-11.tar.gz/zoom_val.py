"""GT check of the zoom on the 2D test clips that carry validation questions (val_test_map: val qid ->
test qid with the validation ground truth). Same request as zoom.py; objects = size priors and size
targets of those clips in the cached 854-px test run; answers rescaled by zoomed/original object length."""
import json, math, sys
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parent))
import zoom
from zoom import rc, ca, load_split

VMAP = Path("/tmp/claude-0/-home-user/879308ec-3ca1-5f52-960b-589240fd8127/scratchpad/hyp/S2/val_test_map.csv")


def build():
    vm = pd.read_csv(VMAP)
    df = load_split("test")
    sub = df[df.qid.isin(vm.tqid) & (df.video_type.str[1] == "2")]
    vids = sorted(set(sub.video_id))
    sub = df[df.video_id.isin(vids)]
    recs = {v: r for v, r in rc.load_records(zoom.RECORDS).items() if v in set(vids)}
    precs = rc.prepare_records(sub, recs)
    anns = ca.load_annotations(precs)
    items = {}
    for r in sub.sort_values("qid").itertuples():
        a = anns.get(int(r.qid))
        if a is None:
            continue
        for tr in a.tracks:
            if tr.role not in ("prior", "target"):
                continue
            q = a.spec.prior if tr.role == "prior" else a.spec.target
            if q.kind != "size":
                continue
            key = (r.video_id, tr.object.strip().casefold(), q.dimension.strip().casefold())
            m = precs[r.video_id]["meta"]
            it = items.setdefault(key, dict(vid=r.video_id, obj=tr.object.strip(), dim=q.dimension.strip(), roles=[], qids=[],
                                            texts=[], qroles={}, category=r.category, video_type=r.video_type, fps=float(r.fps),
                                            W=int(m["image_size"][0]), H=int(m["image_size"][1]), scale=float(m["scale"]),
                                            prior_text=str(r.prior), frames={}))
            if tr.role not in it["roles"]:
                it["roles"].append(tr.role)
            if int(r.qid) not in it["qids"]:
                it["qids"].append(int(r.qid)); it["texts"].append(str(r.question).strip())
            it["qroles"].setdefault(str(int(r.qid)), []).append(tr.role)
            for o in tr.obs:
                if o.extent is None or o.box is None:
                    continue
                f = int(round(o.t * float(r.fps)))
                it["frames"].setdefault(f, dict(ext=[list(map(float, p)) for p in o.extent], box=list(map(float, o.box)), ref=None))
    out = []
    for it in items.values():
        if it["frames"]:
            it["frames"] = {int(f): ob for f, ob in sorted(it["frames"].items())}
            it["n_ref"] = 0
            it["key"] = f"VAL__{it['vid']}__{zoom.slug(it['obj'])}__{zoom.slug(it['dim']) or 'size'}"
            out.append(it)
    return out


if __name__ == "__main__":
    items = build()
    (zoom.OUT / "items_val.json").write_text(json.dumps(items, indent=0))
    print(len(items), "objects in", len({i["vid"] for i in items}), "clips;", sum("prior" in i["roles"] for i in items), "priors")
    for it in items:
        print(it["key"], it["roles"], len(it["frames"]), it["qids"])
