#!/usr/bin/env python
"""Zoomed re-measurement pilot: does asking Claude for an object's extent on an enlarged crop of the
ORIGINAL full-resolution frame measure it better than the 854-px whole-frame annotation of the cached
test run (runs/test_v1_high_854)?

Pilot set: the size objects (prior and target tracks of kind "size") of the 2D simulation clips that
have a pixel-aligned segmented twin (simulation_X + simulation_X_segmented: the S2 investigator's twin
list, hyp/S2/review_code/feret.py). Per object (video, object name, dimension) 3 of the frames Claude
annotated in the cached record are re-measured in ONE request: each frame is cropped around Claude's
box (plus margin), enlarged so the object spans ~600 px (crop long side <= 1024 px), and Claude gives
the two endpoints of the asked dimension in crop pixels (structured output), mapped back to original
pixels.

Reference (re-implementation of hyp/S2/review_code/feret.py `refs`, unchanged logic): on the segmented
twin's frame (white background, static objects removed) the object mask = pixels whose max channel
deviation from white is > 40 inside a window around Claude's box, connected components overlapping the
box, then pixels > 0.5 x the object's median deviation (sub-pixel edge at half contrast). The reference
length is the minimum Feret width (caliper extent, + one pixel footprint) over directions within +-8 deg
of the measured line's direction: the object's own extent along that dimension, robust to small angle
errors of the line. Frames where the mask touches the window border (object cut / merged) give no
reference.

Spend: every request goes through qp.budget (reserve the worst case, record the usage in the ledger,
QP_BUDGET_USD must be 140). Run:
  QP_BUDGET_USD=140 .venv/bin/python zoom.py items            # offline: objects + references
  QP_BUDGET_USD=140 .venv/bin/python zoom.py run --limit 4      # paid requests (cached per object)
  QP_BUDGET_USD=140 .venv/bin/python zoom.py eval               # offline comparison -> report.json
"""
from __future__ import annotations

import argparse
import base64
import json
import math
import os
import re
import sys
import time
from pathlib import Path

import cv2
import numpy as np
import pandas as pd

cv2.setNumThreads(1)
REPO = Path("/home/user/quantiphy-challenge")
sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / "scripts"))
import run_claude as rc  # noqa: E402
from qp import budget  # noqa: E402
from qp import claude_annotate as ca  # noqa: E402
from qp.data import load_split  # noqa: E402

OUT = Path(__file__).resolve().parent
RESP = OUT / "responses"
IMG = OUT / "img"
RECORDS = REPO / "runs/test_v1_high_854/test/records"
MODEL = "claude-opus-5-5"
RUN = "zoom_pilot"
EFFORT = "medium"
MAX_TOKENS = 3000      # 8000 in the first smoke requests; one hit it on thinking (wasted $0.18)
N_FRAMES = 3
OBJ_TARGET_PX = 600      # enlarge so the object's long side spans about this many crop pixels
CROP_CAP = 1024          # crop long side cap after resizing
MAX_UP = 16.0            # upscale cap (tiny objects)
MARGIN_FRAC, MARGIN_MIN = 0.3, 12   # crop margin per side: 30% of the object's long side, >= 12 orig px

# --------------------------------------------------------------------------- pilot items


def pilot_frame() -> tuple[pd.DataFrame, list[str]]:
    df = load_split("test")
    vids = set(df.video_id)
    segs = sorted(v for v in vids if v.endswith("_segmented") and v.startswith("simulation") and v[:-10] in vids)
    origs = sorted({s[:-10] for s in segs})
    sub = df[df.video_id.isin(origs) & (df.video_type.str[1] == "2")].copy()
    return df, sorted(set(sub.video_id))


def read_frames(path: str, idxs) -> dict[int, np.ndarray]:
    out, cap, i, want = {}, cv2.VideoCapture(path), 0, set(int(x) for x in idxs)
    last = max(want) if want else -1
    while i <= last and cap.grab():
        if i in want:
            ok, im = cap.retrieve()
            if ok:
                out[i] = im
        i += 1
    cap.release()
    return out


ANG = np.deg2rad(np.arange(-8, 8.01, 0.25))


def refs(seg: np.ndarray, box, ext) -> dict | None:
    """feret.py's reference (verbatim logic): mask of the object in the segmented twin frame near `box`
    and its Feret widths around the direction of the line `ext` (original px)."""
    H_, W_ = seg.shape[:2]
    dev = (255 - seg.astype(np.int16)).max(axis=2).astype(np.float32)
    x0, y0, x1, y1 = box
    m = 0.25 * max(x1 - x0, y1 - y0) + 8
    wx0, wy0 = max(0, int(x0 - m)), max(0, int(y0 - m))
    wx1, wy1 = min(W_, int(math.ceil(x1 + m))), min(H_, int(math.ceil(y1 + m)))
    win = dev[wy0:wy1, wx0:wx1]
    mk = (win > 40).astype(np.uint8)
    if mk.sum() < 4:
        return None
    n, lab, st, _ = cv2.connectedComponentsWithStats(mk, connectivity=8)
    bx0, by0, bx1, by1 = int(x0 - wx0 - 2), int(y0 - wy0 - 2), int(x1 - wx0 + 2), int(y1 - wy0 + 2)
    inbox = lab[max(0, by0):max(0, by1), max(0, bx0):max(0, bx1)]
    keep = [k for k in range(1, n) if (inbox == k).sum() >= max(3, 0.3 * st[k, cv2.CC_STAT_AREA])]
    if not keep:
        return None
    sel = np.isin(lab, keep).astype(np.uint8)
    ys, xs = np.nonzero(sel)
    if (xs.min() == 0 and wx0 > 0 or ys.min() == 0 and wy0 > 0 or xs.max() == win.shape[1] - 1 and wx1 < W_
            or ys.max() == win.shape[0] - 1 and wy1 < H_):
        return None
    er = cv2.erode(sel, np.ones((3, 3), np.uint8), iterations=2).astype(bool)
    D = float(np.median(win[er])) if er.sum() >= 5 else float(np.median(win[sel.astype(bool)]))
    zone = cv2.dilate(sel, np.ones((3, 3), np.uint8), iterations=2).astype(bool)
    mm = zone & (win > 0.5 * D)
    yy, xx = np.nonzero(mm)
    X = xx + wx0 + 0.5
    Y = yy + wy0 + 0.5
    e = np.asarray(ext, float)
    u = e[1] - e[0]
    a0 = math.atan2(u[1], u[0])
    fer = []
    for da in ANG:
        c, s = math.cos(a0 + da), math.sin(a0 + da)
        p = X * c + Y * s
        fer.append(p.max() - p.min() + abs(c) + abs(s))
    fer = np.array(fer)
    i0 = len(ANG) // 2
    return dict(f_u=float(fer[i0]), f_min=float(fer.min()), a_min=float(np.rad2deg(ANG[fer.argmin()])),
                f_max=float(fer.max()))


def slug(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", s.casefold()).strip("-")[:40]


def build_items() -> list[dict]:
    """Objects (video, object name, dimension) with Claude's extents + boxes per annotated frame, the
    questions they appear in, and the twin reference per frame (where the mask is clean)."""
    df, vids = pilot_frame()
    sub = df[df.video_id.isin(vids)]
    recs = rc.load_records(RECORDS)
    recs = {v: r for v, r in recs.items() if v in set(vids)}
    precs = rc.prepare_records(sub, recs)
    anns = ca.load_annotations(precs)
    items: dict[tuple, dict] = {}
    for r in sub.sort_values("qid").itertuples():
        a = anns.get(int(r.qid))
        if a is None:
            continue
        for tr in a.tracks:
            if tr.role not in ("prior", "target"):
                continue
            q = a.spec.prior if tr.role == "prior" else a.spec.target
            if q.kind != "size":
                continue
            key = (r.video_id, tr.object.strip().casefold(), q.dimension.strip().casefold())
            it = items.setdefault(key, dict(
                vid=r.video_id, obj=tr.object.strip(), dim=q.dimension.strip(), roles=[], qids=[], texts=[],
                category=("S2" if r.video_type[0] == "S" else "D2"), video_type=r.video_type, fps=float(r.fps),
                W=int(precs[r.video_id]["meta"]["image_size"][0]), H=int(precs[r.video_id]["meta"]["image_size"][1]),
                scale=float(precs[r.video_id]["meta"]["scale"]), prior_text=str(r.prior), frames={}))
            if tr.role not in it["roles"]:
                it["roles"].append(tr.role)
            if int(r.qid) not in it["qids"]:
                it["qids"].append(int(r.qid))
                it["texts"].append(str(r.question).strip())
            for o in tr.obs:
                if o.extent is None or o.box is None:
                    continue
                f = int(round(o.t * float(r.fps)))
                it["frames"].setdefault(f, dict(ext=[list(map(float, p)) for p in o.extent],
                                                box=list(map(float, o.box))))
    out = []
    paths = dict(zip(df.video_id, df.video_path))
    by_vid: dict[str, list[dict]] = {}
    for it in items.values():
        if it["frames"]:
            by_vid.setdefault(it["vid"], []).append(it)
    for vid, its in sorted(by_vid.items()):
        need = sorted({f for it in its for f in it["frames"]})
        segf = read_frames(paths[vid + "_segmented"], need)
        for it in its:
            for f, ob in it["frames"].items():
                sg = segf.get(f)
                ob["ref"] = refs(sg, ob["box"], ob["ext"]) if sg is not None else None
            it["frames"] = {int(f): ob for f, ob in sorted(it["frames"].items())}
            it["n_ref"] = sum(ob["ref"] is not None for ob in it["frames"].values())
            it["key"] = f"{vid}__{slug(it['obj'])}__{slug(it['dim']) or 'size'}"
            out.append(it)
        print(vid, len(its), flush=True)
    return out


def choose_frames(it: dict, k: int = N_FRAMES) -> list[int]:
    """k annotated frames spread over the clip, among those with a reference (availability only)."""
    fr = [f for f, ob in it["frames"].items() if ob["ref"] is not None] or list(it["frames"])
    if len(fr) <= k:
        return fr
    return [fr[i] for i in sorted(set(np.linspace(0, len(fr) - 1, k).round().astype(int)))]


# --------------------------------------------------------------------------- request

SYSTEM = """\
You are a precise measurement annotator. You see enlarged crops of ONE object taken from frames of a \
video (each crop is cut from the original full-resolution frame and scaled up), preceded by a small \
overview of a whole frame with the crop region outlined by a red rectangle, so you can tell which \
object is meant. All coordinates you give are pixels of the CROP image they refer to, as shown: x to \
the right, y down, origin at the top-left corner of that crop.

Task: on every crop, give the two endpoints of exactly the asked dimension of the named object: \
extent = the two endpoints of exactly the asked dimension (nose to tail for a length, wingtip to \
wingtip for a wingspan, top to bottom for a height, edge to edge through the centre for a diameter, \
side to side for a width), plus the tight bounding box [x1, y1, x2, y2] of the object.
- Each endpoint lies ON the object's outer boundary: where the object's pixels end and the background \
begins. Do not stop inside the object and do not include shadows, reflections or other objects.
- Measure each crop separately; the object is near the centre of each crop. The crops are enlarged, \
so edges look soft: put the boundary at the middle of the soft transition.
- Be precise: give coordinates to 0.5 px of the crop.
- If the object is not visible in a crop, or the asked dimension is cut by the crop border or \
hidden, set visible to false and extent and box to null."""

SCHEMA = {
    "type": "object",
    "properties": {
        "crops": {"type": "array", "items": {
            "type": "object",
            "properties": {
                "crop": {"type": "integer"},
                "visible": {"type": "boolean"},
                "extent": {"anyOf": [{"type": "array", "items": {"type": "array", "items": {"type": "number"}}},
                                     {"type": "null"}]},
                "box": {"anyOf": [{"type": "array", "items": {"type": "number"}}, {"type": "null"}]},
            },
            "required": ["crop", "visible", "extent", "box"],
            "additionalProperties": False}},
        "notes": {"type": "string"},
    },
    "required": ["crops", "notes"],
    "additionalProperties": False,
}


def crop_geometry(ob: dict, W: int, H: int) -> dict:
    """Crop window (original px, integer bounds) around the union of Claude's box and extent, and the
    resize factors (sx, sy) so the object's long side spans ~OBJ_TARGET_PX (crop long side <= CROP_CAP)."""
    e = np.asarray(ob["ext"], float)
    b = ob["box"]
    x0, y0 = min(b[0], e[:, 0].min()), min(b[1], e[:, 1].min())
    x1, y1 = max(b[2], e[:, 0].max()), max(b[3], e[:, 1].max())
    L = max(x1 - x0, y1 - y0, 1.0)
    m = max(MARGIN_FRAC * L, MARGIN_MIN)
    cx0, cy0 = max(0, int(math.floor(x0 - m))), max(0, int(math.floor(y0 - m)))
    cx1, cy1 = min(W, int(math.ceil(x1 + m))), min(H, int(math.ceil(y1 + m)))
    cw, ch = cx1 - cx0, cy1 - cy0
    s = min(OBJ_TARGET_PX / L, CROP_CAP / max(cw, ch), MAX_UP)
    ow, oh = max(1, round(cw * s)), max(1, round(ch * s))
    return dict(x0=cx0, y0=cy0, x1=cx1, y1=cy1, ow=ow, oh=oh, sx=ow / cw, sy=oh / ch)


def b64(img: np.ndarray, ext: str = ".png") -> str:
    ok, buf = cv2.imencode(ext, img)
    assert ok
    return base64.b64encode(buf).decode()


def build_request(it: dict, frames: dict[int, np.ndarray], chosen: list[int], save_dir: Path | None = None):
    W, H = it["W"], it["H"]
    geos, crops = [], []
    for f in chosen:
        g = crop_geometry(it["frames"][f], W, H)
        im = frames[f][g["y0"]:g["y1"], g["x0"]:g["x1"]]
        interp = cv2.INTER_CUBIC if g["sx"] > 1 else cv2.INTER_AREA
        crops.append(cv2.resize(im, (g["ow"], g["oh"]), interpolation=interp))
        geos.append({**g, "frame": f})
    mid = chosen[len(chosen) // 2]
    gm = geos[len(chosen) // 2]
    so = min(1.0, 512 / max(W, H))
    ov = cv2.resize(frames[mid], (round(W * so), round(H * so)), interpolation=cv2.INTER_AREA)
    cv2.rectangle(ov, (int(gm["x0"] * so), int(gm["y0"] * so)), (int(math.ceil(gm["x1"] * so)), int(math.ceil(gm["y1"] * so))),
                  (0, 0, 255), 2)
    if save_dir is not None:
        save_dir.mkdir(parents=True, exist_ok=True)
        cv2.imwrite(str(save_dir / f"{it['key']}_overview.jpg"), ov)
        for k, c in enumerate(crops):
            cv2.imwrite(str(save_dir / f"{it['key']}_crop{k}.png"), c)
    uses = "; ".join([f"prior: \"{it['prior_text']}\""] * ("prior" in it["roles"])
                     + [f"question: \"{t}\"" for t in it["texts"] if "target" in it["roles"]])
    content = [{"type": "text", "text": (
        f"Object: \"{it['obj']}\". Asked dimension: \"{it['dim'] or 'size'}\". "
        f"Context (the video's text that names it): {uses}.\n"
        f"Overview of frame {mid} ({ov.shape[1]}x{ov.shape[0]} px), crop region in red:")},
        {"type": "image", "source": {"type": "base64", "media_type": "image/jpeg", "data": b64(ov, ".jpg")}}]
    for k, (g, c) in enumerate(zip(geos, crops)):
        content.append({"type": "text", "text": f"Crop {k}: frame {g['frame']} (t={g['frame'] / it['fps']:.3f}s), "
                                                f"{c.shape[1]}x{c.shape[0]} px:"})
        content.append({"type": "image", "source": {"type": "base64", "media_type": "image/png", "data": b64(c)}})
    content.append({"type": "text", "text": (
        f"Give, for each of the {len(crops)} crops (crop = 0..{len(crops) - 1}), the two endpoints of the "
        f"{it['dim'] or 'size'} of the {it['obj']} in that crop's pixel coordinates, and its tight box.")})
    params = {"model": MODEL, "max_tokens": MAX_TOKENS, "system": SYSTEM,
              "messages": [{"role": "user", "content": content}],
              "output_config": {"effort": EFFORT, "format": {"type": "json_schema", "schema": SCHEMA}}}
    n_in = 600 + sum(math.ceil(c.shape[0] * c.shape[1] / 750) for c in crops) + math.ceil(ov.shape[0] * ov.shape[1] / 750)
    n_in += math.ceil((len(SYSTEM) + sum(len(b.get("text", "")) for b in content)) / 3.5)
    return params, geos, n_in


def to_orig(pt, g):
    return [g["x0"] + float(pt[0]) / g["sx"], g["y0"] + float(pt[1]) / g["sy"]]


def parse_response(parsed: dict, geos: list[dict]) -> dict[int, dict]:
    out = {}
    for c in (parsed or {}).get("crops", []):
        k = c.get("crop")
        if not isinstance(k, int) or not 0 <= k < len(geos) or not c.get("visible"):
            continue
        e = c.get("extent")
        if not (isinstance(e, list) and len(e) == 2 and all(isinstance(p, list) and len(p) == 2 for p in e)):
            continue
        g = geos[k]
        b = c.get("box")
        out[g["frame"]] = dict(ext=[to_orig(e[0], g), to_orig(e[1], g)],
                               box=(to_orig(b[:2], g) + to_orig(b[2:], g)) if isinstance(b, list) and len(b) == 4 else None,
                               ext_crop=e)
    return out


# --------------------------------------------------------------------------- commands


def cmd_items(args):
    items = build_items()
    (OUT / "items.json").write_text(json.dumps(items, indent=0))
    n = sum(it["n_ref"] > 0 for it in items)
    print(f"{len(items)} objects in {len({i['vid'] for i in items})} clips; {n} with >= 1 reference frame")


def load_items(name: str = "items.json") -> list[dict]:
    items = json.loads((OUT / name).read_text())
    for it in items:
        it["frames"] = {int(f): ob for f, ob in it["frames"].items()}
    return items


def pilot_spend() -> float:
    return sum(float(e.get("usd", 0)) for e in budget.entries() if e.get("type", "usage") == "usage" and e.get("run") == RUN)


def order(items: list[dict]) -> list[dict]:
    """Priors first (they scale every answer of an S2 video), then size targets; smaller objects first
    within each (where zoom can matter most)."""
    def ref_px(it):
        r = [ob["ref"]["f_min"] for ob in it["frames"].values() if ob["ref"]]
        return float(np.median(r)) * it["scale"] if r else 1e9
    return sorted(items, key=lambda it: ("prior" not in it["roles"], ref_px(it)))


def cmd_run(args):
    if os.environ.get("QP_BUDGET_USD") != "140":
        sys.exit("refusing: run with QP_BUDGET_USD=140")
    rc.load_env()  # .env -> os.environ (the key is never printed)
    import anthropic
    client = anthropic.Anthropic()
    items = order(load_items(args.items))
    if args.items == "items.json":
        items = [it for it in items if it["n_ref"] > 0]  # pilot: objects with a twin reference
    if args.vids:
        items = [it for it in items if it["vid"] in args.vids.split(",")]
    RESP.mkdir(exist_ok=True)
    todo = [it for it in items if not (RESP / f"{it['key']}.json").exists()]
    if args.limit:
        todo = todo[:args.limit]
    print(f"{len(todo)} object(s) to send; pilot spend so far ${pilot_spend():.3f}; "
          f"committed ${budget.committed():.2f} of cap ${budget.cap():.2f}")
    paths = dict(zip(*[load_split("test")[c] for c in ("video_id", "video_path")]))
    for i, it in enumerate(todo, 1):
        if pilot_spend() >= args.max_pilot_usd:
            print(f"pilot spend cap ${args.max_pilot_usd} reached; stopping")
            break
        chosen = choose_frames(it)
        frames = read_frames(paths[it["vid"]], chosen)
        params, geos, n_in = build_request(it, frames, chosen, IMG if args.save_images else None)
        worst = budget.estimate_usd(rc.INPUT_MARGIN * n_in, MAX_TOKENS, MODEL)
        try:
            with budget.reserve(worst):
                msg, rid = rc.call(client, params)
                usd = budget.price(msg.usage, MODEL)
                budget.record(RUN, MODEL, "sync", rid or msg.id, msg.usage, usd, video_id=it["vid"],
                              object=it["key"], split="test")
        except budget.BudgetExceeded as e:
            print(f"budget refused: {e}")
            break
        text = ca.response_text(msg)
        parsed = ca.parse_json(text)
        rec = dict(key=it["key"], vid=it["vid"], frames=chosen, geos=geos, usage=budget.usage_dict(msg.usage),
                   usd=round(usd, 6), stop_reason=msg.stop_reason, n_in_est=n_in, raw_text=text, parsed=parsed,
                   zoom=parse_response(parsed, geos), effort=EFFORT, model=MODEL,
                   ts=time.strftime("%Y-%m-%dT%H:%M:%S"))
        (RESP / f"{it['key']}.json").write_text(json.dumps(rec, indent=1))
        print(f"[{i}/{len(todo)}] {it['key']}: {msg.stop_reason} ${usd:.4f} in {rec['usage']['input_tokens']} "
              f"(est {n_in}) out {rec['usage']['output_tokens']} zoomed {len(rec['zoom'])}/{len(chosen)}", flush=True)
    print(f"pilot spend ${pilot_spend():.3f}; committed ${budget.committed():.2f} of cap ${budget.cap():.2f}")


def main():
    ap = argparse.ArgumentParser()
    sp = ap.add_subparsers(dest="cmd", required=True)
    sp.add_parser("items")
    r = sp.add_parser("run")
    r.add_argument("--limit", type=int, default=0)
    r.add_argument("--vids", default="")
    r.add_argument("--max-pilot-usd", type=float, default=5.5)
    r.add_argument("--save-images", action="store_true")
    r.add_argument("--items", default="items.json", help="items.json (twin pilot) or items_val.json (zoom_val.py)")
    sp.add_parser("eval")
    args = ap.parse_args()
    if args.cmd == "items":
        cmd_items(args)
    elif args.cmd == "run":
        cmd_run(args)
    else:
        import zoom_eval
        zoom_eval.main()


if __name__ == "__main__":
    main()
