"""Offline comparison of the zoom pilot: original Claude extents (cached test run, 854-px view) vs zoomed
extents vs the segmented-twin mask reference (zoom.refs). Writes eval_frames.csv / eval_objects.csv and
returns the summary dict used by report.json."""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import zoom  # noqa: E402
from qp.data import load_split  # noqa: E402

HYB_DEG = 8.0
BUCKETS = [(0, 40), (40, 100), (100, 200), (200, 1e9)]   # reference length in annotator (854-px view) px


def length(e) -> float:
    e = np.asarray(e, float)
    return float(np.linalg.norm(e[1] - e[0]))


def angle(e) -> float:
    e = np.asarray(e, float)
    u = e[1] - e[0]
    return math.degrees(math.atan2(u[1], u[0]))


def frame_table() -> pd.DataFrame:
    items = {it["key"]: it for it in zoom.load_items()}
    df = load_split("test")
    paths = dict(zip(df.video_id, df.video_path))
    rows = []
    resp = [p for p in sorted(zoom.RESP.glob("*.json")) if not p.name.startswith("VAL__")]  # twin pilot only
    by_vid: dict[str, list] = {}
    for p in resp:
        r = json.loads(p.read_text())
        by_vid.setdefault(r["vid"], []).append(r)
    for vid, rs in sorted(by_vid.items()):
        need = sorted({int(f) for r in rs for f in r["zoom"]})
        segf = zoom.read_frames(paths[vid + "_segmented"], need)
        for r in rs:
            it = items[r["key"]]
            for f in r["frames"]:
                ob = it["frames"][int(f)]
                z = r["zoom"].get(str(f)) or r["zoom"].get(f)
                ref_o = ob["ref"]
                row = dict(key=r["key"], vid=vid, obj=it["obj"], dim=it["dim"], category=it["category"],
                           prior="prior" in it["roles"], frame=int(f), scale=it["scale"], W=it["W"],
                           stop=r["stop_reason"], usd=r["usd"],
                           claude=length(ob["ext"]), ang_c=angle(ob["ext"]),
                           ref=ref_o["f_min"] if ref_o else np.nan)
                if z is not None:
                    row["zoom"] = length(z["ext"])
                    row["ang_z"] = angle(z["ext"])
                    rz = zoom.refs(segf[int(f)], ob["box"], z["ext"]) if int(f) in segf else None
                    row["ref_z"] = rz["f_min"] if rz else np.nan
                rows.append(row)
    t = pd.DataFrame(rows)
    t["dang"] = ((t.ang_z - t.ang_c + 90) % 180 - 90).abs()
    t["ref_px"] = t.ref * t.scale            # reference length in annotator px
    t["le_c"] = np.log(t.claude / t.ref)
    t["le_z"] = np.log(t.zoom / t.ref)
    t["le_zz"] = np.log(t.zoom / t.ref_z)    # zoom vs the reference along its own direction
    # hybrid rule (no reference used): the zoomed length where its line is within HYB_DEG of the original
    # line's direction, else the original length
    t["hyb"] = np.where(t.dang <= HYB_DEG, t.zoom, t.claude)
    t["le_h"] = np.log(t.hyb / t.ref)
    return t


def stats(le: pd.Series) -> dict:
    le = le.dropna()
    if not len(le):
        return dict(n=0)
    return dict(n=int(len(le)), within5=round(float((le.abs() < math.log(1.05)).mean()), 3),
                within10=round(float((le.abs() < math.log(1.10)).mean()), 3),
                med_abs_log=round(float(le.abs().median()), 4), med_log=round(float(le.median()), 4),
                mean_mra_proxy=round(float(mra_of_log(le).mean()), 4))


def mra_of_log(le) -> np.ndarray:
    """MRA item score of an answer whose only error is this log scale error."""
    r = np.abs(np.exp(np.asarray(le, float)) - 1)
    th = np.array([.1, .2, .3, .4, .5, .6, .7, .8, .9, .95])
    return (r[:, None] < 1 - th[None, :]).mean(axis=1)


def compare(t: pd.DataFrame, label: str) -> dict:
    out = {"all": dict(original=stats(t.le_c), zoom=stats(t.le_z), hybrid=stats(t.le_h),
                       zoom_vs_ref_along_own_direction=stats(t.le_zz))}
    for lo, hi in BUCKETS:
        s = t[(t.ref_px >= lo) & (t.ref_px < hi)]
        out[f"ref {lo:g}-{hi:g} annot px" if hi < 1e8 else f"ref >= {lo:g} annot px"] = dict(
            original=stats(s.le_c), zoom=stats(s.le_z), hybrid=stats(s.le_h))
    return out


def object_table(t: pd.DataFrame) -> pd.DataFrame:
    g = t.dropna(subset=["ref", "zoom"]).groupby("key")
    o = g.agg(vid=("vid", "first"), category=("category", "first"), prior=("prior", "first"), dim=("dim", "first"),
              claude=("claude", "median"), zoom=("zoom", "median"), hyb=("hyb", "median"), ref=("ref", "median"),
              ref_px=("ref_px", "median"), n=("frame", "size"))
    o["le_c"] = np.log(o.claude / o.ref)
    o["le_z"] = np.log(o.zoom / o.ref)
    o["le_h"] = np.log(o.hyb / o.ref)
    return o


def summarize(t: pd.DataFrame) -> dict:
    ok = t.dropna(subset=["ref", "zoom"])
    # reference failures: both measurements agree (within 10%) but sit > 40% from the mask reference
    bad = (np.abs(np.log(ok.zoom / ok.claude)) < math.log(1.1)) & (np.abs(ok.le_c) > math.log(1.4))
    clean = ok[~bad]
    o = object_table(clean)
    return dict(
        n_objects_sent=int(t.key.nunique()), n_frames_sent=int(len(t)),
        n_frames_zoomed=int(t.zoom.notna().sum()), n_frames_compared=int(len(ok)),
        n_frames_reference_failure=int(bad.sum()),
        frames_all=compare(ok, "all"), frames_clean=compare(clean, "clean"),
        objects_clean=dict(original=stats(o.le_c), zoom=stats(o.le_z), hybrid=stats(o.le_h),
                           by_bucket={f"{lo:g}-{hi:g}": {m: stats(o[(o.ref_px >= lo) & (o.ref_px < hi)][c])
                                                         for m, c in (("original", "le_c"), ("zoom", "le_z"), ("hybrid", "le_h"))}
                                      for lo, hi in BUCKETS},
                           priors={m: stats(o[o.prior][c]) for m, c in (("original", "le_c"), ("zoom", "le_z"), ("hybrid", "le_h"))},
                           targets={m: stats(o[~o.prior][c]) for m, c in (("original", "le_c"), ("zoom", "le_z"), ("hybrid", "le_h"))}),
        direction_change_gt8deg=dict(frames=int((ok.dang > 8).sum()), objects=int(ok[ok.dang > 8].key.nunique())),
    )


def main():
    t = frame_table()
    t.to_csv(zoom.OUT / "eval_frames.csv", index=False)
    s = summarize(t)
    object_table(t.dropna(subset=["ref", "zoom"])).to_csv(zoom.OUT / "eval_objects.csv")
    print(json.dumps(s, indent=1))
    return t, s


if __name__ == "__main__":
    main()
