"""Expected test effect of replacing Claude's whole-frame extents by zoomed ones (pilot-based model).

A 2D answer is prior_value x target_px / prior_px, so a log error d on a measured size object moves the
answer's log error by +-d. Model: an affected answer's other error x (everything except this object's
measurement) is drawn from a Laplace distribution whose scale b is calibrated so that
E[MRA(x + e_orig)] equals the category's current mean item score; the paired pilot objects then give
delta = E[MRA(x + e_zoom)] - E[MRA(x + e_orig)] (objects reweighted to the test's size-bucket mix,
bootstrap over objects for the interval). The category delta is n_affected / N_category x delta.
"""
from __future__ import annotations

import math

import numpy as np
import pandas as pd

TH = np.array([.1, .2, .3, .4, .5, .6, .7, .8, .9, .95])
BINS = [0, 40, 100, 200, 1e9]


def mra(le: np.ndarray) -> np.ndarray:
    r = np.abs(np.exp(le) - 1)
    return (r[..., None] < 1 - TH).mean(axis=-1)


def calibrate(e_orig: np.ndarray, w: np.ndarray, target: float, rng) -> float:
    z = rng.laplace(size=4000)
    lo, hi = 1e-4, 3.0
    for _ in range(50):
        b = math.sqrt(lo * hi)
        s = float((mra(b * z[:, None] + e_orig[None, :]) * w[None, :]).sum(axis=1).mean())
        lo, hi = (b, hi) if s > target else (lo, b)
    return b


def effect(objs: pd.DataFrame, test_px: pd.Series, current: float, n_aff: int, n_cat: int,
           sign: int = 1, n_boot: int = 300, seed: int = 0) -> dict:
    """objs: pilot objects with le_c, le_z, ref_px; test_px: affected answers' object size (annot px)."""
    rng = np.random.default_rng(seed)
    objs = objs.dropna(subset=["le_c", "le_z", "ref_px"]).copy()
    objs["b"] = pd.cut(objs.ref_px, BINS, right=False, labels=False)
    tb = pd.cut(test_px.dropna(), BINS, right=False, labels=False).value_counts(normalize=True)
    pb = objs.b.value_counts()
    objs["w"] = objs.b.map(lambda k: tb.get(k, 0.0) / pb[k])
    if objs.w.sum() == 0:
        return {}
    w = (objs.w / objs.w.sum()).to_numpy()
    ec, ez = sign * objs.le_c.to_numpy(), sign * objs.le_z.to_numpy()
    b = calibrate(ec, w, current, rng)
    z = b * rng.laplace(size=4000)

    def delta(idx):
        ww = w[idx] / w[idx].sum()
        return float(((mra(z[:, None] + ez[None, idx]) - mra(z[:, None] + ec[None, idx])) * ww[None, :]).sum(axis=1).mean())

    d = delta(np.arange(len(objs)))
    boots = [delta(rng.integers(0, len(objs), len(objs))) for _ in range(n_boot)]
    lo, hi = np.percentile(boots, [5, 95])
    return dict(n_pilot_objects=int(len(objs)), laplace_b=round(b, 4), per_answer_delta=round(d, 4),
                per_answer_delta_90ci=[round(float(lo), 4), round(float(hi), 4)], n_affected=int(n_aff),
                category_delta=round(d * n_aff / n_cat, 4),
                category_delta_90ci=[round(float(lo) * n_aff / n_cat, 4), round(float(hi) * n_aff / n_cat, 4)])
