"""Draw zoom extents (green) and original Claude extents (red) on the crops of an object (offline)."""
import sys, json, cv2, numpy as np
import zoom
from qp.data import load_split
paths = dict(zip(*[load_split("test")[c] for c in ("video_id", "video_path")]))
items = {it["key"]: it for it in zoom.load_items()}
for key in sys.argv[1:]:
    r = json.loads((zoom.RESP / f"{key}.json").read_text()); it = items[key]
    fr = zoom.read_frames(paths[it["vid"]], r["frames"])
    tiles = []
    for g in r["geos"]:
        f = g["frame"]; im = fr[f][g["y0"]:g["y1"], g["x0"]:g["x1"]]
        c = cv2.resize(im, (g["ow"], g["oh"]), interpolation=cv2.INTER_CUBIC if g["sx"] > 1 else cv2.INTER_AREA)
        P = lambda p: (int(round((p[0] - g["x0"]) * g["sx"])), int(round((p[1] - g["y0"]) * g["sy"])))
        e = it["frames"][f]["ext"]; cv2.line(c, P(e[0]), P(e[1]), (0, 0, 255), 2)
        z = r["zoom"].get(str(f))
        if z: cv2.line(c, P(z["ext"][0]), P(z["ext"][1]), (0, 255, 0), 2)
        tiles.append(cv2.resize(c, (int(c.shape[1] * 400 / c.shape[0]), 400)))
    cv2.imwrite(str(zoom.OUT / "img" / f"viz_{key}.jpg"), np.hstack(tiles))
