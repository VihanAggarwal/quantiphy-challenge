"""Build report.json: pilot comparison (zoom_eval) + test-impact model (zoom_impact) + spend."""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import zoom  # noqa: E402
import zoom_eval  # noqa: E402
import zoom_impact  # noqa: E402
from qp import budget  # noqa: E402

N_CAT = {"S2": 579, "D2": 1163}
CURRENT = {"S2_all": 0.813, "S2_static": 0.845, "D2_static": 0.80}   # probe-5 S2; diag subsets (v3)


def consistency(t: pd.DataFrame) -> dict:
    """Reference-free precision: within-object spread (std over its frames) of log length, for the
    original and the zoomed extents, on objects with >= 3 compared frames."""
    ok = t.dropna(subset=["zoom"])
    g = ok.groupby("key")
    s = pd.DataFrame({"n": g.size(), "sd_c": g.claude.apply(lambda x: np.log(x).std(ddof=1)),
                      "sd_z": g.zoom.apply(lambda x: np.log(x).std(ddof=1)),
                      "sd_ref": g.ref.apply(lambda x: np.log(x.dropna()).std(ddof=1) if x.notna().sum() >= 2 else np.nan)})
    s = s[s.n >= 3]
    return dict(n_objects=int(len(s)), median_sd_log_original=round(float(s.sd_c.median()), 4),
                median_sd_log_zoom=round(float(s.sd_z.median()), 4),
                median_sd_log_reference=round(float(s.sd_ref.median()), 4),
                share_objects_zoom_more_consistent=round(float((s.sd_z < s.sd_c).mean()), 3))


def main():
    t, summ = zoom_eval.main()
    ok = t.dropna(subset=["ref", "zoom"])
    bad = (np.abs(np.log(ok.zoom / ok.claude)) < math.log(1.1)) & (np.abs(ok.le_c) > math.log(1.4))
    o = zoom_eval.object_table(ok[~bad])
    test = pd.read_pickle(zoom.OUT / "test_s2d2.pkl")
    s2p = test[(test.cat == "S2") & (test.pk == "size")]
    s2t = test[(test.cat == "S2") & (test.tk == "size")]
    d2t = test[(test.cat == "D2") & (test.tk == "size")]
    oh = o.assign(le_z=o.le_h)   # hybrid in the impact model
    imp = {
        "S2_prior_rescale_all_sources": zoom_impact.effect(o, s2p.ppx, CURRENT["S2_all"], len(s2p), N_CAT["S2"], sign=-1),
        "S2_prior_rescale_simulation_only": zoom_impact.effect(
            o, s2p[s2p.src == "simulation"].ppx, CURRENT["S2_all"], int((s2p.src == "simulation").sum()), N_CAT["S2"], sign=-1),
        "S2_size_targets_all_sources": zoom_impact.effect(o, s2t.tpx, CURRENT["S2_static"], len(s2t), N_CAT["S2"], sign=1),
        "D2_size_targets_all_sources": zoom_impact.effect(o, d2t.tpx, CURRENT["D2_static"], len(d2t), N_CAT["D2"], sign=1),
        "D2_size_targets_simulation_only": zoom_impact.effect(
            o, d2t[d2t.src == "simulation"].tpx, CURRENT["D2_static"], int((d2t.src == "simulation").sum()), N_CAT["D2"], sign=1),
    }
    imp = {"zoom_only": imp, "hybrid": {
        "S2_prior_rescale_all_sources": zoom_impact.effect(oh, s2p.ppx, CURRENT["S2_all"], len(s2p), N_CAT["S2"], sign=-1),
        "S2_size_targets_all_sources": zoom_impact.effect(oh, s2t.tpx, CURRENT["S2_static"], len(s2t), N_CAT["S2"], sign=1),
        "D2_size_targets_all_sources": zoom_impact.effect(oh, d2t.tpx, CURRENT["D2_static"], len(d2t), N_CAT["D2"], sign=1),
        "D2_size_targets_simulation_only": zoom_impact.effect(
            oh, d2t[d2t.src == "simulation"].tpx, CURRENT["D2_static"], int((d2t.src == "simulation").sum()), N_CAT["D2"], sign=1),
    }}
    spend = [e for e in budget.entries() if e.get("type", "usage") == "usage" and e.get("run") == zoom.RUN]
    resp = [json.loads(p.read_text()) for p in sorted(zoom.RESP.glob("*.json"))]  # twin pilot + val-mapped objects
    usd = [r["usd"] for r in resp]
    report = dict(
        pilot=summ, consistency=consistency(t), impact_model=imp,
        cost=dict(n_requests=len(spend), pilot_usd=round(sum(float(e["usd"]) for e in spend), 4),
                  usd_per_object_median=round(float(np.median(usd)), 4), usd_per_object_mean=round(float(np.mean(usd)), 4),
                  n_max_tokens=int(sum(r["stop_reason"] == "max_tokens" for r in resp)),
                  ledger_total_usd=round(budget.spent(), 4)),
    )
    (zoom.OUT / "report_numbers.json").write_text(json.dumps(report, indent=1))
    print(json.dumps({k: report[k] for k in ("consistency", "impact_model", "cost")}, indent=1))
    return report


if __name__ == "__main__":
    main()
